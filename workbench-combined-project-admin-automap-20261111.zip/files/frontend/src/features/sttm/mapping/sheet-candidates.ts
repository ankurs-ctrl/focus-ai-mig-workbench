import { rowMappingStatus } from '../shared/row-validation-state';
import type { AutoMapCandidate } from '@/types/api-contract';
import type { MappingState, MappingRuleType } from '../types/sttm.types';

export const DRAFT_SCORING_POLICY = 'draft-caps-v1';

/** Historical AI evidence is display-only; authored definitions are not AI receipts. */
export function candidatePolicyCompatible(candidate: AutoMapCandidate): boolean {
  return candidate.scoring_policy_version === DRAFT_SCORING_POLICY
    || (candidate.origin === 'manual' && candidate.previously_applied === true);
}

/** Do not turn the legacy numeric fallback for an unknown score into confidence. */
export function candidateConfidence(candidate: AutoMapCandidate): number | null {
  if (candidate.confidence_policy_version === 'evidence-v1') return candidate.confidence_score;
  return candidate.adjusted_confidence_score !== undefined ? candidate.adjusted_confidence_score
    : candidate.original_confidence_score === null ? null : candidate.confidence_score;
}

export type CandidateValidationFailure = {reason: string; category: 'source' | 'sql' | 'value' | 'validation'};

function validationReason(issues: NonNullable<AutoMapCandidate['scoring_issues']>): string {
  const categories = new Set(issues.filter(issue => issue.code.startsWith('recheck_')).map(issue => issue.category));
  return categories.has('value') ? 'Confidence is limited because a required project Value is missing or does not match.'
    : categories.has('source') ? 'Confidence is limited because a required source is not available.'
    : categories.has('sql') ? 'Confidence is limited because the proposed rule did not pass its checks.'
    : categories.has('validation') ? 'Confidence is limited because the required checks could not be completed.' : '';
}

/** One refresh for both outcomes; only successful checks can remove prior blockers. */
export function refreshCandidateValidation(candidate: AutoMapCandidate, failure?: CandidateValidationFailure): AutoMapCandidate {
  const rechecked = (issue: NonNullable<AutoMapCandidate['scoring_issues']>[number]) =>
    !issue.code.startsWith('capture_') && issue.code !== 'malformed_field'
    && (['source', 'sql', 'value'].includes(issue.category)
      || ['explain_unavailable', 'graph_unavailable', 'validation_unavailable'].includes(issue.code)
      || issue.code.startsWith('recheck_'));
  const previousIssues = candidate.scoring_issues ?? [];
  // An unavailable retry cannot disprove an earlier known failure.
  const retained = previousIssues.filter(issue => !rechecked(issue) || Boolean(failure &&
    !(issue.code.startsWith('recheck_') && issue.category === 'validation' && failure.category !== 'validation')));
  const issues = [...retained];
  if (failure) issues.push({code: `recheck_${failure.category}`, category: failure.category, severity: 'error', message: failure.reason});
  const unique = [...new Map(issues.map(issue => [JSON.stringify([issue.category, issue.code, issue.message]), issue])).values()];
  const resolved = new Set([...(candidate.validation_errors ?? []), ...previousIssues.filter(rechecked).map(issue => issue.message)]);
  const errors = unique.filter(issue => issue.severity === 'error' && ['source', 'sql', 'value'].includes(issue.category)).map(issue => issue.message);
  const oldReason = validationReason(previousIssues);
  const baseReason = oldReason && candidate.confidence_reason?.endsWith(oldReason)
    ? candidate.confidence_reason.slice(0, -oldReason.length).trimEnd() : candidate.confidence_reason;
  const reason = validationReason(unique);
  const updated: AutoMapCandidate = {...candidate, scoring_issues: unique, validation_errors: [...new Set(errors)],
    confidence_reason: reason ? [baseReason, reason].filter(Boolean).join(' ') : baseReason || null,
    warnings: (candidate.warnings ?? []).filter(message => !resolved.has(message) || unique.some(issue => issue.message === message)),
    validation_status: errors.length ? 'invalid' : unique.some(issue => issue.severity === 'error') ? 'unvalidated' : 'valid'};
  if (candidate.scoring_policy_version === DRAFT_SCORING_POLICY) {
    const cap = Math.min(1, ...unique.map(issue => ['source', 'sql', 'value'].includes(issue.category) && issue.severity === 'error'
      ? .49 : issue.category === 'validation' || issue.severity === 'error' ? .69 : .79));
    if (candidate.confidence_policy_version === 'evidence-v1') {
      const provenance = candidate.confidence_provenance ?? {};
      const base = provenance.score_source === 'model_with_backend_caps' ? provenance.model_score : provenance.evidence_estimate;
      const score = typeof base === 'number' && Number.isFinite(base) ? base : candidate.confidence_score ?? 0;
      updated.adjusted_confidence_score = Math.min(score, cap);
      updated.confidence_score = updated.adjusted_confidence_score;
      updated.confidence_provenance = {...provenance, cap};
    } else {
      updated.adjusted_confidence_score = candidate.original_confidence_score == null ? null : Math.min(candidate.original_confidence_score, cap);
      updated.confidence_score = updated.adjusted_confidence_score ?? 0;
    }
  }
  return updated;
}

/** A complete option, never a names-only alternative with an invented score. */
export function rankedRowCandidates(values: AutoMapCandidate[]): AutoMapCandidate[] {
  const seen = new Set<string>();
  return values.filter(value => {
    if (!value || !value.candidate_id || seen.has(value.candidate_id)
      || !Array.isArray(value.source_attributes) || value.source_attributes.some(source => typeof source !== 'string')
      || [value.confidence_score, value.original_confidence_score, value.adjusted_confidence_score]
        .some(score => score != null && (!Number.isFinite(score) || score < 0 || score > 1))) return false;
    seen.add(value.candidate_id);
    return true;
  }).sort((a, b) => (candidateConfidence(b) ?? -1) - (candidateConfidence(a) ?? -1)).slice(0, 4);
}

export function candidateRowUpdates(candidate: AutoMapCandidate): Partial<MappingState> {
  const mode = candidate.mapping_mode ?? 'source';
  const value = mode === 'constant' || mode === 'attribute';
  const rule = value ? 'Value' : candidate.preprocessing_rule_type || (candidate.preprocessing_rule ? 'Custom' : 'Direct');
  const updates: Partial<MappingState> = {
    sourceColumns: [...candidate.source_attributes],
    sourceColumn: candidate.source_attributes.join(', ') || null,
    sourceType: null,
    mappingMode: mode, constantValue: candidate.constant_value ?? null,
    attributeName: candidate.attribute_name ?? null,
    rule: rule as MappingRuleType,
    // Preserve a proposed expression even when its invalid rule label says Direct.
    expression: /^(DIRECT|IDENTITY)$/i.test(candidate.preprocessing_rule?.trim() ?? '') ? null : candidate.preprocessing_rule ?? null,
    nlRule: candidate.preprocessing_nl_rule ?? null,
    sourceDependencies: [...(candidate.source_dependencies ?? candidate.source_attributes)],
    valueBindingIds: [...(candidate.value_binding_ids ?? [])],
    transformationClassification: candidate.transformation_classification ?? null,
    confidenceScore: candidateConfidence(candidate), confidenceReason: candidate.confidence_reason ?? null,
    draftIssues: candidate.scoring_issues ?? [],
    unmatchedReason: candidate.validation_errors?.join(' ') || candidate.scoring_issues?.map(issue => issue.message).join(' ') || candidate.unmatched_reason || null,
    aiSuggestedRule: candidate.preprocessing_rule ?? null, aiSuggestedRuleType: rule,
    usedInferenceIds: candidate.used_inference_ids ?? [], usedRecommendationIds: candidate.used_recommendation_ids ?? [],
    usedLearningIds: candidate.used_learning_ids ?? [],
    precedentDecision: candidate.precedent_decision ?? null, precedentMappingId: candidate.precedent_mapping_id ?? null,
    overrideEvidence: candidate.override_evidence ?? [],
    status: 'UNMAPPED',
    validation: null,
    manuallySaved: false, manuallyEditedAfterAutoMap: false, learningOrigin: null,
    selectedAiCandidateId: candidate.candidate_id, aiReviewStatus: 'unreviewed',
  };
  updates.status = rowMappingStatus(updates);
  return updates;
}

export function candidateMatchesRow(row: MappingState, candidate: AutoMapCandidate): boolean {
  const proposed = candidateRowUpdates(candidate);
  return ['sourceColumns', 'mappingMode', 'constantValue', 'attributeName', 'rule', 'expression', 'sourceDependencies', 'valueBindingIds']
    .every(key => JSON.stringify(row[key as keyof MappingState] ?? null) === JSON.stringify(proposed[key as keyof MappingState] ?? null));
}

export function aiUndoSnapshot(row: MappingState): Partial<MappingState> {
  // No recursive history. Persist the previous draft definition, including its review state.
  const { aiUndoSnapshot: _history, ...snapshot } = row;
  void _history;
  return {
    sourceColumns: [], sourceColumn: null, sourceType: null, mappingMode: 'source', constantValue: null,
    attributeName: null, expression: null, nlRule: null, sourceDependencies: [], valueBindingIds: [],
    transformationClassification: null, confidenceScore: null, confidenceReason: null, unmatchedReason: null,
    aiSuggestedRule: null, aiSuggestedRuleType: null, usedInferenceIds: [], usedRecommendationIds: [],
    usedLearningIds: [], precedentDecision: null, precedentMappingId: null, overrideEvidence: [],
    manuallySaved: false, manuallyEditedAfterAutoMap: false, learningOrigin: null,
    selectedAiCandidateId: null, aiReviewStatus: null, validation: null,
    ...JSON.parse(JSON.stringify(snapshot)),
  } as Partial<MappingState>;
}
