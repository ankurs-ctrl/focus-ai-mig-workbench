"""Bind uploaded CTE definitions by SQL scope, independent of incoming hashes."""
from sqlglot import exp
from sqlglot.optimizer.normalize_identifiers import normalize_identifiers
from sqlglot.optimizer.scope import Scope, build_scope

from app.core.automap_deterministic import _equivalent, _identifier, _key, _one, _query_output_identifiers
from app.core.automap_retrieval import digest


def _scoped(sql):
    tree = normalize_identifiers(_one(sql), dialect="snowflake")
    root = build_scope(tree)
    if root is None:
        raise ValueError("Selected CTE has no query scope")
    with_clause = tree.args.get("with") or tree.args.get("with_")
    scopes = {id(scope.expression): scope for scope in root.traverse()}
    definitions = {}
    for cte in with_clause.expressions if with_clause else []:
        name = _key(cte.args["alias"].this)
        if name in definitions:
            raise ValueError("Selected CTE has ambiguous definitions")
        definitions[name] = scopes[id(cte.this)]
    return tree, root, definitions


def _wrapper(tree):
    """Only a plain full-output SELECT is a wrapper; filters are definitions."""
    if not isinstance(tree, exp.Select) or len(tree.expressions) != 1:
        return None
    if not isinstance(tree.expressions[0], exp.Star) or any(tree.expressions[0].args.values()):
        return None
    permitted = {"expressions", "from", "from_", "with", "with_"}
    if any(value for key, value in tree.args.items() if key not in permitted):
        return None
    source = tree.args.get("from") or tree.args.get("from_")
    table = source.this if source else None
    if not isinstance(table, exp.Table) or table.db or table.catalog:
        return None
    # A table expression can change rows (SAMPLE, time travel, pivots) or
    # outputs (positional aliases) even when its SELECT has no modifiers.
    if any(value for key, value in source.args.items() if key != "this"):
        return None
    if any(value for key, value in table.args.items() if key not in {"this", "alias"}):
        return None
    alias = table.args.get("alias")
    if alias is not None and any(value for key, value in alias.args.items() if key != "this"):
        return None
    return table


def _reachable(scope):
    pending, seen, result = [scope], set(), []
    while pending:
        current = pending.pop()
        if id(current) in seen:
            continue
        seen.add(id(current))
        result.append(current)
        pending.extend(source for _table, source in current.selected_sources.values() if isinstance(source, Scope))
        pending.extend(current.subquery_scopes + current.union_scopes + current.table_scopes)
    return result


def _require_supported(scope):
    for current in _reachable(scope):
        owner = current.expression.parent
        if isinstance(owner, exp.CTE) and owner.args["alias"].args.get("columns"):
            raise ValueError("Selected CTE dependency has unsupported positional output aliases")


_BINDING_NODE = "automap_binding_node"


def _binding_manifest(root, active):
    """Fingerprint source identities by stable AST location, never SQL names alone."""
    bindings = {}
    for scope in root.traverse():
        owner = scope.expression.meta[_BINDING_NODE]
        if owner not in active:
            continue
        for alias, (_table, source) in scope.selected_sources.items():
            identity = (("scope", source.expression.meta[_BINDING_NODE]) if isinstance(source, Scope)
                        else ("physical", source.sql(dialect="snowflake")))
            bindings[(owner, alias)] = identity
    return bindings


def _verify_rebinding(root, aliases, active, before):
    # The compiler emits graph CTEs under their runtime names. Rebuild that
    # namespace on a copy; retaining old Scope objects would hide name capture.
    tree = root.expression.copy()
    with_clause = tree.args.get("with") or tree.args.get("with_")
    retained = []
    for cte in with_clause.expressions:
        name = _key(cte.args["alias"].this)
        if name in aliases:
            cte.args["alias"].set("this", _identifier(aliases[name]))
            retained.append(cte)
    with_clause.set("expressions", retained)
    rebound = build_scope(normalize_identifiers(tree, dialect="snowflake"))
    if rebound is None or _binding_manifest(rebound, active) != before:
        raise ValueError("CTE runtime rewrite changes relation bindings")


def _rebind(root, definitions, aliases):
    """Prove that runtime names cannot capture or redirect authored bindings."""
    identities = {id(scope): name for name, scope in definitions.items()}
    runtime_names = {_key(_identifier(alias)) for alias in aliases.values()}
    if len(runtime_names) != len(aliases):
        raise ValueError("CTE runtime aliases are ambiguous")
    # Only emitted definitions and their reachable scopes participate. Unused
    # authored CTEs are not new graph dependencies or reasons to block a source.
    active_scopes = {id(scope): scope for name in aliases for scope in _reachable(definitions[name])}
    for index, node in enumerate(root.expression.walk()):
        node.meta[_BINDING_NODE] = index
    active = {scope.expression.meta[_BINDING_NODE] for scope in active_scopes.values()}
    before = _binding_manifest(root, active)
    edits = []
    changed_names = {_key(_identifier(alias)) for name, alias in aliases.items()
                     if _key(_identifier(alias)) != name}
    for scope in active_scopes.values():
        for table, source in scope.selected_sources.values():
            name = identities.get(id(source)) if isinstance(source, Scope) else None
            if name is not None and name not in aliases:
                raise ValueError("Selected CTE dependency has no graph runtime binding")
            if (isinstance(source, exp.Table) and not source.db and not source.catalog
                    and isinstance(source.this, exp.Identifier) and _key(source.this) in changed_names):
                raise ValueError("CTE runtime alias collides with a physical source binding")
            if name not in aliases or not isinstance(table, exp.Table):
                continue
            runtime_name = _key(_identifier(aliases[name]))
            captured = scope.cte_sources.get(runtime_name)
            if captured is not None and id(captured) not in identities:
                raise ValueError("CTE runtime alias collides with a nested CTE binding")
            edits.append((table, aliases[name]))
    for table, alias in edits:
        # FROM p becomes FROM runtime_p AS p. Explicit aliases and their
        # bound column references remain intact, including quoted names.
        if not table.args.get("alias"):
            table.set("alias", exp.TableAlias(this=table.this.copy()))
        table.set("this", _identifier(alias))
    _verify_rebinding(root, aliases, active, before)


def hydrate_authored_cte_graph(req):
    graph, workspace = req.context.relation_graph, req.context.workspace_context
    if graph is None or workspace is None:
        return req
    named = [node for node in graph.nodes
             if node.kind.value == "DERIVED_SOURCE" and node.original_cte_name]
    if not named:
        return req
    sql = workspace.mapping_sql or workspace.raw_mapping_sql
    if not sql:
        raise ValueError("Current authored SQL is absent for uploaded CTEs")
    if workspace.mapping_sql and workspace.raw_mapping_sql and workspace.mapping_sql != workspace.raw_mapping_sql:
        raise ValueError("Current authored SQL conflicts with the CTE graph")
    _tree, root, definitions = _scoped(sql)
    aliases = {_key(_identifier(node.original_cte_name)): node.alias for node in named}
    if len(aliases) != len(named):
        raise ValueError("Selected CTE names are ambiguous")
    if not set(aliases) <= definitions.keys():
        raise ValueError("A selected CTE is missing from the current authored SQL")
    for name in aliases:
        _require_supported(definitions[name])
    # Capture the authored dependency bodies before changing their table names.
    original_bodies = {name: scope.expression.copy() for name, scope in definitions.items()}
    _rebind(root, definitions, aliases)
    updated = []
    for node in graph.nodes:
        if node not in named:
            updated.append(node)
            continue
        name = _key(_identifier(node.original_cte_name))
        expected = definitions[name].expression
        identifiers = _query_output_identifiers(original_bodies[name])
        from app.core.automap_output_identifiers import bind_output_columns
        if not node.output_columns:
            raise ValueError("Selected CTE outputs differ from current authored SQL")
        output_columns = bind_output_columns(node.output_columns, identifiers)
        actual_tree, actual_root, actual_defs = _scoped(node.sql_text or "")
        wrapper = _wrapper(actual_tree)
        if wrapper is not None:
            source_name = _key(wrapper.this)
            if source_name != name:
                raise ValueError("Selected CTE wrapper refers to a different definition")
            if actual_defs:
                selected = actual_root.selected_sources.get(wrapper.alias_or_name)
                actual_scope = selected[1] if selected else None
                if not isinstance(actual_scope, Scope) or actual_scope is not actual_defs.get(name):
                    raise ValueError("Selected CTE wrapper is not bound to its definition")
                _require_supported(actual_scope)
                relevant = {id(actual_scope), *(id(scope) for scope in _reachable(actual_scope))}
                for dependency, scope in actual_defs.items():
                    if id(scope) in relevant and (dependency not in original_bodies
                            or not _equivalent(scope.expression, original_bodies[dependency])):
                        raise ValueError("Selected CTE body or dependency differs from current authored SQL")
            # A bare frontend name wrapper resolves only in this authored scope.
        elif not (_equivalent(actual_tree, expected) or _equivalent(actual_tree, original_bodies[name])):
            # Hashes are never a substitute for this comparison of actual SQL.
            raise ValueError("Selected CTE body differs from the current authored SQL")
        body_sql = expected.sql(dialect="snowflake")
        current_hash = digest({"sql": body_sql, "parents": node.parent_relation_ids,
                               "authored_sql": digest(sql)})
        updated.append(node.model_copy(update={"sql_text": body_sql, "dependency_hash": current_hash, "output_columns": output_columns}))
    return req.model_copy(update={"context": req.context.model_copy(update={
        "relation_graph": graph.model_copy(update={"nodes": updated})})})
