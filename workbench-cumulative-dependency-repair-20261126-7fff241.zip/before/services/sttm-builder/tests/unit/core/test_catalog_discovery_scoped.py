from types import SimpleNamespace
from threading import RLock
from unittest.mock import Mock
import pytest
from app.agent_tools.catalog_discovery import discover
from app.core.exceptions import DelegatedCredentialsRotated


def workbench(rows=None,error=None):
    session=SimpleNamespace(sql=Mock())
    session.sql.return_value.collect.side_effect=error
    if error is None:session.sql.return_value.collect.return_value=rows or []
    return SimpleNamespace(_settings=SimpleNamespace(snowflake_database='APP_DB'),_domain_lock=RLock(),_session=session)


def test_explicit_names_scope_query_before_collection():
    w=workbench([{'TABLE_CATALOG':'DB','TABLE_SCHEMA':'SC','TABLE_NAME':'ACCOUNTS'}])
    result=discover(w,['DB.SC.ACCOUNTS'],8)
    query=w._session.sql.call_args.args[0];params=w._session.sql.call_args.kwargs['params']
    assert '"DB".INFORMATION_SCHEMA.TABLES' in query and 'TABLE_SCHEMA = ?' in query and 'TABLE_NAME = ?' in query
    assert params==['SC','ACCOUNTS',8] and 'ACCOUNT' not in query
    assert result.status=='succeeded' and result.data['candidates']==['"DB"."SC"."ACCOUNTS"']


def test_current_authorized_schema_is_used_for_natural_language():
    w=workbench();discover(w,['loan income'],8,context={'authorized_schemas':['DATA.LOANS']})
    call=w._session.sql.call_args
    assert '"DATA".INFORMATION_SCHEMA.TABLES' in call.args[0]
    assert call.kwargs['params']==['LOANS','%loan%','%income%',8]


def test_quoted_case_and_schema_relative_name_are_preserved():
    w=workbench();discover(w,['"Mixed.Schema"."CaseTable"'],5,database='"CaseDb"')
    assert '"CaseDb".INFORMATION_SCHEMA' in w._session.sql.call_args.args[0]
    assert w._session.sql.call_args.kwargs['params']==['Mixed.Schema','CaseTable',5]


def test_timeout_is_not_repeated_for_reworded_same_scope_but_exact_lookup_can_proceed():
    error=RuntimeError('private SQL must never escape');error.sql_error_code=630;error.sfqid='query-123'
    w=workbench(error=error)
    first=discover(w,['account'],8,database='DB',schema='SC')
    second=discover(w,['contact'],8,database='DB',schema='SC')
    assert first.error_code==second.error_code=='catalog_timeout'
    assert second.data['diagnostics']=={'native_code':'630','query_id':'query-123'}
    assert w._session.sql.call_count==1 and 'private SQL' not in str(first)
    w._session.sql.return_value.collect.side_effect=None;w._session.sql.return_value.collect.return_value=[]
    assert discover(w,['DB.SC.ACCOUNTS'],8).status=='succeeded'
    assert w._session.sql.call_count==2


def test_same_query_is_cached_and_rotation_is_not_cached():
    w=workbench();discover(w,['SC.ACCOUNTS'],8);discover(w,['SC.ACCOUNTS'],8)
    assert w._session.sql.call_count==2  # One cached schema inventory plus one table query.
    w=workbench(error=DelegatedCredentialsRotated('rotate'))
    with pytest.raises(DelegatedCredentialsRotated):discover(w,['SC.ACCOUNTS'],8)
    assert not getattr(w, "_scoped_catalog_cache", {})


def test_scope_missing_does_not_scan_account():
    w=workbench();w._settings.snowflake_database=None
    assert discover(w,['accounts'],8).error_code=='catalog_scope_required'
    w._session.sql.assert_not_called()


def test_failed_scope_does_not_cross_caller_instances():
    error=RuntimeError('timeout');error.sql_error_code=630
    one=workbench(error=error);two=workbench()
    assert discover(one,['account'],8,database='DB',schema='SC').status=='failed'
    assert discover(two,['account'],8,database='DB',schema='SC').status=='succeeded'


def test_native_diagnostics_survive_wrapper_code_and_keep_query_id():
    from app.agent_tools.catalog_discovery import sql_diagnostics
    cause=RuntimeError('secret statement');cause.errno=630;cause.sfqid='native-id'
    wrapper=RuntimeError('secret bindings');wrapper.errno=1304;wrapper.__cause__=cause
    assert sql_diagnostics(wrapper)=={'native_code':'630','query_id':'native-id'}


def test_declared_schema_boundary_is_enforced_before_sql():
    w=workbench()
    assert discover(w,['OTHER.SCHEMA.TABLE'],8,context={'authorized_schemas':['DB.SC']}).status=='denied'
    w._session.sql.assert_not_called()


def test_quoted_catalog_results_keep_exact_run_authorization():
    from app.agent_tools.capability_registry import CapabilityRegistry
    check=CapabilityRegistry._within_authorized_table_scope
    assert check('"DB"."SC"."ACCOUNTS"',{'authorized_schemas':['DB.SC']})
    assert not check('"DB"."sc"."ACCOUNTS"',{'authorized_schemas':['DB.SC']})
    assert not check('DB.OTHER.ACCOUNTS',{'authorized_schemas':['DB.SC'],'authorized_source_scope':['DB.SC.ACCOUNTS']})


def test_registry_keeps_native_sql_diagnostics_without_statement_text():
    from app.agent_tools.capability_registry import CapabilityRegistry
    from app.agent_runtime.execution import ExecutionBudget
    cause=RuntimeError('secret SQL');cause.errno=630;cause.sfqid='native-query'
    wrapper=RuntimeError('private bindings');wrapper.errno=1304;wrapper.__cause__=cause
    registry=CapabilityRegistry(context_provider=lambda:{},workflow_executor=lambda *a:{},workbench=None,budget=ExecutionBudget(model_limit=5,tool_limit=5))
    def fail():raise wrapper
    result=registry._execute('search_catalog',fail)
    assert result['error_code']=='630'
    assert result['data']['diagnostics']=={'native_code':'630','query_id':'native-query'}
    assert 'secret SQL' not in str(result) and 'private bindings' not in str(result)


def test_schema_shorthand_finds_other_database_without_table_account_scan():
    w=workbench()
    def sql(query,params=None):
        if query.startswith('SHOW SCHEMAS'):
            rows=[{'database_name':'DATA_DB','name':'DW_OPS'}, {'database_name':'DATA_DB','name':'DL_AMOUNT'}, {'database_name':'APP_DB','name':'METADATA'}]
        elif params[0]=='DW_OPS':
            rows=[{'TABLE_CATALOG':'DATA_DB','TABLE_SCHEMA':'DW_OPS','TABLE_NAME':'LOAN_INCOME_AMOUNT_CALCULATION'}]
        else: rows=[]
        return SimpleNamespace(collect=lambda:rows)
    w._session.sql.side_effect=sql
    r=discover(w,['DW.LOAN_INCOME_AMOUNT_CALCULATION'],8)
    assert r.data['candidates']==['"DATA_DB"."DW_OPS"."LOAN_INCOME_AMOUNT_CALCULATION"']
    assert r.data['coverage']['exhaustive'] is False
    assert w._session.sql.call_count==2
    assert not any('TABLES IN ACCOUNT' in c.args[0] for c in w._session.sql.call_args_list)
    discover(w,['DW.LOAN_INCOME_AMOUNT_CALCULATION'],8)
    assert w._session.sql.call_count==2


def test_shared_discovery_bound_includes_empty_and_reworded_batch_searches():
    w=workbench()
    for i in range(30):
        r=discover(w,[f'business name {i}'],8,database='DB',schema='SC')
    assert w._session.sql.call_count==24
    assert r.data['coverage']['discovery_allowance_exhausted']
    assert r.data['coverage']['deferred_scopes']==[{'database':'DB','schema':'SC'}]
    assert not r.data['coverage']['exhaustive']
    # A specific verified identity remains inspectable after broad discovery ends.
    discover(w,['DB.SC.LOAN'],8)
    assert w._session.sql.call_count==25


def test_schema_inventory_never_broadens_declared_run_scope():
    w=workbench()
    discover(w,['loan income'],8,context={'authorized_schemas':['DATA.DW'],'prompt':'DW.loan'})
    assert w._session.sql.call_count==1
    assert 'SHOW SCHEMAS' not in w._session.sql.call_args.args[0]


def test_plural_business_names_find_singular_current_tables():
    w=workbench()
    discover(w,['notes','portal_users'],8,database='DATA',schema='DW')
    calls=w._session.sql.call_args_list
    assert calls[0].kwargs['params']==['DW','%note%',8]
    assert calls[1].kwargs['params']==['DW','%portal%','%user%',8]


def test_unqualified_terms_use_prompt_schema_hints_not_metadata_database():
    w=workbench()
    def sql(query,params=None):
        if query.startswith('SHOW SCHEMAS'):
            rows=[{'database_name':'DATA','name':'DL_AMOUNT'},{'database_name':'DATA','name':'DW_OPS'}]
        else: rows=[]
        return SimpleNamespace(collect=lambda: rows)
    w._session.sql.side_effect=sql
    result=discover(w,['loan income','notes'],8,context={'prompt':'Use DW.LOAN_INCOME with DL loan income and notes'})
    assert {i['schema'] for i in result.data['coverage']['checked_scopes']}=={'DW_OPS','DL_AMOUNT'}
    assert all('APP_DB' not in call.args[0] for call in w._session.sql.call_args_list)


def test_one_failed_scope_preserves_successful_sibling_matches():
    w=workbench()
    def sql(query,params=None):
        if 'BAD_DB' in query:
            error=RuntimeError('private statement');error.sql_error_code=630;raise error
        return SimpleNamespace(collect=lambda:[{'TABLE_CATALOG':'GOOD_DB','TABLE_SCHEMA':'DW','TABLE_NAME':'LOAN'}])
    w._session.sql.side_effect=sql
    r=discover(w,['loan'],8,context={'authorized_schemas':['BAD_DB.DW','GOOD_DB.DW']})
    assert r.status=='succeeded'
    assert r.data['candidates']==['"GOOD_DB"."DW"."LOAN"']
    assert len(r.data['coverage']['failed_scopes'])==1
    assert 'private statement' not in str(r)


def test_contract_identity_preserves_quoted_case_and_dots():
    from app.agent_tools.contract_reader import normalize_fqn, split_fqn
    assert normalize_fqn('"DB"."SC"."LOAN"')=='DB.SC.LOAN'
    assert normalize_fqn('db.sc.loan')=='DB.SC.LOAN'
    assert normalize_fqn('"CaseDb"."Mixed.Schema"."Loan"')=='"CaseDb"."Mixed.Schema"."Loan"'
    assert split_fqn('"CaseDb"."Mixed.Schema"."Loan"')==('CaseDb','Mixed.Schema','Loan')
    with pytest.raises(ValueError): split_fqn('DB.SC.T; DROP TABLE X')


def test_batch_inspection_accepts_equivalent_catalog_identifier_spellings():
    from app.agent_tools.capability_registry import CapabilityRegistry
    from app.agent_runtime.execution import ExecutionBudget
    from app.agent_runs.models import ToolResult
    calls=[]
    def inspect(table):
        calls.append(table)
        return ToolResult(status='succeeded',summary='Verified',data={'columns':['ID']})
    registry=CapabilityRegistry(context_provider=lambda:{},workflow_executor=lambda *a:{},
        workbench=SimpleNamespace(inspect_table_contract=inspect),budget=ExecutionBudget(model_limit=5,tool_limit=10))
    registry._catalog_candidates.add('"DB"."SC"."LOAN"')
    tool=next(t for t in registry.tools() if t.name=='inspect_table_contracts_batch')
    result=tool.invoke({'table_fqns':['DB.SC.LOAN','"DB"."SC"."LOAN"']})
    assert result['status']=='succeeded'
    assert result['data']['contracts'][0]['table']=='DB.SC.LOAN'
    assert calls==['DB.SC.LOAN']


def test_registry_single_and_batch_share_discovery_allowance_even_with_no_matches():
    from app.agent_tools.capability_registry import CapabilityRegistry
    from app.agent_runtime.execution import ExecutionBudget
    from app.agent_runs.models import ToolResult
    batch=Mock(return_value=ToolResult(status='succeeded',summary='No matches in checked scope',data={'candidates':[]}))
    one=Mock(return_value=ToolResult(status='succeeded',summary='No matches in checked scope',data={'candidates':[]}))
    registry=CapabilityRegistry(context_provider=lambda:{},workflow_executor=lambda *a:{},
        workbench=SimpleNamespace(search_catalog_batch=batch,search_catalog=one),budget=ExecutionBudget(model_limit=5,tool_limit=10))
    registry._search_catalog('loan',8)
    tool=next(t for t in registry.tools() if t.name=='search_catalog_batch')
    tool.invoke({'search_terms':['income']})
    result=tool.invoke({'search_terms':['unrelated']})
    assert result['data']['discovery_allowance_exhausted']
    assert batch.call_count==one.call_count==1
    tool.invoke({'search_terms':['DB.SC.LOAN']})
    assert batch.call_count==2


@pytest.mark.parametrize('prompt,requires_workflow',[
    ('Find and inspect Loan Income. This is read-only: do not create a project, mapping or migration plan.',False),
    ('Use read-only source access and create a draft mapping.',True),
    ('Read-only research; do not publish, but create the draft mapping.',True),
    ('Create the Loan Income mapping using previous learnings.',True),
])
def test_read_only_discovery_does_not_force_unrequested_migration_checkpoint(prompt,requires_workflow):
    from app.agent_runtime.deepagents_runtime import _migration_workflow_required
    invocation=SimpleNamespace(prompt=prompt,workflow_input={'intent':'NEW_MIGRATION_TASK','page_context':{}})
    assert _migration_workflow_required(invocation,SimpleNamespace()) is requires_workflow


@pytest.mark.parametrize('tool_name',['read_stored_semantic_context','sql_analyst'])
def test_semantics_and_analyst_accept_exact_quoted_discovered_names(tool_name):
    from app.agent_tools.capability_registry import CapabilityRegistry
    from app.agent_runtime.execution import ExecutionBudget
    from app.agent_runs.models import ToolResult
    workbench=SimpleNamespace()
    workbench.read_stored_semantic_context=Mock(return_value=ToolResult(status='succeeded',summary='Read stored semantics'))
    workbench.ask_sql_analyst=Mock(return_value=ToolResult(status='succeeded',summary='Analyst answered'))
    registry=CapabilityRegistry(context_provider=lambda:{},workflow_executor=lambda *a:{},workbench=workbench,
        budget=ExecutionBudget(model_limit=5,tool_limit=10))
    registry._catalog_candidates.update(['DB.SC.LOAN','"CaseDb"."Mixed.Schema"."Loan"'])
    tool=next(t for t in registry.tools() if t.name==tool_name)
    args={'source_tables':['"DB"."SC"."LOAN"'],'target_table':'"CaseDb"."Mixed.Schema"."Loan"'}
    if tool_name=='sql_analyst':args['question']='Explain the current source columns'
    assert tool.invoke(args)['status']=='succeeded'
    args['target_table']='"CaseDb"."mixed.schema"."Loan"'
    assert tool.invoke(args)['error_code']=='unverified_semantic_selection'


def test_exact_contract_batch_does_not_require_redundant_catalog_search():
    from app.agent_tools.capability_registry import CapabilityRegistry
    from app.agent_runtime.execution import ExecutionBudget
    from app.agent_runs.models import ToolResult
    inspect=Mock(return_value=ToolResult(status='succeeded',summary='Verified actual table',data={'columns':['ID']}))
    registry=CapabilityRegistry(context_provider=lambda:{'authorized_schemas':['DB.SC']},workflow_executor=lambda *a:{},
        workbench=SimpleNamespace(inspect_table_contract=inspect),budget=ExecutionBudget(model_limit=5,tool_limit=10))
    tool=next(t for t in registry.tools() if t.name=='inspect_table_contracts_batch')
    assert tool.invoke({'table_fqns':['DB.SC.LOAN']})['status']=='succeeded'
    assert inspect.call_count==1
    assert tool.invoke({'table_fqns':['OTHER.SC.LOAN']})['error_code']=='unverified_evidence_selection'
    assert inspect.call_count==1
