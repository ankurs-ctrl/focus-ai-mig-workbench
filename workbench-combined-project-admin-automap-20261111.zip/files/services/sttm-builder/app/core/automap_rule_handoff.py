"""Checked routing of existing Auto-map definitions to the scalar-rule specialist."""
import hashlib
import json
import re
from sqlglot import exp, parse_one
from app.core.mapping_contracts import valid_attribute_expression


def definition_hash(mapping, context=None):
    body = {key: getattr(mapping, key) for key in ('source_attributes', 'source_dependencies',
        'mapping_mode', 'constant_value', 'attribute_name', 'preprocessing_rule', 'value_binding_ids',
        'preprocessing_nl_rule', 'rule_intent')}
    if context is not None:
        graph = context.relation_graph
        if graph:
            lookup = {identifier: binding.value for binding in graph.value_bindings
                      for identifier in (binding.binding_id, binding.value)}
            body['value_binding_ids'] = sorted({lookup.get(identifier, identifier) for identifier in body['value_binding_ids']})
        body['workspace'] = context.model_dump(mode='json', include={'relation_graph', 'mapping_intent', 'semantic_bundle_hash', 'target_table'})
    return hashlib.sha256(json.dumps(body, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def custom_rule(mapping):
    expression = (mapping.preprocessing_rule or '').strip()
    nl = (mapping.preprocessing_nl_rule or '').strip()
    descriptive_direct = bool(re.match(r'^(?:direct (?:mapping|copy|assignment)|copy (?:the )?source|use (?:the )?(?:approved )?firm value)\b', nl, re.I))
    operation_intent = bool(re.search(r'\b(case|when|if|concat(?:enate)?|trim|upper|lower|convert|cast|format|combine|prefix|suffix|coalesce|replace|calculate|derive)\b', nl, re.I))
    direct_value = mapping.mapping_mode in {'constant', 'attribute'} and (
        not expression or expression == mapping.constant_value or expression.upper() in {'NULL', 'TRUE', 'FALSE'})
    intent = bool(mapping.rule_intent or (nl and not descriptive_direct and (not direct_value or operation_intent)))
    if intent:
        return True
    if mapping.mapping_mode in {'constant', 'attribute'} and (not expression or expression == mapping.constant_value):
        return False
    if valid_attribute_expression(expression):
        tree = parse_one(expression, read='snowflake')
        if mapping.mapping_mode == 'source' and isinstance(tree, exp.Column):
            return False
        if mapping.mapping_mode in {'constant', 'attribute'} and expression.upper() in {'NULL', 'TRUE', 'FALSE'}:
            return False
        return True
    return (len(mapping.source_attributes) > 1
            or mapping.transformation_classification in {'complex', 'simple_multi_source'}
            or str(mapping.preprocessing_rule_type or '').upper() not in {'', 'DIRECT', 'IDENTITY', 'VALUE', 'SELECT...'})


def rule_route(mapping, context=None):
    if custom_rule(mapping):
        if mapping.rule_stage == 'rule_complete' and mapping.rule_definition_hash == definition_hash(mapping, context):
            return 'rule_complete', 'The unchanged rule was already completed by the specialist.'
        return 'rule_pending', 'Custom SQL or transformation intent requires the transformation specialist.'
    if mapping.mapping_mode in {'constant', 'attribute'}:
        return 'value', 'Direct constant or Firm Value assignment; no custom rule is required.'
    if len(mapping.source_attributes) == 1:
        return 'direct', 'One source column with no custom-rule intent.'
    return 'missing_dependency', 'No supported binding or executable Value definition is available.'


class RuleStageBudgetExhausted(TimeoutError):
    """No rule dispatch occurred: the existing shared allowance is exhausted."""
