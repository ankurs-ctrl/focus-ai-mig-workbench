-- Apply in the configured metadata schema before rolling out fenced workers.
ALTER TABLE TBL_AGENT_RUNS ADD COLUMN IF NOT EXISTS LEASE_GENERATION NUMBER DEFAULT 0;
