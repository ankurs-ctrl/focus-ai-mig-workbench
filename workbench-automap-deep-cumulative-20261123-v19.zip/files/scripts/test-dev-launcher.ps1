$ErrorActionPreference = "Stop"
$launcher = Join-Path (Split-Path -Parent $PSScriptRoot) "start-ai-workbench-dev.ps1"
$tokens = $null
$parseErrors = $null
$ast = [System.Management.Automation.Language.Parser]::ParseFile($launcher, [ref]$tokens, [ref]$parseErrors)
if ($parseErrors.Count) { throw "Launcher syntax errors: $parseErrors" }
foreach ($name in @("Assert-PortsAvailable", "Assert-Configuration")) {
    $definition = $ast.Find({ param($node)
        $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq $name
    }, $true)
    . ([scriptblock]::Create($definition.Extent.Text))
}

# Run actual preflight functions with isolated OS/configuration boundaries.
function Die($message) { throw $message }
function Log-Backend($message) { $script:lastLog = $message }
function Get-NetTCPConnection { param($State, $LocalPort, $ErrorAction) $script:listeners }
function Test-Path { param($LiteralPath, $PathType) $script:pathExists }
function Select-String { param($LiteralPath, $Pattern) $script:templateAccount }
function Resolve-Path { param($LiteralPath) [pscustomobject]@{ Path = $LiteralPath } }
function Expect-Failure($action, $message) {
    $caught = $null
    try { & $action } catch { $caught = $_.Exception.Message }
    if (-not $caught -or $caught -notlike "*$message*") { throw "Expected '$message', got '$caught'" }
}

$BACKEND_PORT = "8000"
$FRONTEND_PORT = "3000"
$ENV_FILE = "configured.env"
$CaBundle = ""
$listeners = @([pscustomobject]@{ OwningProcess = 1234 })
Expect-Failure { Assert-PortsAvailable } "Port 8000 is already in use"
$listeners = @()
Assert-PortsAvailable
$pathExists = $false
Expect-Failure { Assert-Configuration } "No configured environment file"
$pathExists = $true
$templateAccount = "your_org-your_account"
Expect-Failure { Assert-Configuration } "template values"
$templateAccount = $null
Assert-Configuration
$CaBundle = "trusted-ca.pem"
Assert-Configuration
if ($lastLog -notlike "*trusted-ca.pem*") { throw "CA selection must be visible" }
Write-Output "Launcher syntax and occupied-port, missing/template environment, and explicit CA checks passed."