from types import SimpleNamespace

import pytest
from snowflake.snowpark import Row
from snowflake.snowpark.types import StringType, StructField

from app.core.automap_learning_pack import select_learning_pack
from app.core.automap_source_format import normalize_source_objects
from app.core.config import Settings
from app.core.mapping_contracts import mapping_transformation_text
from app.core.mapping_sql import MappingSqlService
from app.core.target_mapping_patterns import TargetMappingPatternService
from app.schema.sttm_builder import RelationGraphContext
from tests.unit.core.test_learning_loop_reuse import _pattern, _RetrievalSession
from tests.test_automap_fast_transport import harness as transport_harness


def test_draft_specialist_splits_oversized_group_before_dispatch(monkeypatch, transport_harness):
    import asyncio
    import json
    from tests.unit.core.test_automap_guarded_specialist import setup, rules
    from app.core.agent_payload_budget import AgentPayloadBudgetError
    from app.core import automap_specialist_context
    builder, models, req, source = setup(transport_harness, 2)
    req.meta['automap_generation_policy'] = 'draft-v3'
    from app.core.automap_batch import freeze_fast_handoff
    req.meta['_automap_fast_handoff'] = freeze_fast_handoff(req)
    original = automap_specialist_context.specialist_messages
    sizes = []
    def bounded(service, request, runtime):
        sizes.append(len(request.data.attributes))
        if len(request.data.attributes) > 1:
            raise AgentPayloadBudgetError('fixture: two targets do not fit')
        return original(service, request, runtime)
    monkeypatch.setattr(automap_specialist_context, 'specialist_messages', bounded)
    def hook(outgoing):
        if 'AGT_SOURCE_MAPPING' in outgoing.url.path:
            transport_harness.state.answer = source
        else:
            packet = json.loads(json.loads(outgoing.content)['messages'][0]['content'][0]['text'])
            transport_harness.state.answer = rules(*[item['target_attribute'] for item in packet['data']['attributes']])
    transport_harness.state.hook = hook
    final = asyncio.run(builder.invoke_auto_map_parallel(req))
    assert sizes == [2, 1, 1]
    assert all(item.preprocessing_rule == 'TRIM(a.X47)' for item in final.result.mappings.values())
    assert models[0]._stage_calls == {'source_mapping': 1, 'transformation_rule': 2, 'evidence_review': 0}


def test_linked_priority_does_not_disqualify_accessible_cross_project_recipe():
    records = [dict(pattern_id=owner, project_id=owner, mapping_recipe={
        'expression': f"a.NAME || '{owner}'", 'source_dependencies': ['a.NAME']}) for owner in ('other', 'linked', 'current')]
    selected = select_learning_pack(records, project_id='current', linked_projects=['linked'], source_columns=['a.NAME'])
    assert [item['project_id'] for item in selected] == ['current', 'linked', 'other']
    assert all(item['applicable'] for item in selected)


def test_dedup_retains_same_expression_with_different_population():
    records = [dict(pattern_id=str(i), project_id='p', mapping_recipe={'expression': 'a.NAME'},
                    query_shaping_dependencies=[{'kind': 'filter', 'expression': predicate}]) for i, predicate in enumerate(('ACTIVE = TRUE', 'ACTIVE = FALSE'))]
    assert len(select_learning_pack(records, project_id='p')) == 2


def test_missing_grain_can_generate_draft_without_certifying_unknown_metadata():
    pattern = _pattern('8101').model_copy(update={'source_system_profile': {'source_tables': ['DB.SRC.CLIENT']}})
    service = TargetMappingPatternService(_RetrievalSession(pattern), Settings())
    candidates = service.retrieve_candidates(target_table='DB.TGT.ACCOUNTS', target_columns=['NAME'],
        source_tables=['DB.SRC.CLIENT'], source_columns=['DB.SRC.CLIENT.FULL_NAME'], allow_incomplete_metadata=True)
    assert candidates[0].decision == 'accept_exact_precedent'
    assert candidates[0].compatibility_checks['grain_compatible'] is None
    assert 'compatible_source_grain' in candidates[0].missing_dependencies


def test_sql_null_survives_fir_projection_as_an_expression():
    service = TargetMappingPatternService(SimpleNamespace(), Settings())
    patterns = service.extract_document_patterns(asset_id='null', project_id='p', evidence_class='published_mapping',
        base_confidence=.9, parsed_document={'target_table': 'D.S.T', 'column_mappings': [
            {'target_alias': 'OWNERNAME', 'mapping_mode': 'constant', 'constant_value': 'NULL', 'transformation': 'NULL'}]})
    assert patterns[0].scope == 'client'
    assert patterns[0].mapping_recipe['expression'] == 'NULL'
    assert patterns[0].mapping_recipe['has_project_specific_literal'] is False


def test_preview_keys_preserve_actual_quoted_output_values():
    fields = [StructField('"Import Notes"', StringType()), StructField('"IndvAccount.Status"', StringType()),
              StructField('"MixedCase"', StringType())]
    rows = [Row(**{'Import Notes': '', 'IndvAccount.Status': False, 'MixedCase': None})]
    result = MappingSqlService._serialize_preview_result(fields, rows)
    assert [column.key for column in result.columns] == ['Import Notes', 'IndvAccount.Status', 'MixedCase']
    assert all(column.key in result.rows[0].values for column in result.columns)
    assert result.rows[0].values == {'Import Notes': '', 'IndvAccount.Status': False, 'MixedCase': None}


@pytest.mark.parametrize('name,alias', [('JimsContacts', 'j'), ('"Customers"', '"cust"')])
def test_comparison_maps_generated_cte_alias_to_approved_outer_alias(name, alias):
    graph = RelationGraphContext.model_validate({'nodes': [{'relation_id': 'sql-cte:contacts', 'alias': 'cte_jimscontacts',
        'kind': 'DERIVED_SOURCE', 'original_cte_name': name, 'sql_text': 'SELECT ID AS LegacyCRMID FROM D.S.T'}]})
    sql = MappingSqlService._source_value_preview_query(
        f'WITH {name} AS (SELECT ID AS LegacyCRMID FROM D.S.T) SELECT {alias}.LegacyCRMID FROM {name} {alias}',
        {'cte_jimscontacts.LegacyCRMID': 'SRC_1'}, limit=5, graph=graph)
    assert f'{alias}.LegacyCRMID AS SRC_1' in sql
    assert 'cte_jimscontacts.LegacyCRMID' not in sql


def test_source_record_id_resolves_only_through_admitted_binding():
    body = {'binding': {'sql_qualifier': 'a', 'relation_id': 'r'}, 'column': 'NAME'}
    plan = SimpleNamespace(admitted_sources=lambda: [SimpleNamespace(record_id='source-id', body=body)])
    envelope = {'result': {'mappings': {'NAME': {'source_attributes': ['source-id'],
        'source_dependencies': ['src:a.NAME'], 'candidate_source_attributes': ['src:unknown.NAME'],
        'candidates': [{'source_attributes': ['src:a.NAME'], 'source_dependencies': ['source-id']}]}}}}
    result = normalize_source_objects(envelope, plan)['result']['mappings']['NAME']
    assert result['source_attributes'] == result['source_dependencies'] == ['a.NAME']
    assert result['candidate_source_attributes'] == ['src:unknown.NAME']
    assert result['candidates'][0]['source_attributes'] == result['candidates'][0]['source_dependencies'] == ['a.NAME']


@pytest.mark.parametrize('label', ['Select...', 'Direct', 'CAST', 'Custom'])
def test_placeholder_rule_labels_do_not_become_persisted_transformations(label):
    assert mapping_transformation_text({'rule': label, 'mapping_mode': 'source'}) == ''


@pytest.mark.parametrize('value', ['', '0', 'false', 'NULL'])
def test_real_constant_definitions_survive_persistence(value):
    assert mapping_transformation_text({'mapping_mode': 'constant', 'constant_value': value})


@pytest.mark.parametrize('qualified', [False, True])
def test_actual_contacts_import_can_publish_without_restructuring_cte_population(qualified):
    from sqlglot import exp, parse_one
    from sqlglot.optimizer.scope import traverse_scope
    from app.core.sql_parser import parse_sql_document
    from tests.unit.core.test_sql_upload_real_fixture import ROOT, run_frontend
    sql = (ROOT / 'services/sttm-builder/tests/fixtures/sql_upload/contacts_actual.sql').read_text(encoding='utf-8-sig')
    if qualified:
        tree = parse_one(sql, read='snowflake')
        for scope in traverse_scope(tree):
            for table in scope.tables:
                if isinstance(scope.sources.get(table.alias_or_name), exp.Table) and not table.db:
                    table.set('db', exp.to_identifier('S'))
                    table.set('catalog', exp.to_identifier('D'))
        sql = tree.sql(dialect='snowflake')
    parsed = parse_sql_document(sql).to_dict()
    references = [dict(raw_identifier=name, resolved_fqn='D.S.' + name if '.' not in name else name,
        reference_role='source', resolution_status='resolved', catalog_status='available') for name in parsed['source_tables']]
    result = run_frontend(dict(asset_id='contacts-publication', parsed_summary=parsed,
        import_preview=dict(sql=sql, table_references=references)))
    snapshot = result['snapshot']
    snapshot.update(relation_graph=result['graph'], target_table={'database': 'D', 'schema': 'S', 'table': 'CONTACT_TARGET'},
        raw_mapping_sql=sql, mapping_sql=sql, mapping_preview_sql=sql, driving_relation_id=result['state']['drivingTableId'])
    values = [SimpleNamespace(attribute_name=name[1:], attribute_value='TEST_VALUE', attribute_type='VARCHAR')
              for name in MappingSqlService._placeholders_in_sql(sql)]
    explained = []
    def execute(query):
        explained.append(query)
        return SimpleNamespace(collect=lambda: [])
    validated = MappingSqlService(session=SimpleNamespace(sql=execute), analyst_client=None).validate_publication(
        snapshot, project_attributes=values, project_id='test')
    assert len(snapshot['mapping_rows']) == 49
    assert len(list(parse_one(validated['preview_sql'], read='snowflake').args['with_'].expressions)) == 4
    assert snapshot['raw_mapping_sql'] == sql
    assert explained and all(query.startswith('EXPLAIN USING TEXT ') for query in explained)


def test_dependency_suggestions_retain_only_retrieved_published_join_and_cte():
    from app.core.automap_dependency_suggestions import dependency_suggestions
    pattern = {'pattern_id': 'published-street', 'validation_status': 'published',
        'target_contract': {'target_column': 'STREET'}, 'mapping_recipe': {'expression': 'c.ADDRESS'},
        'derived_dependencies': [{'name': 'c', 'sql_text': 'SELECT ADDRESS FROM D.S.T WHERE ACTIVE = TRUE'}],
        'relationship_dependencies': [{'join_type': 'LEFT', 'sql_predicate': 'c.ID = a.ID'}],
        'provenance': {'publication_version_id': '42'}}
    store = SimpleNamespace(evidence={'STREET': {'canonical_target_mapping_patterns': [dict(pattern=pattern,
        decision='unresolved', missing_dependencies=['derived_output:C'])]}}, available_evidence={}, historical_dependencies={})
    suggestions = dependency_suggestions('STREET', store)
    assert len(suggestions) == 1
    proposal = suggestions[0].dependency_proposal
    assert proposal.evidence_ids == ['published-street']
    assert proposal.publication_version_id == '42'
    assert proposal.ctes == pattern['derived_dependencies']
    assert proposal.joins == pattern['relationship_dependencies']
    store.evidence['STREET']['canonical_target_mapping_patterns'][0]['pattern']['validation_status'] = 'rejected'
    assert dependency_suggestions('STREET', store) == []


def test_failure_metadata_excludes_query_and_credentials():
    from app.core.sql_failure import sql_failure_details
    error = RuntimeError('secret query and credentials')
    error.errno, error.sfqid, error.sqlstate = 904, '01-query-id', '42000'
    error.query = 'SELECT secret'
    assert sql_failure_details(error) == {'error_type': 'RuntimeError', 'sql_error_code': '904',
                                          'query_id': '01-query-id', 'sql_state': '42000'}


def test_invalid_unused_cte_does_not_stop_ready_physical_source_drafts():
    from app.core.automap_fast_context import validate_derived_output_contracts, FastContextPlan
    from app.core.automap_retrieval import AutoMapContext
    from app.schema.sttm_builder import STTMBuilderEnvelopeRequest
    from tests.unit.core.test_automap_fast_context import fast_payload
    payload = fast_payload(1)
    payload['meta'] = {**payload.get('meta', {}), 'automap_generation_policy': 'draft-v3'}
    payload['context']['relation_graph']['nodes'].append({'relation_id': 'bad-cte', 'kind': 'CTE',
        'alias': 'bad', 'sql_text': 'SELECT 1 AS OTHER', 'output_columns': [{'name': 'ID'}]})
    req = STTMBuilderEnvelopeRequest.model_validate(payload)
    proofs = validate_derived_output_contracts(req, None)
    assert 'bad-cte' in proofs.failures
    assert 'bad-cte' not in proofs
    plan = FastContextPlan(AutoMapContext(payload), max_chars=180000, max_bytes=180000, validated_derived=proofs)
    assert plan.binding_admissions()
    assert all(item.relation_id != 'bad-cte' for item in plan.binding_admissions())
    assert plan.blocks.enabled is False


def test_new_draft_run_uses_source_agent_without_quote_review_protocol():
    import json
    from app.core.automap_batch import invoke_batch
    from tests.unit.core.test_automap_fast_batch import FinalAgent, prepared_request, service
    from tests.unit.core.test_automap_fast_context import fast_payload
    payload = fast_payload(1)
    payload['meta'] = {**payload.get('meta', {}), 'automap_generation_policy': 'draft-v3'}
    agent = FinalAgent([json.dumps({'agent': 'AGT_SOURCE_MAPPING', 'data': {'result': {'mappings': {
        'NAME0': {'source_attributes': ['a.X47'], 'confidence_score': .4, 'transformation_classification': 'direct'}}}}})])
    builder = service(agent)
    raw, _, _ = invoke_batch(builder, prepared_request(payload), SimpleNamespace())
    response = json.loads(raw)
    assert response['data']['result']['mappings']['NAME0']['source_attributes']
    assert len(agent.calls) == 1
    assert all('auto_map_exact_evidence_block_v1' not in json.dumps(messages) for messages, _ in agent.calls)


@pytest.mark.parametrize('primary_ready', [False, True])
def test_candidate_only_complex_selection_gets_expression_without_replacing_ready_primary(primary_ready):
    import asyncio
    from tests.unit.core.test_automap_retrieval import payload, service, ScriptedAgent
    from app.schema.sttm_builder import STTMBuilderEnvelopeRequest, STTMBuilderResponse, SourceMappingResult, TransformationResult
    value = payload(description_size=0)
    value['context']['learning_context'] = {}
    req = STTMBuilderEnvelopeRequest.model_validate(value)
    builder = service(ScriptedAgent())
    result = SourceMappingResult.model_validate({'mappings': {'NAME0': {
        'source_attributes': ['a.X47'] if primary_ready else [], 'confidence_score': .8,
        'preprocessing_rule_type': 'Direct', 'transformation_classification': 'direct' if primary_ready else 'unresolved',
        'candidates': [{'source_attributes': ['a.X47'], 'source_dependencies': ['a.X47'], 'confidence_score': .7,
            'preprocessing_rule_type': 'Custom', 'transformation_classification': 'complex'}]}}})
    response = STTMBuilderResponse.from_invocation(req, thread_id=None, parent_message_id=None,
        agent='SOURCE_MAPPING_AGENT', result=result, message='', status='completed')
    calls = []
    def invoke(request, **kwargs):
        calls.append(request)
        return STTMBuilderResponse.from_invocation(request, thread_id=None, parent_message_id=None,
            agent='TRANSFORMATION_AGENT', result=TransformationResult.model_validate({'rules': [{
                'target_attribute': 'NAME0', 'rule': 'TRIM(a.X47)', 'source_dependencies': ['a.X47']}]}),
            message='', status='completed')
    builder.invoke = invoke
    final = asyncio.run(builder._apply_complex_transformation_stage(req, response, governance_decision=None))
    assert len(calls) == (0 if primary_ready else 1)
    assert final.result.mappings['NAME0'].source_attributes == ['a.X47']
    assert final.result.mappings['NAME0'].preprocessing_rule == (None if primary_ready else 'TRIM(a.X47)')


def test_cross_project_literal_requires_current_value_but_null_stays_reusable():
    records = [dict(pattern_id=name, project_id='old-project', scope='project' if literal else 'client',
        mapping_recipe={'expression': expression, 'constant_value': expression,
                        'has_project_specific_literal': literal})
        for name, expression, literal in [('firm', "'OLD-FIRM-ID'", True), ('neutral', 'NULL', False)]]
    pack = {item['pattern_id']: item for item in select_learning_pack(records, project_id='new-project')}
    assert pack['neutral']['applicable'] is True
    assert pack['neutral']['mapping_recipe']['expression'] == 'NULL'
    assert pack['firm']['applicable'] is False
    assert pack['firm']['mapping_recipe']['requires_current_project_value'] is True
    assert pack['firm']['mapping_recipe']['expression'] is None
    assert pack['firm']['mapping_recipe']['constant_value'] is None


def test_followup_recipe_page_excludes_seen_ids_using_binds_and_keeps_current_corrections():
    from app.core.automap_learning_pack import AutoMapLearningPack
    captured = []
    session = SimpleNamespace(sql=lambda sql, params: (
        captured.append((sql, params)) or SimpleNamespace(collect=lambda: [])))
    pack = AutoMapLearningPack(session, Settings(_env_file=None))
    assert pack.retrieve(targets=['NAME'], target_table='D.S.T', project_id='new',
        excluded_pattern_ids=['fir:seen-pattern', "unsafe'identifier"]) == {'NAME': []}
    sql, binds = captured[0]
    assert "unsafe'identifier" not in sql
    assert "p.PATTERN_ID NOT IN (?,?)" in sql
    assert "evidence_class::STRING = 'explicit_user_correction' AND TO_VARCHAR(p.PROJECT_ID) = ?" in sql
    assert binds[-3:] == ['seen-pattern', "unsafe'identifier", 'new']
    assert pack.counts == {'NAME': 0}


@pytest.mark.parametrize('draft', [False, True])
def test_semantic_service_outage_is_optional_for_new_drafts_only(monkeypatch, draft):
    from app.core.sttm_builder import STTMBuilderService
    from app.schema.sttm_builder import STTMBuilderEnvelopeRequest
    from tests.unit.core.test_automap_fast_context import fast_payload
    value = fast_payload()
    if draft:
        value['meta']['automap_generation_policy'] = 'draft-v3'
    req = STTMBuilderEnvelopeRequest.model_validate(value)
    builder = STTMBuilderService.__new__(STTMBuilderService)
    builder._settings = Settings(_env_file=None)
    builder._conversation_memory = None
    builder._sanitize_request_semantic_context = lambda request: request
    def unavailable(request):
        raise RuntimeError('unavailable')
    builder._with_semantic_context = unavailable
    builder._with_learning_context = lambda request: request
    monkeypatch.setattr('app.core.sttm_builder.attach_agent_execution_context', lambda request, memory: request)
    if not draft:
        with pytest.raises(RuntimeError):
            builder.prepare_auto_map_request(req)
    else:
        prepared = builder.prepare_auto_map_request(req)
        assert prepared.context.relation_graph == req.context.relation_graph
        assert prepared.meta['automap_semantics_unavailable']
        assert any(item.code == 'AUTO_MAP_SEMANTICS_UNAVAILABLE' for item in prepared.warnings)


def test_fir_preparation_outage_retains_current_graph_and_freezes_degraded_context():
    from app.core.sttm_builder import STTMBuilderService
    from app.core.automap_policy import preparation_hash, POLICY_VERSION
    from app.schema.sttm_builder import STTMBuilderEnvelopeRequest
    from tests.unit.core.test_automap_fast_context import fast_payload
    from unittest.mock import Mock
    value = fast_payload()
    value['meta']['automap_generation_policy'] = 'draft-v3'
    value['context']['learning_context'] = None
    req = STTMBuilderEnvelopeRequest.model_validate(value)
    builder = STTMBuilderService.__new__(STTMBuilderService)
    builder._auto_map_retrieval_enabled = lambda request: True
    builder._learning_service = SimpleNamespace(get_auto_map_context=Mock(side_effect=RuntimeError('unavailable')))
    builder._with_project_firm_values = lambda graph, project: graph
    prepared = builder._with_learning_context(req)
    assert prepared.context.relation_graph == req.context.relation_graph
    assert prepared.context.learning_context.automap_policy_version == POLICY_VERSION
    assert prepared.context.prepared_context_hash == preparation_hash(prepared.context)
    assert prepared.meta['automap_fir_context_unavailable']


def test_publication_reprojection_is_read_only_by_default_and_keeps_version_provenance(monkeypatch):
    import json
    from unittest.mock import Mock
    from app.core.project_service import ProjectService
    from scripts.reproject_published_automap_learning import reproject_publications
    snapshot = {'mapping_rows': [{'target_column': 'OWNERNAME', 'expression': 'NULL'}]}
    captured = []
    session = SimpleNamespace(sql=lambda sql, params: (captured.append((sql, params)) or SimpleNamespace(
        collect=lambda: [Row(VERSION_ID=42, STTM_ID=7, PROJECT_ID=1, VERSION_PAYLOAD=json.dumps(snapshot))])))
    project = Mock(return_value=1)
    monkeypatch.setattr(ProjectService, '_record_target_mapping_patterns', project)
    settings = Settings(_env_file=None, SNOWFLAKE_DATABASE='D', SNOWFLAKE_SCHEMA='S')
    dry = reproject_publications(session, settings, after_version=40, limit=1000)
    project.assert_not_called()
    assert dry['execute'] is False and dry['next_after_version'] == 42
    assert 'VERSION_NUMBER = s.CURRENT_VERSION' in captured[0][0]
    assert 'LIMIT 100' in captured[0][0] and captured[0][1] == [40]
    reproject_publications(session, settings, execute=True)
    assert project.call_args.kwargs['snapshot'] == snapshot
    assert project.call_args.kwargs['publication_version_id'] == '42'
    assert project.call_args.kwargs['strict'] is True
