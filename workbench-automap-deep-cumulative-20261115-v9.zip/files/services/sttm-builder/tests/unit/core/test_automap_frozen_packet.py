"""Exact parent/worker receipts, without a model or source-data execution."""
from copy import deepcopy
import json
from types import SimpleNamespace

import pytest

from app.core.automap_batch import invoke_batch
from app.core.automap_frozen_packet import freeze, hydrate
from app.core.automap_input_budget import wire_text
from app.core.automap_retrieval import digest
from app.core.sttm_builder import STTMBuilderService
from tests.unit.core.test_automap_fast_batch import prepared_request, service, FinalAgent
from tests.unit.core.test_automap_fast_context import fast_payload


def packet_fixture():
    value = fast_payload(3)
    value['meta'].update(automap_generation_policy='draft-v3', automap_rules_policy='rules-v2', automap_packet_policy='frozen-packets-v1')
    req = prepared_request(value)
    builder = service(FinalAgent())
    projection = STTMBuilderService.project_agent_payload(req, builder._settings)
    assert projection.frozen_packet is not None
    packet = json.loads(json.dumps(projection.frozen_packet))
    req.meta['_automap_frozen_packet'] = packet
    req.meta['_automap_fast_handoff']['packet_digest'] = packet['receipt_digest']
    return req, builder, packet


def test_parent_packet_hydrates_without_planning_or_exact_read_repetition(monkeypatch):
    req, builder, packet = packet_fixture()
    def forbidden(*args, **kwargs):
        raise AssertionError('Frozen packet must not be repacked in the worker')
    monkeypatch.setattr('app.core.automap_fast_context.FastContextPlan.__init__', forbidden)
    monkeypatch.setattr('app.core.automap_fast_context.FastContextPlan._render', forbidden)
    raw, _, meta = invoke_batch(builder, req, SimpleNamespace())
    assert len(builder._agent.calls) == 1, meta
    assert digest(builder._agent.calls[0][0]) == packet['message_digest']
    assert set(json.loads(raw)['data']['result']['mappings']) == {'NAME0', 'NAME1', 'NAME2'}
    assert meta['auto_map_retrieval']['auto_map_fast_path']['frozen_packet']['worker_verified']


def test_private_packet_bodies_are_not_echoed_into_result_metadata():
    from app.schema.sttm_builder import STTMBuilderResponse
    req,_,_=packet_fixture()
    req.meta['_automap_resolution_plan']={'large_private_snapshot':'x'*20000}
    from app.schema.sttm_builder import STTMStatus
    response=STTMBuilderResponse.from_invocation(req,thread_id=None,parent_message_id=None,agent=None,result=None,message=None,status=STTMStatus.COMPLETED,
        meta={'_automap_packet_ref':{'private':True},'public_timing':2})
    assert not {'_automap_frozen_packet','_automap_packet_ref','_automap_fast_handoff','_automap_resolution_plan'} & response.meta.keys()
    assert response.meta['public_timing']==2
    assert req.meta['_automap_frozen_packet']


@pytest.mark.parametrize('field', ['messages', 'input_digest', 'final_bytes', 'state'])
def test_tampered_packets_never_dispatch(field):
    req, builder, packet = packet_fixture()
    if field == 'messages': packet[field][0]['content'][0]['text'] += ' '
    elif field == 'input_digest': packet[field] = '0' * 64
    elif field == 'final_bytes': packet[field] += 1
    else: packet[field]['unexpected'] = True
    raw, _, meta = invoke_batch(builder, req, SimpleNamespace())
    assert builder._agent.calls == []
    assert all(row['transformation_classification'] == 'unresolved' for row in json.loads(raw)['data']['result']['mappings'].values())


def test_cached_catalog_is_identical_and_does_not_reindex_yaml(monkeypatch):
    from app.core.automap_packet_policy import catalog_index
    from app.core.automap_retrieval import AutoMapContext
    value = fast_payload(3)
    index = json.loads(json.dumps(catalog_index(value)))
    cold = AutoMapContext(value)
    def forbidden(*args, **kwargs):
        raise AssertionError('Prepared catalog must not be reindexed')
    monkeypatch.setattr(AutoMapContext, '_index_model', forbidden)
    warm = AutoMapContext(value, catalog_index=index)
    assert vars(cold) == vars(warm)


def test_stale_catalog_is_rebuilt_from_current_semantics():
    from app.core.automap_packet_policy import catalog_index
    from app.core.automap_retrieval import AutoMapContext
    value = fast_payload(1)
    index = catalog_index(value)
    value['context']['semantic_context'][0]['semantic_model']['description'] = 'New pipeline version'
    assert vars(AutoMapContext(value, catalog_index=index)) == vars(AutoMapContext(value))


def test_legacy_projection_keeps_original_operation_identity():
    from app.core.automap_packet_policy import source_planning_input
    from app.core.automap_policy import focused_learning
    from app.schema.sttm_builder import STTMAgentRequestEnvelope
    value = fast_payload(3)
    value['meta'].update(automap_generation_policy='draft-v3', automap_rules_policy='rules-v2')
    req = prepared_request(value)
    original = STTMAgentRequestEnvelope.from_builder_request(req).model_dump(mode='json', exclude_none=True)
    original['meta'] = {'automap_generation_policy':'draft-v3','automap_rules_policy':'rules-v2'}
    original['context']['learning_context'] = focused_learning(original['context'].get('learning_context') or {})
    assert source_planning_input(req) == original


def test_new_projection_scopes_history_without_changing_authored_query():
    from app.core.automap_packet_policy import source_planning_input
    req, _, _ = packet_fixture()
    req.context.workspace_context = req.context.workspace_context.model_copy(update={'mapping_sql':'SELECT a.ID FROM D.S.A a', 'mapping_rows':[
        {'target_column':'NAME0','expression':'a.ID','ai_candidates':[{'large':'generated'}]},
        {'target_column':'OTHER','expression':'a.ID'}]})
    req.context.learning_context.mapping_precedents = [{'mappings':[
        {'target_column':'NAME0','description':'complete applicable history'},
        {'target_column':'OTHER','description':'irrelevant history'}]}]
    raw = source_planning_input(req)
    assert raw['context']['workspace_context']['mapping_sql'] == 'SELECT a.ID FROM D.S.A a'
    assert raw['context']['workspace_context']['mapping_rows'] == [{'target_column':'NAME0','expression':'a.ID'}]
    assert raw['context']['learning_context']['mapping_precedents'] == [{'mappings':[
        {'target_column':'NAME0','description':'complete applicable history'}]}]
    assert req.context.workspace_context.mapping_rows[0]['ai_candidates']
