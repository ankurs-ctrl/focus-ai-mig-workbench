import api from "@/api/axiosInstance";
import type {
  FIRRecommendation,
  FIRRecommendationEvaluationResponse,
  WorkbenchContextSnapshotV2,
} from "@/types/api-contract";

export const recommendationService = {
  evaluate: async (
    workspaceContext: WorkbenchContextSnapshotV2,
    options?: { checkpoint?: string | null; projectId?: string | null; signal?: AbortSignal },
  ): Promise<FIRRecommendationEvaluationResponse> => {
    const response = await api.post(
      "/v1/recommendations/evaluate",
      {
        workspace_context: workspaceContext,
        checkpoint: options?.checkpoint ?? workspaceContext.checkpoint ?? workspaceContext.milestone,
        project_id: options?.projectId ?? workspaceContext.project_id,
        limit: 20,
        include_search_fallback: true,
        include_evidence: false,
      },
      {
        timeout: 90000,
        signal: options?.signal,
        // Checkpoint evaluation is background guidance. A slow FIR lookup must
        // never interrupt table selection with a blocking application dialog.
        skipGlobalError: true,
      },
    );
    return response.data as FIRRecommendationEvaluationResponse;
  },

  get: async (recommendationId: string): Promise<FIRRecommendation> => {
    const response = await api.get(
      `/v1/recommendations/${encodeURIComponent(recommendationId)}`,
      { timeout: 90000 },
    );
    return response.data as FIRRecommendation;
  },

  recordOutcome: async (
    recommendationId: string,
    payload: {
      outcome_type: string;
      context_key?: string | null;
      snapshot_id?: string | null;
      user_id?: string | null;
      payload?: Record<string, unknown>;
    },
  ) => {
    await api.post(`/v1/recommendations/${encodeURIComponent(recommendationId)}/outcomes`, payload, {
      timeout: 60000,
      skipGlobalError: true,
    });
  },

  recordShownOutcomes: async (
    items: Array<{
      recommendation_id: string;
      context_key?: string | null;
      snapshot_id?: string | null;
      user_id?: string | null;
      payload?: Record<string, unknown>;
    }>,
  ) => {
    if (!items.length) return;
    await api.post(
      "/v1/recommendations/outcomes/batch",
      {
        items: items.map((item) => ({ ...item, outcome_type: "shown" })),
      },
      { timeout: 60000, skipGlobalError: true },
    );
  },
};
