"""Prepare an idempotent CRM/publication backfill SQL artifact; does not execute SQL."""
import argparse
from pathlib import Path
import re


def backfill_sql(namespace):
    if not re.fullmatch(r'[A-Z_][A-Z0-9_]*\.[A-Z_][A-Z0-9_]*', namespace):
        raise ValueError('Expected a canonical DATABASE.SCHEMA namespace')
    return f'''-- Review before execution. Re-running updates only missing CRM or older recipes.
UPDATE {namespace}.TBL_FIR_TARGET_MAPPING_PATTERNS p
SET PATTERN_PAYLOAD = OBJECT_INSERT(p.PATTERN_PAYLOAD, 'source_system_profile',
    OBJECT_INSERT(COALESCE(p.PATTERN_PAYLOAD:source_system_profile, OBJECT_CONSTRUCT()),
      'vendor_family', UPPER(project.PROJECT_METADATA:source_system_key::STRING), TRUE), TRUE),
    UPDATED_AT = CURRENT_TIMESTAMP()
FROM {namespace}.TBL_PROJECTS project
WHERE TO_VARCHAR(project.PROJECT_ID) = TO_VARCHAR(p.PROJECT_ID)
  AND NULLIF(project.PROJECT_METADATA:source_system_key::STRING, '') IS NOT NULL
  AND NULLIF(p.PATTERN_PAYLOAD:source_system_profile:vendor_family::STRING, '') IS NULL;

UPDATE {namespace}.TBL_FIR_TARGET_MAPPING_PATTERNS p
SET PATTERN_PAYLOAD = OBJECT_INSERT(p.PATTERN_PAYLOAD, 'provenance',
    OBJECT_INSERT(COALESCE(p.PATTERN_PAYLOAD:provenance, OBJECT_CONSTRUCT()),
      'published_at', TO_VARCHAR(v.PUBLISHED_DATETIME), TRUE), TRUE)
FROM {namespace}.TBL_STTM_VERSIONS v
WHERE TO_VARCHAR(v.VERSION_ID) = p.PATTERN_PAYLOAD:provenance:publication_version_id::STRING
  AND TO_VARCHAR(v.STTM_ID) = TO_VARCHAR(p.STTM_ID)
  AND p.VALIDATION_STATUS = 'published'
  AND NULLIF(p.PATTERN_PAYLOAD:provenance:published_at::STRING, '') IS NULL;

UPDATE {namespace}.TBL_FIR_TARGET_MAPPING_PATTERNS old
SET SUPERSEDED_BY = newest.PATTERN_ID, STATUS = 'inactive', UPDATED_AT = CURRENT_TIMESTAMP()
FROM (
    SELECT p.PATTERN_ID, p.STTM_ID, p.TARGET_COLUMN, p.PATTERN_PAYLOAD, v.VERSION_ID
    FROM {namespace}.TBL_FIR_TARGET_MAPPING_PATTERNS p
    JOIN {namespace}.TBL_STTM s ON s.STTM_ID = TRY_TO_NUMBER(p.STTM_ID)
    JOIN {namespace}.TBL_STTM_VERSIONS v ON v.STTM_ID = s.STTM_ID
      AND v.VERSION_NUMBER = s.CURRENT_VERSION
      AND TO_VARCHAR(v.VERSION_ID) = p.PATTERN_PAYLOAD:provenance:publication_version_id::STRING
    WHERE p.VALIDATION_STATUS = 'published' AND p.STATUS = 'active' AND p.SUPERSEDED_BY IS NULL
    QUALIFY ROW_NUMBER() OVER (PARTITION BY p.STTM_ID, p.TARGET_COLUMN ORDER BY p.UPDATED_AT DESC, p.PATTERN_ID) = 1
) newest
WHERE old.STTM_ID = newest.STTM_ID AND UPPER(old.TARGET_COLUMN) = UPPER(newest.TARGET_COLUMN)
  AND old.SUPERSEDED_BY IS NULL AND old.VALIDATION_STATUS = 'published'
  AND TRY_TO_NUMBER(old.PATTERN_PAYLOAD:provenance:publication_version_id::STRING) < newest.VERSION_ID
  AND old.PATTERN_ID <> newest.PATTERN_ID
  AND old.PATTERN_PAYLOAD:mapping_recipe::STRING <> newest.PATTERN_PAYLOAD:mapping_recipe::STRING;
'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--namespace', required=True)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    args.output.write_text(backfill_sql(args.namespace))


if __name__ == '__main__':
    main()
