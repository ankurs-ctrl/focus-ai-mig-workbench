"""Single-attempt transport for a trusted, isolated named scan agent.

Pass this callable through ScanCallAdmission.wrap_backend(), and use the paired
admission context. The caller supplies an existing same-caller agent client and
owns the reusable httpx client. Its transports/hooks MUST NOT retry, redirect,
read responses eagerly, change credentials, or log headers/bodies. This module
bypasses run/run_detailed (which retry and audit payloads), disables HTTP auth
flows and redirects, and never reads the token directly.

The deployment must verify the named agent's tools/instructions outside this
adapter. Paired runtime calls create an empty thread, commit its reference via
admission, then issue one model POST. Explicit recovery issues GET only; no
client-side tools, polling or cancellation API is invoked. Rejecting tool blocks
cannot undo server-side tool execution.

ScanRequest has no input budget: the registry already checks the serialized
normalized messages array. We validate that array and embed its ORIGINAL bytes
in {"messages":<array>,"stream":false}. Managed calls add only thread_id and
parent_message_id=0; exactly one original user message is required.
Neither the wrapper nor provider-side prompts/tools are covered by that message
budget. max_response_bytes caps the raw HTTP entity, including reasoning and
metadata; output_budget independently caps extracted text in chars/UTF-8 bytes.
Compression is refused so a small compressed body cannot expand past the cap.

Deadlines are cooperative: check before/after dispatch, each raw chunk and
parsing, and supply remaining time as HTTP operation timeouts. Synchronous DNS,
hooks, networking and parser work cannot be interrupted exactly at the deadline.
Stopping locally is NOT proof of remote cancellation; uncertain outcomes raise
ordinary exceptions so admission quarantines them, even on pre-dispatch errors.
Only recognized terminal outcomes raise RemoteCallCompleted subclasses.

Response contract: https://docs.snowflake.com/en/user-guide/snowflake-cortex/cortex-agents-run
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace
from enum import Enum
from typing import Callable
import json
import logging
import math
import re

import httpx

from app.core.automap_admission import (
    AdmissionError, Permit, RemoteCallCompleted, ScanCallAdmission,
    ScanCallLifecycle, ThreadReference, request_digest,
)
from app.core.automap_scan import (
    InvalidScanResponse, ScanBackendError, ScanOutputBudgetError, ScanRequest, ScanStopped, ScanTransportReason,
)
from app.core.snowflake_agent import SnowflakeAgentClient
from app.core.automap_shards import SnapshotScope


AUTOMAP_USER_AGENT = "ffp-ai-migration-workbench/1.0"
logger = logging.getLogger(__name__)


class ScanTransportError(ScanBackendError):
    """Remote completion is unknown; keep the admission permit quarantined."""


def _http_error_reason(error: httpx.HTTPError) -> ScanTransportReason:
    # Match library types, never derive a persisted code from exception names
    # or text (including user-defined HTTPError subclasses).
    for error_type, reason in (
        (httpx.ConnectTimeout, ScanTransportReason.HTTP_CONNECT_TIMEOUT),
        (httpx.ReadTimeout, ScanTransportReason.HTTP_READ_TIMEOUT),
        (httpx.WriteTimeout, ScanTransportReason.HTTP_WRITE_TIMEOUT),
        (httpx.PoolTimeout, ScanTransportReason.HTTP_POOL_TIMEOUT),
        (httpx.ConnectError, ScanTransportReason.HTTP_CONNECT_ERROR),
        (httpx.ReadError, ScanTransportReason.HTTP_READ_ERROR),
        (httpx.WriteError, ScanTransportReason.HTTP_WRITE_ERROR),
        (httpx.CloseError, ScanTransportReason.HTTP_CLOSE_ERROR),
        (httpx.LocalProtocolError, ScanTransportReason.HTTP_LOCAL_PROTOCOL_ERROR),
        (httpx.RemoteProtocolError, ScanTransportReason.HTTP_REMOTE_PROTOCOL_ERROR),
        (httpx.ProxyError, ScanTransportReason.HTTP_PROXY_ERROR),
        (httpx.UnsupportedProtocol, ScanTransportReason.HTTP_UNSUPPORTED_PROTOCOL),
        (httpx.DecodingError, ScanTransportReason.HTTP_DECODING_ERROR),
        (httpx.TooManyRedirects, ScanTransportReason.HTTP_TOO_MANY_REDIRECTS),
        (httpx.HTTPStatusError, ScanTransportReason.HTTP_STATUS_ERROR),
    ):
        if isinstance(error, error_type):
            return reason
    return ScanTransportReason.HTTP_ERROR


class RawResponseBudgetError(ScanTransportError):
    """The raw entity is too large to establish remote completion safely."""


class TerminalCallFailure(RemoteCallCompleted):
    """The provider reported terminal failure or definitively rejected the call."""


class TerminalOutputBudgetError(RemoteCallCompleted, ScanOutputBudgetError):
    """A completed response exceeds the extracted-text budget."""


class DiagnosticOperation(str, Enum):
    MODEL_RUN = "model_run"
    THREAD_CREATE = "thread_create"


class DiagnosticPhase(str, Enum):
    BEFORE_PARSE = "before_parse"
    PARSED = "parsed"
    FAILURE = "failure"


class DiagnosticEncoding(str, Enum):
    IDENTITY = "identity"
    GZIP = "gzip"
    DEFLATE = "deflate"
    BR = "br"
    OTHER = "other"
    UNKNOWN = "unknown"


class DiagnosticMedia(str, Enum):
    JSON = "json"
    EVENT_STREAM = "event_stream"
    OTHER = "other"
    UNKNOWN = "unknown"


class DiagnosticStatus(str, Enum):
    ABSENT = "absent"
    COMPLETED = "completed"
    ERROR = "error"
    TIMED_OUT = "timed_out"
    CANCELLED = "cancelled"
    UNKNOWN = "unknown"
    MIXED = "mixed"


class DiagnosticReason(str, Enum):
    UNKNOWN_FAILURE = "unknown_failure"
    RAW_BUDGET = "raw_budget"
    TERMINAL_FAILURE = "terminal_failure"
    TERMINAL_RESPONSE = "terminal_response"
    TERMINAL_OUTPUT_BUDGET = "terminal_output_budget"
    STOPPED = "stopped"


class TerminalResponseReason(str, Enum):
    INVALID_MESSAGE = "invalid_message"
    INVALID_ROLE = "invalid_role"
    INVALID_CONTENT_SHAPE = "invalid_content_shape"
    INVALID_BLOCK_SHAPE = "invalid_block_shape"
    BLOCK_ERROR = "block_error"
    INVALID_CONTENT_KIND = "invalid_content_kind"
    INVALID_TEXT_VALUE = "invalid_text_value"
    NO_TEXT = "no_text"
    INVALID_EXTRACTION = "invalid_extraction"


class DiagnosticContentKind(str, Enum):
    MISSING_OR_NULL = "missing_or_null"
    LIST = "list"
    OTHER = "other"


class DiagnosticBlockType(str, Enum):
    # Diagnostic vocabulary only; this does NOT expand accepted response types.
    TEXT = "text"
    THINKING = "thinking"
    SUGGESTED_QUERIES = "suggested_queries"
    TOOL_USE = "tool_use"
    TOOL_RESULT = "tool_result"
    CITATION = "citation"
    FILE = "file"
    IMAGE = "image"
    TABLE = "table"
    CHART = "chart"
    ERROR = "error"
    UNKNOWN = "unknown"
    MISSING = "missing"
    INVALID = "invalid"
    NON_OBJECT = "non_object"


class TerminalResponseError(RemoteCallCompleted, InvalidScanResponse):
    """Completed but unusable output, carrying only a bounded shape projection."""

    def __init__(self, message, *, response_reason=TerminalResponseReason.INVALID_EXTRACTION, content=None):
        if type(response_reason) is not TerminalResponseReason:
            raise ValueError("Invalid terminal response reason")
        super().__init__(message)
        self.response_reason = response_reason
        self.content_kind = (DiagnosticContentKind.LIST if type(content) is list else
            DiagnosticContentKind.MISSING_OR_NULL if content is None else DiagnosticContentKind.OTHER)
        self.block_count = min(len(content), 1_000_000) if type(content) is list else 0
        kinds = set()
        for block in content if type(content) is list else ():
            if type(block) is not dict:
                kind = DiagnosticBlockType.NON_OBJECT
            elif "type" not in block:
                kind = DiagnosticBlockType.MISSING
            elif type(block["type"]) is not str:
                kind = DiagnosticBlockType.INVALID
            else:
                # Select enum constants, never retain arbitrary provider strings.
                kind = next((item for item in DiagnosticBlockType if item.value == block["type"]),
                            DiagnosticBlockType.UNKNOWN)
            kinds.add(kind)
        self.block_types = tuple(sorted(kinds, key=lambda item: item.value))


def _provider_request_id(value: object) -> str | None:
    # Only canonical UUID spelling; no generic safe-string/token escape hatch.
    if type(value) is str and re.fullmatch(
            r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}", value):
        return value.lower()
    return None


def _provider_run_id(value: object) -> str | None:
    # Provider thread-message pair, decimal only, at most two signed-int64 widths.
    # This is an identifier filter, not evidence that a run exists or completed.
    if type(value) is str and re.fullmatch(r"[0-9]{1,19}-[0-9]{1,19}", value):
        return value
    return None


@dataclass(frozen=True)
class ScanTransportDiagnostic:
    """Fixed nonsecret projection; never contains a request, body or headers.

    At most six events per managed call (thread creation + model exchange); three
    for an unmanaged call. Missing events/IDs mean a trace gap, NOT completion. Scope/generation/shard come from the
    trusted ScanRequest; provider status is descriptive, not admission evidence.
    Content shape is populated only with response_reason; block_count saturates
    at 1,000,000 and block_types is a sorted, unique fixed-vocabulary set.
    """

    scope: SnapshotScope
    generation: str
    shard_id: str
    phase: DiagnosticPhase
    operation: DiagnosticOperation = DiagnosticOperation.MODEL_RUN
    http_status: int | None = None
    encoding: DiagnosticEncoding = DiagnosticEncoding.UNKNOWN
    media: DiagnosticMedia = DiagnosticMedia.UNKNOWN
    request_id: str | None = None
    run_id: str | None = None
    status: DiagnosticStatus = DiagnosticStatus.ABSENT
    reason: ScanTransportReason | DiagnosticReason | None = None
    response_reason: TerminalResponseReason | None = None
    content_kind: DiagnosticContentKind = DiagnosticContentKind.MISSING_OR_NULL
    block_count: int = 0
    block_types: tuple[DiagnosticBlockType, ...] = ()

    def __post_init__(self):
        if not isinstance(self.scope, SnapshotScope):
            raise ValueError("Diagnostic scope required")
        for value in (self.scope.owner_id, self.scope.snapshot_id, self.generation, self.shard_id):
            if type(value) is not str or not 1 <= len(value) <= 256 or any(
                    ord(char) < 32 or ord(char) == 127 for char in value):
                raise ValueError("Invalid diagnostic scope identifier")
        for value, kind in ((self.operation, DiagnosticOperation), (self.phase, DiagnosticPhase), (self.encoding, DiagnosticEncoding),
                            (self.media, DiagnosticMedia), (self.status, DiagnosticStatus),
                            (self.content_kind, DiagnosticContentKind)):
            if type(value) is not kind:
                raise ValueError("Invalid diagnostic enum")
        if self.http_status is not None and (type(self.http_status) is not int or not 100 <= self.http_status <= 599):
            raise ValueError("Invalid diagnostic HTTP status")
        if self.reason is not None and type(self.reason) not in (ScanTransportReason, DiagnosticReason):
            raise ValueError("Invalid diagnostic reason")
        if self.response_reason is not None and type(self.response_reason) is not TerminalResponseReason:
            raise ValueError("Invalid terminal response reason")
        if type(self.block_count) is not int or not 0 <= self.block_count <= 1_000_000:
            raise ValueError("Invalid diagnostic block count")
        if (type(self.block_types) is not tuple or len(self.block_types) > len(DiagnosticBlockType)
                or any(type(kind) is not DiagnosticBlockType for kind in self.block_types)
                or len(set(self.block_types)) != len(self.block_types)):
            raise ValueError("Invalid diagnostic block types")
        if self.request_id is not None and _provider_request_id(self.request_id) != self.request_id:
            raise ValueError("Invalid diagnostic request ID")
        if self.run_id is not None and _provider_run_id(self.run_id) != self.run_id:
            raise ValueError("Invalid diagnostic run ID")


def _diagnostic_reason(error: BaseException) -> ScanTransportReason | DiagnosticReason:
    if isinstance(error, ScanTransportError) and type(error.reason) is ScanTransportReason:
        return error.reason
    for error_type, reason in (
        (RawResponseBudgetError, DiagnosticReason.RAW_BUDGET),
        (TerminalOutputBudgetError, DiagnosticReason.TERMINAL_OUTPUT_BUDGET),
        (TerminalResponseError, DiagnosticReason.TERMINAL_RESPONSE),
        (TerminalCallFailure, DiagnosticReason.TERMINAL_FAILURE),
        (ScanStopped, DiagnosticReason.STOPPED),
    ):
        if isinstance(error, error_type):
            return reason
    return DiagnosticReason.UNKNOWN_FAILURE


@dataclass(frozen=True)
class ScanTransportConfig:
    """Trusted deployment configuration, never supplied by a model or request."""

    agent: str
    max_response_bytes: int

    def __post_init__(self) -> None:
        if type(self.agent) is not str or not re.fullmatch(
                r"[A-Za-z_][A-Za-z0-9_$]{0,254}(\.[A-Za-z_][A-Za-z0-9_$]{0,254}){2}", self.agent):
            raise ValueError("Scan agent requires an unquoted DATABASE.SCHEMA.AGENT")
        if type(self.max_response_bytes) is not int or self.max_response_bytes <= 0:
            raise ValueError("max_response_bytes must be a positive integer")
        object.__setattr__(self, "agent", self.agent.upper())


def _unique_object(pairs: list[tuple[str, object]]) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON field")
        result[key] = value
    return result


def _reject_constant(value: str) -> None:
    raise ValueError("Nonfinite JSON number")


def _load_json(text: str) -> object:
    return json.loads(text, object_pairs_hook=_unique_object, parse_constant=_reject_constant)


def _strip_outer_json_fence(text: str) -> str:
    """Remove one whole-text Markdown wrapper, never extract or repair JSON."""
    stripped = text.strip()
    opening, separator, remainder = stripped.partition("\n")
    if not separator or opening.rstrip("\r") not in ("```json", "```"):
        return text
    body, separator, closing = remainder.rpartition("\n")
    if not separator or closing.strip() != "```":
        return text
    # Fence-like lines inside the wrapper indicate multiple/nested blocks.
    # Backticks within JSON strings are content, not Markdown delimiters.
    if any(line.lstrip().startswith("```") for line in body.split("\n")):
        return text
    return body.strip()


def _request_body(request: ScanRequest, *, new_thread: bool = False) -> bytes:
    try:
        messages = _load_json(request.message)
        if type(messages) is not list or not messages:
            raise ValueError
        for message in messages:
            if (type(message) is not dict or set(message) != {"role", "content", "status"}
                    or message["role"] not in ("user", "assistant")
                    or message["status"] != "completed"
                    or type(message["content"]) is not list or not message["content"]):
                raise ValueError
            for block in message["content"]:
                if (type(block) is not dict or set(block) != {"type", "text"}
                        or block["type"] != "text" or type(block["text"]) is not str):
                    raise ValueError
                block["text"].encode("utf-8")
        if new_thread and (len(messages) != 1 or messages[0]["role"] != "user"):
            raise ValueError
        if messages[-1]["role"] != "user":
            raise ValueError
        return ('{"messages":' + request.message + ',"stream":false}').encode("utf-8")
    except (ValueError, TypeError, UnicodeError, RecursionError):
        raise ScanTransportError("Expected checked normalized scan messages") from None


class ThreadTerminalStatus(str, Enum):
    COMPLETED = "completed"
    ERROR = "error"
    CANCELLED = "cancelled"
    TIMED_OUT = "timed_out"


class ThreadEvidenceSource(str, Enum):
    STRUCTURED_V2_PAYLOAD = "thread_get.message_payload.v2.status"


@dataclass(frozen=True)
class ThreadTerminalEvidence:
    """Provider lifecycle evidence, NOT authority to retire a dispatcher/release."""

    thread_id: int
    user_message_id: int
    assistant_message_id: int
    status: ThreadTerminalStatus
    source: ThreadEvidenceSource = field(default=ThreadEvidenceSource.STRUCTURED_V2_PAYLOAD, init=False)

    def __post_init__(self) -> None:
        if (any(type(value) is not int or not 0 < value < 2**63 for value in (
                self.thread_id, self.user_message_id, self.assistant_message_id))
                or self.user_message_id == self.assistant_message_id
                or type(self.status) is not ThreadTerminalStatus):
            raise ValueError("Invalid thread terminal evidence")

    @property
    def run_id(self) -> str:
        return f"{self.thread_id}-{self.user_message_id}"


@dataclass(frozen=True)
class ThreadRecoveryObservation:
    """Scoped GET observation; never automatically reconciles an occupied slot."""

    permit: Permit
    reference: ThreadReference
    assistant_message_ids: tuple[int, ...]
    terminal: ThreadTerminalEvidence | None = None


def _thread_terminal(messages: list[dict], request: ScanRequest,
                     reference: ThreadReference, *, max_payload_bytes: int = 120_000) -> ThreadTerminalEvidence | None:
    # This lifecycle creates one exclusive root and sends exactly one model POST.
    # More records/branches (including compaction) are outside that proof. A full
    # page cannot prove exclusivity, even if it happens to contain the root.
    if len(messages) != 2 or any(message["message_type"] != "conversation" for message in messages):
        return None
    users = [message for message in messages if message["role"] == "user"]
    assistants = [message for message in messages if message["role"] == "assistant"]
    if len(users) != 1 or len(assistants) != 1:
        return None
    user, assistant = users[0], assistants[0]
    if user.get("parent_id") != 0 or assistant.get("parent_id") != user["message_id"]:
        return None
    try:
        # is_compressed may be true for plain JSON (verified provider shape).
        # Never decompress, decode base64, unwrap strings, or inspect model text.
        payloads = []
        for message in (user, assistant):
            text = message["message_payload"]
            if len(text.encode("utf-8")) > max_payload_bytes:
                return None
            payload = _load_json(text)
            if (type(payload) is not dict or payload.get("schema_version") != "v2"
                    or payload.get("role") != message["role"]
                    or type(payload.get("content")) is not list):
                return None
            payloads.append(payload)
        user_payload, assistant_payload = payloads
        # schema_version/tags belong to the persisted provider envelope, not the
        # original Message. Only status=completed may be absent on the user row.
        # No trimming, text JSON parsing, block reordering or extra fields allowed.
        if (set(user_payload) - {"role", "content", "status", "schema_version", "tags"}
                or ("status" in user_payload and user_payload["status"] != "completed")):
            return None
        expected = _load_json(request.message)[0]
        observed = {key: value for key, value in user_payload.items() if key not in ("schema_version", "tags")}
        observed.setdefault("status", "completed")
        if observed != expected:
            return None
        status = assistant_payload.get("status")
        if type(status) is not str or status not in {value.value for value in ThreadTerminalStatus}:
            return None
        return ThreadTerminalEvidence(reference.thread_id, user["message_id"],
                                      assistant["message_id"], ThreadTerminalStatus(status))
    except (ValueError, TypeError, UnicodeError, RecursionError):
        return None


class SnowflakeScanTransport:
    """Reusable ScanBackend; construction performs no I/O and stores no headers.

    http_client is caller-owned, thread-safe, and configured without transport
    retries or unsafe hooks. No default client, credentials, agent, or model is
    discovered from environment variables by this adapter. diagnostic_sink is a
    trusted, caller-owned, thread-safe, synchronous best-effort callback. It MUST
    be nonblocking and perform no I/O: callback execution time cannot be enforced,
    and delays before terminal classification can quarantine an otherwise valid
    call. It must not mutate cancellation/deadlines. Exceptions are swallowed
    without retry/logging; absence of events means a trace gap. The runtime factory
    leaves this callback unset. With paired admission, diagnostics are bounded
    per-request memory only; the thread reference is committed before model POST.
    """

    def __init__(self, *, agent_client: SnowflakeAgentClient, http_client: httpx.Client,
                 config: ScanTransportConfig,
                 diagnostic_sink: Callable[[ScanTransportDiagnostic], None] | None = None,
                 admission: ScanCallAdmission | None = None) -> None:
        if not isinstance(agent_client, SnowflakeAgentClient):
            raise TypeError("An existing same-caller SnowflakeAgentClient is required")
        if not isinstance(http_client, httpx.Client):
            raise TypeError("A reusable httpx.Client is required")
        if not isinstance(config, ScanTransportConfig):
            raise TypeError("Trusted ScanTransportConfig is required")
        # The existing helper owns endpoint/auth conventions. Reject malformed
        # origins rather than allowing a host path or userinfo to redirect auth.
        origin = httpx.URL(agent_client._base_url)
        if (origin.scheme != "https" or not origin.host or origin.userinfo
                or origin.path not in ("", "/") or origin.query or origin.fragment):
            raise ValueError("Agent client requires a trusted HTTPS account origin")
        self._url = str(origin.copy_with(path=agent_client._build_endpoint(config.agent)))
        self._threads_url = str(origin.copy_with(path="/api/v2/cortex/threads"))
        if admission is not None and not isinstance(admission, ScanCallAdmission):
            raise TypeError("A paired ScanCallAdmission is required")
        if admission is not None and diagnostic_sink is not None:
            raise ValueError("Managed lifecycle uses memory diagnostics only")
        self._admission = admission
        if admission is not None:
            # Fail configuration before creating an unpersistable orphan thread.
            ThreadReference(2**63 - 1, config.agent, "0" * 64)
        self._agent_client = agent_client
        self._http_client = http_client
        self._config = config
        if diagnostic_sink is not None and not callable(diagnostic_sink):
            raise TypeError("Diagnostic sink must be a trusted callable")
        self._diagnostic_sink = diagnostic_sink

    def __call__(self, request: ScanRequest) -> str:
        # Per-call state, never shared across worker threads. Diagnostics are
        # best-effort: neither construction nor sink errors affect the outcome.
        diagnostic = None
        lifecycle = self._admission.bind_lifecycle(request) if self._admission is not None else None
        sink = lifecycle.record_diagnostic if lifecycle is not None else self._diagnostic_sink

        def emit(phase, *, response=None, data=None, error=None, operation=None):
            nonlocal diagnostic
            if sink is None:
                return
            try:
                if operation is not None and diagnostic is not None and diagnostic.operation != operation:
                    diagnostic = None
                if diagnostic is None:
                    diagnostic = ScanTransportDiagnostic(request.scope, request.generation,
                        request.shard_id, phase or DiagnosticPhase.BEFORE_PARSE,
                        operation=operation or DiagnosticOperation.MODEL_RUN)
                if phase is None:
                    return  # Operation transition, no fabricated HTTP receipt.
                diagnostic = replace(diagnostic, phase=phase)
                if response is not None:
                    encoding = response.headers.get("content-encoding", "identity").lower()
                    media = response.headers.get("content-type", "").split(";", 1)[0].strip().lower()
                    diagnostic = replace(diagnostic, http_status=response.status_code,
                        encoding=DiagnosticEncoding(encoding) if encoding in (
                            "identity", "gzip", "deflate", "br") else DiagnosticEncoding.OTHER,
                        media={"application/json": DiagnosticMedia.JSON,
                               "text/event-stream": DiagnosticMedia.EVENT_STREAM,
                               "": DiagnosticMedia.UNKNOWN}.get(media, DiagnosticMedia.OTHER),
                        request_id=_provider_request_id(response.headers.get("x-snowflake-request-id"))
                            or _provider_request_id(response.headers.get("x-request-id")))
                if type(data) is dict:
                    message = data.get("message")
                    envelopes = [data, message] if type(message) is dict else [data]
                    statuses = [envelope["status"] for envelope in envelopes if "status" in envelope]
                    known = ("completed", "error", "timed_out", "cancelled")
                    status = DiagnosticStatus.ABSENT
                    if statuses:
                        if any(type(value) is not str or value not in known for value in statuses):
                            status = DiagnosticStatus.UNKNOWN
                        elif len(set(statuses)) > 1:
                            status = DiagnosticStatus.MIXED
                        else:
                            status = DiagnosticStatus(statuses[0])
                    # Only top-level provider fields, never assistant content,
                    # nested error text, or arbitrary metadata dictionaries.
                    diagnostic = replace(diagnostic, status=status,
                        request_id=diagnostic.request_id or _provider_request_id(data.get("request_id"))
                            or _provider_request_id(data.get("requestId")),
                        run_id=_provider_run_id(data.get("run_id")))
                if error is not None:
                    diagnostic = replace(diagnostic, reason=_diagnostic_reason(error))
                    if isinstance(error, TerminalResponseError):
                        diagnostic = replace(diagnostic, response_reason=error.response_reason,
                            content_kind=error.content_kind, block_count=error.block_count,
                            block_types=error.block_types)
                sink(diagnostic)
            except Exception:
                pass  # No fallback logs/files, retry, or completion inference.

        try:
            return self._exchange(request, emit, lifecycle)
        except Exception as error:
            emit(DiagnosticPhase.FAILURE, error=error)
            if isinstance(error, TerminalResponseError):
                try:
                    logger.warning("Auto-map terminal response rejected code=%s content_kind=%s block_count=%s block_types=%s",
                        error.response_reason.value, error.content_kind.value, error.block_count,
                        ",".join(kind.value for kind in error.block_types) or "none")
                except Exception:
                    pass  # Logging cannot change completion or permit disposition.
            raise

    def _headers(self) -> dict[str, str]:
        headers = self._agent_client._build_headers()
        # Raw Request deliberately skips client defaults, including HTTPX's UA.
        headers["User-Agent"] = AUTOMAP_USER_AGENT
        headers["Accept-Encoding"] = "identity"
        return headers

    def _thread_recovery_cap(self):
        return 120_000

    def _thread_exchange(self, request: ScanRequest, *, thread_id: int | None = None,
                         emit=None) -> object:
        """Same caller, one HTTP request, no prompts/retries/redirects/SDK."""
        request.check_active()
        method = "POST" if thread_id is None else "GET"
        url = self._threads_url if thread_id is None else f"{self._threads_url}/{thread_id}?page_size=100"
        cap = 4096 if thread_id is None else min(self._config.max_response_bytes, self._thread_recovery_cap())
        try:
            headers = self._headers()
            headers["Accept"] = "application/json"
            timeouts = httpx.Timeout(request.remaining_seconds()).as_dict()
            outgoing = httpx.Request(method, url, headers=headers,
                content=b"{}" if thread_id is None else b"", extensions={"timeout": timeouts})
            request.check_active()
            response = self._http_client.send(outgoing, stream=True, auth=None, follow_redirects=False)
            try:
                if emit is not None:
                    emit(DiagnosticPhase.BEFORE_PARSE, response=response)
                raw = self._read_raw(response, request, timeouts, max_bytes=cap)
            finally:
                response.close()
            request.check_active()
            if response.status_code not in ((200, 201) if thread_id is None else (200,)):
                raise ScanTransportError("Thread HTTP exchange did not succeed")
            data = _load_json(raw.decode("utf-8"))
            request.check_active()
            return data
        except httpx.HTTPError as error:
            raise ScanTransportError("Thread HTTP exchange failed", reason=_http_error_reason(error)) from None
        except (ValueError, UnicodeError, RecursionError):
            raise ScanTransportError("Malformed thread response") from None

    def recover_thread(self, permit: Permit, request: ScanRequest) -> ThreadRecoveryObservation:
        """Read persisted reference + one bounded GET; classify structured v2 only.

        request may use a fresh recovery deadline but must retain exact original
        messages/snapshot/generation/shard. Caller/job/pool ownership is checked
        both before and after GET, so stale evidence cannot authorize anything.
        """
        gate = self._admission
        if (not isinstance(permit, Permit) or not isinstance(request, ScanRequest)
                or gate is None or permit.identity.job_id != gate.job_id
                or permit.identity.caller_id != gate.caller_id
                or request.scope.owner_id != gate.caller_id
                or permit.identity.generation != request.generation
                or permit.identity.shard_id != request.shard_id):
            raise AdmissionError("Recovery caller/job/request scope mismatch")
        request.check_active()
        reference = gate.store.read_reconciliation(permit)
        if (reference.agent_fqn != self._config.agent
                or reference.request_digest != request_digest(request)):
            raise AdmissionError("Recovery agent/request digest mismatch")
        _request_body(request, new_thread=True)
        data = self._thread_exchange(request, thread_id=reference.thread_id)
        if (type(data) is not dict or type(data.get("metadata")) is not dict
                or type(data["metadata"].get("thread_id")) is not int
                or data["metadata"]["thread_id"] != reference.thread_id
                or type(data.get("messages")) is not list or len(data["messages"]) > 100):
            raise ScanTransportError("Invalid thread description")
        assistants = []
        seen = set()
        for message in data["messages"]:
            if (type(message) is not dict or type(message.get("message_id")) is not int
                    or not 0 < message["message_id"] < 2**63 or message["message_id"] in seen
                    or message.get("role") not in ("user", "assistant")
                    or type(message.get("message_payload")) is not str
                    or message.get("message_type") not in ("conversation", "compaction")
                    or (message.get("parent_id") is not None and (
                        type(message["parent_id"]) is not int or not 0 <= message["parent_id"] < 2**63))):
                raise ScanTransportError("Invalid persisted thread message")
            seen.add(message["message_id"])
            if message["role"] == "assistant" and message["message_type"] == "conversation":
                assistants.append(message["message_id"])
        terminal = _thread_terminal(data["messages"], request, reference, max_payload_bytes=self._thread_recovery_cap())
        request.check_active()
        if gate.store.read_reconciliation(permit) != reference:
            raise AdmissionError("Recovery reference changed during GET")
        request.check_active()
        return ThreadRecoveryObservation(permit, reference, tuple(assistants), terminal)

    def _exchange(self, request: ScanRequest, emit, lifecycle: ScanCallLifecycle | None = None) -> str:
        if not isinstance(request, ScanRequest):
            raise TypeError("A ScanRequest is required")
        if (type(request.deadline) not in (int, float) or not math.isfinite(request.deadline)):
            raise ScanTransportError("Scan deadline must be finite")
        request.check_active()
        body = _request_body(request, new_thread=lifecycle is not None)
        if lifecycle is not None:
            emit(None, operation=DiagnosticOperation.THREAD_CREATE)
            data = self._thread_exchange(request, emit=lambda phase, **values: emit(
                phase, operation=DiagnosticOperation.THREAD_CREATE, **values))
            try:
                reference = ThreadReference(data["thread_id"], self._config.agent, request_digest(request))
            except (KeyError, TypeError, ValueError):
                raise ScanTransportError("Invalid created thread metadata") from None
            lifecycle.record_reconciliation(reference)
            # Preserve the immutable messages array byte-for-byte. No history,
            # repair, content reserialization or model-side thread creation.
            body = body[:-1] + (f',"thread_id":{reference.thread_id},"parent_message_id":0}}').encode("ascii")
            emit(None, operation=DiagnosticOperation.MODEL_RUN)
        try:
            headers = self._headers()
            request.check_active()
            timeouts = httpx.Timeout(request.remaining_seconds()).as_dict()
            # Do not merge client-level cookies, query params or default headers.
            outgoing = httpx.Request("POST", self._url, headers=headers, content=body,
                                     extensions={"timeout": timeouts})
            if lifecycle is not None:
                lifecycle.check_dispatch()
            request.check_active()
            response = self._http_client.send(outgoing, stream=True, auth=None, follow_redirects=False)
            try:
                emit(DiagnosticPhase.BEFORE_PARSE, response=response, operation=DiagnosticOperation.MODEL_RUN)
                request.check_active()
                raw = self._read_raw(response, request, timeouts)
            finally:
                response.close()
        except httpx.HTTPError as exc:
            # HTTP exceptions can retain a credential-bearing request or echo
            # sensitive server text. Never expose/log them or their cause.
            raise ScanTransportError("Scan HTTP exchange failed; remote completion unknown",
                                     reason=_http_error_reason(exc)) from None
        request.check_active()
        if response.status_code != 200 and (self._diagnostic_sink is not None or lifecycle is not None):
            # Only the fully bounded, uncompressed entity may be inspected.
            # Parse failure cannot change the pre-existing HTTP outcome.
            try:
                data = _load_json(raw.decode("utf-8"))
            except Exception:
                pass  # Diagnostic-only inspection cannot mask the HTTP outcome.
            else:
                emit(DiagnosticPhase.PARSED, data=data)
        if response.status_code == 429:
            raise TerminalCallFailure("Scan request rejected with HTTP 429")
        if response.status_code != 200:
            raise ScanTransportError("Unexpected scan HTTP status; remote completion unknown",
                                     reason=ScanTransportReason.UNEXPECTED_HTTP_STATUS)
        text = self._extract(raw, request, emit)
        request.check_active()
        return text

    def _read_raw(self, response: httpx.Response, request: ScanRequest,
                  timeouts: dict[str, float | None], *, max_bytes: int | None = None) -> bytes:
        limit = self._config.max_response_bytes if max_bytes is None else max_bytes
        if response.headers.get("content-encoding", "identity").lower() != "identity":
            raise ScanTransportError("Encoded scan responses are not supported",
                                     reason=ScanTransportReason.UNSUPPORTED_CONTENT_ENCODING)
        content_length = response.headers.get("content-length")
        if content_length is not None:
            if not content_length.isascii() or not content_length.isdecimal():
                raise ScanTransportError("Invalid scan response length")
            if len(content_length) > 20 or int(content_length) > limit:
                raise RawResponseBudgetError("Raw scan response byte limit exceeded")
        body = bytearray()
        chunks = response.iter_raw()
        while True:
            request.check_active()
            # HTTP transports may snapshot this value; activity checks still run
            # between chunks, without resetting the request's total deadline.
            timeouts["read"] = request.remaining_seconds()
            try:
                chunk = next(chunks)
            except StopIteration:
                break
            request.check_active()
            if len(chunk) > limit - len(body):
                raise RawResponseBudgetError("Raw scan response byte limit exceeded")
            body.extend(chunk)
        request.check_active()
        if content_length is not None and len(body) != int(content_length):
            raise ScanTransportError("Incomplete scan response body")
        return bytes(body)

    def _extract(self, raw: bytes, request: ScanRequest, emit) -> str:
        try:
            data = _load_json(raw.decode("utf-8"))
        except (ValueError, UnicodeError, RecursionError):
            raise ScanTransportError("Malformed scan response JSON",
                                     reason=ScanTransportReason.MALFORMED_JSON) from None
        emit(DiagnosticPhase.PARSED, data=data)
        request.check_active()
        if type(data) is not dict:
            raise ScanTransportError("Expected scan response object")
        message = data.get("message", data)
        envelopes = [data] if message is data or type(message) is not dict else [data, message]
        statuses = [envelope["status"] for envelope in envelopes if "status" in envelope]
        # Unknown/nonterminal status takes precedence over text or an error field.
        if any(type(status) is not str or status not in ("completed", "error", "timed_out", "cancelled")
               for status in statuses):
            raise ScanTransportError("Scan run completion is not established",
                                     reason=ScanTransportReason.UNKNOWN_STATUS)
        if any(status != "completed" for status in statuses):
            raise TerminalCallFailure("Scan run terminated without successful completion")
        if any("error" in envelope or "code" in envelope or "error_code" in envelope
               for envelope in envelopes):
            if statuses:
                raise TerminalCallFailure("Completed scan response reports an error")
            raise ScanTransportError("Scan error has no established terminal status",
                                     reason=ScanTransportReason.UNKNOWN_STATUS)
        terminal = bool(statuses)

        content = message.get("content") if type(message) is dict else None

        def invalid(reason: TerminalResponseReason) -> None:
            if terminal:
                raise TerminalResponseError("Completed scan response is not isolated text output",
                                            response_reason=reason, content=content)
            raise ScanTransportError("Unrecognized scan response; completion unknown")

        if type(message) is not dict:
            invalid(TerminalResponseReason.INVALID_MESSAGE)
        if message.get("role", "assistant") != "assistant":
            invalid(TerminalResponseReason.INVALID_ROLE)
        if type(content) is not list:
            invalid(TerminalResponseReason.INVALID_CONTENT_SHAPE)
        if not content:
            invalid(TerminalResponseReason.NO_TEXT)
        text_count = 0
        suggestion_count = 0
        for block in content:
            if type(block) is not dict:
                invalid(TerminalResponseReason.INVALID_BLOCK_SHAPE)
            if "error" in block:
                invalid(TerminalResponseReason.BLOCK_ERROR)
            if block.get("type") == "text":
                value = block.get("text")
                if type(value) is dict and set(value) == {"value"}:
                    value = value["value"]
                if type(value) is not str:
                    invalid(TerminalResponseReason.INVALID_TEXT_VALUE)
                text_count += 1
            elif block.get("type") == "suggested_queries":
                # Cortex Agents may append follow-up suggestions to a completed
                # answer. They are inert metadata, never part of the mapping JSON.
                suggestions = block.get("suggested_queries")
                if (set(block) != {"type", "suggested_queries"}
                        or type(suggestions) is not list
                        or any(type(item) is not dict or set(item) != {"query"}
                               or type(item["query"]) is not str
                               for item in suggestions)):
                    invalid(TerminalResponseReason.INVALID_BLOCK_SHAPE)
                suggestion_count += len(suggestions)
                if suggestion_count > 32:
                    invalid(TerminalResponseReason.INVALID_BLOCK_SHAPE)
            elif block.get("type") != "thinking":
                # In particular, never silently skip tool_use/tool_result/error.
                invalid(TerminalResponseReason.INVALID_CONTENT_KIND)
        if not text_count:
            invalid(TerminalResponseReason.NO_TEXT)
        # The documented synchronous final assistant shape can omit status.
        # A generic HTTP 200/string/error envelope is not equivalent evidence.
        if not terminal and message.get("role") != "assistant":
            invalid(TerminalResponseReason.INVALID_ROLE)
        try:
            text, _ = self._agent_client._extract_text_and_thread(data, None)
            output_bytes = len(text.encode("utf-8"))
        except (ValueError, TypeError, AttributeError, UnicodeError):
            raise TerminalResponseError("Completed scan response contains invalid text",
                response_reason=TerminalResponseReason.INVALID_EXTRACTION, content=content) from None
        request.check_active()
        if len(text) > request.output_budget.max_chars or output_bytes > request.output_budget.max_bytes:
            raise TerminalOutputBudgetError("Scan output character or UTF-8 byte budget exceeded")
        if not text.strip():
            raise TerminalResponseError("Completed scan response contains no text",
                response_reason=TerminalResponseReason.NO_TEXT, content=content)
        # Charge the full extracted output, including wrapper and whitespace.
        return _strip_outer_json_fence(text)
