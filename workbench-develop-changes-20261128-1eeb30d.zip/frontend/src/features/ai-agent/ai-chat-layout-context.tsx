'use client';

import {
    createContext,
    useCallback,
    useContext,
    useEffect,
    useMemo,
    useRef,
    useState,
    useSyncExternalStore,
    type ReactNode,
} from 'react';
import {
    AI_CHAT_DEFAULT_SIDEBAR_WIDTH,
    AI_CHAT_MAX_SIDEBAR_WIDTH,
    AI_CHAT_MIN_SIDEBAR_WIDTH,
    AI_CHAT_MOBILE_BREAKPOINT,
    AI_CHAT_RAIL_TOP_STORAGE_KEY,
    AI_CHAT_SIDEBAR_WIDTH_STORAGE_KEY,
    AI_CHAT_TABLET_BREAKPOINT,
    clampRailTop,
    getDefaultRailTop,
    loadRailTop,
    loadSidebarWidth,
} from '@/features/ai-agent/ai-chat-layout-constants';
import {
    loadAllStoredChatSessions,
    loadStoredChatSessions,
    persistChatSessions,
} from '@/features/ai-agent/ai-chat-history-store';
import {
    createChatSessionId,
    deriveSessionTitle,
    type StoredChatSession,
} from '@/features/ai-agent/ai-chat-session-utils';
import { authService } from '@/services/authService';
import { cacheRevision, cacheScope, onCacheIdentityChange } from '@/services/session-cache-scope';
import { useSttmBuilderContext } from '@/features/sttm/context/sttm-builder-context';
import { suggestAssistantConversationTitle, deleteAssistantConversation, setAssistantConversationArchived, fetchAssistantConversation, fetchAssistantConversationHistory, saveQuickAssistantHistory, updateAssistantConversation } from '@/services/migrationAgentService';

type PanelView = 'chat' | 'history' | 'notifications';

type AiChatLayoutContextValue = {
    isOpen: boolean;
    isFullscreen: boolean;
    panelView: PanelView;
    historySearch: string;
    sessions: StoredChatSession[];
    historyLoading: boolean;
    historyError: string | null;
    activeSessionId: string | null;
    selectedRecommendationId: string | null;
    resolvedRecommendationIds: ReadonlySet<string>;
    recentSessions: StoredChatSession[];
    railTop: number;
    effectiveSidebarWidth: number;
    isResizing: boolean;
    isMobile: boolean;
    isTablet: boolean;
    layoutHeight: number;
    newChatVersion: number;
    agentPageProjectId: string | null;
    setLayoutMetrics: (width: number, height: number) => void;
    setHistorySearch: (value: string) => void;
    setPanelView: (view: PanelView) => void;
    setAgentPageProjectId: (projectId: string | null) => void;
    openChat: () => void;
    closeChat: () => void;
    enterFullscreen: () => void;
    toggleFullscreen: () => void;
    exitFullscreen: () => void;
    handleNewChat: () => void;
    handleShowHistory: () => void;
    handleShowNotifications: () => void;
    handleSelectRecommendation: (recommendationId: string) => void;
    markRecommendationResolved: (recommendationId: string) => void;
    handleSelectSession: (session: StoredChatSession) => void;
    renameSession: (sessionId: string, title: string) => void;
    deleteSession: (sessionId: string) => Promise<void>;
    handleDeleteSession: (session: StoredChatSession) => Promise<void>;
    handleArchiveSession: (session: StoredChatSession) => Promise<void>;
    handleUpdateSession: (session: StoredChatSession, changes: { title?: string; projectId?: string | null; pinned?: boolean }) => Promise<void>;
    beginRailDrag: (event: React.MouseEvent<HTMLDivElement>) => void;
    beginRailTouchDrag: (event: React.TouchEvent<HTMLDivElement>) => void;
    beginSidebarResize: (event: React.MouseEvent<HTMLDivElement>) => void;
};

const AiChatLayoutContext = createContext<AiChatLayoutContextValue | null>(null);

function hasUserMessages(messages: { role: string }[]) {
    return messages.some((message) => message.role === 'user');
}

export function AiChatLayoutProvider({ children }: { children: ReactNode }) {
    const [isOpen, setIsOpen] = useState(false);
    const [isFullscreen, setIsFullscreen] = useState(false);
    const [panelView, setPanelView] = useState<PanelView>('chat');
    const [sidebarWidth, setSidebarWidth] = useState(AI_CHAT_DEFAULT_SIDEBAR_WIDTH);
    const [isResizing, setIsResizing] = useState(false);
    const [historySearch, setHistorySearch] = useState('');
    const [savedSessions, setSessions] = useState<StoredChatSession[]>([]);
    const [loadedScope, setLoadedScope] = useState<string | null>(null);
    const [historyLoading, setHistoryLoading] = useState(true);
    const [historyError, setHistoryError] = useState<string | null>(null);
    const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
    const [selectedRecommendationId, setSelectedRecommendationId] = useState<string | null>(null);
    const [resolvedRecommendationIds, setResolvedRecommendationIds] = useState<Set<string>>(
        () => new Set(),
    );
    const [railTop, setRailTop] = useState(0);
    const [layoutWidth, setLayoutWidth] = useState(1200);
    const [layoutHeight, setLayoutHeight] = useState(600);
    const [hydrated, setHydrated] = useState(false);
    const [newChatVersion, setNewChatVersion] = useState(0);
    const [agentPageProjectId, setAgentPageProjectIdState] = useState<string | null>(null);
    const isDraggingRailRef = useRef(false);

    const {
        chatMessages,
        agentLogicalConversationId,
        resetChatSession,
        restoreChatSession,
        chatLoading,
        activeProjectId,
        activeSttmId,
    } = useSttmBuilderContext();
    const identity = useSyncExternalStore(onCacheIdentityChange, cacheScope, () => null);
    const authenticatedUserId = identity ? String(JSON.parse(identity)[0]) : null;
    useEffect(() => {
        if (!identity) void authService.getSession().catch(() => undefined);
    }, [identity]);
    const chatScope =
        agentPageProjectId != null
            ? `${authenticatedUserId ?? 'anonymous'}::${agentPageProjectId || 'general'}::agent`
            : `${authenticatedUserId ?? 'anonymous'}::${activeProjectId ?? 'new'}::${activeSttmId ?? 'new'}`;

    const scopedIdentity = authenticatedUserId ? JSON.stringify([identity, chatScope]) : null;
    const sessions = useMemo(() => scopedIdentity && loadedScope === scopedIdentity ? savedSessions : [],
        [scopedIdentity, loadedScope, savedSessions]);
    const scopeRef = useRef(scopedIdentity);
    scopeRef.current = scopedIdentity;
    const historyRequest = useRef(0);
    const restoreRequest = useRef(0);

    const isMobile = layoutWidth < AI_CHAT_MOBILE_BREAKPOINT;
    const isTablet =
        layoutWidth >= AI_CHAT_MOBILE_BREAKPOINT && layoutWidth < AI_CHAT_TABLET_BREAKPOINT;

    const effectiveSidebarWidth = useMemo(() => {
        if (isFullscreen) {
            return Math.max(AI_CHAT_MIN_SIDEBAR_WIDTH, layoutWidth);
        }
        if (isMobile) {
            return Math.max(AI_CHAT_MIN_SIDEBAR_WIDTH, layoutWidth);
        }
        if (isTablet) {
            return Math.min(380, Math.max(AI_CHAT_MIN_SIDEBAR_WIDTH, layoutWidth - 16));
        }
        return Math.min(
            AI_CHAT_MAX_SIDEBAR_WIDTH,
            Math.max(
                AI_CHAT_MIN_SIDEBAR_WIDTH,
                Math.min(sidebarWidth, layoutWidth - 16),
            ),
        );
    }, [isFullscreen, isMobile, isTablet, layoutWidth, sidebarWidth]);

    const setLayoutMetrics = useCallback((width: number, height: number) => {
        setLayoutWidth(width);
        setLayoutHeight(height);
        setRailTop((current) => clampRailTop(current || getDefaultRailTop(height), height));
    }, []);

    const refreshHistory = useCallback(async () => {
        if (!scopedIdentity) return;
        const request = ++historyRequest.current;
        const revision = cacheRevision();
        const isCurrent = () => request === historyRequest.current && cacheRevision() === revision
            && scopeRef.current === scopedIdentity;
        setHistoryLoading(true);
        setHistoryError(null);
        try {
            const server = await fetchAssistantConversationHistory(
                agentPageProjectId == null ? { projectId: activeProjectId, sttmId: activeSttmId } : undefined,
            );
            if (!isCurrent()) return;
            setSessions(current => {
                const cached = new Map(current.filter(item => item.backendConversationId)
                    .map(item => [item.backendConversationId, item]));
                const serverIds = new Set(server.map(item => item.conversation_id));
                return [
                    ...current.filter(item => !item.backendConversationId && !serverIds.has(item.id)),
                    ...server.map(item => {
                        const previous = cached.get(item.conversation_id);
                        return {
                            ...previous,
                            id: previous?.id ?? item.conversation_id,
                            title: item.title,
                            mode: item.mode,
                            messages: previous?.messages ?? [],
                            backendConversationId: item.conversation_id,
                            projectId: item.project_id ?? null,
                            sttmId: item.sttm_id ?? null,
                            updatedAt: new Date(item.updated_at).getTime(),
                            pinned: item.pinned ?? false,
                        };
                    }),
                ].sort((a, b) => b.updatedAt - a.updatedAt);
            });
        } catch {
            if (isCurrent()) setHistoryError('Chat history could not be loaded. Reopen history to retry.');
        } finally {
            if (isCurrent()) setHistoryLoading(false);
        }
    }, [scopedIdentity, agentPageProjectId, activeProjectId, activeSttmId]);

    useEffect(() => {
        const stored = !authenticatedUserId ? [] : agentPageProjectId != null
            ? loadAllStoredChatSessions(authenticatedUserId) : loadStoredChatSessions(chatScope);
        setSessions(stored);
        setLoadedScope(scopedIdentity);
        setActiveSessionId(null);
        setSelectedRecommendationId(null);
        setResolvedRecommendationIds(new Set());
        setSidebarWidth(loadSidebarWidth());
        setHydrated(true);
        void refreshHistory();
        return () => {
            historyRequest.current++;
            restoreRequest.current++;
        };
    }, [agentPageProjectId, chatScope, authenticatedUserId, scopedIdentity, refreshHistory]);

    useEffect(() => {
        if (!hydrated || layoutHeight <= 0) return;
        // Restore the persisted position after the container has a measured height.
        // eslint-disable-next-line react-hooks/set-state-in-effect
        setRailTop((current) => {
            if (current > 0) return clampRailTop(current, layoutHeight);
            return loadRailTop(layoutHeight);
        });
    }, [hydrated, layoutHeight]);

    useEffect(() => {
        const refresh = () => { void refreshHistory(); };
        const refreshWhenVisible = () => {
            if (document.visibilityState === 'visible') refresh();
        };
        window.addEventListener('aia:refresh-assistant-history', refresh);
        window.addEventListener('focus', refreshWhenVisible);
        document.addEventListener('visibilitychange', refreshWhenVisible);
        return () => {
            window.removeEventListener('aia:refresh-assistant-history', refresh);
            window.removeEventListener('focus', refreshWhenVisible);
            document.removeEventListener('visibilitychange', refreshWhenVisible);
        };
    }, [refreshHistory]);

    useEffect(() => {
        if (!hydrated) return;
        try {
            window.localStorage.setItem(AI_CHAT_RAIL_TOP_STORAGE_KEY, String(railTop));
        } catch {
            // Ignore storage errors.
        }
    }, [railTop, hydrated]);

    useEffect(() => {
        if (!hydrated || isMobile || isTablet) return;
        try {
            window.localStorage.setItem(AI_CHAT_SIDEBAR_WIDTH_STORAGE_KEY, String(sidebarWidth));
        } catch {
            // Ignore storage errors.
        }
    }, [sidebarWidth, hydrated, isMobile, isTablet]);

    // Optional naming stays off the chat/run path. One request at a time;
    // ownership and concurrent manual renames are checked again by the API.
    const titleAttempts = useRef(new Set<string>());
    const titleQueueBusy = useRef(false);
    useEffect(() => {
        if (!authenticatedUserId || !scopedIdentity || !hydrated || titleQueueBusy.current) return;
        const revision = cacheRevision();
        const item = sessions.find(chat => chat.id === activeSessionId && chat.backendConversationId);
        if (!item?.backendConversationId) return;
        const first = item.messages.find(message => message.role === 'user')?.content?.trim();
        const title = item.title.trim().replace(/[.!?…]+$/, '').trim();
        if (item.mode !== 'quick' && title !== 'New chat' && (!first || !first.toLowerCase().startsWith(title.toLowerCase()))) return;
        const key = `workbench:title-attempt:${authenticatedUserId}:${item.backendConversationId}:${item.title}`;
        const suggest = async () => {
            if (cacheRevision() !== revision || scopeRef.current !== scopedIdentity || titleAttempts.current.has(key)) return;
            try {
                if (window.localStorage.getItem(key)) return;
                window.localStorage.setItem(key, String(Date.now()));
            } catch { /* The current tab still deduplicates when storage is unavailable. */ }
            titleAttempts.current.add(key);
            titleQueueBusy.current = true;
            try {
                const updated = await suggestAssistantConversationTitle(item.backendConversationId!, item.title);
                if (cacheRevision() !== revision || scopeRef.current !== scopedIdentity || updated.title === item.title) return;
                setSessions(current => current.map(chat => chat.backendConversationId === updated.conversation_id
                    && chat.title === item.title ? {...chat, title: updated.title} : chat));
                try { window.localStorage.setItem(`workbench:title-attempt:${authenticatedUserId}:${updated.conversation_id}:${updated.title}`, String(Date.now())); } catch { /* Optional storage. */ }
            } catch {
                titleAttempts.current.delete(key);
                try { window.localStorage.removeItem(key); } catch { /* Optional storage. */ }
            }
            finally { titleQueueBusy.current = false; }
        };
        if (navigator.locks) void navigator.locks.request(key, suggest);
        else void suggest();
    }, [sessions, activeSessionId, authenticatedUserId, hydrated, scopedIdentity]);

    const activeSessionMode = sessions.find(item => item.id === activeSessionId)?.mode;
    const upsertCurrentSession = useCallback(() => {
        if (!scopedIdentity || loadedScope !== scopedIdentity || chatLoading || !hasUserMessages(chatMessages)) return;
        if (activeSessionMode === 'deep') return;

        const firstUserId = chatMessages.find(message => message.role === 'user')?.id;
        const priorSession = firstUserId && loadStoredChatSessions(chatScope).find(item =>
            item.messages.find(message => message.role === 'user')?.id === firstUserId);
        const sessionId = activeSessionId || (priorSession ? priorSession.id : createChatSessionId());
        const nextSession: StoredChatSession = {
            id: sessionId,
            title: deriveSessionTitle(chatMessages),
            messages: chatMessages.map((message) => ({ ...message })),
            updatedAt: Date.now(),
            mode: 'quick',
            logicalConversationId: agentLogicalConversationId,
            backendConversationId: null,
            projectId: agentPageProjectId != null ? (agentPageProjectId === 'general' ? null : agentPageProjectId) : activeProjectId,
            sttmId: agentPageProjectId != null ? null : activeSttmId,
            storageScope: chatScope,
        };

        setSessions((previous) => {
            const existing = previous.find((item) => item.id === sessionId) || priorSession;
            if (existing) {
                nextSession.backendConversationId = existing.backendConversationId;
                nextSession.title = existing.title === 'New chat' ? nextSession.title : existing.title;
                nextSession.pinned = existing.pinned;
            }
            const filtered = previous.filter(session => session.id !== sessionId
                && (!nextSession.backendConversationId || session.backendConversationId !== nextSession.backendConversationId));
            const next = [nextSession, ...filtered];
            const local = loadStoredChatSessions(chatScope).filter((session) => session.id !== sessionId);
            persistChatSessions(chatScope, [nextSession, ...local]);
            return next;
        });
        setActiveSessionId(sessionId);
    }, [activeSessionId, agentLogicalConversationId, agentPageProjectId, activeProjectId, activeSttmId, chatMessages, chatScope, scopedIdentity, loadedScope, chatLoading, activeSessionMode]);

    useEffect(() => {
        if (!hasUserMessages(chatMessages)) return;
        const timeout = window.setTimeout(() => {
            upsertCurrentSession();
        }, 400);
        return () => window.clearTimeout(timeout);
    }, [chatMessages, upsertCurrentSession]);

    const saveInFlight = useRef(new Set<string>());
    const savedTranscripts = useRef(new Map<string, string>());
    const [saveRevision, setSaveRevision] = useState(0);
    useEffect(() => {
        const item = sessions.find(chat => chat.mode === 'quick' && (
            chat.id === activeSessionId || (!activeSessionId && !chat.backendConversationId && chat.messages.length > 0)
        ));
        if (!scopedIdentity || !item || chatLoading) return;
        const first = item.messages.findIndex(message => message.role === 'user');
        if (first < 0) return;
        const messages = item.messages.slice(first, first + 500)
            .filter(message => !message.isStreaming && message.content.trim())
            .map((message, index) => ({
                id: message.id ?? `legacy-${index}`,
                role: message.role, content: message.content, status: message.status,
                options: message.options, request_id: message.requestId, created_at: message.createdAt,
            }));
        if (!messages.some(message => message.role === 'assistant')) return;
        const key = JSON.stringify([scopedIdentity, item.id]);
        const signature = JSON.stringify(messages.map(message => message.id));
        if (saveInFlight.current.has(key) || savedTranscripts.current.get(key) === signature) return;
        const revision = cacheRevision();
        saveInFlight.current.add(key);
        void saveQuickAssistantHistory({
            local_id: item.id, conversation_id: item.backendConversationId,
            project_id: item.projectId, sttm_id: item.sttmId,
            logical_conversation_id: item.logicalConversationId, messages,
        }).then(saved => {
            if (cacheRevision() !== revision) return;
            savedTranscripts.current.set(key, signature);
            const update = (entry: StoredChatSession) => entry.id === item.id
                ? { ...entry, backendConversationId: saved.conversation_id, title: saved.title } : entry;
            if (item.storageScope) {
                persistChatSessions(item.storageScope, loadStoredChatSessions(item.storageScope).map(update));
            }
            if (scopeRef.current === scopedIdentity) {
                setSessions(current => current.filter(entry => entry.id === item.id
                    || entry.backendConversationId !== saved.conversation_id).map(update));
            }
        }).catch(() => {
            if (cacheRevision() === revision && scopeRef.current === scopedIdentity) {
                setHistoryError('This chat is saved on this device. Reopen history to retry syncing.');
            }
        }).finally(() => { saveInFlight.current.delete(key); });
    }, [activeSessionId, chatLoading, scopedIdentity, sessions, saveRevision]);

    const openChat = useCallback(() => {
        setIsOpen(true);
    }, []);

    const closeChat = useCallback(() => {
        setIsOpen(false);
        setIsFullscreen(false);
        setPanelView('chat');
        setHistorySearch('');
    }, []);

    const enterFullscreen = useCallback(() => {
        setIsOpen(true);
        setIsFullscreen(true);
        setPanelView('chat');
    }, []);

    const toggleFullscreen = useCallback(() => {
        setIsFullscreen((current) => !current);
    }, []);

    const exitFullscreen = useCallback(() => {
        setIsFullscreen(false);
    }, []);

    const setAgentPageProjectId = useCallback((projectId: string | null) => {
        setAgentPageProjectIdState(projectId);
        setPanelView('chat');
        setHistorySearch('');
        setSelectedRecommendationId(null);
        setResolvedRecommendationIds(new Set());
    }, []);

    const handleNewChat = useCallback(() => {
        restoreRequest.current++;
        upsertCurrentSession();
        setActiveSessionId(null);
        resetChatSession();
        setNewChatVersion((current) => current + 1);
        setPanelView('chat');
        setHistorySearch('');
    }, [resetChatSession, upsertCurrentSession]);

    const handleShowHistory = useCallback(() => {
        upsertCurrentSession();
        setPanelView('history');
        setSaveRevision(value => value + 1);
        void refreshHistory();
    }, [upsertCurrentSession, refreshHistory]);

    const handleShowNotifications = useCallback(() => {
        setPanelView('notifications');
    }, []);

    useEffect(() => {
        const show = () => {setPanelView('notifications');setIsOpen(true);};
        window.addEventListener('sttm:open-join-recommendation',show);
        return () => window.removeEventListener('sttm:open-join-recommendation',show);
    }, []);

    const handleSelectRecommendation = useCallback((recommendationId: string) => {
        setSelectedRecommendationId(recommendationId);
        setPanelView('chat');
        setIsOpen(true);
    }, []);

    const markRecommendationResolved = useCallback((recommendationId: string) => {
        setResolvedRecommendationIds((current) => {
            const next = new Set(current);
            next.add(recommendationId);
            return next;
        });
        setSelectedRecommendationId((current) =>
            current === recommendationId ? null : current,
        );
    }, []);

    const handleSelectSession = useCallback(
        (session: StoredChatSession) => {
            if (!scopedIdentity || chatLoading || !sessions.some(item => item.id === session.id)) return;
            const request = ++restoreRequest.current;
            const revision = cacheRevision();
            if (session.mode === 'deep' && session.backendConversationId) {
                setActiveSessionId(session.id);
                setPanelView('chat');
                window.dispatchEvent(new CustomEvent('aia:restore-assistant-conversation', {
                    detail: { conversationId: session.backendConversationId, mode: session.mode },
                }));
                return;
            }
            window.dispatchEvent(new CustomEvent('aia:select-assistant-mode', {
                detail: { mode: 'quick' },
            }));
            if (session.mode === 'quick' && session.backendConversationId) {
                void fetchAssistantConversation(session.backendConversationId).then(detail => {
                    if (request !== restoreRequest.current || cacheRevision() !== revision || scopeRef.current !== scopedIdentity) return;
                    const turns = detail.turns.filter(turn => turn.role === 'user' || turn.role === 'assistant');
                    const messages = turns.map(turn => ({
                        id: turn.metadata?.quick_message_id ?? turn.turn_id,
                        role: turn.role as 'user' | 'assistant',
                        content: turn.message,
                        status: turn.metadata?.status,
                        options: turn.metadata?.options,
                        requestId: turn.metadata?.request_id,
                        createdAt: turn.metadata?.created_at ?? turn.created_at,
                    }));
                    const logicalConversationId = turns.findLast(turn => turn.metadata?.logical_conversation_id)
                        ?.metadata?.logical_conversation_id ?? session.logicalConversationId ?? null;
                    setActiveSessionId(session.id);
                    restoreChatSession({ messages, logicalConversationId });
                    setPanelView('chat');
                }).catch(() => {
                    if (request === restoreRequest.current && cacheRevision() === revision && scopeRef.current === scopedIdentity) {
                        setHistoryError('This chat could not be reopened. Select it again to retry.');
                    }
                });
                return;
            }
            setActiveSessionId(session.id);
            restoreChatSession({ messages: session.messages, logicalConversationId: session.logicalConversationId ?? null });
            setPanelView('chat');
        },
        [restoreChatSession, scopedIdentity, sessions, chatLoading],
    );

    const handleDeleteSession = useCallback(async (session: StoredChatSession, archive = false) => {
        if (!scopedIdentity || !sessions.some(item => item.id === session.id)) return;
        if (saveInFlight.current.has(JSON.stringify([scopedIdentity, session.id]))
            || (session.id === activeSessionId && chatLoading)) {
            throw new Error('Wait for the current message to finish saving, then retry.');
        }
        const revision = cacheRevision();
        if (archive) {
            if (!session.backendConversationId) throw new Error('This chat needs to sync before it can be archived.');
            await setAssistantConversationArchived(session.backendConversationId, true);
        } else if (session.backendConversationId) {
            await deleteAssistantConversation(session.backendConversationId);
        }
        if (cacheRevision() !== revision || scopeRef.current !== scopedIdentity) return;
        historyRequest.current++;
        restoreRequest.current++;
        setHistoryLoading(false);
        setSessions((previous) => {
            const next = previous.filter((item) => item.id !== session.id);
            if (session.storageScope) {
                persistChatSessions(session.storageScope, loadStoredChatSessions(session.storageScope).filter((item) => item.id !== session.id));
            }
            return next;
        });
        if (activeSessionId === session.id) {
            resetChatSession();
            setActiveSessionId(null);
            setNewChatVersion((value) => value + 1);
        }
    }, [activeSessionId, chatLoading, resetChatSession, scopedIdentity, sessions]);

    const handleArchiveSession = useCallback((session: StoredChatSession) => handleDeleteSession(session, true), [handleDeleteSession]);

    const handleUpdateSession = useCallback(async (session: StoredChatSession, changes: { title?: string; projectId?: string | null; pinned?: boolean }) => {
        if (!scopedIdentity || !sessions.some(item => item.id === session.id)) return;
        const revision = cacheRevision();
        const updated = session.backendConversationId
            ? await updateAssistantConversation(session.backendConversationId, {
                ...(changes.title !== undefined ? { title: changes.title } : {}),
                ...(changes.projectId !== undefined ? { project_id: changes.projectId } : {}),
                ...(changes.pinned !== undefined ? { pinned: changes.pinned } : {}),
            })
            : null;
        if (cacheRevision() !== revision || scopeRef.current !== scopedIdentity) return;
        const patch = {
            title: updated?.title ?? changes.title ?? session.title,
            projectId: updated ? updated.project_id ?? null : changes.projectId !== undefined ? changes.projectId : session.projectId,
            sttmId: updated ? updated.sttm_id ?? null : changes.projectId !== undefined ? null : session.sttmId,
            pinned: updated?.pinned ?? changes.pinned ?? session.pinned ?? false,
        };
        setSessions((current) => current.map((item) => item.id === session.id ? { ...item, ...patch } : item));
        if (session.storageScope) {
            persistChatSessions(session.storageScope, loadStoredChatSessions(session.storageScope).map((item) => item.id === session.id ? { ...item, ...patch } : item));
        }
    }, [scopedIdentity, sessions]);

    const renameSession = useCallback(
        (sessionId: string, title: string) => {
            const nextTitle = title.trim();
            const existing = sessions.find(item => item.id === sessionId);
            if (!existing || !nextTitle) return;
            // Use the saved conversation's own scope, including local-only history.
            void handleUpdateSession(existing, { title: nextTitle })
                .catch(error => console.warn('Could not rename conversation', error));
        },
        [sessions, handleUpdateSession],
    );

    const deleteSession = useCallback(
        async (sessionId: string) => {
            const existing = sessions.find(item => item.id === sessionId);
            if (existing) await handleDeleteSession(existing);
        },
        [sessions, handleDeleteSession],
    );
    const beginRailDrag = useCallback(
        (event: React.MouseEvent<HTMLDivElement>) => {
            event.preventDefault();
            event.stopPropagation();
            isDraggingRailRef.current = false;

            const startY = event.clientY;
            const startTop = railTop;

            const onMove = (moveEvent: MouseEvent) => {
                const deltaY = moveEvent.clientY - startY;
                if (Math.abs(deltaY) > 4) {
                    isDraggingRailRef.current = true;
                }
                setRailTop(clampRailTop(startTop + deltaY, layoutHeight));
            };

            const onUp = () => {
                document.removeEventListener('mousemove', onMove);
                document.removeEventListener('mouseup', onUp);
                window.setTimeout(() => {
                    isDraggingRailRef.current = false;
                }, 0);
            };

            document.addEventListener('mousemove', onMove);
            document.addEventListener('mouseup', onUp);
        },
        [layoutHeight, railTop],
    );

    const beginRailTouchDrag = useCallback(
        (event: React.TouchEvent<HTMLDivElement>) => {
            event.stopPropagation();
            isDraggingRailRef.current = false;

            const startY = event.touches[0]?.clientY ?? 0;
            const startTop = railTop;

            const onMove = (moveEvent: TouchEvent) => {
                const clientY = moveEvent.touches[0]?.clientY;
                if (clientY == null) return;
                const deltaY = clientY - startY;
                if (Math.abs(deltaY) > 4) {
                    isDraggingRailRef.current = true;
                }
                setRailTop(clampRailTop(startTop + deltaY, layoutHeight));
            };

            const onEnd = () => {
                document.removeEventListener('touchmove', onMove);
                document.removeEventListener('touchend', onEnd);
                window.setTimeout(() => {
                    isDraggingRailRef.current = false;
                }, 0);
            };

            document.addEventListener('touchmove', onMove, { passive: false });
            document.addEventListener('touchend', onEnd);
        },
        [layoutHeight, railTop],
    );

    const beginSidebarResize = useCallback(
        (event: React.MouseEvent<HTMLDivElement>) => {
            if (isMobile || isTablet) return;
            event.preventDefault();
            setIsResizing(true);
            const startX = event.clientX;
            const startWidth = sidebarWidth;

            const onMove = (moveEvent: MouseEvent) => {
                const nextWidth = Math.min(
                    Math.min(AI_CHAT_MAX_SIDEBAR_WIDTH, layoutWidth - 16),
                    Math.max(AI_CHAT_MIN_SIDEBAR_WIDTH, startWidth + (startX - moveEvent.clientX)),
                );
                setSidebarWidth(nextWidth);
            };

            const onUp = () => {
                setIsResizing(false);
                document.removeEventListener('mousemove', onMove);
                document.removeEventListener('mouseup', onUp);
            };

            document.addEventListener('mousemove', onMove);
            document.addEventListener('mouseup', onUp);
        },
        [isMobile, isTablet, layoutWidth, sidebarWidth],
    );

    const value = useMemo(
        () => ({
            isOpen,
            isFullscreen,
            panelView,
            historySearch,
            sessions,
            historyLoading,
            historyError,
            activeSessionId,
            selectedRecommendationId,
            resolvedRecommendationIds,
            recentSessions: sessions.slice(0, 3),
            railTop,
            effectiveSidebarWidth,
            isResizing,
            isMobile,
            isTablet,
            layoutHeight,
            newChatVersion,
            agentPageProjectId,
            setLayoutMetrics,
            setHistorySearch,
            setPanelView,
            setAgentPageProjectId,
            openChat,
            closeChat,
            enterFullscreen,
            toggleFullscreen,
            exitFullscreen,
            handleNewChat,
            handleShowHistory,
            handleShowNotifications,
            handleSelectRecommendation,
            markRecommendationResolved,
            handleSelectSession,
            renameSession,
            deleteSession,
            handleDeleteSession,
            handleArchiveSession,
            handleUpdateSession,
            beginRailDrag,
            beginRailTouchDrag,
            beginSidebarResize,
        }),
        [
            isOpen,
            isFullscreen,
            panelView,
            historySearch,
            sessions,
            historyLoading,
            historyError,
            activeSessionId,
            selectedRecommendationId,
            resolvedRecommendationIds,
            railTop,
            effectiveSidebarWidth,
            isResizing,
            isMobile,
            isTablet,
            layoutHeight,
            agentPageProjectId,
            setLayoutMetrics,
            setHistorySearch,
            setPanelView,
            newChatVersion,
            agentPageProjectId,
            setLayoutMetrics,
            setAgentPageProjectId,
            openChat,
            closeChat,
            enterFullscreen,
            toggleFullscreen,
            exitFullscreen,
            handleNewChat,
            handleShowHistory,
            handleShowNotifications,
            handleSelectRecommendation,
            markRecommendationResolved,
            handleSelectSession,
            renameSession,
            deleteSession,
            handleDeleteSession,
            handleArchiveSession,
            handleUpdateSession,
            beginRailDrag,
            beginRailTouchDrag,
            beginSidebarResize,
        ],
    );

    return <AiChatLayoutContext.Provider value={value}>{children}</AiChatLayoutContext.Provider>;
}

export function useAiChatLayout() {
    const context = useContext(AiChatLayoutContext);
    if (!context) {
        throw new Error('useAiChatLayout must be used within AiChatLayoutProvider');
    }
    return context;
}
