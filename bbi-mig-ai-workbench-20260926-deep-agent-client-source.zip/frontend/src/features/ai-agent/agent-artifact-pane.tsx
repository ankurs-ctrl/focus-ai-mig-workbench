'use client';

import { useEffect, useMemo, useState, type MouseEvent, type ReactNode } from 'react';
import { Tab, Tabs } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import WrapTextIcon from '@mui/icons-material/WrapText';
import OpenInFullIcon from '@mui/icons-material/OpenInFull';
import CloseFullscreenIcon from '@mui/icons-material/CloseFullscreen';
import { AiaBox, AiaButton, AiaIconButton, AiaInput, AiaStack } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import { SqlHighlight } from '@/components/sql/sql-highlight';
import type { AgentSqlArtifact } from '@/features/ai-agent/agent-artifact-text';

export type AgentArtifactTab = 'research' | 'plan' | 'sql' | 'results';
export type { AgentSqlArtifact } from '@/features/ai-agent/agent-artifact-text';

type PlanChoice = { id?: string; label: string };

type AgentArtifactPaneProps = {
  pageMode: boolean;
  tab: AgentArtifactTab;
  onTabChange: (tab: AgentArtifactTab) => void;
  onClose: () => void;
  plan: Record<string, unknown> | null;
  planContent: ReactNode;
  researchContent: ReactNode;
  researchText: string;
  hasResearch: boolean;
  sqlArtifact: AgentSqlArtifact | null;
  sqlArtifacts?: AgentSqlArtifact[];
  planChoices: PlanChoice[];
  planEditQuestion: string | null;
  busy: boolean;
  sqlActionDisabled: boolean;
  sqlActionBlockReason?: string | null;
  onPlanChoice: (id: string, label: string) => void;
  onPlanFeedback: (feedback: string) => void;
  onSqlRevision: (sql: string, note: string, mappingName?: string) => void;
  onSqlReject: (reason: string, mappingName?: string) => void;
};

function resultCells(rows: string[], configuredColumns: string[]) {
  const parsed = rows.map((row) => {
    try {
      const value: unknown = JSON.parse(row);
      if (value && typeof value === 'object' && !Array.isArray(value)) {
        const record = value as Record<string, unknown>;
        const cells = record.values;
        return cells && typeof cells === 'object' && !Array.isArray(cells)
          ? cells as Record<string, unknown> : record;
      }
    } catch {
      // Older run records stored Pydantic's `values={...}` representation.
    }
    const legacy = row.startsWith('values=') ? row.slice(7) : row;
    const cells: Record<string, unknown> = {};
    const pairs = /'((?:\\.|[^'\\])*)':\s*(None|True|False|'(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*"|-?\d+(?:\.\d+)?)/g;
    for (const match of legacy.matchAll(pairs)) {
      const raw = match[2];
      cells[match[1]] = raw === 'None' ? null : raw === 'True' ? true : raw === 'False' ? false
        : raw.startsWith("'") || raw.startsWith('"') ? raw.slice(1, -1).replace(/\\'/g, "'").replace(/\\"/g, '"')
          : Number(raw);
    }
    return Object.keys(cells).length ? cells : null;
  });
  const columns = configuredColumns.length ? configuredColumns : Array.from(
    new Set(parsed.flatMap((row) => Object.keys(row ?? {}))),
  );
  return { parsed, columns };
}

const PANE_WIDTH_KEY = 'aia:review-pane-width';
const DEFAULT_PANE_WIDTH = 620;

function clampPaneWidth(width: number) {
  if (typeof window === 'undefined') return width;
  return Math.max(360, Math.min(width, Math.max(360, Math.min(window.innerWidth * 0.72, window.innerWidth - 520))));
}

export function AgentArtifactPane({
  pageMode, tab, onTabChange, onClose, plan, planContent, researchContent, researchText, hasResearch, sqlArtifact, sqlArtifacts,
  planChoices, planEditQuestion, busy, sqlActionDisabled, sqlActionBlockReason, onPlanChoice, onPlanFeedback,
  onSqlRevision, onSqlReject,
}: AgentArtifactPaneProps) {
  const [wordWrap, setWordWrap] = useState(true);
  const [sqlMode, setSqlMode] = useState<'read' | 'edit' | 'reject'>('read');
  const [sqlDraft, setSqlDraft] = useState(sqlArtifact?.sql ?? '');
  const [sqlNote, setSqlNote] = useState('');
  const [planFeedback, setPlanFeedback] = useState('');
  const [copyStatus, setCopyStatus] = useState('');
  const [selectedSqlIndex, setSelectedSqlIndex] = useState(() => tab === 'results'
    ? Math.max(0, sqlArtifacts?.findIndex((artifact) => artifact.previewRows.length > 0) ?? 0) : 0);
  const availableSqlArtifacts = sqlArtifacts?.length ? sqlArtifacts : sqlArtifact ? [sqlArtifact] : [];
  const activeSqlArtifact = availableSqlArtifacts[Math.min(selectedSqlIndex, availableSqlArtifacts.length - 1)] ?? null;
  const [paneWidth, setPaneWidth] = useState(DEFAULT_PANE_WIDTH);
  const [expandedWidth, setExpandedWidth] = useState(false);
  useEffect(() => {
    const stored = Number(window.localStorage.getItem(PANE_WIDTH_KEY));
    if (Number.isFinite(stored) && stored >= 360) setPaneWidth(clampPaneWidth(stored));
  }, []);
  const beginResize = (event: MouseEvent<HTMLDivElement>) => {
    if (!pageMode) return;
    event.preventDefault();
    const originalWidth = paneWidth;
    const startX = event.clientX;
    document.body.style.cursor = 'col-resize';
    document.body.style.userSelect = 'none';
    const move = (next: globalThis.MouseEvent) => {
      setExpandedWidth(false);
      setPaneWidth(clampPaneWidth(originalWidth + startX - next.clientX));
    };
    const stop = (next: globalThis.MouseEvent) => {
      const width = clampPaneWidth(originalWidth + startX - next.clientX);
      setPaneWidth(width);
      window.localStorage.setItem(PANE_WIDTH_KEY, String(width));
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', stop);
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', stop);
  };
  const availableTabs: AgentArtifactTab[] = [
    ...(hasResearch ? ['research' as const] : []),
    ...(plan ? ['plan' as const] : []),
    ...(activeSqlArtifact?.sql ? ['sql' as const] : []),
    ...(activeSqlArtifact?.previewRows.length ? ['results' as const] : []),
  ];
  const selectedTab = availableTabs.includes(tab) ? tab : availableTabs[0];
  const preview = useMemo(
    () => resultCells(activeSqlArtifact?.previewRows ?? [], activeSqlArtifact?.previewColumns ?? []),
    [activeSqlArtifact],
  );

  const copyCurrent = async () => {
    const text = selectedTab === 'sql' ? activeSqlArtifact?.sql ?? ''
      : selectedTab === 'results' ? activeSqlArtifact?.previewRows.join('\n') ?? ''
        : selectedTab === 'research' ? researchText : JSON.stringify(plan, null, 2);
    try {
      await navigator.clipboard.writeText(text);
      setCopyStatus('Copied');
    } catch {
      setCopyStatus('Copy failed');
    }
  };

  return (
    <AiaBox component="aside" aria-label="Plan and SQL review workspace" sx={{
      width: pageMode ? (expandedWidth ? 'min(72vw, calc(100vw - 520px))' : `${paneWidth}px`) : 'min(700px, 94vw)',
      minWidth: pageMode ? 360 : 0,
      flexShrink: 0,
      display: 'flex', flexDirection: 'column', minHeight: 0,
      position: pageMode ? 'relative' : 'fixed',
      top: pageMode ? undefined : 0, right: pageMode ? undefined : 0, bottom: pageMode ? undefined : 0,
      zIndex: pageMode ? 'auto' : 1500,
      backgroundColor: '#fff', borderLeft: '1px solid #dbe2ea',
      boxShadow: pageMode ? '-8px 0 24px rgba(15,23,42,0.05)' : '-18px 0 48px rgba(15,23,42,0.18)',
      '@media (max-width: 1100px)': { position: 'fixed', top: 0, right: 0, bottom: 0, zIndex: 1500, width: 'min(700px, 94vw)', minWidth: 0 },
    }}>
      {pageMode ? <AiaBox role="separator" aria-orientation="vertical" aria-label="Resize review workspace" aria-valuenow={paneWidth} aria-valuemin={360} aria-valuemax={Math.round(typeof window === 'undefined' ? 1200 : window.innerWidth * 0.72)} tabIndex={0} onMouseDown={beginResize} onKeyDown={(event: React.KeyboardEvent) => {
        if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight') return;
        event.preventDefault();
        const width = clampPaneWidth(paneWidth + (event.key === 'ArrowLeft' ? 24 : -24));
        setPaneWidth(width);
        setExpandedWidth(false);
        window.localStorage.setItem(PANE_WIDTH_KEY, String(width));
      }} sx={{ position: 'absolute', top: 0, left: -4, bottom: 0, width: 8, zIndex: 2, cursor: 'col-resize', '&:hover': { backgroundColor: '#bfdbfe' }, '&:focus-visible': { outline: '2px solid #2563eb' }, '@media (max-width: 1100px)': { display: 'none' } }} /> : null}
      <AiaStack direction="row" sx={{ px: 1.75, py: 1, alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid #e2e8f0', minHeight: 53 }}>
        <AiaBox>
          <AiaText sx={{ fontSize: 14, fontWeight: 800, color: '#0f172a' }}>Review workspace</AiaText>
          <AiaText sx={{ fontSize: 11, color: '#64748b' }}>Plan, generated SQL, and sample results</AiaText>
        </AiaBox>
        <AiaStack direction="row" spacing={0.25} sx={{ alignItems: 'center' }}>
          {pageMode ? <AiaIconButton size="small" aria-label={expandedWidth ? 'Restore review workspace width' : 'Expand review workspace'} title={expandedWidth ? 'Restore width' : 'Expand'} onClick={() => setExpandedWidth((current) => !current)}><AiaBox component={expandedWidth ? CloseFullscreenIcon : OpenInFullIcon} sx={{ fontSize: 17 }} /></AiaIconButton> : null}
          <AiaIconButton size="small" aria-label={wordWrap ? 'Turn word wrap off' : 'Turn word wrap on'} title={wordWrap ? 'Turn word wrap off' : 'Turn word wrap on'} aria-pressed={wordWrap} onClick={() => setWordWrap((current) => !current)} sx={{ color: wordWrap ? '#2563eb' : '#64748b' }}><WrapTextIcon fontSize="small" /></AiaIconButton>
          <AiaIconButton size="small" aria-label="Copy current tab" title="Copy current tab" onClick={() => void copyCurrent()}><ContentCopyIcon sx={{ fontSize: 18 }} /></AiaIconButton>
          <AiaIconButton size="small" aria-label="Close review workspace" title="Close" onClick={onClose}><CloseIcon fontSize="small" /></AiaIconButton>
        </AiaStack>
      </AiaStack>
      <Tabs value={selectedTab} onChange={(_, next: AgentArtifactTab) => onTabChange(next)} variant="scrollable" scrollButtons="auto" aria-label="Review artifacts" sx={{ minHeight: 42, borderBottom: '1px solid #e2e8f0', '& .MuiTab-root': { minHeight: 42, textTransform: 'none', fontSize: 12, fontWeight: 700 } }}>
        {hasResearch ? <Tab value="research" label="Research and gaps" /> : null}
        {plan ? <Tab value="plan" label={`Plan · revision ${String(plan.revision ?? 1)}`} /> : null}
        {activeSqlArtifact?.sql ? <Tab value="sql" label="SQL preview" /> : null}
        {activeSqlArtifact?.previewRows.length ? <Tab value="results" label={`Sample results · ${activeSqlArtifact.previewRowCount}`} /> : null}
      </Tabs>
      {availableSqlArtifacts.length > 1 && (selectedTab === 'sql' || selectedTab === 'results') ? <Tabs value={selectedSqlIndex} onChange={(_, index: number) => {
        setSelectedSqlIndex(index);
        setSqlDraft(availableSqlArtifacts[index].sql);
        setSqlMode('read');
        setSqlNote('');
      }} variant="scrollable" scrollButtons="auto" aria-label="Mapping SQL artifacts" sx={{ minHeight: 36, borderBottom: '1px solid #e2e8f0', '& .MuiTab-root': { minHeight: 36, textTransform: 'none', fontSize: 11 } }}>
        {availableSqlArtifacts.map((artifact, index) => <Tab key={`${artifact.mappingName ?? 'mapping'}:${index}`} label={artifact.mappingName ?? `Mapping ${index + 1}`} />)}
      </Tabs> : null}
      {copyStatus ? <AiaText role="status" sx={{ px: 2, pt: 0.5, fontSize: 11, color: copyStatus === 'Copied' ? '#047857' : '#b91c1c' }}>{copyStatus}</AiaText> : null}

      {selectedTab === 'research' && hasResearch ? <AiaBox role="tabpanel" aria-label="Migration research and evidence gaps" sx={{ flex: 1, minHeight: 0, overflow: 'auto', p: 2 }}>
        <AiaText sx={{ mb: 1.25, fontSize: 12, color: '#64748b' }}>Source decisions remain open. SQL and sample results appear here after a source graph and mapping plan pass validation.</AiaText>
        {researchContent}
      </AiaBox> : null}

      {selectedTab === 'plan' && plan ? <>
        <AiaBox role="tabpanel" aria-label="Migration plan" sx={{ flex: 1, minHeight: 0, overflow: 'auto', p: 1.5, '& pre': { whiteSpace: wordWrap ? 'pre-wrap !important' : 'pre !important', overflowWrap: wordWrap ? 'anywhere !important' : 'normal !important' } }}>
          {planContent}
        </AiaBox>
        {planEditQuestion ? <AiaBox sx={{ p: 1.5, borderTop: '1px solid #e2e8f0' }}>
          <AiaText sx={{ fontSize: 12, fontWeight: 700, mb: 0.75 }}>{planEditQuestion}</AiaText>
          <AiaInput multiline minRows={2} value={planFeedback} onChange={setPlanFeedback} placeholder="Describe the change to sources, joins, mappings, or validation" sx={{ '& .MuiInputBase-input': { fontSize: 13, lineHeight: 1.5 }, '& .MuiInputBase-input::placeholder': { fontSize: 13, opacity: 1, color: '#94a3b8' } }} />
          <AiaButton size="small" variant="contained" disabled={!planFeedback.trim() || busy} onClick={() => { onPlanFeedback(planFeedback.trim()); setPlanFeedback(''); }} sx={{ mt: 1, textTransform: 'none' }}>Submit plan changes</AiaButton>
        </AiaBox> : planChoices.length ? <AiaStack direction="row" spacing={0.75} sx={{ p: 1.5, borderTop: '1px solid #e2e8f0', flexWrap: 'wrap', rowGap: 0.75 }}>
          {planChoices.filter((choice) => ['approve', 'edit', 'reject'].includes(String(choice.id))).map((choice) => <AiaButton key={choice.id} size="small" variant={choice.id === 'approve' ? 'contained' : 'outlined'} disabled={busy} onClick={() => onPlanChoice(String(choice.id), choice.label)} sx={{ textTransform: 'none', color: choice.id === 'reject' ? '#b91c1c' : undefined, borderColor: choice.id === 'reject' ? '#fecaca' : undefined }}>
            {choice.id === 'approve' ? 'Implement plan' : choice.id === 'edit' ? 'Edit plan' : 'Reject'}
          </AiaButton>)}
        </AiaStack> : null}
      </> : null}

      {selectedTab === 'sql' && activeSqlArtifact ? <>
        <AiaStack direction="row" spacing={1} sx={{ px: 1.75, py: 1, alignItems: 'center', borderBottom: '1px solid #e2e8f0', flexWrap: 'wrap' }}>
          <AiaText sx={{ fontSize: 11, fontWeight: 700, color: activeSqlArtifact.compileValid ? '#047857' : '#b45309' }}>Compile {activeSqlArtifact.compileValid ? 'passed' : 'needs review'}</AiaText>
          <AiaText sx={{ fontSize: 11, color: '#94a3b8' }}>·</AiaText>
          <AiaText sx={{ fontSize: 11, fontWeight: 700, color: activeSqlArtifact.previewValid ? '#047857' : '#b45309' }}>Preview {activeSqlArtifact.previewValid ? 'passed' : 'needs review'}</AiaText>
          {activeSqlArtifact.mappedCount || activeSqlArtifact.unresolvedCount ? <AiaText sx={{ fontSize: 11, color: '#64748b' }}>· {activeSqlArtifact.mappedCount} mapped · {activeSqlArtifact.unresolvedCount} unresolved</AiaText> : null}
        </AiaStack>
        {sqlMode === 'edit' ? <AiaBox component="textarea" aria-label="Edit SQL preview" value={sqlDraft} onChange={(event: React.ChangeEvent<HTMLTextAreaElement>) => setSqlDraft(event.target.value)} wrap={wordWrap ? 'soft' : 'off'} sx={{ flex: 1, minHeight: 0, width: '100%', p: 2, resize: 'none', outline: 'none', border: 0, backgroundColor: '#0b1220', color: '#e5e7eb', fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace', fontSize: 12, lineHeight: 1.65, whiteSpace: wordWrap ? 'pre-wrap' : 'pre', overflowWrap: wordWrap ? 'anywhere' : 'normal' }} /> : <AiaBox role="tabpanel" aria-label="Generated SQL" sx={{ flex: 1, minHeight: 0, overflow: 'auto', backgroundColor: '#0b1220' }}>
          <AiaBox component="pre" sx={{ m: 0, p: 2, width: wordWrap ? '100%' : 'max-content', minWidth: '100%', color: '#e5e7eb', fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace', fontSize: 12, lineHeight: 1.65 }}>
            {activeSqlArtifact.sql.split('\n').map((line, index) => <AiaBox key={index} sx={{ display: 'grid', gridTemplateColumns: '35px minmax(0, 1fr)' }}>
              <AiaBox component="span" aria-hidden sx={{ pr: 1, mr: 1, textAlign: 'right', color: '#64748b', borderRight: '1px solid #334155', userSelect: 'none' }}>{index + 1}</AiaBox>
              <AiaBox component="code" sx={{ whiteSpace: wordWrap ? 'pre-wrap' : 'pre', overflowWrap: wordWrap ? 'anywhere' : 'normal' }}><SqlHighlight text={line || ' '} /></AiaBox>
            </AiaBox>)}
          </AiaBox>
        </AiaBox>}
        {sqlMode !== 'read' ? <AiaBox sx={{ px: 1.5, pt: 1, borderTop: '1px solid #e2e8f0' }}><AiaInput multiline minRows={2} value={sqlNote} onChange={setSqlNote} placeholder={sqlMode === 'reject' ? 'Why should this SQL be rejected?' : 'Explain any changes or validation concerns (optional)'} sx={{ '& .MuiInputBase-input': { fontSize: 13, lineHeight: 1.5 }, '& .MuiInputBase-input::placeholder': { fontSize: 13, opacity: 1, color: '#94a3b8' } }} /></AiaBox> : null}
        <AiaStack direction="row" spacing={0.75} sx={{ p: 1.5, borderTop: sqlMode === 'read' ? '1px solid #e2e8f0' : undefined, alignItems: 'center', flexWrap: 'wrap', rowGap: 0.75 }}>
          {sqlMode === 'read' ? <>
            <AiaButton size="small" variant="outlined" onClick={() => { setSqlDraft(activeSqlArtifact.sql); setSqlMode('edit'); }} sx={{ textTransform: 'none' }}>Edit SQL</AiaButton>
            <AiaButton size="small" variant="outlined" onClick={() => setSqlMode('reject')} sx={{ textTransform: 'none', color: '#b91c1c', borderColor: '#fecaca' }}>Reject SQL</AiaButton>
          </> : <>
            <AiaButton size="small" variant="contained" disabled={sqlActionDisabled || (sqlMode === 'edit' ? !sqlDraft.trim() || (sqlDraft === activeSqlArtifact.sql && !sqlNote.trim()) : !sqlNote.trim())} onClick={() => {
              if (sqlMode === 'edit') onSqlRevision(sqlDraft, sqlNote.trim(), activeSqlArtifact.mappingName);
              else onSqlReject(sqlNote.trim(), activeSqlArtifact.mappingName);
              setSqlMode('read'); setSqlNote('');
            }} sx={{ textTransform: 'none' }}>{sqlMode === 'edit' ? 'Request validation' : 'Send rejection'}</AiaButton>
            <AiaButton size="small" variant="text" onClick={() => { setSqlMode('read'); setSqlNote(''); setSqlDraft(activeSqlArtifact.sql); }} sx={{ textTransform: 'none' }}>Cancel</AiaButton>
          </>}
        </AiaStack>
        {sqlMode !== 'read' && sqlActionBlockReason ? <AiaText role="status" sx={{ px: 1.5, pb: 0.75, fontSize: 11.5, color: '#64748b' }}>{sqlActionBlockReason}</AiaText> : null}
        <AiaText sx={{ px: 1.5, pb: 1, fontSize: 10.5, color: '#64748b' }}>Edits and rejection feedback return to the agent for a new validated revision. The saved draft is not changed here.</AiaText>
      </> : null}

      {selectedTab === 'results' && activeSqlArtifact ? <AiaBox role="tabpanel" aria-label="Sample results" sx={{ flex: 1, minHeight: 0, overflow: 'auto', p: 1.5 }}>
        <AiaText sx={{ fontSize: 12, color: '#475569', mb: 1 }}>Bounded sample · {activeSqlArtifact.previewRowCount} rows</AiaText>
        {preview.columns.length && preview.parsed.every(Boolean) ? <AiaBox sx={{ overflow: 'auto', maxHeight: '100%', border: '1px solid #e2e8f0', borderRadius: 1.5 }}>
          <AiaBox component="table" sx={{ borderCollapse: 'separate', borderSpacing: 0, minWidth: '100%', width: 'max-content', fontSize: 12, fontVariantNumeric: 'tabular-nums' }}>
            <AiaBox component="thead"><AiaBox component="tr">{preview.columns.map((column) => <AiaBox component="th" key={column} scope="col" sx={{ position: 'sticky', top: 0, zIndex: 1, p: 1, textAlign: 'left', color: '#334155', backgroundColor: '#f1f5f9', borderBottom: '1px solid #cbd5e1', whiteSpace: 'nowrap' }}>{column}</AiaBox>)}</AiaBox></AiaBox>
            <AiaBox component="tbody">{preview.parsed.map((row, index) => <AiaBox component="tr" key={index} sx={{ backgroundColor: index % 2 ? '#f8fafc' : '#fff', '&:hover': { backgroundColor: '#eff6ff' } }}>{preview.columns.map((column) => <AiaBox component="td" key={column} sx={{ p: 1, color: row?.[column] == null ? '#94a3b8' : '#334155', borderBottom: '1px solid #e2e8f0', whiteSpace: wordWrap ? 'normal' : 'nowrap', overflowWrap: wordWrap ? 'anywhere' : 'normal', maxWidth: wordWrap ? 280 : undefined }}>{row?.[column] == null ? '—' : String(row[column])}</AiaBox>)}</AiaBox>)}</AiaBox>
          </AiaBox>
        </AiaBox> : <AiaBox component="pre" sx={{ m: 0, p: 1.5, borderRadius: 1.5, backgroundColor: '#f8fafc', color: '#334155', fontSize: 11, whiteSpace: wordWrap ? 'pre-wrap' : 'pre', overflowWrap: wordWrap ? 'anywhere' : 'normal' }}>{activeSqlArtifact.previewRows.join('\n')}</AiaBox>}
      </AiaBox> : null}
    </AiaBox>
  );
}
