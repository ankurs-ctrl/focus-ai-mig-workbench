export type SqlFunctionCategoryId =
  | 'string'
  | 'numeric'
  | 'date'
  | 'conversion'
  | 'logic'
  | 'window';

export type SqlFunctionCategory = {
  id: SqlFunctionCategoryId;
  label: string;
};

export type SqlSnippetAction = {
  id: string;
  label: string;
  snippet: string;
  /** When true, wraps existing editor content inside `()` functions like `UPPER()`. */
  wrapExisting?: boolean;
};

export type SqlInsertOptions = {
  wrapExisting?: boolean;
  /** When false, the snippet is inserted exactly at the caret. */
  separateTokens?: boolean;
  /**
   * When the user has highlighted part of `table.COLUMN`, replace that whole
   * reference instead of only the highlighted characters.
   */
  replaceColumnReference?: boolean;
};

export type SqlEditorProps = {
  value: string;
  onChange?: (next: string) => void;
  readOnly?: boolean;
  /** SQL identifiers offered by the editor. Tab or Enter accepts the active match. */
  suggestions?: string[];

  title?: string;
  subtitle?: string;
  /** Optional controls rendered in the SQL toolbar beside the built-in actions. */
  toolbarActions?: import('react').ReactNode;
  placeholder?: string;
  emptyText?: string;

  showCopy?: boolean;
  onCopy?: () => void | Promise<void>;
  onCopySuccess?: (message: string) => void;
  onCopyError?: (message: string) => void;

  showUpload?: boolean;
  onUpload?: (content: string, fileName: string) => void;
  onUploadError?: (message: string) => void;

  /** When true, renders the shared Function Library on the right of the editor. */
  showFunctionLibrary?: boolean;

  quickActions?: SqlSnippetAction[];
  functionCategories?: SqlFunctionCategory[];
  functionsByCategory?: Record<SqlFunctionCategoryId, string[]>;
  defaultFunctionCategory?: SqlFunctionCategoryId;

  /** Optional `data-tour` anchors for the function library panel (e.g. derived-table modal tour). */
  functionLibraryTourTargets?: {
    root?: string;
    library?: string;
    panel?: string;
    tabs?: string;
  };

  showLineNumbers?: boolean;
  /** SQL identifiers/keywords offered as inline ghost-text completions. Tab accepts the active completion. */
  completionCandidates?: string[];
  /** Fill parent height with min/max bounds instead of a fixed height. */
  fillHeight?: boolean;
  minHeight?: number | string;
  maxHeight?: number | string;
  className?: string;
  sx?: import('@mui/material/styles').SxProps;
  /**
   * Receives the editor's insert-at-cursor function. The last caret is kept
   * after the editor loses focus, so a sidebar click can insert there.
   */
  insertAtCursorRef?: import('react').MutableRefObject<
    ((snippet: string, options?: SqlInsertOptions) => void) | null
  >;
  /**
   * Keeps an editor undo stack for Ctrl+Z / Ctrl+Y. Off unless a caller opts in,
   * so other SQL editors keep their current undo behavior.
   */
  undoHistory?: boolean;
  /** Clears the undo stack when this value changes, for example when the row changes. */
  historyKey?: string | null;
};
