"""Administrator capacity operations. Health is read-only and never resumes jobs."""
from contextlib import contextmanager
from typing import Annotated, Literal
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field

from app.auth.dependencies import get_current_principal
from app.auth.models import AppPersona
from app.core.config import get_settings, Settings
from app.core.automap_admission import CallIdentity, StalePermit
from app.core.automap_durable_admission import DurableRunAdmission
from app.core.snowflake import caller_write_lease
from app.core.warehouse_routing import WarehouseWorkload
from app.api.deps import _request_user_token, _default_role_for_principal

router=APIRouter(prefix='/api/v1/auto-mapping/capacity',tags=['Auto Mapping Capacity'])


def admin_pool(request:Request,settings:Annotated[Settings,Depends(get_settings)], tracking:Literal["operations","legacy"]="operations"):
    principal=get_current_principal(request)
    if principal.app_persona is not AppPersona.ADMIN:
        raise HTTPException(status_code=403,detail='Administrator access required')
    if not settings.automap_durable_runs_v2:
        raise HTTPException(status_code=409,detail='Durable run capacity is not enabled')
    token=_request_user_token(request,settings);role=_default_role_for_principal(request,settings)
    @contextmanager
    def sessions():
        if settings.local_dev_auth_enabled and not token:
            from app.core.automap_local_session import local_session
            with local_session(settings,role) as session:
                yield session
            return
        with caller_write_lease(settings,token,role,WarehouseWorkload.CONTROL,reusable=True,maximum=2,
                                purpose='automap-recovery') as client:
            yield client.session
    from app.core.automap_operation_tracking import OperationCallTracking, operation_table
    use_operations = tracking == "operations" and not settings.automap_shared_capacity_limit
    pool_type = OperationCallTracking if use_operations else DurableRunAdmission
    table = operation_table(settings) if use_operations else settings.automap_parallel_permit_table_fqn
    return principal,pool_type(session_factory=sessions,table=table,
        account_namespace=settings.automap_parallel_account_namespace,pool_epoch=settings.automap_parallel_pool_epoch,
        capacity=settings.automap_parallel_pool_capacity,recovery_capacity=settings.automap_recovery_capacity)


class AbandonOperation(BaseModel):
    slot_id:int=Field(ge=1)
    fence:int=Field(ge=0)
    pool_epoch:str
    job_id:str=Field(min_length=1,max_length=256)
    caller_id:str=Field(min_length=1,max_length=256)
    generation:str=Field(min_length=1,max_length=256)
    shard_id:str=Field(min_length=1,max_length=256)
    reason:str=Field(min_length=1,max_length=256)
    dispatcher_retirement_verified:Literal[True]
    retirement_evidence:str=Field(min_length=1,max_length=256)
    acknowledge_unknown_remote_outcome:Literal[True]


@router.get('/health')
def health(context=Depends(admin_pool)):
    _,pool=context
    result=pool.health()
    if result.get("shared_capacity_limit") is False:
        return {**result,"all_unavailable":False,"needs_recovery":result["quarantined"]>0}
    result.update(execution_capacity=pool.capacity,recovery_capacity=pool.recovery_capacity,
        outstanding_ceiling=pool.inventory_capacity,all_unavailable=result['execution_free']==0,
        needs_recovery=result['quarantined']>0)
    return result


@router.post('/abandon')
def abandon(body:AbandonOperation,context=Depends(admin_pool)):
    principal,pool=context
    if body.pool_epoch!=pool.pool_epoch:
        raise HTTPException(status_code=409,detail='Pool epoch changed')
    try:
        permit=pool.operation(body.slot_id,body.fence,CallIdentity(body.job_id,body.caller_id,body.generation,body.shard_id))
        pool.operator_abandon(permit,actor=principal.snowflake_user,reason=body.reason,
            retirement_evidence=body.retirement_evidence,acknowledge_unknown=True)
    except StalePermit:
        raise HTTPException(status_code=409,detail='Operation changed; read the exact identity again') from None
    return {'outcome':'operator_abandoned','remote_outcome':'unknown','still_counted':True,
        'message':'Unknown exposure retained for background recovery; no terminal completion was fabricated.'}
