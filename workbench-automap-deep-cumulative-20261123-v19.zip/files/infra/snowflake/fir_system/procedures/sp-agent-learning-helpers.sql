-- Optional helper procedures for agent learning persistence.
-- The application also has a direct table MERGE fallback for restricted clients.

CREATE OR REPLACE PROCEDURE __STTM_METADATA_NAMESPACE__.SP_RECORD_AGENT_LEARNING(
    P_AGENT_TYPE VARCHAR,
    P_LEARNING_TYPE VARCHAR,
    P_SUMMARY VARCHAR,
    P_ATTRIBUTES VARIANT,
    P_ENTITY_TYPE VARCHAR,
    P_ENTITY_IDS VARIANT,
    P_TAGS ARRAY,
    P_CONFIDENCE FLOAT,
    P_CREATED_BY VARCHAR
)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS OWNER
AS
$$
DECLARE
    V_LEARNING_ID VARCHAR DEFAULT 'lrn_' || UUID_STRING();
    V_LEARNING_KEY VARCHAR;
    V_TRUST_STAGE VARCHAR DEFAULT 'observation';
    V_ATTRIBUTES VARIANT;
    V_EVIDENCE_IDS VARIANT;
    V_AUTHORITY_COUNT INTEGER DEFAULT 0;
BEGIN
    SELECT CASE WHEN
        :P_ATTRIBUTES:learning_evidence:contract_version::STRING = 'mapping_evidence_v1'
        AND NULLIF(:P_ENTITY_IDS:project_id::STRING, '') IS NOT NULL
        AND NULLIF(:P_ENTITY_IDS:sttm_id::STRING, '') IS NOT NULL
        AND :P_ATTRIBUTES:learning_evidence:project_id::STRING = :P_ENTITY_IDS:project_id::STRING
        AND :P_ATTRIBUTES:learning_evidence:sttm_id::STRING = :P_ENTITY_IDS:sttm_id::STRING
        AND NULLIF(:P_ATTRIBUTES:learning_evidence:snapshot_id::STRING, '') IS NOT NULL
        AND NULLIF(:P_ATTRIBUTES:learning_evidence:event_id::STRING, '') IS NOT NULL
        AND (
            (:P_ATTRIBUTES:learning_evidence:stage::STRING = 'published'
                AND NULLIF(:P_ATTRIBUTES:learning_evidence:version_id::STRING, '') IS NOT NULL)
            OR (:P_ATTRIBUTES:learning_evidence:stage::STRING IN ('accepted', 'corrected')
                AND NULLIF(:P_ATTRIBUTES:learning_evidence:actor_id::STRING, '') IS NOT NULL)
            OR (:P_ATTRIBUTES:learning_evidence:stage::STRING = 'validated'
                AND NULLIF(:P_ATTRIBUTES:learning_evidence:validation_receipt_id::STRING, '') IS NOT NULL)
        ) THEN :P_ATTRIBUTES:learning_evidence:stage::STRING ELSE 'observation' END
      INTO :V_TRUST_STAGE;
    IF (V_TRUST_STAGE <> 'observation') THEN
        SELECT COUNT(*) INTO :V_AUTHORITY_COUNT
        FROM __STTM_METADATA_NAMESPACE__.TBL_WORKBENCH_FIR_EVENTS e
        JOIN __STTM_METADATA_NAMESPACE__.TBL_WORKSPACE_SNAPSHOTS s ON s.SNAPSHOT_ID = e.SNAPSHOT_ID
        LEFT JOIN __STTM_METADATA_NAMESPACE__.TBL_STTM_VERSIONS v
          ON v.SNAPSHOT_ID = s.SNAPSHOT_ID AND TO_VARCHAR(v.STTM_ID) = s.STTM_ID,
        LATERAL FLATTEN(INPUT => s.SNAPSHOT_PAYLOAD:mapping_rows) r
        WHERE e.EVENT_ID = :P_ATTRIBUTES:learning_evidence:event_id::STRING
          AND s.SNAPSHOT_ID = :P_ATTRIBUTES:learning_evidence:snapshot_id::STRING
          AND s.PROJECT_ID = :P_ENTITY_IDS:project_id::STRING
          AND s.STTM_ID = :P_ENTITY_IDS:sttm_id::STRING
          AND COALESCE(s.RUNTIME_SUPPRESSED, FALSE) = FALSE
          AND r.VALUE:target_column::STRING = :P_ATTRIBUTES:target_column::STRING
          AND LOWER(r.VALUE:status::STRING) = 'mapped'
          AND COALESCE(:P_ATTRIBUTES:canonical_decision, :P_ATTRIBUTES:correct_decision) =
              OBJECT_CONSTRUCT_KEEP_NULL(
                  'source_columns', ARRAY_SORT(COALESCE(r.VALUE:source_columns::ARRAY, ARRAY_CONSTRUCT())),
                  'source_dependencies', ARRAY_SORT(COALESCE(r.VALUE:source_dependencies::ARRAY, ARRAY_CONSTRUCT())),
                  'mapping_mode', COALESCE(r.VALUE:mapping_mode::STRING, 'source'),
                  'expression', COALESCE(r.VALUE:expression::STRING, ''),
                  'constant_value', r.VALUE:constant_value,
                  'attribute_name', r.VALUE:attribute_name,
                  'value_binding_ids', ARRAY_SORT(COALESCE(r.VALUE:value_binding_ids::ARRAY, ARRAY_CONSTRUCT())))
          AND (:P_ATTRIBUTES:canonical_decision IS NULL OR (
              COALESCE(:P_ATTRIBUTES:expression::STRING, '') = :P_ATTRIBUTES:canonical_decision:expression::STRING
              AND ARRAY_SORT(COALESCE(:P_ATTRIBUTES:source_columns::ARRAY, ARRAY_CONSTRUCT())) = :P_ATTRIBUTES:canonical_decision:source_columns))
          AND (:P_ATTRIBUTES:incorrect_decision IS NULL OR (
              :V_TRUST_STAGE = 'corrected' AND e.EVENT_PAYLOAD:before = :P_ATTRIBUTES:incorrect_decision
              AND e.EVENT_PAYLOAD:scope_hash = :P_ATTRIBUTES:scope_hash))
          AND (
              (:V_TRUST_STAGE IN ('accepted', 'corrected')
               AND e.EVENT_TYPE = 'mapping.' || :V_TRUST_STAGE
               AND e.USER_ID = :P_ATTRIBUTES:learning_evidence:actor_id::STRING
               AND :P_ATTRIBUTES:learning_evidence:target_column = :P_ATTRIBUTES:target_column
               AND e.EVENT_PAYLOAD:target_column = :P_ATTRIBUTES:target_column
               AND e.EVENT_PAYLOAD:learning_evidence = :P_ATTRIBUTES:learning_evidence
               AND e.EVENT_PAYLOAD:after = COALESCE(:P_ATTRIBUTES:canonical_decision, :P_ATTRIBUTES:correct_decision))
              OR (:V_TRUST_STAGE = 'validated' AND e.EVENT_TYPE = 'mapping.compiler_validated'
                  AND e.EVENT_PAYLOAD:validation_kind::STRING = 'snowflake_explain'
                  AND e.EVENT_ID = :P_ATTRIBUTES:learning_evidence:validation_receipt_id::STRING
                  AND e.EVENT_PAYLOAD:contract_hash = :P_ATTRIBUTES:learning_evidence:contract_hash
                  AND e.EVENT_PAYLOAD:sql_hash = :P_ATTRIBUTES:learning_evidence:sql_hash
                  AND ARRAY_CONTAINS(:P_ATTRIBUTES:target_column, e.EVENT_PAYLOAD:target_columns::ARRAY))
              OR (:V_TRUST_STAGE = 'published' AND e.EVENT_TYPE = 'sttm.published'
                  AND TO_VARCHAR(v.VERSION_ID) = :P_ATTRIBUTES:learning_evidence:version_id::STRING)
          );
        -- Structural records and older shapes need application-side projection
        -- verification; this general SQL entry point must not self-certify them.
        IF (V_AUTHORITY_COUNT = 0) THEN
            V_TRUST_STAGE := 'observation';
        END IF;
    END IF;
    V_ATTRIBUTES := OBJECT_INSERT(OBJECT_INSERT(OBJECT_INSERT(
        COALESCE(P_ATTRIBUTES, OBJECT_CONSTRUCT()), 'learning_contract_version', 'mapping_evidence_v1', TRUE),
        'trust_stage', V_TRUST_STAGE, TRUE), 'validation_status', V_TRUST_STAGE, TRUE);
    SELECT IFF(:V_TRUST_STAGE = 'observation', ARRAY_CONSTRUCT(),
        ARRAY_SORT(ARRAY_DISTINCT(ARRAY_CONSTRUCT_COMPACT(
            :P_ATTRIBUTES:learning_evidence:event_id::STRING,
            :P_ATTRIBUTES:learning_evidence:snapshot_id::STRING,
            :P_ATTRIBUTES:learning_evidence:version_id::STRING,
            :P_ATTRIBUTES:learning_evidence:validation_receipt_id::STRING))))
      INTO :V_EVIDENCE_IDS;
    V_LEARNING_KEY := MD5(
        COALESCE(P_AGENT_TYPE, '') || '|' ||
        COALESCE(P_LEARNING_TYPE, '') || '|' ||
        COALESCE(TO_JSON(V_ATTRIBUTES), '') || '|' || COALESCE(TO_JSON(P_ENTITY_IDS), '')
    );
    IF (V_TRUST_STAGE <> 'observation') THEN
        SELECT SHA2(TO_JSON(ARRAY_CONSTRUCT('mapping_evidence_v1', :P_AGENT_TYPE, :P_LEARNING_TYPE,
            COALESCE(:P_ENTITY_IDS:project_id::STRING, ''), COALESCE(:P_ENTITY_IDS:sttm_id::STRING, ''),
            COALESCE(:P_ATTRIBUTES:learning_evidence:event_id::STRING, ''),
            COALESCE(:P_ATTRIBUTES:target_column::STRING, ''), COALESCE(:P_ATTRIBUTES:name::STRING, ''),
            COALESCE(:P_ATTRIBUTES:left_table::STRING, ''), COALESCE(:P_ATTRIBUTES:right_table::STRING, ''))), 256)
          INTO :V_LEARNING_KEY;
    END IF;

    MERGE INTO __STTM_METADATA_NAMESPACE__.TBL_AGENT_LEARNINGS target
    USING (
        SELECT
            :V_LEARNING_ID AS LEARNING_ID,
            :P_AGENT_TYPE AS AGENT_TYPE,
            :P_LEARNING_TYPE AS LEARNING_TYPE,
            :V_LEARNING_KEY AS LEARNING_KEY,
            :P_SUMMARY AS SUMMARY,
            :P_CONFIDENCE AS CONFIDENCE,
            :P_ENTITY_TYPE AS ENTITY_TYPE,
            :P_ENTITY_IDS AS ENTITY_IDS,
            :V_ATTRIBUTES AS ATTRIBUTES,
            :V_TRUST_STAGE AS TRUST_STAGE,
            :V_EVIDENCE_IDS AS EVIDENCE_IDS,
            :P_TAGS AS TAGS,
            :P_CREATED_BY AS CREATED_BY
    ) source
    ON target.LEARNING_KEY = source.LEARNING_KEY
    WHEN MATCHED AND target.STATUS = 'active' AND target.SUPERSEDED_BY IS NULL THEN UPDATE SET
        SUMMARY = source.SUMMARY,
        CONFIDENCE = GREATEST(
            COALESCE(target.CONFIDENCE, 0),
            source.CONFIDENCE
        ),
        ENTITY_TYPE = COALESCE(source.ENTITY_TYPE, target.ENTITY_TYPE),
        ENTITY_IDS = COALESCE(source.ENTITY_IDS, target.ENTITY_IDS),
        ATTRIBUTES = source.ATTRIBUTES,
        TRUST_STAGE = source.TRUST_STAGE,
        EVIDENCE_IDS = source.EVIDENCE_IDS,
        TAGS = COALESCE(source.TAGS, target.TAGS),
        LAST_USED_AT = CURRENT_TIMESTAMP()
    WHEN NOT MATCHED THEN INSERT (
        LEARNING_ID, AGENT_TYPE, LEARNING_TYPE, LEARNING_KEY, SUMMARY,
        CONFIDENCE, ENTITY_TYPE, ENTITY_IDS, ATTRIBUTES, TAGS,
        CREATED_BY, STATUS, TRUST_STAGE, EVIDENCE_IDS
    ) VALUES (
        source.LEARNING_ID, source.AGENT_TYPE, source.LEARNING_TYPE,
        source.LEARNING_KEY, source.SUMMARY, source.CONFIDENCE,
        source.ENTITY_TYPE, source.ENTITY_IDS, source.ATTRIBUTES,
        source.TAGS, source.CREATED_BY, 'active', source.TRUST_STAGE, source.EVIDENCE_IDS
    );

    SELECT LEARNING_ID
      INTO :V_LEARNING_ID
      FROM __STTM_METADATA_NAMESPACE__.TBL_AGENT_LEARNINGS
     WHERE LEARNING_KEY = :V_LEARNING_KEY
       AND STATUS = 'active'
       AND SUPERSEDED_BY IS NULL
     ORDER BY CREATED_AT DESC
     LIMIT 1;

    RETURN V_LEARNING_ID;
END;
$$;

CREATE OR REPLACE PROCEDURE __STTM_METADATA_NAMESPACE__.SP_TRACK_LEARNING_USAGE(
    P_LEARNING_ID VARCHAR,
    P_WAS_SUCCESSFUL BOOLEAN
)
RETURNS BOOLEAN
LANGUAGE SQL
EXECUTE AS OWNER
AS
$$
BEGIN
    UPDATE __STTM_METADATA_NAMESPACE__.TBL_AGENT_LEARNINGS
       SET USAGE_COUNT = COALESCE(USAGE_COUNT, 0) + 1,
           SUCCESS_COUNT = COALESCE(SUCCESS_COUNT, 0)
               + IFF(:P_WAS_SUCCESSFUL, 1, 0),
           LAST_USED_AT = CURRENT_TIMESTAMP()
     WHERE LEARNING_ID = :P_LEARNING_ID;
    RETURN TRUE;
END;
$$;
