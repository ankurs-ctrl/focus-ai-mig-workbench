from __future__ import annotations

import json
import threading
from contextlib import contextmanager
from abc import ABC, abstractmethod
from collections.abc import Mapping
from datetime import UTC, datetime, timedelta
from typing import Any
from functools import wraps

from app.agent_runs.models import (
    AgentCommandReceipt,
    AgentReviewItem,
    AgentRun,
    AgentRunEvent,
    AgentRunStep,
    MappingDagNode,
    ReviewItemStatus,
    RunStatus,
    StepStatus,
)


def fenced_write(method):
    @wraps(method)
    def guarded(self, *args, **kwargs):
        if self._lease_fence is None:
            return method(self, *args, **kwargs)
        with self.command_transaction():
            return method(self, *args, **kwargs)
    return guarded


class AgentRunRepository(ABC):
    @abstractmethod
    def create_run(self, run: AgentRun) -> AgentRun: ...

    @abstractmethod
    def find_run_by_idempotency(self, actor_user_id: str, key: str) -> AgentRun | None: ...

    @abstractmethod
    def get_run(self, run_id: str) -> AgentRun | None: ...

    @abstractmethod
    def get_latest_run(self, actor_user_id: str, tenant_id: str) -> AgentRun | None: ...

    @abstractmethod
    def list_runs_for_conversation(self, conversation_id: str, actor_user_id: str, tenant_id: str) -> list[AgentRun]: ...

    def latest_conversation_summary(
        self, conversation_id: str, actor_user_id: str, tenant_id: str, *, exclude_run_id: str | None = None,
    ) -> str:
        """The newest supervisor compaction summary from this user's earlier runs in the conversation."""
        return ""

    def get_latest_run_for_conversation(
        self, conversation_id: str, actor_user_id: str, tenant_id: str
    ) -> AgentRun | None:
        """The newest run only; a turn never needs the whole run history."""
        runs = self.list_runs_for_conversation(conversation_id, actor_user_id, tenant_id)
        return runs[-1] if runs else None

    def latest_budget_usage(self, run_id: str) -> dict[str, Any] | None:
        return None

    @abstractmethod
    def save_run(self, run: AgentRun) -> AgentRun: ...

    @abstractmethod
    def save_run_if_current(self, run: AgentRun, previous: AgentRun) -> AgentRun: ...

    @abstractmethod
    def save_run_owned(self, run: AgentRun) -> AgentRun:
        """Save worker state only while its exact lease generation remains valid."""
        ...

    @abstractmethod
    def acquire_lease(self, worker_id: str, lease_seconds: int) -> AgentRun | None: ...

    @abstractmethod
    def renew_lease(self, run_id: str, worker_id: str, lease_seconds: int, generation: int | None = None) -> bool: ...

    @abstractmethod
    def release_lease(self, run_id: str, worker_id: str, generation: int | None = None) -> None: ...

    @abstractmethod
    def append_event(self, event: AgentRunEvent) -> AgentRunEvent: ...

    def append_events(self, events: list[AgentRunEvent]) -> list[AgentRunEvent]:
        """Append an ordered event batch.

        Stores without a native batch implementation retain the exact contract
        by appending serially. Production Snowflake overrides this to amortize
        the transactional cursor reservation across the whole batch.
        """
        return [self.append_event(event) for event in events]

    @abstractmethod
    def list_events(self, run_id: str, after: int = 0, limit: int = 500) -> list[AgentRunEvent]: ...

    def list_events_by_type(
        self, run_id: str, event_types: set[str] | frozenset[str], limit: int = 500
    ) -> list[AgentRunEvent]:
        """Ordered events of the given types, without transferring the rest."""
        return [event for event in self.list_events(run_id, limit=limit) if event.event_type in event_types]

    @abstractmethod
    def save_step(self, step: AgentRunStep) -> AgentRunStep: ...

    @abstractmethod
    def list_steps(self, run_id: str) -> list[AgentRunStep]: ...

    @abstractmethod
    def save_review_item(self, item: AgentReviewItem) -> AgentReviewItem: ...

    @abstractmethod
    def answer_review_item(self, item: AgentReviewItem) -> bool: ...

    @abstractmethod
    def get_review_item(self, run_id: str, item_id: str) -> AgentReviewItem | None: ...

    @abstractmethod
    def list_review_items(self, run_id: str) -> list[AgentReviewItem]: ...

    def find_answered_decisions(
        self, actor_user_id: str, tenant_id: str, subject_keys: list[str], limit: int = 200,
        *, exclude_run_id: str | None = None,
    ) -> list[AgentReviewItem]:
        """Answered decision checkpoints from this user's earlier runs, newest first."""
        return []

    @abstractmethod
    def save_dag_node(self, node: MappingDagNode) -> MappingDagNode: ...

    @abstractmethod
    def list_dag_nodes(self, run_id: str) -> list[MappingDagNode]: ...

    @abstractmethod
    def get_command_receipt(self, idempotency_key: str) -> AgentCommandReceipt | None: ...

    @abstractmethod
    def save_command_receipt(self, receipt: AgentCommandReceipt) -> AgentCommandReceipt: ...

    @abstractmethod
    def save_evaluation(self, evaluation_id: str, run_id: str, payload: dict[str, Any]) -> None: ...

    @abstractmethod
    def command_transaction(self): ...


class InMemoryAgentRunRepository(AgentRunRepository):
    """Deterministic repository for tests and local development.

    Production uses :class:`SnowflakeAgentRunRepository`; the same lease and replay
    semantics are deliberately exercised here without a database dependency.
    """

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._runs: dict[str, AgentRun] = {}
        self._idempotency: dict[tuple[str, str], str] = {}
        self._events: dict[str, list[AgentRunEvent]] = {}
        self._steps: dict[tuple[str, str], AgentRunStep] = {}
        self._review_items: dict[tuple[str, str], AgentReviewItem] = {}
        self._dag: dict[tuple[str, str], MappingDagNode] = {}
        self._commands: dict[str, AgentCommandReceipt] = {}
        self._event_sequences: dict[str, int] = {}
        self._evaluations: dict[str, dict[str, Any]] = {}

    @staticmethod
    def _copy(value: Any) -> Any:
        return value.model_copy(deep=True)

    def create_run(self, run: AgentRun) -> AgentRun:
        with self._lock:
            if run.run_id in self._runs:
                return self._copy(self._runs[run.run_id])
            key = run.request.idempotency_key
            if key:
                existing_id = self._idempotency.get((run.actor.user_id, key))
                if existing_id:
                    existing = self._runs[existing_id]
                    if existing.request_hash != run.request_hash:
                        raise ValueError("Idempotency key was already used for a different run request")
                    return self._copy(existing)
                self._idempotency[(run.actor.user_id, key)] = run.run_id
            self._runs[run.run_id] = self._copy(run)
            return self._copy(run)

    def find_run_by_idempotency(self, actor_user_id: str, key: str) -> AgentRun | None:
        with self._lock:
            run_id = self._idempotency.get((actor_user_id, key))
            return self._copy(self._runs[run_id]) if run_id else None

    def latest_budget_usage(self, run_id: str) -> dict[str, Any] | None:
        with self._lock:
            for event in reversed(self._events.get(run_id, [])):
                value = event.data.get("budget_usage")
                if isinstance(value, dict):
                    return dict(value)
        return None

    def get_run(self, run_id: str) -> AgentRun | None:
        with self._lock:
            run = self._runs.get(run_id)
            return self._copy(run) if run else None

    def get_latest_run(self, actor_user_id: str, tenant_id: str) -> AgentRun | None:
        with self._lock:
            eligible = [
                run
                for run in self._runs.values()
                if run.actor.user_id == actor_user_id and run.actor.tenant_id == tenant_id
            ]
            if not eligible:
                return None
            return self._copy(max(eligible, key=lambda run: run.created_at))

    def list_runs_for_conversation(self, conversation_id: str, actor_user_id: str, tenant_id: str) -> list[AgentRun]:
        with self._lock:
            eligible = [
                run for run in self._runs.values()
                if run.actor.user_id == actor_user_id
                and run.actor.tenant_id == tenant_id
                and run.request.conversation_id == conversation_id
            ]
            return [self._copy(run) for run in sorted(eligible, key=lambda item: item.created_at)]

    def save_run(self, run: AgentRun) -> AgentRun:
        with self._lock:
            run.updated_at = datetime.now(UTC)
            self._runs[run.run_id] = self._copy(run)
            return self._copy(run)

    def save_run_owned(self, run: AgentRun) -> AgentRun:
        from app.agent_runtime.execution import ExecutionLeaseLostError
        with self._lock:
            current = self._runs.get(run.run_id)
            if (current is None or not run.lease_owner or current.lease_owner != run.lease_owner
                    or current.lease_generation != run.lease_generation
                    or current.lease_expires_at is None or current.lease_expires_at <= datetime.now(UTC)):
                raise ExecutionLeaseLostError('Worker state rejected by the durable lease fence')
            # Do not replace a concurrent heartbeat or erase a user cancellation.
            run.lease_expires_at = current.lease_expires_at
            run.heartbeat_at = current.heartbeat_at
            run.cancel_requested_at = current.cancel_requested_at or run.cancel_requested_at
            run.cancel_reason = current.cancel_reason or run.cancel_reason
            run.run_revision = max(current.run_revision, run.run_revision)
            if run.cancel_requested_at and run.status != RunStatus.CANCELLED:
                from app.agent_runtime.execution import ExecutionCancelledError
                raise ExecutionCancelledError('Cancellation must be acknowledged before saving worker state')
            return self.save_run(run)

    def save_run_if_current(self, run: AgentRun, previous: AgentRun) -> AgentRun:
        with self._lock:
            current = self._runs.get(run.run_id)
            fields = ('status', 'run_revision', 'lease_generation', 'cancel_requested_at')
            if current is None or any(getattr(current, key) != getattr(previous, key) for key in fields):
                from app.agent_runs.service import RunConflictError
                raise RunConflictError('The run changed; refresh before applying this decision')
            run.run_revision = previous.run_revision + 1
            run.lease_owner, run.lease_expires_at = current.lease_owner, current.lease_expires_at
            return self.save_run(run)

    def acquire_lease(self, worker_id: str, lease_seconds: int) -> AgentRun | None:
        now = datetime.now(UTC)
        with self._lock:
            eligible = sorted(
                (
                    run for run in self._runs.values()
                    if run.status not in {
                        RunStatus.READY_FOR_REVIEW,
                        RunStatus.COMPLETED,
                        RunStatus.COMPLETED_WITH_REVIEW_ITEMS,
                        RunStatus.FAILED,
                        RunStatus.NEEDS_REVIEW,
                        RunStatus.CANCELLED,
                        RunStatus.EXPIRED,
                        RunStatus.AWAITING_INPUT,
                        RunStatus.AWAITING_CONFIRMATION,
                    }
                    and (run.lease_expires_at is None or run.lease_expires_at <= now)
                ),
                key=lambda item: item.created_at,
            )
            if not eligible:
                return None
            run = eligible[0]
            run.lease_generation += 1
            run.lease_owner = worker_id
            run.lease_expires_at = now + timedelta(seconds=lease_seconds)
            run.heartbeat_at = now
            run.updated_at = now
            return self._copy(run)

    def renew_lease(self, run_id: str, worker_id: str, lease_seconds: int, generation: int | None = None) -> bool:
        now = datetime.now(UTC)
        with self._lock:
            run = self._runs.get(run_id)
            if (run is None or run.lease_owner != worker_id or run.lease_expires_at is None
                    or run.lease_expires_at <= now
                    or (generation is not None and run.lease_generation != generation)):
                return False
            run.heartbeat_at = now
            run.lease_expires_at = now + timedelta(seconds=lease_seconds)
            run.updated_at = now
            return True

    def release_lease(self, run_id: str, worker_id: str, generation: int | None = None) -> None:
        with self._lock:
            run = self._runs.get(run_id)
            if run and run.lease_owner == worker_id and (generation is None or run.lease_generation == generation):
                run.lease_owner = None
                run.lease_expires_at = None
                run.updated_at = datetime.now(UTC)

    def append_event(self, event: AgentRunEvent) -> AgentRunEvent:
        return self.append_events([event])[0]

    def append_events(self, events: list[AgentRunEvent]) -> list[AgentRunEvent]:
        if not events:
            return []
        with self._lock:
            run_ids = {event.run_id for event in events}
            if len(run_ids) != 1:
                raise ValueError("An event batch must belong to one migration run")
            run_id = events[0].run_id
            next_sequence = self._event_sequences.get(run_id, 0)
            stored: list[AgentRunEvent] = []
            for event in events:
                next_sequence += 1
                event.sequence = next_sequence
                copied = self._copy(event)
                self._events.setdefault(run_id, []).append(copied)
                stored.append(self._copy(copied))
            self._event_sequences[run_id] = next_sequence
            return stored

    def list_events(self, run_id: str, after: int = 0, limit: int = 500) -> list[AgentRunEvent]:
        with self._lock:
            return [
                self._copy(event)
                for event in self._events.get(run_id, [])
                if event.sequence > after
            ][:limit]

    def save_step(self, step: AgentRunStep) -> AgentRunStep:
        with self._lock:
            self._steps[(step.run_id, step.step_id)] = self._copy(step)
            return self._copy(step)

    def list_steps(self, run_id: str) -> list[AgentRunStep]:
        with self._lock:
            return [
                self._copy(step)
                for (candidate_run_id, _), step in self._steps.items()
                if candidate_run_id == run_id
            ]

    def save_review_item(self, item: AgentReviewItem) -> AgentReviewItem:
        with self._lock:
            self._review_items[(item.run_id, item.review_item_id)] = self._copy(item)
            return self._copy(item)

    def answer_review_item(self, item: AgentReviewItem) -> bool:
        with self._lock:
            key = (item.run_id, item.review_item_id)
            current = self._review_items.get(key)
            if current is None or current.status is not ReviewItemStatus.OPEN:
                return False
            self._review_items[key] = self._copy(item)
            return True

    def get_review_item(self, run_id: str, item_id: str) -> AgentReviewItem | None:
        with self._lock:
            item = self._review_items.get((run_id, item_id))
            return self._copy(item) if item else None

    def list_review_items(self, run_id: str) -> list[AgentReviewItem]:
        with self._lock:
            return [
                self._copy(item)
                for (candidate_run_id, _), item in self._review_items.items()
                if candidate_run_id == run_id
            ]

    def find_answered_decisions(
        self, actor_user_id: str, tenant_id: str, subject_keys: list[str], limit: int = 200,
        *, exclude_run_id: str | None = None,
    ) -> list[AgentReviewItem]:
        keys = set(subject_keys)
        with self._lock:
            current = self._runs.get(exclude_run_id or "")
            cutoff = current.created_at if current else None
            owned = {
                run_id for run_id, run in self._runs.items()
                if run.actor.user_id == actor_user_id and run.actor.tenant_id == tenant_id
                and run_id != exclude_run_id
            }
            matches = [
                item for (run_id, _), item in self._review_items.items()
                if run_id in owned
                and item.status.value in {"ANSWERED", "RESOLVED"}
                and item.category in {"confidence_gate", "confidence_gate_batch"}
                and keys.intersection(item.subject_keys)
                and (cutoff is None or (item.answered_at or item.created_at) < cutoff)
            ]
            matches.sort(key=lambda item: item.answered_at or item.created_at, reverse=True)
            return [self._copy(item) for item in matches[:limit]]

    def save_dag_node(self, node: MappingDagNode) -> MappingDagNode:
        with self._lock:
            self._dag[(node.run_id, node.mapping_key)] = self._copy(node)
            return self._copy(node)

    def list_dag_nodes(self, run_id: str) -> list[MappingDagNode]:
        with self._lock:
            return [
                self._copy(node)
                for (candidate_run_id, _), node in self._dag.items()
                if candidate_run_id == run_id
            ]

    def get_command_receipt(self, idempotency_key: str) -> AgentCommandReceipt | None:
        with self._lock:
            receipt = self._commands.get(idempotency_key)
            return self._copy(receipt) if receipt else None

    def save_command_receipt(self, receipt: AgentCommandReceipt) -> AgentCommandReceipt:
        with self._lock:
            existing = self._commands.get(receipt.idempotency_key)
            if existing:
                if existing.payload_hash != receipt.payload_hash:
                    raise ValueError("Idempotency key payload mismatch")
                return self._copy(existing)
            self._commands[receipt.idempotency_key] = self._copy(receipt)
            return self._copy(receipt)

    def save_evaluation(self, evaluation_id: str, run_id: str, payload: dict[str, Any]) -> None:
        with self._lock:
            self._evaluations[evaluation_id] = json.loads(json.dumps(payload, default=str))

    @contextmanager
    def command_transaction(self):
        with self._lock:
            from copy import deepcopy
            snapshots = {key: deepcopy(value) for key, value in vars(self).items() if isinstance(value, dict)}
            try:
                yield
            except Exception:
                for key, value in snapshots.items():
                    setattr(self, key, value)
                raise


class SnowflakeAgentRunRepository(AgentRunRepository):
    """Snowflake-backed durable repository used by API and worker replicas."""

    def __init__(self, session: Any, *, database: str = "", schema: str = "", lease_fence: tuple[str, str, int] | None = None) -> None:
        self._session = session
        self._lease_fence = lease_fence
        self._allow_cancelled_fence = False
        self._transaction_depth = 0
        prefix = ".".join(part for part in (database, schema) if part)
        self._prefix = f"{prefix}." if prefix else ""

    def _table(self, name: str) -> str:
        return f"{self._prefix}{name}"

    def link_unassigned_conversation_to_project(
        self, conversation_id: str, project_id: str, *, user_id: str, tenant_id: str
    ) -> None:
        """Keep a project created by a run with its originating chat."""
        if not conversation_id or not project_id:
            return
        self._session.sql(
            f"UPDATE {self._table('TBL_ASSISTANT_CONVERSATIONS')} "
            "SET PROJECT_ID=?, UPDATED_AT=CURRENT_TIMESTAMP() "
            "WHERE CONVERSATION_ID=? AND ACTOR_USER_ID=? AND TENANT_ID=? "
            "AND STATUS='ACTIVE' AND PROJECT_ID IS NULL",
            [project_id, conversation_id, user_id, tenant_id],
        ).collect()

    def set_worker_fence(self, run: AgentRun | None):
        self._lease_fence = (run.run_id, run.lease_owner, run.lease_generation) if run else None
        self._allow_cancelled_fence = True

    @staticmethod
    def _json(value: Any) -> str:
        if isinstance(value, BaseException):
            value = str(value)
        if hasattr(value, "model_dump"):
            value = value.model_dump(mode="json")
        return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)

    @staticmethod
    def _row(row: Any) -> dict[str, Any]:
        return row.as_dict() if hasattr(row, "as_dict") else dict(row)

    @staticmethod
    def _variant(value: Any) -> Any:
        """Normalize Snowflake VARIANT values across connector implementations."""
        if not isinstance(value, str):
            return value
        try:
            return json.loads(value)
        except (TypeError, json.JSONDecodeError):
            return value

    def create_run(self, run: AgentRun) -> AgentRun:
        payload = self._json(run)
        try:
            self._session.sql(
                f"""
                INSERT INTO {self._table('TBL_AGENT_RUNS')}
                    (RUN_ID, ACTOR_USER_ID, TENANT_ID, IDEMPOTENCY_KEY, REQUEST_HASH,
                     STATUS, CONVERSATION_ID, TURN_ID, PARENT_RUN_ID, RESUME_ATTEMPT,
                     RUN_REVISION, RUN_PAYLOAD, CREATED_AT, UPDATED_AT)
                SELECT ?, ?, ?, NULLIF(?, ''), ?, ?, NULLIF(?, ''), NULLIF(?, ''),
                       NULLIF(?, ''), ?, ?, PARSE_JSON(?), CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()
                """,
                [
                    run.run_id,
                    run.actor.user_id,
                    run.actor.tenant_id,
                    run.request.idempotency_key or "",
                    run.request_hash,
                    run.status.value,
                    run.request.conversation_id or "",
                    run.request.turn_id or "",
                    run.request.parent_run_id or "",
                    run.resume_attempt,
                    run.run_revision,
                    payload,
                ],
            ).collect()
        except Exception:
            if run.request.idempotency_key:
                existing = self.find_run_by_idempotency(run.actor.user_id, run.request.idempotency_key)
                if existing:
                    if existing.request_hash != run.request_hash:
                        raise ValueError("Idempotency key was already used for a different run request")
                    return existing
            raise
        return run

    def _deserialize_run(self, row: dict[str, Any]) -> AgentRun:
        payload = row.get("RUN_PAYLOAD") or {}
        if isinstance(payload, str):
            payload = json.loads(payload)
        payload.update(
            {
                "status": row.get("STATUS") or payload.get("status"),
                "lease_owner": row.get("LEASE_OWNER"),
                "lease_generation": int(row.get("LEASE_GENERATION") or 0),
                "lease_expires_at": row.get("LEASE_EXPIRES_AT"),
                "heartbeat_at": row.get("HEARTBEAT_AT"),
                # Cancellation is monotonic control-plane state. Always prefer
                # its normalized column over a stale JSON run snapshot.
                "cancel_requested_at": row.get("CANCEL_REQUESTED_AT")
                or payload.get("cancel_requested_at"),
                "cancel_reason": row.get("CANCEL_REASON") or payload.get("cancel_reason"),
                "resume_attempt": row.get("RESUME_ATTEMPT")
                if row.get("RESUME_ATTEMPT") is not None else payload.get("resume_attempt", 0),
                "run_revision": row.get("RUN_REVISION")
                if row.get("RUN_REVISION") is not None else payload.get("run_revision", 0),
                "updated_at": row.get("UPDATED_AT") or payload.get("updated_at"),
            }
        )
        request_payload = dict(payload.get("request") or {})
        request_payload.update({
            "conversation_id": row.get("CONVERSATION_ID") or request_payload.get("conversation_id"),
            "turn_id": row.get("TURN_ID") or request_payload.get("turn_id"),
            "parent_run_id": row.get("PARENT_RUN_ID") or request_payload.get("parent_run_id"),
        })
        payload["request"] = request_payload
        return AgentRun.model_validate(payload)

    def find_run_by_idempotency(self, actor_user_id: str, key: str) -> AgentRun | None:
        rows = self._session.sql(
            f"SELECT * FROM {self._table('TBL_AGENT_RUNS')} WHERE ACTOR_USER_ID = ? AND IDEMPOTENCY_KEY = ? LIMIT 1",
            [actor_user_id, key],
        ).collect()
        return self._deserialize_run(self._row(rows[0])) if rows else None

    def latest_budget_usage(self, run_id: str) -> dict[str, Any] | None:
        rows = self._session.sql(
            f"SELECT EVENT_DATA:budget_usage USAGE FROM {self._table('TBL_AGENT_RUN_EVENTS')} "
            "WHERE RUN_ID = ? AND IS_OBJECT(EVENT_DATA:budget_usage) "
            "ORDER BY EVENT_SEQ DESC LIMIT 1", [run_id],
        ).collect()
        if rows:
            value = rows[0].as_dict().get("USAGE")
            return json.loads(value) if isinstance(value, str) else value
        # Older checkpoints did not carry usage snapshots. At minimum retain
        # provider attempts and their acknowledged token usage on restart.
        rows = self._session.sql(
            f"SELECT COUNT_IF(EVENT_TYPE = 'model.started') MODEL_CALLS, "
            "SUM(IFF(EVENT_TYPE = 'model.completed', COALESCE(EVENT_DATA:metrics:input_tokens::INTEGER,0),0)) INPUT_TOKENS, "
            "SUM(IFF(EVENT_TYPE = 'model.completed', COALESCE(EVENT_DATA:metrics:output_tokens::INTEGER,0),0)) OUTPUT_TOKENS "
            f"FROM {self._table('TBL_AGENT_RUN_EVENTS')} WHERE RUN_ID = ?", [run_id],
        ).collect()
        data = rows[0].as_dict() if rows else {}
        return {"model_calls": int(data.get("MODEL_CALLS") or 0),
                "category_input_tokens": int(data.get("INPUT_TOKENS") or 0),
                "category_output_tokens": int(data.get("OUTPUT_TOKENS") or 0)}

    def get_run(self, run_id: str) -> AgentRun | None:
        rows = self._session.sql(
            f"SELECT * FROM {self._table('TBL_AGENT_RUNS')} WHERE RUN_ID = ? LIMIT 1",
            [run_id],
        ).collect()
        return self._deserialize_run(self._row(rows[0])) if rows else None

    def get_latest_run(self, actor_user_id: str, tenant_id: str) -> AgentRun | None:
        rows = self._session.sql(
            f"""
            SELECT * FROM {self._table('TBL_AGENT_RUNS')}
            WHERE ACTOR_USER_ID = ? AND TENANT_ID = ?
            ORDER BY CREATED_AT DESC
            LIMIT 1
            """,
            [actor_user_id, tenant_id],
        ).collect()
        return self._deserialize_run(self._row(rows[0])) if rows else None

    def list_runs_for_conversation(self, conversation_id: str, actor_user_id: str, tenant_id: str) -> list[AgentRun]:
        rows = self._session.sql(
            f"""SELECT * FROM {self._table('TBL_AGENT_RUNS')}
            WHERE CONVERSATION_ID=? AND ACTOR_USER_ID=? AND TENANT_ID=?
            ORDER BY CREATED_AT""",
            [conversation_id, actor_user_id, tenant_id],
        ).collect()
        return [self._deserialize_run(self._row(row)) for row in rows]

    def latest_conversation_summary(
        self, conversation_id: str, actor_user_id: str, tenant_id: str, *, exclude_run_id: str | None = None,
    ) -> str:
        if not conversation_id:
            return ""
        rows = self._session.sql(
            f"""SELECT e.EVENT_DATA:summary::STRING SUMMARY
            FROM {self._table('TBL_AGENT_RUN_EVENTS')} e
            JOIN {self._table('TBL_AGENT_RUNS')} r ON r.RUN_ID = e.RUN_ID
            WHERE r.CONVERSATION_ID = ? AND r.ACTOR_USER_ID = ? AND r.TENANT_ID = ?
              AND r.RUN_ID <> COALESCE(?, '') AND e.EVENT_TYPE = 'context.compacted'
              AND e.EVENT_DATA:summary IS NOT NULL
            ORDER BY e.CREATED_AT DESC LIMIT 1""",
            [conversation_id, actor_user_id, tenant_id, exclude_run_id or ""],
        ).collect()
        return str(self._row(rows[0]).get("SUMMARY") or "") if rows else ""

    def get_latest_run_for_conversation(
        self, conversation_id: str, actor_user_id: str, tenant_id: str
    ) -> AgentRun | None:
        rows = self._session.sql(
            f"""SELECT * FROM {self._table('TBL_AGENT_RUNS')}
            WHERE CONVERSATION_ID=? AND ACTOR_USER_ID=? AND TENANT_ID=?
            ORDER BY CREATED_AT DESC LIMIT 1""",
            [conversation_id, actor_user_id, tenant_id],
        ).collect()
        return self._deserialize_run(self._row(rows[0])) if rows else None

    def list_conversation_restore_rows(
        self, conversation_id: str, actor_user_id: str, tenant_id: str
    ) -> list[dict[str, Any]]:
        """Project only scalar restore fields from potentially huge run JSON."""
        rows = self._session.sql(
            f"""
            SELECT RUN_ID, STATUS, TURN_ID,
                   COALESCE(RUN_PAYLOAD:request:intent::STRING, 'NEW_MIGRATION_TASK') INTENT,
                   COALESCE(RESUME_ATTEMPT, 0) RESUME_ATTEMPT,
                   COALESCE(RUN_REVISION, 0) RUN_REVISION,
                   RUN_PAYLOAD:error_code::STRING ERROR_CODE,
                   RUN_PAYLOAD:request:attachment_ids::STRING ATTACHMENT_IDS,
                   RUN_PAYLOAD:safe_error::STRING SAFE_ERROR,
                   COALESCE(RUN_PAYLOAD:request:prompt::STRING, '') PROMPT,
                   CREATED_AT, UPDATED_AT
            FROM {self._table('TBL_AGENT_RUNS')}
            WHERE CONVERSATION_ID = ? AND ACTOR_USER_ID = ? AND TENANT_ID = ?
            ORDER BY CREATED_AT
            """,
            [conversation_id, actor_user_id, tenant_id],
        ).collect()
        return [self._row(row) for row in rows]

    def save_run(self, run: AgentRun) -> AgentRun:
        return self._save_run(run, owned=False)

    def save_run_owned(self, run: AgentRun) -> AgentRun:
        return self._save_run(run, owned=True)

    def save_run_if_current(self, run: AgentRun, previous: AgentRun) -> AgentRun:
        run.run_revision = previous.run_revision + 1
        return self._save_run(run, owned=False, previous=previous)

    def _save_run(self, run: AgentRun, *, owned: bool, previous: AgentRun | None = None) -> AgentRun:
        run.updated_at = datetime.now(UTC)
        fence = (" AND LEASE_OWNER=? AND LEASE_GENERATION=?"
                 " AND LEASE_EXPIRES_AT>CURRENT_TIMESTAMP()"
                 " AND (CANCEL_REQUESTED_AT IS NULL OR ?='CANCELLED')") if owned else ""
        expected = []
        if previous is not None:
            fence += ' AND STATUS=? AND COALESCE(RUN_REVISION,0)=? AND COALESCE(LEASE_GENERATION,0)=? AND EQUAL_NULL(CANCEL_REQUESTED_AT,?)'
            expected = [previous.status.value, previous.run_revision, previous.lease_generation, previous.cancel_requested_at]
        rows = self._session.sql(
            f"""
            UPDATE {self._table('TBL_AGENT_RUNS')}
            SET STATUS = ?, RUN_PAYLOAD = PARSE_JSON(?), PROJECT_ID = NULLIF(?, ''),
                CURRENT_STEP_ID = NULLIF(?, ''), CURRENT_STTM_ID = NULLIF(?, ''),
                CONVERSATION_ID = NULLIF(?, ''), TURN_ID = NULLIF(?, ''),
                PARENT_RUN_ID = NULLIF(?, ''), RESUME_ATTEMPT = ?, RUN_REVISION = GREATEST(COALESCE(RUN_REVISION,0), ?),
                CANCEL_REQUESTED_AT = COALESCE(CANCEL_REQUESTED_AT, ?),
                CANCEL_REASON = COALESCE(CANCEL_REASON, NULLIF(?, '')),
                COMPLETED_AT = ?, UPDATED_AT = CURRENT_TIMESTAMP()
            WHERE RUN_ID = ?{fence}
            """,
            [
                run.status.value,
                self._json(run),
                run.project_id or "",
                run.current_step_id or "",
                run.current_sttm_id or "",
                run.request.conversation_id or "",
                run.request.turn_id or "",
                run.request.parent_run_id or "",
                run.resume_attempt,
                run.run_revision,
                run.cancel_requested_at,
                run.cancel_reason or "",
                run.completed_at,
                run.run_id,
            ] + ([run.lease_owner, run.lease_generation, run.status.value] if owned else []) + expected,
        ).collect()
        if previous is not None:
            if not rows or int(next(iter(self._row(rows[0]).values()))) != 1:
                from app.agent_runs.service import RunConflictError
                raise RunConflictError('The run changed; refresh before applying this decision')
            return self.get_run(run.run_id) or run
        if owned:
            if not rows or int(next(iter(self._row(rows[0]).values()))) != 1:
                current = self.get_run(run.run_id)
                if (current and current.lease_owner == run.lease_owner
                        and current.lease_generation == run.lease_generation
                        and current.lease_expires_at and current.lease_expires_at > datetime.now(UTC)
                        and current.cancel_requested_at):
                    from app.agent_runtime.execution import ExecutionCancelledError
                    raise ExecutionCancelledError('Cancellation must be acknowledged before saving worker state')
                from app.agent_runtime.execution import ExecutionLeaseLostError
                raise ExecutionLeaseLostError('Worker state rejected by the durable lease fence')
            # The fenced UPDATE matched exactly this lease generation with no
            # pending cancellation, so the written object is the current state.
            # Re-reading the whole payload cost a round trip on every save.
            return run
        return run

    def acquire_lease(self, worker_id: str, lease_seconds: int) -> AgentRun | None:
        # Claim the oldest eligible run in the UPDATE itself. The previous
        # SELECT -> UPDATE -> SELECT path paid three Snowflake round trips for
        # every claim and let two workers choose the same candidate before the
        # guarded update. This keeps the compare-and-set at the database
        # boundary and needs only one follow-up read for the claimed payload.
        self._session.sql(
            f"""
            UPDATE {self._table('TBL_AGENT_RUNS')} target
            SET LEASE_GENERATION=COALESCE(LEASE_GENERATION,0)+1, LEASE_OWNER = ?, LEASE_EXPIRES_AT = DATEADD(second, ?, CURRENT_TIMESTAMP()),
                HEARTBEAT_AT = CURRENT_TIMESTAMP(), UPDATED_AT = CURRENT_TIMESTAMP()
            WHERE target.RUN_ID = (
                SELECT candidate.RUN_ID
                FROM {self._table('TBL_AGENT_RUNS')} candidate
                WHERE candidate.STATUS NOT IN (
                    'COMPLETED','READY_FOR_REVIEW','COMPLETED_WITH_REVIEW_ITEMS',
                    'FAILED','NEEDS_REVIEW','CANCELLED','EXPIRED','AWAITING_INPUT','AWAITING_CONFIRMATION'
                )
                  AND (candidate.LEASE_EXPIRES_AT IS NULL OR candidate.LEASE_EXPIRES_AT < CURRENT_TIMESTAMP())
                ORDER BY candidate.CREATED_AT
                LIMIT 1
            )
              AND (target.LEASE_EXPIRES_AT IS NULL OR target.LEASE_EXPIRES_AT < CURRENT_TIMESTAMP())
            """,
            [worker_id, lease_seconds],
        ).collect()
        rows = self._session.sql(
            f"""
            SELECT * FROM {self._table('TBL_AGENT_RUNS')}
            WHERE LEASE_OWNER = ?
              AND LEASE_EXPIRES_AT >= CURRENT_TIMESTAMP()
            ORDER BY HEARTBEAT_AT DESC
            LIMIT 1
            """,
            [worker_id],
        ).collect()
        return self._deserialize_run(self._row(rows[0])) if rows else None

    def renew_lease(self, run_id: str, worker_id: str, lease_seconds: int, generation: int | None = None) -> bool:
        rows = self._session.sql(
            f"""
            UPDATE {self._table('TBL_AGENT_RUNS')}
            SET LEASE_EXPIRES_AT = DATEADD(second, ?, CURRENT_TIMESTAMP()),
                HEARTBEAT_AT = CURRENT_TIMESTAMP(), UPDATED_AT = CURRENT_TIMESTAMP()
            WHERE RUN_ID = ? AND LEASE_OWNER = ? AND LEASE_EXPIRES_AT>CURRENT_TIMESTAMP()
              AND (? IS NULL OR LEASE_GENERATION=?)
            """,
            [lease_seconds, run_id, worker_id, generation, generation],
        ).collect()
        return bool(rows and int(next(iter(self._row(rows[0]).values()))) == 1)

    def release_lease(self, run_id: str, worker_id: str, generation: int | None = None) -> None:
        self._session.sql(
            f"UPDATE {self._table('TBL_AGENT_RUNS')} SET LEASE_OWNER=NULL, LEASE_EXPIRES_AT=NULL WHERE RUN_ID=? AND LEASE_OWNER=? AND (? IS NULL OR LEASE_GENERATION=?)",
            [run_id, worker_id, generation, generation],
        ).collect()

    def append_event(self, event: AgentRunEvent) -> AgentRunEvent:
        return self.append_events([event])[0]

    def append_events(self, events: list[AgentRunEvent]) -> list[AgentRunEvent]:
        if not events:
            return []
        run_ids = {event.run_id for event in events}
        if len(run_ids) != 1:
            raise ValueError("An event batch must belong to one migration run")
        run_id = events[0].run_id
        payload = [
            {
                "event_id": event.event_id,
                "event_type": event.event_type,
                "status": event.status,
                "safe_summary": event.safe_summary,
                "project_id": event.project_id or "",
                "sttm_id": event.sttm_id or "",
                "step_id": event.step_id or "",
                "parent_event_id": event.parent_event_id or "",
                "trace_id": event.trace_id or "",
                "span_id": event.span_id or "",
                "subject_keys": event.subject_keys,
                "artifact_refs": event.artifact_refs,
                "data": event.data,
            }
            for event in events
        ]
        if self._lease_fence:
            if self._lease_fence[0] != run_id:
                raise PermissionError('Event run does not match the worker lease')
            rows = self._session.sql(
                f"CALL {self._table('SP_APPEND_AGENT_RUN_EVENTS_FENCED')}(?, PARSE_JSON(?), ?, ?)",
                [run_id,self._json(payload),self._lease_fence[1],self._lease_fence[2]]).collect()
        else:
            rows = self._session.sql(
                f"CALL {self._table('SP_APPEND_AGENT_RUN_EVENTS')}(?, PARSE_JSON(?))",
                [run_id, self._json(payload)],
            ).collect()
        if not rows:
            raise RuntimeError("Snowflake event append procedure returned no cursor")
        result = next(iter(self._row(rows[0]).values()))
        result = self._variant(result)
        if not isinstance(result, Mapping):
            raise RuntimeError("Snowflake event append procedure returned a malformed cursor")
        if result.get('error') == 'worker_lease_lost':
            from app.agent_runtime.execution import ExecutionLeaseLostError
            raise ExecutionLeaseLostError('Event append rejected by durable lease fence')
        first_sequence = int(result.get("first_sequence") or result.get("FIRST_SEQUENCE") or 0)
        if first_sequence <= 0:
            raise RuntimeError("Snowflake event append procedure returned an invalid cursor")
        for index, event in enumerate(events):
            event.sequence = first_sequence + index
        visible_kinds = {
            "assistant.update": ("progress", "progress"),
            "assistant.final": ("assistant", "final"),
            "run.failed": ("error", "error"),
            "run.cancelled": ("cancellation", "cancellation"),
        }
        for event in events:
            visible = visible_kinds.get(event.event_type)
            if not visible or not event.conversation_id:
                continue
            # A heartbeat is live status; restored history keeps only milestones.
            if dict(event.data.get("progress") or {}).get("kind") == "heartbeat":
                continue
            role, message_kind = visible
            message = str(event.data.get("text") or event.safe_summary)
            self._session.sql(
                f"""MERGE INTO {self._table('TBL_WORKBENCH_CONVERSATION_TURNS')} target
                USING (SELECT ? TURN_ID) source ON target.TURN_ID=source.TURN_ID
                WHEN NOT MATCHED THEN INSERT
                  (TURN_ID, CONVERSATION_ID, ROLE, ROUTE, INTENT_CLASS, MESSAGE,
                   TURN_SEQUENCE, MODE, MESSAGE_KIND, RUN_ID, TURN_META)
                VALUES (?, ?, ?, 'assistant', ?, ?, ?, 'deep', ?, ?, PARSE_JSON(?))""",
                [event.event_id, event.event_id, event.conversation_id, role,
                 event.intent.value, message, 1_000_000 + event.sequence, message_kind,
                 event.run_id, self._json({"event_id": event.event_id, "owning_turn_id": event.turn_id})],
            ).collect()
        return events

    def list_events(self, run_id: str, after: int = 0, limit: int = 500) -> list[AgentRunEvent]:
        rows = self._session.sql(
            f"SELECT * FROM {self._table('TBL_AGENT_RUN_EVENTS')} WHERE RUN_ID=? AND EVENT_SEQ>? ORDER BY EVENT_SEQ LIMIT ?",
            [run_id, after, limit],
        ).collect()
        return self._events_from_rows(rows)

    def list_events_by_type(
        self, run_id: str, event_types: set[str] | frozenset[str], limit: int = 500
    ) -> list[AgentRunEvent]:
        types = sorted(event_types)
        if not types:
            return []
        placeholders = ", ".join("?" for _ in types)
        rows = self._session.sql(
            f"SELECT * FROM {self._table('TBL_AGENT_RUN_EVENTS')} WHERE RUN_ID=? "
            f"AND EVENT_TYPE IN ({placeholders}) ORDER BY EVENT_SEQ LIMIT ?",
            [run_id, *types, limit],
        ).collect()
        return self._events_from_rows(rows)

    def _events_from_rows(self, rows: list[Any]) -> list[AgentRunEvent]:
        events: list[AgentRunEvent] = []
        for data in (self._row(row) for row in rows):
            subject_keys = self._variant(data.get("SUBJECT_KEYS"))
            artifact_refs = self._variant(data.get("ARTIFACT_REFS"))
            event_data = self._variant(data.get("EVENT_DATA"))
            events.append(
                AgentRunEvent(
                    event_id=str(data["EVENT_ID"]),
                    run_id=str(data["RUN_ID"]),
                    sequence=int(data["EVENT_SEQ"]),
                    event_type=str(data["EVENT_TYPE"]),
                    status=str(data["STATUS"]),
                    safe_summary=str(data["SAFE_SUMMARY"]),
                    project_id=data.get("PROJECT_ID"),
                    sttm_id=data.get("STTM_ID"),
                    step_id=data.get("STEP_ID"),
                    parent_event_id=data.get("PARENT_EVENT_ID"),
                    trace_id=data.get("TRACE_ID"),
                    span_id=data.get("SPAN_ID"),
                    subject_keys=list(subject_keys) if isinstance(subject_keys, (list, tuple)) else [],
                    artifact_refs=list(artifact_refs) if isinstance(artifact_refs, (list, tuple)) else [],
                    data=dict(event_data) if isinstance(event_data, Mapping) else {},
                    created_at=data.get("CREATED_AT") or datetime.now(UTC),
                )
            )
        return events

    @fenced_write
    def _upsert_payload(self, table: str, keys: dict[str, str], payload_name: str, value: Any) -> None:
        if self._lease_fence and keys.get('RUN_ID') != self._lease_fence[0]:
            raise PermissionError('Mutation run does not match the worker lease')
        predicates = " AND ".join(f"target.{column}=source.{column}" for column in keys)
        columns = list(keys)
        placeholders = ", ".join("?" for _ in columns)
        self._session.sql(
            f"""
            MERGE INTO {self._table(table)} target
            USING (SELECT {', '.join(f'? AS {column}' for column in columns)}) source
            ON {predicates}
            WHEN MATCHED THEN UPDATE SET {payload_name}=PARSE_JSON(?), UPDATED_AT=CURRENT_TIMESTAMP()
            WHEN NOT MATCHED THEN INSERT ({', '.join(columns)}, {payload_name}, CREATED_AT, UPDATED_AT)
              VALUES ({', '.join(f'source.{column}' for column in columns)}, PARSE_JSON(?), CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP())
            """,
            [*keys.values(), self._json(value), self._json(value)],
        ).collect()

    def save_step(self, step: AgentRunStep) -> AgentRunStep:
        self._upsert_payload("TBL_AGENT_RUN_STEPS", {"RUN_ID": step.run_id, "STEP_ID": step.step_id}, "STEP_PAYLOAD", step)
        return step

    def list_steps(self, run_id: str) -> list[AgentRunStep]:
        rows = self._session.sql(f"SELECT STEP_PAYLOAD FROM {self._table('TBL_AGENT_RUN_STEPS')} WHERE RUN_ID=? ORDER BY CREATED_AT", [run_id]).collect()
        return [AgentRunStep.model_validate(self._variant(self._row(row)["STEP_PAYLOAD"])) for row in rows]

    def save_review_item(self, item: AgentReviewItem) -> AgentReviewItem:
        self._upsert_payload("TBL_AGENT_REVIEW_ITEMS", {"RUN_ID": item.run_id, "REVIEW_ITEM_ID": item.review_item_id}, "REVIEW_PAYLOAD", item)
        return item

    def answer_review_item(self, item: AgentReviewItem) -> bool:
        rows = self._session.sql(
            f"""UPDATE {self._table('TBL_AGENT_REVIEW_ITEMS')}
            SET REVIEW_PAYLOAD=PARSE_JSON(?), UPDATED_AT=CURRENT_TIMESTAMP()
            WHERE RUN_ID=? AND REVIEW_ITEM_ID=? AND REVIEW_PAYLOAD:status::STRING='OPEN'
              AND EXISTS (SELECT 1 FROM {self._table('TBL_AGENT_RUNS')} r
                          WHERE r.RUN_ID=? AND (r.STATUS IN ('AWAITING_INPUT','AWAITING_CONFIRMATION')
                            OR (r.STATUS='NEEDS_REVIEW' AND REVIEW_PAYLOAD:category::STRING='mapping_candidate_review'))
                            AND r.CANCEL_REQUESTED_AT IS NULL)""",
            [self._json(item),item.run_id,item.review_item_id,item.run_id],
        ).collect()
        return bool(rows and int(next(iter(self._row(rows[0]).values()))) == 1)

    def get_review_item(self, run_id: str, item_id: str) -> AgentReviewItem | None:
        rows = self._session.sql(f"SELECT REVIEW_PAYLOAD FROM {self._table('TBL_AGENT_REVIEW_ITEMS')} WHERE RUN_ID=? AND REVIEW_ITEM_ID=?", [run_id, item_id]).collect()
        return AgentReviewItem.model_validate(self._variant(self._row(rows[0])["REVIEW_PAYLOAD"])) if rows else None

    def list_review_items(self, run_id: str) -> list[AgentReviewItem]:
        rows = self._session.sql(f"SELECT REVIEW_PAYLOAD FROM {self._table('TBL_AGENT_REVIEW_ITEMS')} WHERE RUN_ID=? ORDER BY CREATED_AT", [run_id]).collect()
        return [AgentReviewItem.model_validate(self._variant(self._row(row)["REVIEW_PAYLOAD"])) for row in rows]

    def find_answered_decisions(
        self, actor_user_id: str, tenant_id: str, subject_keys: list[str], limit: int = 200,
        *, exclude_run_id: str | None = None,
    ) -> list[AgentReviewItem]:
        keys = sorted({str(value) for value in subject_keys if str(value).strip()})
        if not keys:
            return []
        rows = self._session.sql(
            f"""SELECT item.REVIEW_PAYLOAD
            FROM {self._table('TBL_AGENT_REVIEW_ITEMS')} item
            JOIN {self._table('TBL_AGENT_RUNS')} run ON run.RUN_ID = item.RUN_ID
            WHERE run.ACTOR_USER_ID = ? AND run.TENANT_ID = ? AND run.RUN_ID <> ?
              -- Only answers that existed before the current run started, so a
              -- replayed graph node sees the same set on every resume.
              AND item.UPDATED_AT < COALESCE(
                  (SELECT current_run.CREATED_AT FROM {self._table('TBL_AGENT_RUNS')} current_run
                   WHERE current_run.RUN_ID = ?), CURRENT_TIMESTAMP())
              AND item.REVIEW_PAYLOAD:status::STRING IN ('ANSWERED', 'RESOLVED')
              AND item.REVIEW_PAYLOAD:category::STRING IN ('confidence_gate', 'confidence_gate_batch')
              AND ARRAYS_OVERLAP(item.REVIEW_PAYLOAD:subject_keys::ARRAY, PARSE_JSON(?)::ARRAY)
            ORDER BY item.UPDATED_AT DESC
            LIMIT ?""",
            [actor_user_id, tenant_id, exclude_run_id or "", exclude_run_id or "", self._json(keys), limit],
        ).collect()
        return [AgentReviewItem.model_validate(self._variant(self._row(row)["REVIEW_PAYLOAD"])) for row in rows]

    def save_dag_node(self, node: MappingDagNode) -> MappingDagNode:
        with self.command_transaction():
            self._upsert_payload("TBL_AGENT_MAPPING_DAG", {"RUN_ID": node.run_id, "MAPPING_KEY": node.mapping_key}, "NODE_PAYLOAD", node)
        return node

    def list_dag_nodes(self, run_id: str) -> list[MappingDagNode]:
        rows = self._session.sql(f"SELECT NODE_PAYLOAD FROM {self._table('TBL_AGENT_MAPPING_DAG')} WHERE RUN_ID=? ORDER BY CREATED_AT", [run_id]).collect()
        return [MappingDagNode.model_validate(self._variant(self._row(row)["NODE_PAYLOAD"])) for row in rows]

    def get_command_receipt(self, idempotency_key: str) -> AgentCommandReceipt | None:
        rows = self._session.sql(f"SELECT RECEIPT_PAYLOAD FROM {self._table('TBL_AGENT_COMMANDS')} WHERE IDEMPOTENCY_KEY=?", [idempotency_key]).collect()
        return AgentCommandReceipt.model_validate(self._variant(self._row(rows[0])["RECEIPT_PAYLOAD"])) if rows else None

    def save_command_receipt(self, receipt: AgentCommandReceipt) -> AgentCommandReceipt:
        existing = self.get_command_receipt(receipt.idempotency_key)
        if existing:
            if existing.payload_hash != receipt.payload_hash:
                raise ValueError("Idempotency key payload mismatch")
            return existing
        self._session.sql(
            f"INSERT INTO {self._table('TBL_AGENT_COMMANDS')} (COMMAND_ID, IDEMPOTENCY_KEY, PAYLOAD_HASH, OPERATION, STATUS, RECEIPT_PAYLOAD, RUN_ID, EVENT_PUBLISHED, CREATED_AT, UPDATED_AT) SELECT ?,?,?,?,?,PARSE_JSON(?),?,FALSE,CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP()",
            [receipt.command_id, receipt.idempotency_key, receipt.payload_hash, receipt.operation, receipt.status, self._json(receipt), receipt.run_id],
        ).collect()
        return receipt

    @fenced_write
    def save_evaluation(self, evaluation_id: str, run_id: str, payload: dict[str, Any]) -> None:
        if self._lease_fence and run_id != self._lease_fence[0]:
            raise PermissionError('Evaluation run does not match the worker lease')
        self._session.sql(
            f"""
            INSERT INTO {self._table('TBL_AGENT_EVALUATION_RESULTS')}
                (EVALUATION_ID, RUN_ID, AGENT_VERSION, PROMPT_VERSION, SCORE, PASSED, RESULT_PAYLOAD, CREATED_AT)
            SELECT ?, ?, ?, ?, ?, ?, PARSE_JSON(?), CURRENT_TIMESTAMP()
            """,
            [
                evaluation_id,
                run_id,
                str(payload.get("agent_version") or "unknown"),
                str(payload.get("prompt_version") or "unknown"),
                float(payload.get("score") or 0.0),
                bool(payload.get("passed")),
                json.dumps(payload, default=str),
            ],
        ).collect()

    def flush_command_outbox(self, run_id: str) -> None:
        self._session.sql(f"CALL {self._table('SP_FLUSH_AGENT_COMMAND_OUTBOX')}(?)", [run_id]).collect()

    def recover_terminal_command_outboxes(self, limit: int = 25) -> int:
        """Recover committed receipts even when a terminal run is never resumed."""
        if not 1 <= limit <= 1000:
            raise ValueError('Outbox recovery batch must be between 1 and 1000')
        rows = self._session.sql(f"""
            SELECT r.RUN_ID FROM {self._table('TBL_AGENT_RUNS')} r
            WHERE r.STATUS IN ('FAILED','CANCELLED','EXPIRED','NEEDS_REVIEW',
                'COMPLETED','READY_FOR_REVIEW','COMPLETED_WITH_REVIEW_ITEMS')
              AND (r.LEASE_EXPIRES_AT IS NULL OR r.LEASE_EXPIRES_AT<CURRENT_TIMESTAMP())
              AND EXISTS (SELECT 1 FROM {self._table('TBL_AGENT_COMMANDS')} c
                WHERE c.RUN_ID=r.RUN_ID AND NOT COALESCE(c.EVENT_PUBLISHED,FALSE))
            ORDER BY r.UPDATED_AT LIMIT ?
        """, [limit]).collect()
        for row in rows:
            self.flush_command_outbox(str(self._row(row)['RUN_ID']))
        return len(rows)

    def assert_write_fence(self) -> None:
        if self._lease_fence is None:
            return
        run_id, owner, generation = self._lease_fence
        rows = self._session.sql(
            f"""UPDATE {self._table('TBL_AGENT_RUNS')} SET UPDATED_AT=CURRENT_TIMESTAMP()
            WHERE RUN_ID=? AND LEASE_OWNER=? AND LEASE_GENERATION=?
              AND LEASE_EXPIRES_AT>CURRENT_TIMESTAMP() AND (CANCEL_REQUESTED_AT IS NULL OR ?)""",
            [run_id, owner, generation, self._allow_cancelled_fence],
        ).collect()
        if not rows or int(next(iter(self._row(rows[0]).values()))) != 1:
            from app.agent_runtime.execution import ExecutionLeaseLostError
            raise ExecutionLeaseLostError('Draft write rejected by the durable lease fence')

    @contextmanager
    def command_transaction(self):
        if self._transaction_depth:
            yield
            return
        self._session.sql("BEGIN").collect()
        self._transaction_depth = 1
        try:
            yield
            self.assert_write_fence()
            self._session.sql("COMMIT").collect()
        except Exception:
            self._session.sql("ROLLBACK").collect()
            raise
        finally:
            self._transaction_depth = 0
