"""Actual durable SQL boundaries with simulated VARIANT numeric normalization."""
from copy import deepcopy
import json
from pathlib import Path
from types import SimpleNamespace

import pytest
from fastapi import HTTPException

from app.core import auto_mapping_proxy as module
from app.core import automap_restart as restart
from app.core.automap_batch import validate_fast_request
from app.core.automap_policy import preparation_hash
from app.schema.sttm_builder import (
    AgentExecutionContextV2, LearningContext, STTMBuilderEnvelopeRequest,
)
from tests.test_automap_fast_job import authored, proxy, request_context
from tests.unit.core.test_auto_mapping_proxy import _response


MARKER = "_automap_exact_json"
SECTIONS = ("request_envelope", "partial_responses", "response")


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    import socket
    monkeypatch.setattr(socket.socket, "connect", lambda *args: pytest.fail("Network access"))
    monkeypatch.setattr(socket, "getaddrinfo", lambda *args, **kwargs: pytest.fail("DNS access"))


def wire(value):
    return json.dumps(value, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def variant(text):
    def number(value):
        parsed = float(value)
        return int(parsed) if parsed.is_integer() else parsed
    return json.loads(text, parse_float=number)


class DurableSession:
    def __init__(self, *, text=False):
        self.text = text
        self.state = None
        self.queries = []
        self.lease_owner = None

    def sql(self, sql, params=None):
        params = params or []
        self.queries.append((sql, params))
        if "MERGE INTO" in sql:
            self.state = variant(params[-1])
            rows = [{"number of rows inserted": 1}]
        elif "SELECT JOB_STATE" in sql:
            assert params == [self.state["job_id"], self.state["owner"]]
            assert "OWNER_ID = ?" in sql and "EXPIRES_AT > CURRENT_TIMESTAMP()" in sql
            state = wire(self.state) if self.text else deepcopy(self.state)
            rows = [{"JOB_STATE": state}]
        elif "SET LEASE_OWNER" in sql:
            self.lease_owner = params[0]
            rows = [(1,)]
        elif "SELECT LEASE_OWNER" in sql:
            rows = [{"LEASE_OWNER": self.lease_owner}]
        elif "SET LEASE_EXPIRES_AT" in sql:
            assert params[-1] == self.lease_owner
            rows = [(1,)]
        else:
            pytest.fail(f"Unexpected SQL: {sql}")
        return SimpleNamespace(collect=lambda: rows)


def save_load(client, record, session):
    client._persist_job(record, headers={}, session=session, required=True)
    return client._load_persisted_job(record["job_id"], owner=record["owner"], headers={}, session=session)


def prepared_record(client, *, value=12.0):
    req = authored(pending=1)
    req.context.execution_context = AgentExecutionContextV2(context_key="durable-json")
    req.context.learning_context = LearningContext(retrieval_diagnostics={
        "project_context": {"status": "ok", "duration_ms": value},
    })
    req.context.prepared_context_hash = preparation_hash(req.context)
    root = client._bind_fast_handoff(client._freeze_resolution(req), discovery={
        "COL_2": {"diagnostics": {"status": "no_match", "duration_ms": value}},
    })
    client._build_batches(root)
    pending = client._pending_resolution_request(root)
    validate_fast_request(pending, client._settings)
    response = _response(pending).model_dump(mode="json")
    response["meta"]["durable_probe"] = {"duration_ms": value, "order": [2, None, 1]}
    return root, {
        "job_id": "durable-json-test", "owner": "ALICE", "request_id": req.request_id,
        "status": "running", "stage": "source_mapping", "state_version": 5,
        "execution_protocol": "background_v2", "recovery_role": "ROLE",
        "recovery_session_hash": "a" * 64, "acceptance_hash": "accepted",
        "scoring_policy_version": module.SCORING_POLICY_VERSION,
        "request_envelope": root.model_dump(mode="json"),
        "partial_responses": [{"batch_index": 0, "response": response,
                               "batch_identity": client._batch_identity(root, pending.data.attributes)}],
        "response": response,
    }


def test_import_is_from_target_worktree():
    assert Path(module.__file__).resolve().parents[2] == Path(__file__).resolve().parents[1]


@pytest.mark.parametrize("text", [False, True])
@pytest.mark.parametrize("value", [12.0, 0.0, -0.0, 1.2e3, 1e-7, 1e20])
def test_actual_save_load_preserves_exact_sections_and_pending_proofs(text, value):
    client = proxy(AUTO_MAP_PIPELINE_V2=True)
    root, record = prepared_record(client, value=value)
    before = wire(record)
    session = DurableSession(text=text)
    loaded = save_load(client, record, session)
    assert wire(record) == before
    assert MARKER not in record and MARKER not in loaded
    for section in SECTIONS:
        assert wire(loaded[section]) == wire(record[section])
        assert client._resolution_digest(loaded[section]) == client._resolution_digest(record[section])
    assert session.state[MARKER]["encoding"] == "automap-exact-json-v2"
    if value.is_integer():
        assert type(session.state["request_envelope"]["context"]["learning_context"][
            "retrieval_diagnostics"]["project_context"]["duration_ms"]) is int
        assert wire(session.state["request_envelope"]) != wire(record["request_envelope"])
    from app.core.automap_stored_json import load_stored
    assert wire(load_stored(session.state[MARKER]['payload'])) == wire({key:record[key] for key in SECTIONS})
    restored = client._restore_resolution(STTMBuilderEnvelopeRequest.model_validate(loaded["request_envelope"]))
    assert wire(restored.meta[module._RESOLUTION_PLAN_KEY]) == wire(root.meta[module._RESOLUTION_PLAN_KEY])
    pending = client._pending_resolution_request(restored)
    validate_fast_request(pending, client._settings)
    assert pending.context.prepared_context_hash == root.context.prepared_context_hash


@pytest.mark.parametrize("text", [False, True])
def test_nested_unicode_null_array_order_and_repeated_saves(text):
    client = proxy(AUTO_MAP_PIPELINE_V2=True)
    value = {"unicode": "\u96ea\u00e9\U0001f680", "escaped": "a\\b\r\n\t\"quoted\"",
             "nested": [12.0, 0.0, -0.0, 1e-7, 1e20, None, False, {"values": [3, 2, 1]}]}
    record = {"job_id": "j", "owner": "ALICE", "state_version": 1,
              "request_envelope": {"meta": deepcopy(value)},
              "partial_responses": [deepcopy(value)], "response": deepcopy(value)}
    session = DurableSession(text=text)
    for revision in range(1, 4):
        record["state_version"] = revision
        record["response"]["revision"] = float(revision)
        loaded = save_load(client, record, session)
        assert wire(loaded) == wire(record)
        assert MARKER not in loaded


def test_sql_projections_and_native_lease_updates_remain_authoritative(monkeypatch):
    client = proxy(AUTO_MAP_PIPELINE_V2=True)
    _, record = prepared_record(client)
    session = DurableSession()
    loaded = save_load(client, record, session)
    state_before = wire(session.state)
    assert session.state["request_envelope"]["context"]["project_id"] == "501"
    assert session.state["request_envelope"]["context"]["sttm_id"] == record["request_envelope"]["context"]["sttm_id"]
    assert session.state["response"]["result"]["mappings"]
    assert session.state["execution_protocol"] == "background_v2"
    sql = session.queries[0][0]
    for path in ("acceptance_hash", "state_version", "dispatcher_lease_owner"):
        assert f"JOB_STATE:{path}" in sql
    monkeypatch.setitem(module._AUTO_MAP_JOBS, record["job_id"], loaded)
    assert client._claim_job_lease(record["job_id"], owner="ALICE", headers={}, session=session)
    monkeypatch.setattr(client, "_open_job_client", lambda headers: SimpleNamespace(session=session, close=lambda: None))
    assert client._renew_job_lease(record["job_id"], headers={})
    assert wire(session.state) == state_before
    session.state.update(status="failed", stage="stopped", state_version=8, owner="BOB",
                         recovery_role="NEW_ROLE", dispatcher_lease_owner="new-owner")
    restored = client._load_job_state(session.state)
    for key in ("status", "stage", "state_version", "owner", "recovery_role", "dispatcher_lease_owner"):
        assert restored[key] == session.state[key]


def test_modern_large_context_storage_is_lossless_bounded_and_sql_readable():
    client = proxy(AUTO_MAP_PIPELINE_V2=True)
    _, record = prepared_record(client)
    record['request_envelope']['meta']['automap_packet_policy']='frozen-packets-v1'
    record['request_envelope']['context']['semantic_context']=[{'table':'source','body':'complete semantics ' * 20000,'duration':12.0}]
    record['request_envelope']['context']['learning_context']={'precedent':'complete expression ' * 12000}
    session=DurableSession()
    loaded=save_load(client,record,session)
    assert wire(loaded)==wire(record)
    assert len(wire(session.state)) < len(wire(record)) / 3
    assert session.state['request_envelope']['context']['project_id']=='501'
    assert session.state['response']['result']['mappings']
    assert session.state[MARKER]['encoding']=='automap-exact-json-v2'
    changed=deepcopy(session.state)
    changed['request_envelope']['context']['project_id']='other-project'
    with pytest.raises(ValueError,match='projection changed'):
        client._load_job_state(changed)


@pytest.mark.parametrize('value',[12.0,0.0,-0.0,1e-7,1e20])
def test_modern_exact_sections_preserve_numeric_types_even_when_small(value):
    client=proxy(AUTO_MAP_PIPELINE_V2=True)
    record={'job_id':'small','owner':'ALICE','request_envelope':{
        'meta':{'automap_packet_policy':'frozen-packets-v1'},'context':{'project_id':'1','duration':value}},
        'partial_responses':[],'response':None}
    assert wire(save_load(client,record,DurableSession()))==wire(record)


@pytest.mark.parametrize("text", [False, True])
def test_legacy_valid_records_load_without_inventing_proofs(text):
    client = proxy(AUTO_MAP_PIPELINE_V2=True)
    _, record = prepared_record(client, value=12)
    session = DurableSession(text=text)
    session.state = deepcopy(record)
    loaded = client._load_persisted_job(record["job_id"], owner="ALICE", headers={}, session=session)
    assert wire(loaded) == wire(record)
    restored = client._restore_resolution(STTMBuilderEnvelopeRequest.model_validate(loaded["request_envelope"]))
    validate_fast_request(client._pending_resolution_request(restored), client._settings)


def test_legacy_numeric_corruption_is_not_repaired_or_resealed():
    client = proxy(AUTO_MAP_PIPELINE_V2=True)
    root, record = prepared_record(client)
    session = DurableSession()
    session.state = deepcopy(record)
    diagnostics = session.state["request_envelope"]["context"]["learning_context"]["retrieval_diagnostics"]
    diagnostics["project_context"]["duration_ms"] = 12
    loaded = client._load_persisted_job(record["job_id"], owner="ALICE", headers={}, session=session)
    restored = client._restore_resolution(STTMBuilderEnvelopeRequest.model_validate(loaded["request_envelope"]))
    assert restored.context.prepared_context_hash == root.context.prepared_context_hash
    with pytest.raises(ValueError) as error:
        client._pending_resolution_request(restored)
    assert error.value.code == "prepared_hash_mismatch"
    # Saving an already-corrupt legacy job cannot manufacture its lost float.
    reloaded = save_load(client, loaded, session)
    with pytest.raises(ValueError):
        validate_fast_request(client._pending_resolution_request(client._restore_resolution(
            STTMBuilderEnvelopeRequest.model_validate(reloaded["request_envelope"]))), client._settings)


@pytest.mark.parametrize("wrapper", [
    None, [], "text", {}, {"encoding": "automap-exact-json-v2", "json": "{}"},
    {"encoding": "automap-exact-json-v1", "json": {}},
    {"encoding": "automap-exact-json-v1", "json": "{"},
    {"encoding": "automap-exact-json-v1", "json": "null"},
    {"encoding": "automap-exact-json-v1", "json": "[]"},
    {"encoding": "automap-exact-json-v1", "json": "{}", "extra": True},
    {"encoding": "automap-exact-json-v1", "json": '{"request_envelope":{},"request_envelope":{}}'},
    {"encoding": "automap-exact-json-v1", "json": '{"request_envelope":{"value":NaN}}'},
    {"encoding": "automap-exact-json-v1", "json": '{"request_envelope":{"value":1e999}}'},
    {"encoding": "automap-exact-json-v1", "json": '{"request_envelope":[],"status":"completed"}'},
])
def test_malformed_wrapper_fails_closed_in_actual_loader_and_restart(monkeypatch, wrapper):
    client = proxy(AUTO_MAP_PIPELINE_V2=True)
    session = DurableSession()
    session.state = {"job_id": "j", "owner": "ALICE", "request_envelope": {}, MARKER: wrapper}
    with pytest.raises(HTTPException) as error:
        client._load_persisted_job("j", owner="ALICE", headers={}, session=session)
    assert error.value.status_code == 503
    monkeypatch.setattr(restart, "_rows", lambda *args: pytest.fail("Malformed state reached authentication"))
    with pytest.raises(ValueError):
        restart.resume_job(client._settings, {"JOB_ID": "j", "OWNER_ID": "ALICE", "JOB_STATE": session.state})


@pytest.mark.parametrize("section", SECTIONS)
def test_stale_section_projection_is_rejected(section):
    client = proxy(AUTO_MAP_PIPELINE_V2=True)
    _, record = prepared_record(client)
    session = DurableSession()
    save_load(client, record, session)
    session.state[section] = [] if section == "partial_responses" else {}
    with pytest.raises(ValueError, match="projection changed"):
        client._load_job_state(session.state)


@pytest.mark.parametrize("projection,exact", [(False, 0), (True, 1.0), ([1, 2], [2, 1]), ({}, None)])
def test_projection_guard_does_not_equate_booleans_or_ignore_structure(projection, exact):
    state = {"response": {"value": projection}, MARKER: {
        "encoding": "automap-exact-json-v1", "json": wire({"response": {"value": exact}})}}
    with pytest.raises(ValueError, match="projection changed"):
        module.AutoMappingProxyClient._load_job_state(state)


@pytest.mark.parametrize("mutation", ["body", "hash"])
def test_consistent_projection_tampering_still_fails_original_plan_proof(mutation):
    client = proxy(AUTO_MAP_PIPELINE_V2=True)
    _, record = prepared_record(client)
    plan = record["request_envelope"]["meta"][module._RESOLUTION_PLAN_KEY]
    if mutation == "body":
        plan["handoff"]["discovery"]["COL_2"]["diagnostics"]["duration_ms"] = 99.0
    else:
        plan["handoff_hash"] = "0" * 64
    loaded = save_load(client, record, DurableSession())
    with pytest.raises(module.SnowflakeAgentError, match="handoff changed"):
        client._restore_resolution(STTMBuilderEnvelopeRequest.model_validate(loaded["request_envelope"]))


@pytest.mark.parametrize("text", [False, True])
def test_background_restart_decodes_before_validation_and_cache(monkeypatch, text):
    client = proxy(AUTO_MAP_PIPELINE_V2=True, SNOWFLAKE_DATABASE="DB", SNOWFLAKE_SCHEMA="META")
    _, record = prepared_record(client)
    session = DurableSession(text=text)
    save_load(client, record, session)
    monkeypatch.setattr(restart, "_rows", lambda *args: [{"SESSION_ID": "session"}])
    monkeypatch.setattr(restart, "authenticated_headers", lambda *args: {"caller": "verified"})
    calls = []
    def launch(self, job_id, **kwargs):
        calls.append(kwargs)
        assert MARKER not in kwargs["record"]
        assert wire(kwargs["record"]["request_envelope"]) == wire(record["request_envelope"])
        restored = self._restore_resolution(kwargs["req"])
        validate_fast_request(self._pending_resolution_request(restored), self._settings)
    monkeypatch.setattr(module.AutoMappingProxyClient, "_launch_job_runner", launch)
    monkeypatch.setattr(module, "_AUTO_MAP_JOBS", {})
    monkeypatch.setattr(module, "_AUTO_MAP_ACTIVE_RUNNERS", set())
    restart.resume_job(client._settings, {"JOB_ID": record["job_id"], "OWNER_ID": "ALICE",
        "JOB_STATE": wire(session.state) if text else session.state})
    assert len(calls) == 1
    assert MARKER not in module._AUTO_MAP_JOBS[record["job_id"]]


@pytest.mark.parametrize("record", [
    {}, {"request_envelope": None, "partial_responses": [], "response": None},
    {"request_envelope": {}, "response": {}},
])
def test_optional_sections_and_nulls_roundtrip(record):
    client = proxy(AUTO_MAP_PIPELINE_V2=True)
    record = {"job_id": "j", "owner": "ALICE", **record}
    assert save_load(client, record, DurableSession()) == record


@pytest.mark.parametrize("exact", [
    {}, {"request_envelope": []}, {"request_envelope": {}, "owner": "BOB"},
    {"request_envelope": {}, "partial_responses": []},
])
def test_malformed_section_set_or_type_is_rejected(exact):
    state = {"request_envelope": {}, MARKER: {
        "encoding": "automap-exact-json-v1", "json": wire(exact)}}
    with pytest.raises(ValueError, match="section"):
        module.AutoMappingProxyClient._load_job_state(state)


def test_native_outcome_query_still_reads_existing_sql_paths():
    from app.core.sttm_builder import STTMBuilderService
    from app.schema.sttm_builder import Interface
    client = proxy(AUTO_MAP_PIPELINE_V2=True)
    _, record = prepared_record(client)
    record["response"]["meta"]["auto_mapping_review"] = {"mapped_count": 1}
    session = DurableSession()
    save_load(client, record, session)
    req = authored(pending=1)
    req.data.intent = Interface.CHAT
    req.context.sttm_id = "sheet"
    def sql(query, params):
        assert params == ["ALICE", "501", "sheet"]
        for path in ("request_envelope:context:project_id", "request_envelope:context:sttm_id",
                     "response:result:mappings", "response:meta:auto_mapping_review"):
            assert f"JOB_STATE:{path}" in query
        assert "OWNER_ID = ?" in query
        row = {"JOB_ID": record["job_id"], "REQUEST_ID": record["request_id"],
               "CONTEXT_HASH": "context", "CREATED_AT": "2026-11-10", "STATUS": "completed",
               "MAPPINGS": session.state["response"]["result"]["mappings"],
               "REVIEW": session.state["response"]["meta"]["auto_mapping_review"]}
        return SimpleNamespace(collect=lambda: [SimpleNamespace(as_dict=lambda: row)])
    service = STTMBuilderService.__new__(STTMBuilderService)
    service._settings = client._settings
    service._session = SimpleNamespace(sql=sql)
    restored = service.restore_auto_map_outcome(req, owner="ALICE")
    outcome = restored.context.workspace_context.auto_map_outcome
    assert outcome["review"] == {"mapped_count": 1}
    assert outcome["mappings"] == session.state["response"]["result"]["mappings"]


def test_partial_receipts_remain_valid_after_actual_durable_roundtrip():
    client = proxy(AUTO_MAP_PIPELINE_V2=True)
    root, record = prepared_record(client)
    retained_before, rejected_before = client._resolution_receipts(root, record["partial_responses"])
    assert len(retained_before) == 1 and rejected_before == []
    loaded = save_load(client, record, DurableSession())
    restored = client._restore_resolution(STTMBuilderEnvelopeRequest.model_validate(loaded["request_envelope"]))
    retained, rejected = client._resolution_receipts(restored, loaded["partial_responses"])
    assert wire(retained) == wire(retained_before) and rejected == []


def test_get_job_decodes_before_runner_and_does_not_publish_private_json(monkeypatch):
    client = proxy(AUTO_MAP_PIPELINE_V2=True)
    _, record = prepared_record(client)
    record["partial_responses"] = []
    session = DurableSession()
    save_load(client, record, session)
    monkeypatch.setattr(module, "_AUTO_MAP_JOBS", {})
    monkeypatch.setattr(client, "_forward_headers", lambda *args: {})
    calls = []
    def launch(job_id, **kwargs):
        restored = client._restore_resolution(kwargs["req"])
        validate_fast_request(client._pending_resolution_request(restored), client._settings)
        calls.append(job_id)
    monkeypatch.setattr(client, "_launch_job_runner", launch)
    public = client.get_job(request_context(), record["job_id"], session=session)
    assert calls == [record["job_id"]]
    assert MARKER not in public and "request_envelope" not in public
    assert MARKER not in module._AUTO_MAP_JOBS[record["job_id"]]
