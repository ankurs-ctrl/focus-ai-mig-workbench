#!/usr/bin/env python3
"""Read-only client-account install verification; never enables or deploys.

Run inside the application's Python environment on the AVD with an existing
Snowflake connection. Prints specification pins only after comparing the reviewed
rendered specifications and invoking all nine read-only protocol probes.
It does not substitute for a genuine source/Search/Analyst/rule canary.
"""
import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "services/sttm-builder"))
from scripts.render_automap_native import identifier, fingerprint


def verify(session, agent, metadata, rendered):
    from app.core.automap_native_store import plain

    metadata = identifier(metadata, 2)
    pins = {}
    template = json.loads(
        (ROOT / "infra/snowflake/automap_native_v1/agent-template.json").read_text()
    )
    for kind in ("source", "rule"):
        expected = json.loads(
            (Path(rendered) / ("agent-" + kind + ".json")).read_text()
        )
        actual = agent.get_specification(metadata + "." + template[kind]["name"])
        if any(actual.get(key) != value for key, value in expected.items()):
            raise ValueError(
                "Deployed "
                + kind
                + " specification differs from reviewed render; inspect before pinning"
            )
        pins[
            "AUTOMAP_NATIVE_"
            + ("SOURCE" if kind == "source" else "RULE")
            + "_SPEC_SHA256"
        ] = fingerprint(actual)
    probes = {
        item["procedure"]: (name, "source") for name, item in template["tools"].items()
    }
    probes.update(
        {
            "VALIDATE_RULE": ("ValidateProposal", "rule"),
            "SUBMIT_RULE": ("SubmitProposals", "rule"),
        }
    )
    for suffix, (tool, phase) in probes.items():
        rows = session.sql(
            "CALL " + metadata + ".SP_AUTOMAP_" + suffix + "(REQUEST_JSON => ?)",
            params=['{"protocol_probe":"automap_native_v1"}'],
        ).collect(
            statement_params={"STATEMENT_TIMEOUT_IN_SECONDS": "10", "LOCK_TIMEOUT": "1"}
        )
        result = json.loads(next(iter(plain(rows[0]).values())))
        if result != {
            "protocol": "automap_native_v1",
            "tool": tool,
            "phase": phase,
            "metadata": metadata,
        }:
            raise ValueError("Registered tool protocol probe failed: " + suffix)
    session.sql(
        "DESC CORTEX SEARCH SERVICE " + metadata + ".CSS_AUTOMAP_SOURCE_COLUMNS_V2"
    ).collect(statement_params={"STATEMENT_TIMEOUT_IN_SECONDS": "5"})
    rows = [
        plain(row)
        for row in session.sql(
            "SELECT SLOT_ID,STATE FROM "
            + metadata
            + ".TBL_AUTOMAP_NATIVE_ANALYST_SLOTS"
        ).collect()
    ]
    if len(rows) != 4 or {row["SLOT_ID"] for row in rows} != {0, 1, 2, 3}:
        raise ValueError("Analyst inventory mismatch")
    return {
        "checks": "installed_protocol_and_pinned_specifications",
        "pins": pins,
        "native_flag_enabled": False,
        "live_mapping_and_tool_acceptance": "NOT_RUN",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--connection", required=True)
    parser.add_argument("--metadata", required=True)
    parser.add_argument("--rendered", required=True)
    args = parser.parse_args()
    from snowflake.snowpark import Session
    from app.core.snowflake import SnowflakeClient
    from app.core.snowflake_agent import SnowflakeAgentClient

    session = Session.builder.config("connection_name", args.connection).create()
    try:
        wrapper = SnowflakeClient.__new__(SnowflakeClient)
        wrapper._session = session
        context = wrapper.get_rest_session_context()
        role = session.get_current_role().strip('"')
        client = SnowflakeAgentClient(
            context.token,
            host=context.host,
            auth_mode="snowflake_token",
            role=role,
            request_timeout=15,
        )
        print(
            json.dumps(verify(session, client, args.metadata, args.rendered), indent=2)
        )
    finally:
        session.close()


if __name__ == "__main__":
    main()
