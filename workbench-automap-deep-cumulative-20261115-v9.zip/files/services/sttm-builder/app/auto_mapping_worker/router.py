import logging
from typing import Annotated

from fastapi import APIRouter, Depends, Request

from app.api.deps import get_sttm_builder_service
from app.core.sttm_builder import STTMBuilderService
from app.schema.contracts import resolve_request_id
from app.schema.sttm_builder import (
    STTMBuilderEnvelopeRequest,
    STTMBuilderRequest,
    STTMBuilderResponse,
    normalize_sttm_builder_invoke_body,
)

router = APIRouter(prefix="/api/v1/auto-mapping", tags=["Auto Mapping Worker"])
logger = logging.getLogger(__name__)


@router.post(
    "/invoke",
    response_model=STTMBuilderResponse,
    summary="Run auto-mapping in parallel inside the private worker service",
)
async def invoke(
    request: Request,
    body: STTMBuilderEnvelopeRequest | STTMBuilderRequest,
    service: Annotated[STTMBuilderService, Depends(get_sttm_builder_service)],
) -> STTMBuilderResponse:
    normalized = normalize_sttm_builder_invoke_body(body)
    if normalized.meta.get('_automap_packet_ref') is not None:
        import asyncio
        from app.core.automap_frozen_packet import hydrate_worker_reference
        import time
        started = time.perf_counter()
        try:
            normalized = await asyncio.to_thread(hydrate_worker_reference, service, normalized)
        except (ValueError, KeyError, TypeError):
            from app.core.exceptions import AppValidationError
            raise AppValidationError('Auto-map could not verify its saved packet. Please run Auto-map again.',
                details=[{'code':'AUTO_MAP_PREPARATION_INVALID','stage':'worker_packet_hydration',
                    'invariant':'packet_reference_invalid','trace_id':str(normalized.request_id)}]) from None
        service._automap_worker_hydration_ms = round((time.perf_counter() - started) * 1000, 2)
    if not normalized.request_id:
        normalized = normalized.model_copy(update={"request_id": resolve_request_id(request)})
    logger.info(
        "Auto-mapping worker received request_id=%s attributes=%s source_tables=%s",
        normalized.request_id,
        len(normalized.data.attributes or []),
        len(normalized.context.source_tables or []),
    )
    response = await service.invoke_auto_map_parallel(normalized)
    if hasattr(service, '_automap_worker_hydration_ms'):
        response.meta['worker_packet_hydration_ms'] = service._automap_worker_hydration_ms
    return response
