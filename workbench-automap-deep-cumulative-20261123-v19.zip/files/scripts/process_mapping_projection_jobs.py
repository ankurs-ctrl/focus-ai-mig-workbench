"""Explicit, mapping-scoped recovery worker for already captured projection jobs.

No scheduling, privilege changes, or publication. Run only with
an approved connection and mapping. Pending and expired jobs are claimed through
the same service used by the application; failures retain their durable state.
Existing writers may initialize storage; provision and approve it before use.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
import uuid
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "services" / "sttm-builder"))

from snowflake.snowpark import Session

from app.core.config import Settings
from app.core.conversation_memory import ConversationMemoryService
from app.core.project_service import ProjectService


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--connection", required=True)
    parser.add_argument("--mapping-id", required=True)
    parser.add_argument("--env-file", required=True)
    parser.add_argument("--max-jobs", type=int, default=4, choices=range(1, 21))
    parser.add_argument("--poll-seconds", type=int, default=0,
                        help="Zero processes once; at least 10 enables an independent recovery loop.")
    args = parser.parse_args()
    if args.poll_seconds and args.poll_seconds < 10:
        parser.error("--poll-seconds must be zero or at least 10")
    settings = Settings(_env_file=args.env_file)
    session = Session.builder.config("connection_name", args.connection).create()
    worker_id = f"mapping-recovery:{uuid.uuid4().hex}"
    try:
        memory = ConversationMemoryService(session, settings)
        service = ProjectService(session=session, settings=settings, memory_service=memory)
        if service.get_sttm_record(args.mapping_id) is None:
            raise RuntimeError("Mapping is not visible to the selected connection.")
        while True:
            processed = service.process_postsave_jobs(
                worker_id=worker_id, sttm_id=args.mapping_id, max_jobs=args.max_jobs,
            )
            print(json.dumps({"mapping_id": args.mapping_id, "completed_jobs": processed}), flush=True)
            if not args.poll_seconds:
                break
            time.sleep(args.poll_seconds)
    finally:
        session.close()


if __name__ == "__main__":
    main()