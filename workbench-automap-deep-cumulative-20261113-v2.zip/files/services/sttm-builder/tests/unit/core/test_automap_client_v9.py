"""Client V8 regressions: real preparation/reducers/guarded transport, synthetic request data.

No archived client request or real Snowflake/model is available here. These
fixtures deliberately exercise normal envelopes and naturally unbound lineage.
"""
from copy import deepcopy
import asyncio
import json
import pytest
from app.core.automap_evidence_blocks import EvidenceBlocks, EvidenceBlockError
from app.core.automap_input_budget import wire_text
from tests.unit.core.test_automap_fast_context import fast_payload, plan_for, add_table, unpack
from tests.unit.core.test_automap_fast_batch import prepared_request, answer_for
from tests.unit.core.test_automap_evidence_blocks import review
from tests.unit.core.test_automap_guarded_specialist import setup, rules
from tests.test_automap_fast_transport import harness as transport_harness


def normal_review(block):
    legacy = json.loads(review(block))
    return {'contract_version':'1.0','request_id':'client-generated-review', 'operation':'sttm.auto_map',
        'context':{}, 'data':{'intent':'AUTO_MAP','status':'completed','agent':legacy['agent'],
        'result':legacy['data']['result'],'message':None,'artifact_type':'none','artifact':None,
        'semantic_level_achieved':None,'semantic_refresh_status':None},
        'meta':legacy['meta'],'warnings':[],'error':None}


@pytest.mark.parametrize('form',['legacy','normal','duplicate'])
def test_explicit_supported_review_envelopes_reach_verified_state(form):
    blocks=EvidenceBlocks('snapshot',180000,180000);blocks.enabled=True;blocks.begin()
    blocks.project('Exact business rule: retain nulls. '*12000)
    identity=blocks.pending[0];block=blocks.blocks[identity]
    body=json.loads(review(block)) if form=='legacy' else normal_review(block)
    if form=='duplicate':
        body['agent']='AGT_SOURCE_MAPPING';body['result']=deepcopy(body['data']['result']);body['data']['meta']=deepcopy(body['meta'])
    blocks.accept(identity,json.dumps(body))
    assert blocks.reviews[identity]['facts'][0]['quote'] in block['text']


@pytest.mark.parametrize('mutation',[
    lambda b:b.update(contract_version='2.0'),lambda b:b.update(operation='sttm.transform'),
    lambda b:b.update(request_id={}),lambda b:b.update(warnings={'delegation':{}}),
    lambda b:b.update(warnings=[{'code':'BAD','message':'x','delegation':{}}]),
    lambda b:b.update(context={'delegation':{}}),lambda b:b.update(agent='AGT_TRANSFORMATION_RULE'),
    lambda b:b['data'].update(status='pending'),lambda b:b.update(status='failed'),
    lambda b:b.update(error='failed'),lambda b:b['data'].update(error='failed'),
    lambda b:b['data'].update(meta={'delegation':{}}),lambda b:b['meta'].update(delegation={}),
    lambda b:b.update(result={'mappings':{'FOREIGN':{}}}),lambda b:b['data'].update(artifact={'tool':'run'}),
    lambda b:b['meta']['evidence_review']['facts'][0].update(observation='not literal'),
    lambda b:b['meta']['evidence_review']['facts'][0].update(quote='Fabricated assertion'),
    lambda b:b['meta']['evidence_review'].update(block_id='foreign'),
    lambda b:b['data'].pop('agent'),lambda b:b['data'].pop('status'),
])
def test_normal_contract_compatibility_does_not_weaken_the_review_gate(mutation):
    blocks=EvidenceBlocks('snapshot',180000,180000);blocks.enabled=True;blocks.begin()
    blocks.project('Exact rule. '*20000);identity=blocks.pending[0]
    body=normal_review(blocks.blocks[identity]);mutation(body)
    with pytest.raises(EvidenceBlockError):blocks.accept(identity,json.dumps(body))
    assert not blocks.reviews


def uploaded_shape(targets,metadata):
    value=fast_payload(targets);add_table(value,columns=600)
    node=value['context']['relation_graph']['nodes'][0]
    node.update(kind='DERIVED_SOURCE',derived_source_id='selected-cte',
        sql_text='SELECT OTHER0 AS X47 FROM D.S.UNUSED',parent_relation_ids=['UNUSED'])
    value['context']['semantic_context'].append({'table':{'database':'D','schema':'S','table':'CACHED_CTE_SEMANTICS'},
        'semantic_model':{'derived_source_id':'selected-cte','attributes':metadata}})
    return value


@pytest.mark.parametrize('targets',[1,10,37])
@pytest.mark.parametrize('metadata',[
    [{'name':'X47','business_meaning':'Exposed CTE output'}],
    [{'name':'HIDDEN','business_meaning':'Unexposed cached upstream column'}],
    [{'name':'X47'},{'name':'HIDDEN'}],
    [{'name':'Mixed.Case','business_meaning':'Quoted cache metadata'}],
])
def test_naturally_unbound_uploaded_lineage_projects_without_granting_source_authority(targets,metadata):
    value=uploaded_shape(targets,metadata);original=deepcopy(value)
    store,plan=plan_for(value,max_chars=180000,max_bytes=180000)
    nulls=[card for card in plan.prepared.records if card.kind=='lineage_column' and card.body.get('binding') is None]
    assert nulls, 'Fixture must generate unbound cards through production preparation'
    # Same node read resolves both physical contract and cached semantic owner.
    plan._pin_operations([{'operation':'column','relation':'a','column':item['name']} for item in metadata])
    assert not {card.record_id for card in nulls}&plan.pinned
    packet=unpack(plan.messages([]))
    assert {item['source_ref'] for item in packet['context']['selectable_sources']}=={'a.X47'}
    assert value==original and len(store.inventory['D.S.UNUSED'])==600
    assert all(name not in plan.allowed for name in ['a.HIDDEN','a.OTHER599'])
    assert len(wire_text(plan.messages([])).encode())<=180000


def profile_value():
    value=fast_payload();value['context']['learning_context']={}
    profile={'confirmed_pk':['X47'],'pk_note':'Confirmed identity remains required.',
        'eliminated_candidates':[{'column':f'FIELD_{i}', 'reason':'Eliminated as primary-key candidate due to nulls or nonuniqueness.'} for i in range(1500)]}
    value['context']['semantic_context'][0]['semantic_model']['pk_detection']=profile
    return value


def test_large_key_elimination_keeps_exact_typed_optional_evidence_and_required_key_contract():
    value=profile_value();store,plan=plan_for(value,max_chars=60000,max_bytes=60000)
    packet=unpack(plan.messages([]));optional=set(plan.blocks.roots)-plan.blocks.required_roots
    assert optional and not plan.required_pending_blocks()
    refs=[entry.source_ref for entry in plan.binding_admissions()];assert any(ref.replace(chr(34),'')=='a.X47' for ref in refs)
    assert 'Confirmed identity remains required.' in json.dumps(packet)
    assert 'confirmed_pk' in json.dumps(packet) and 'not mapping eligibility' in packet['instructions']
    for root in optional:
        text=''.join(plan.blocks.blocks[i]['text'] for i in sorted(plan.blocks.roots[root],key=lambda i:plan.blocks.blocks[i]['text_start']))
        assert 'FIELD_' in text
        assert all(context['purpose']=='primary_key_candidate_profiling' for context in plan.blocks.root_contexts[root])
        assert any(context['owner']['relation']=='D.S.A' for context in plan.blocks.root_contexts[root])
        assert all('pk_detection' in context['path'] and 'eliminated_candidates' in context['path'] for context in plan.blocks.root_contexts[root])
    assert value['context']['semantic_context'][0]['semantic_model']['pk_detection'] in [
        item['pk_detection'] for item in store.tables['D.S.A'] if 'pk_detection' in item]
    saved=set(plan.blocks.required_roots)
    assert not plan.request_optional_evidence_roots(['a.X47'],['foreign'])
    assert not plan.request_optional_evidence_roots(['a.FABRICATED'],list(optional))
    assert plan.blocks.required_roots==saved
    assert plan.request_optional_evidence_roots(['a.X47'],list(optional))
    assert plan.required_pending_blocks()
    identity=plan.required_pending_blocks()[0]
    request=json.loads(plan.blocks.request(identity)[0]['content'][0]['text'])
    assert request['context']['evidence_ownership'][0]['owner']['relation']=='D.S.A'


def test_identical_text_in_a_business_constraint_cannot_inherit_optional_pk_classification():
    blocks=EvidenceBlocks('snapshot',180000,180000);blocks.enabled=True;blocks.begin()
    text='This exact content is shared, but provenance differs. '*4000
    optional=blocks.project(text,path=('semantics','pk_detection','eliminated_candidates'))
    mandatory=blocks.project(text,path=('semantics','business_rules'))
    assert optional['exact_evidence_root']==mandatory['exact_evidence_root']
    assert blocks.pending_for_roots({mandatory['exact_evidence_root']})


@pytest.mark.parametrize('specialist',[False,True])
def test_normal_review_envelopes_reach_decisions_and_real_specialist_transport(transport_harness,specialist):
    h=transport_harness;builder,models,_,_=setup(h,3)
    value=fast_payload(3)
    value['data']['message']='Mandatory synthetic population rule, preserve filters. '*100
    calls=[]
    def hook(outgoing):
        from scripts.automap_message_sizes import expand_packet
        packet=expand_packet(json.JSONDecoder().raw_decode(json.loads(outgoing.content)['messages'][0]['content'][0]['text'])[0])
        calls.append((outgoing.url.path,packet.get('protocol')))
        if packet.get('protocol')=='auto_map_exact_evidence_block_v1':
            h.state.answer=json.dumps(normal_review(packet['context']['evidence_block']))
        elif 'AGT_TRANSFORMATION_RULE' in outgoing.url.path:
            h.state.answer=rules(*[a['target_attribute'] for a in packet['data']['attributes']])
        else:
            names=[a['target_attribute'] for a in packet['data']['attributes']]
            h.state.answer=answer_for(names,**{name:{'source_attributes':['a.X47'],'source_dependencies':['a.X47'],
                'preprocessing_rule_type':'Custom' if specialist else 'Direct',
                'transformation_classification':'complex' if specialist else 'direct'} for name in names})
    h.state.hook=hook
    final=asyncio.run(builder.invoke_auto_map_parallel(prepared_request(value)))
    assert sum(protocol=='auto_map_fast_path_v1' for _,protocol in calls) <= 3
    assert any(protocol=='auto_map_fast_path_v1' for _,protocol in calls)
    assert list(final.result.mappings)==['NAME0','NAME1','NAME2']
    assert all(row.source_attributes==['a.X47'] for row in final.result.mappings.values())
    if specialist:
        assert any('AGT_TRANSFORMATION_RULE' in path for path,_ in calls)
        assert all(row.preprocessing_rule=='TRIM(a.X47)' for row in final.result.mappings.values())
    assert all(slot['STATE']=='FREE' for slot in h.database.slots)
    for runtime in models:
        for index in range(1,len(h.state.models)+1):
            try:message=runtime.request_for(index).message
            except (KeyError,ValueError):continue
            assert len(message)<=120000 and len(message.encode())<=120000


def test_large_pk_diagnostic_does_not_gate_the_first_mapping_call(transport_harness):
    h=transport_harness;builder,models,_,_=setup(h,1)
    builder._settings=builder._settings.model_copy(update={'agent_outbound_message_max_chars':60000,'agent_outbound_message_max_bytes':60000})
    calls=[]
    def hook(outgoing):
        packet=json.loads(json.loads(outgoing.content)['messages'][0]['content'][0]['text'])
        calls.append(packet.get('protocol'))
        assert packet.get('protocol')=='auto_map_fast_path_v1'
        h.state.answer=answer_for(['NAME0'])
    h.state.hook=hook
    final=asyncio.run(builder.invoke_auto_map_parallel(prepared_request(profile_value())))
    assert calls==['auto_map_fast_path_v1'] and final.result.mappings['NAME0'].source_attributes==['a.X47']


def test_full_37_target_parent_and_four_workers_reach_decisions_with_normal_review_contract(monkeypatch):
    """Real parent freeze/restore/wire/governance/worker, fake model and HTTP.

    This proves routing/contracts/coverage, not semantic mapping accuracy.
    """
    import httpx
    from types import SimpleNamespace
    from app.core.sttm_builder import STTMBuilderService
    from app.schema.sttm_builder import STTMBuilderEnvelopeRequest
    from tests.test_automap_fast_job import proxy,deny
    from tests.unit.core.test_automap_fast_batch import governed_parent_discovery
    worker,req=governed_parent_discovery()
    discovery=deepcopy(req.meta.pop('_automap_fast_handoff')['discovery'])
    req.meta['auto_map_resolution_mode']='preserve_and_complete'
    req.data.message='Mandatory population evidence; preserve current filters and joins. '*50
    client=proxy(AUTOMAP_CONTEXT_BATCH_COUNT=4,SNOWFLAKE_DATABASE='DB',SNOWFLAKE_SCHEMA='META')
    monkeypatch.setattr(STTMBuilderService,'_load_project_firm_values',lambda *args:[])
    monkeypatch.setattr(STTMBuilderService,'prepare_auto_map_request',lambda self,current:current)
    monkeypatch.setattr(STTMBuilderService,'_discover_auto_map_batch_evidence',lambda self,current,targets:deepcopy(discovery))
    original_run=worker._agent.run_detailed
    def model(messages,**kwargs):
        packet=unpack(messages)
        if packet.get('protocol')=='auto_map_exact_evidence_block_v1':
            worker._agent.calls.append((deepcopy(messages),kwargs))
            return json.dumps(normal_review(packet['context']['evidence_block'])),None,None
        return original_run(messages,**kwargs)
    monkeypatch.setattr(worker._agent,'run_detailed',model)
    headers={'X-Workbench-OAuth-Role':'SAME_CALLER_ROLE','X-Workbench-OAuth-User':'OFFLINE_CALLER'}
    root=client._prepare_job_request(req,session=SimpleNamespace(sql=deny),owner='OFFLINE_CALLER',headers=headers)
    frozen=root.model_dump(mode='json')
    restored=client._restore_resolution(STTMBuilderEnvelopeRequest.model_validate(json.loads(json.dumps(frozen))))
    responses=[]
    def send(http,outgoing,**kwargs):
        assert outgoing.headers['X-Workbench-OAuth-User']=='OFFLINE_CALLER'
        incoming=STTMBuilderEnvelopeRequest.model_validate(json.loads(outgoing.content))
        from app.core.automap_row_candidates import validate_row_candidates
        response=validate_row_candidates(worker,incoming,worker.invoke(incoming));responses.append(response)
        return httpx.Response(200,json=response.model_dump(mode='json'),request=outgoing)
    monkeypatch.setattr(httpx.Client,'send',send)
    final=client._invoke_with_headers(restored,headers=headers)
    assert len(responses)==5
    assert sorted(len(response.result.mappings) for response in responses)==[7]*3+[8]*2
    assert len(final.result.mappings)==37
    assert all(row.source_attributes==['a.X47'] for row in final.result.mappings.values())
    packets=[unpack(messages) for messages,_ in worker._agent.calls]
    assert sum(packet.get('protocol')=='auto_map_fast_path_v1' for packet in packets)==5
    assert len(packets) <= 3 * len(responses)
    assert final.meta['auto_mapping_dispatch']['failed_batches']==[]
    assert root.model_dump(mode='json')==frozen
    for messages,_ in worker._agent.calls:
        assert len(wire_text(messages))<=120000 and len(wire_text(messages).encode())<=120000


def test_model_can_explicitly_navigate_optional_profile_roots_on_owning_guarded_runtime(transport_harness):
    h=transport_harness;builder,models,_,_=setup(h,1)
    builder._settings=builder._settings.model_copy(update={'agent_outbound_message_max_chars':60000,'agent_outbound_message_max_bytes':60000})
    calls=[];decision_count=0
    def hook(outgoing):
        nonlocal decision_count
        packet=json.JSONDecoder().raw_decode(json.loads(outgoing.content)['messages'][0]['content'][0]['text'])[0]
        from scripts.automap_message_sizes import expand_packet
        packet=expand_packet(packet);calls.append(packet.get('protocol'))
        if packet.get('protocol')=='auto_map_exact_evidence_block_v1':
            assert any(owner['purpose']=='primary_key_candidate_profiling' for owner in packet['context']['evidence_ownership'])
            h.state.answer=json.dumps(normal_review(packet['context']['evidence_block']))
        else:
            decision_count+=1
            if decision_count==1:
                roots=[node['root_id'] for node in packet['context']['evidence_graph']['evidence_nodes'] if not node['required_for_mapping']]
                assert roots
                ref=packet['context']['selectable_sources'][0]['source_ref']
                body=json.loads(answer_for(['NAME0'],NAME0={'source_attributes':[], 'confidence_score':0,
                    'transformation_classification':'unresolved','unmatched_reason':'Inspect the key-profile detail before deciding'}))
                body['meta']={'evidence_requests':[{'target':'NAME0','snapshot_hash':packet['context']['evidence_graph']['snapshot_hash'],
                    'source_refs':[ref],'evidence_roots':roots}]}
                h.state.answer=json.dumps(body)
            else:h.state.answer=answer_for(['NAME0'])
    h.state.hook=hook
    final=asyncio.run(builder.invoke_auto_map_parallel(prepared_request(profile_value())))
    assert calls[0]=='auto_map_fast_path_v1'
    from app.core.automap_evidence_blocks import MAX_EVIDENCE_REVIEW_CALLS
    assert calls.count('auto_map_exact_evidence_block_v1') <= MAX_EVIDENCE_REVIEW_CALLS
    assert calls.count('auto_map_fast_path_v1') <= 3
    assert final.result.mappings['NAME0'].transformation_classification == 'unresolved'
    assert all(slot['STATE']=='FREE' for slot in h.database.slots)


@pytest.mark.parametrize('suffix',['x'*150000, ('界\\"'*40000)], ids=['ascii-delimiter-free', 'unicode-escaped-delimiter-free'])
def test_lossless_text_factoring_handles_long_delimiter_free_suffix_in_linear_time(suffix):
    import time
    from app.core.automap_retrieval import factor_exact_text_lines
    from scripts.automap_message_sizes import expand_packet
    # Actual transport factoring, including quotes, Unicode, comma/semicolon
    # delimiters inside SQL literals, empty lines and repeated join clauses.
    text="SELECT 'comma, inside; literal'\n\tFROM D.S.A a\nLEFT JOIN D.S.B b ON a.ID=b.ID WHERE a.ACTIVE=1; \n"+suffix
    original={'sql':[text,text], 'single':suffix}
    start=time.monotonic();factored=factor_exact_text_lines(deepcopy(original))
    assert time.monotonic()-start<5, 'Text segmentation must not scan every possible suffix'
    assert expand_packet(factored)==original


def test_profile_named_fields_inside_authored_business_rules_are_not_exempted():
    blocks=EvidenceBlocks('snapshot',180000,180000);blocks.enabled=True;blocks.begin()
    blocks.project({'business_rules':{'pk_detection':{'eliminated_candidates':'Exact authored rule. '*20000}}})
    assert blocks.pending
    assert all(context['required_for_mapping'] for values in blocks.root_contexts.values() for context in values)


@pytest.fixture(scope='module')
def available_upload_shape():
    from tests.unit.core.test_automap_fast_context import available_ft_pitt_request
    return available_ft_pitt_request.__wrapped__()


def test_required_only_global_capsules_do_not_trigger_per_column_repacking_for_every_target(available_upload_shape,monkeypatch):
    import app.core.automap_fast_context as module
    original=module.factor_fast_packet;calls=[]
    def measured(*args,**kwargs):
        calls.append(1)
        assert len(calls)<=80, 'Required-only globals must share exact framing instead of hundreds of futile renders'
        return original(*args,**kwargs)
    monkeypatch.setattr(module,'factor_fast_packet',measured)
    _,plan=plan_for(available_upload_shape)
    assert plan.binding_admissions() and plan._fits(plan.messages([]))
