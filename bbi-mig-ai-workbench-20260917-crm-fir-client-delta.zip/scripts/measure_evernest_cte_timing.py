#!/usr/bin/env python3
"""Measure the real Selection-page Cortex Analyst CTE route without publishing.

The historical filename is retained for compatibility; runtime inputs are fully
STTM-driven and do not assume a database, schema, table, or business domain.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Any


REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT / "scripts"))

import run_evernest_v2_acceptance as acceptance  # noqa: E402


def _artifact(response: dict[str, Any]) -> dict[str, Any]:
    data = response.get("data") or {}
    value = data.get("artifact") or response.get("artifact") or {}
    return value if isinstance(value, dict) else {}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sttm-id", required=True)
    parser.add_argument("--runs", type=int, default=2)
    parser.add_argument(
        "--exclude-source",
        action="append",
        default=[],
        help="Case-insensitive source FQN suffix to omit from this derived-source scope.",
    )
    args = parser.parse_args()

    acceptance._configure_environment()
    from fastapi.testclient import TestClient

    from app.core.config import get_settings
    from app.main import app

    get_settings.cache_clear()
    headers = {
        "Sf-Context-Current-User": "ANKURS",
        "Sf-Context-Current-User-Email": "ankur@example.com",
    }
    reports: list[dict[str, Any]] = []
    with TestClient(app) as client:
        detail = acceptance._response_data(
            client.get(f"/api/v1/sttms/{args.sttm_id}", headers=headers)
        )
        sttm = detail.get("sttm") or {}
        snapshot = detail.get("latest_snapshot") or {}
        excluded = tuple(value.upper() for value in args.exclude_source)
        source_tables = [
            table
            for table in snapshot.get("source_tables") or []
            if not acceptance._table_fqn(table).upper().endswith(excluded)
        ]
        scoped_snapshot = {**snapshot, "source_tables": source_tables}
        request = {
            "contract_version": "1.0",
            "operation": "sttm.derived_sql.generate",
            "context": {
                "source_tables": source_tables,
                "target_table": snapshot.get("target_table"),
                "driving_table": snapshot.get("driving_table"),
                "relationships": snapshot.get("relationships") or [],
                "relation_graph": snapshot.get("relation_graph"),
                "selected_columns_by_table": snapshot.get("selected_columns_by_table") or {},
                "selected_derived_sources": [
                    item.get("id")
                    for item in snapshot.get("derived_sources") or []
                    if item.get("id")
                ],
                "surface": "SOURCE_SELECTION",
                "semantic_level_requested": "FULL_REGISTRY",
                "project_id": str(sttm.get("project_id") or ""),
                "sttm_id": args.sttm_id,
                "workspace_context": scoped_snapshot,
            },
            "data": {
                "intent": "CHAT",
                "message": (
                    "Generate one reusable derived source CTE for the selected migration "
                    "sources. Use the verified relationships and return "
                    "the complete SQL draft. Do not run or save it."
                ),
            },
        }
        for index in range(max(1, args.runs)):
            started = time.perf_counter()
            response = client.post(
                "/api/v1/workbench/invoke",
                headers=headers,
                json=request,
            )
            elapsed_ms = round((time.perf_counter() - started) * 1000, 1)
            payload = response.json()
            artifact = _artifact(payload)
            data = payload.get("data") or {}
            meta = payload.get("meta") or {}
            derived_meta = meta.get("derived_sql_generation") or {}
            sql = str(
                artifact.get("sql_text")
                or artifact.get("sql")
                or data.get("sql")
                or ""
            )
            reports.append(
                {
                    "run": index + 1,
                    "http_status": response.status_code,
                    "elapsed_ms": elapsed_ms,
                    "status": data.get("status") or payload.get("status"),
                    "agent": data.get("agent") or payload.get("agent"),
                    "artifact_type": data.get("artifact_type"),
                    "executed_by": derived_meta.get("executed_by"),
                    "model_source": derived_meta.get("model_source"),
                    "open_in_builder": (
                        derived_meta.get("open_in_builder")
                        if "open_in_builder" in derived_meta
                        else artifact.get("open_in_builder")
                    ),
                    "cache_source": meta.get("cache_source"),
                    "timings_ms": meta.get("timings_ms"),
                    "sql_bytes": len(sql.encode("utf-8")),
                    "error": payload.get("error"),
                }
            )
    print(json.dumps({"sttm_id": args.sttm_id, "runs": reports}, indent=2, default=str))


if __name__ == "__main__":
    main()
