'use client';

'use client';

import { useState } from 'react';
import { AiaBox, AiaButton } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';

type LearningEvent = { traceId: string; kind: string; summary: string; timestamp: string; details: Record<string, unknown> };

type Learned = { id: string; title: string; detail: string };

/** Preferences saved and corrections learned in this run, newest first. */
export function learnedItems(events: LearningEvent[]): Learned[] {
  const items: Learned[] = [];
  for (const event of [...events].sort((a, b) => b.timestamp.localeCompare(a.timestamp))) {
    if (event.kind !== 'learning') continue;
    const details = event.details;
    if (details.kind === 'user_preference') {
      items.push({
        id: event.traceId,
        title: `${details.scope === 'project' ? 'Project' : 'Your'} preference`,
        detail: String(details.statement ?? event.summary),
      });
    } else if (details.kind === 'mapping_correction' && Array.isArray(details.corrections)) {
      const target = String(details.target_table ?? '').split('.').pop();
      for (const correction of details.corrections as Array<Record<string, unknown>>) {
        const before = (correction.before as string[] | undefined)?.join(', ') ?? '';
        const after = (correction.after as string[] | undefined)?.join(', ') ?? '';
        items.push({
          id: `${event.traceId}:${String(correction.column)}`,
          title: `${target}.${String(correction.column)}`,
          detail: `Use ${after} instead of ${before} next time.`,
        });
      }
    }
  }
  return items;
}

export function AgentLearnedList({ items }: { items: Learned[] }) {
  const [open, setOpen] = useState(false);
  if (!items.length) return null;
  return (
    <AiaBox sx={{ mt: 2, borderTop: '1px solid #e2e8f0', pt: 0.75 }}>
      <AiaButton size="small" variant="text" onClick={() => setOpen((value) => !value)} aria-expanded={open}
        sx={{ textTransform: 'none', px: 0, fontSize: 11.5, color: '#475569' }}>
        {open ? 'Hide' : 'Show'} recent learning · {items.length}
      </AiaButton>
      {open ? <AiaBox component="ul" sx={{ mt: 0.5, mb: 0, pl: 2 }}>
        {items.map((item) => (
          <AiaBox component="li" key={item.id} sx={{ fontSize: 12, color: '#475569', mb: 0.25 }}>
            <strong>{item.title}:</strong> {item.detail}
          </AiaBox>
        ))}
      </AiaBox> : null}
      {open ? <AiaText sx={{ mt: 0.5, fontSize: 10.5, color: '#64748b' }}>
        Used by later runs in this project; evidence still wins when it disagrees.
      </AiaText> : null}
    </AiaBox>
  );
}
