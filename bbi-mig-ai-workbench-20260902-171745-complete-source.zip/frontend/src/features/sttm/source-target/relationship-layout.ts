import type { JoinConfig } from '@/features/sttm/types/sttm.types';

export type RelationshipLayoutMetrics = {
  nodeWidth: number;
  nodeHeight: number;
  gapX: number;
  gapY: number;
  startX: number;
  startY: number;
};

export const RELATIONSHIP_LAYOUT_FULL: RelationshipLayoutMetrics = {
  nodeWidth: 360,
  nodeHeight: 380,
  gapX: 140,
  gapY: 110,
  startX: 48,
  startY: 48,
};

export const RELATIONSHIP_LAYOUT_COMPACT: RelationshipLayoutMetrics = {
  nodeWidth: 280,
  nodeHeight: 300,
  gapX: 110,
  gapY: 90,
  startX: 32,
  startY: 40,
};

const NEAR_GAP_X = 110;
const NEAR_GAP_Y = 90;

/** Minimum breathing room kept between two cards once real sizes are known. */
const MIN_SEPARATION_X = 48;
const MIN_SEPARATION_Y = 48;

/** Cards stacked in one join-distance column before it wraps into a new one. */
const MAX_ROWS_PER_LEVEL = 4;

function rowY(metrics: RelationshipLayoutMetrics, rowIndex: number) {
  return metrics.startY + rowIndex * (metrics.nodeHeight + metrics.gapY);
}

function columnIndexFromX(x: number, metrics: RelationshipLayoutMetrics) {
  const step = metrics.nodeWidth + metrics.gapX;
  if (step <= 0) return 0;
  return Math.max(0, Math.round((x - metrics.startX) / step));
}

function rectanglesOverlap(
  a: { x: number; y: number },
  b: { x: number; y: number },
  metrics: RelationshipLayoutMetrics,
) {
  const horizontalOverlap =
    a.x < b.x + metrics.nodeWidth && a.x + metrics.nodeWidth > b.x;
  const verticalOverlap =
    a.y < b.y + metrics.nodeHeight && a.y + metrics.nodeHeight > b.y;
  return horizontalOverlap && verticalOverlap;
}

function findOpenSlotInColumn(
  columnIndex: number,
  occupiedPositions: Array<{ x: number; y: number }>,
  metrics: RelationshipLayoutMetrics,
  preferredY?: number,
  gapX = metrics.gapX,
  gapY = metrics.gapY,
) {
  const targetX = metrics.startX + columnIndex * (metrics.nodeWidth + gapX);
  let candidateY = preferredY ?? metrics.startY;

  while (
    occupiedPositions.some((position) =>
      rectanglesOverlap({ x: targetX, y: candidateY }, position, metrics),
    )
  ) {
    candidateY += metrics.nodeHeight + gapY;
  }

  return { x: targetX, y: candidateY };
}

function resolveAnchorTableId(
  newTableId: string,
  existingIds: Set<string>,
  joins: JoinConfig[],
  drivingTableId: string | null | undefined,
  fallbackTableId?: string,
) {
  for (const join of joins) {
    if (
      join.leftTableId === newTableId &&
      join.rightTableId &&
      existingIds.has(join.rightTableId)
    ) {
      return join.rightTableId;
    }
    if (
      join.rightTableId === newTableId &&
      join.leftTableId &&
      existingIds.has(join.leftTableId)
    ) {
      return join.leftTableId;
    }
  }

  if (drivingTableId && existingIds.has(drivingTableId)) {
    return drivingTableId;
  }

  return fallbackTableId ?? null;
}

function findNearPlacementForNewNode(
  newTableId: string,
  previousNodes: Array<{ id: string; position: { x: number; y: number } }>,
  occupiedPositions: Array<{ x: number; y: number }>,
  layoutPositions: Record<string, { x: number; y: number }>,
  metrics: RelationshipLayoutMetrics,
  joins: JoinConfig[],
  drivingTableId: string | null | undefined,
) {
  if (previousNodes.length === 0) {
    return layoutPositions[newTableId] ?? { x: metrics.startX, y: metrics.startY };
  }

  const existingIds = new Set(previousNodes.map((node) => node.id));
  const positionById = Object.fromEntries(
    previousNodes.map((node) => [node.id, node.position]),
  ) as Record<string, { x: number; y: number }>;

  const anchorId = resolveAnchorTableId(
    newTableId,
    existingIds,
    joins,
    drivingTableId,
    previousNodes[0]?.id,
  );
  const anchorPosition = anchorId ? positionById[anchorId] : null;

  const candidateOffsets = anchorPosition
    ? [
        { x: anchorPosition.x + metrics.nodeWidth + NEAR_GAP_X, y: anchorPosition.y },
        { x: anchorPosition.x, y: anchorPosition.y + metrics.nodeHeight + NEAR_GAP_Y },
      ]
    : [];

  if (occupiedPositions.length > 0) {
    const maxRight = Math.max(
      ...occupiedPositions.map((position) => position.x + metrics.nodeWidth),
    );
    const minY = Math.min(...occupiedPositions.map((position) => position.y));
    candidateOffsets.push({ x: maxRight + NEAR_GAP_X, y: minY });
  }

  for (const candidate of candidateOffsets) {
    if (
      !occupiedPositions.some((position) =>
        rectanglesOverlap(candidate, position, metrics),
      )
    ) {
      return candidate;
    }
  }

  if (anchorPosition) {
    return findOpenSlotInColumn(
      columnIndexFromX(anchorPosition.x, metrics),
      occupiedPositions,
      metrics,
      anchorPosition.y + metrics.nodeHeight + NEAR_GAP_Y,
      NEAR_GAP_X,
      NEAR_GAP_Y,
    );
  }

  const layoutPosition = layoutPositions[newTableId] ?? {
    x: metrics.startX,
    y: metrics.startY,
  };
  return findOpenSlotInColumn(
    columnIndexFromX(layoutPosition.x, metrics),
    occupiedPositions,
    metrics,
    layoutPosition.y,
    NEAR_GAP_X,
    NEAR_GAP_Y,
  );
}

/**
 * Default hub layout: driving table in the left column, joined tables in
 * subsequent columns by join distance (see reference sketch).
 */
export function buildRelationshipLayout(
  tableIds: string[],
  drivingTableId: string | null | undefined,
  joins: JoinConfig[],
  metrics: RelationshipLayoutMetrics = RELATIONSHIP_LAYOUT_FULL,
): Record<string, { x: number; y: number }> {
  if (tableIds.length === 0) return {};

  const driving =
    drivingTableId && tableIds.includes(drivingTableId) ? drivingTableId : tableIds[0];

  const levels = new Map<string, number>();
  levels.set(driving, 0);

  const adjacency = new Map<string, Set<string>>();
  for (const tableId of tableIds) {
    adjacency.set(tableId, new Set());
  }

  for (const join of joins) {
    const leftId = join.leftTableId;
    const rightId = join.rightTableId;
    if (!leftId || !rightId) continue;
    if (!adjacency.has(leftId) || !adjacency.has(rightId)) continue;
    adjacency.get(leftId)?.add(rightId);
    adjacency.get(rightId)?.add(leftId);
  }

  const queue = [driving];
  while (queue.length > 0) {
    const current = queue.shift() as string;
    const currentLevel = levels.get(current) ?? 0;
    for (const neighbor of adjacency.get(current) ?? []) {
      if (levels.has(neighbor)) continue;
      levels.set(neighbor, currentLevel + 1);
      queue.push(neighbor);
    }
  }

  const disconnectedIds = tableIds
    .filter((tableId) => !levels.has(tableId))
    .sort();
  const connectedMaxLevel = Math.max(0, ...Array.from(levels.values()));
  const disconnectedStartLevel = levels.size === 1 ? 0 : connectedMaxLevel + 1;
  const disconnectedColumnCount = Math.min(3, Math.max(1, disconnectedIds.length));
  disconnectedIds.forEach((tableId, index) => {
    levels.set(
      tableId,
      disconnectedStartLevel + (index % disconnectedColumnCount),
    );
  });

  const tablesByLevel = new Map<number, string[]>();
  for (const tableId of tableIds) {
    const level = levels.get(tableId) ?? 0;
    const bucket = tablesByLevel.get(level) ?? [];
    bucket.push(tableId);
    tablesByLevel.set(level, bucket);
  }

  for (const bucket of tablesByLevel.values()) {
    bucket.sort();
  }

  const positions: Record<string, { x: number; y: number }> = {};
  const occupiedPositions: Array<{ x: number; y: number }> = [];
  let columnCursor = 0;

  for (const [, ids] of Array.from(tablesByLevel.entries()).sort(([a], [b]) => a - b)) {
    // A join distance holding many tables becomes an unreadable tower, so wrap
    // it into a compact block of sub-columns instead of one tall stack.
    ids.forEach((tableId, index) => {
      const position = findOpenSlotInColumn(
        columnCursor + Math.floor(index / MAX_ROWS_PER_LEVEL),
        occupiedPositions,
        metrics,
        rowY(metrics, index % MAX_ROWS_PER_LEVEL),
      );
      positions[tableId] = position;
      occupiedPositions.push(position);
    });

    columnCursor += Math.max(1, Math.ceil(ids.length / MAX_ROWS_PER_LEVEL));
  }

  return positions;
}

export type RelationshipNodeSize = { width?: number | null; height?: number | null };

type MeasurableNode = {
  measured?: RelationshipNodeSize | null;
  width?: number | null;
  height?: number | null;
};

/** Real rendered size of a card, falling back to the layout estimate. */
function resolveNodeSize(
  nodeId: string,
  node: unknown,
  metrics: RelationshipLayoutMetrics,
  sizeById?: Map<string, RelationshipNodeSize>,
) {
  const measurable = node as MeasurableNode | undefined;
  const known = sizeById?.get(nodeId);
  const width =
    known?.width || measurable?.measured?.width || measurable?.width || metrics.nodeWidth;
  const height =
    known?.height || measurable?.measured?.height || measurable?.height || metrics.nodeHeight;
  return { width, height };
}

/** Collects the sizes React Flow has already measured so layout can reuse them. */
export function collectRelationshipNodeSizes<T extends { id: string }>(
  nodes: T[],
): Map<string, RelationshipNodeSize> {
  const sizes = new Map<string, RelationshipNodeSize>();
  for (const node of nodes) {
    const measurable = node as unknown as MeasurableNode;
    const width = measurable.measured?.width || measurable.width;
    const height = measurable.measured?.height || measurable.height;
    if (width || height) {
      sizes.set(node.id, { width, height });
    }
  }
  return sizes;
}

/**
 * Pushes cards apart so no two overlap, keeping each card's column (x) and only
 * shifting collisions downwards. Idempotent: a second pass is a no-op.
 */
export function resolveRelationshipNodeOverlaps<
  T extends { id: string; position: { x: number; y: number } },
>(
  nodes: T[],
  metrics: RelationshipLayoutMetrics = RELATIONSHIP_LAYOUT_FULL,
  sizeById?: Map<string, RelationshipNodeSize>,
): T[] {
  if (nodes.length < 2) return nodes;

  const boxes = nodes.map((node) => {
    const { width, height } = resolveNodeSize(node.id, node, metrics, sizeById);
    return { id: node.id, x: node.position.x, y: node.position.y, width, height };
  });

  const ordered = [...boxes].sort(
    (left, right) => left.x - right.x || left.y - right.y || left.id.localeCompare(right.id),
  );

  const placed: typeof ordered = [];
  for (const box of ordered) {
    // Bounded loop: each iteration clears at least one collision.
    for (let attempt = 0; attempt <= nodes.length; attempt += 1) {
      const collisions = placed.filter(
        (other) =>
          box.x < other.x + other.width + MIN_SEPARATION_X &&
          box.x + box.width + MIN_SEPARATION_X > other.x &&
          box.y < other.y + other.height + MIN_SEPARATION_Y &&
          box.y + box.height + MIN_SEPARATION_Y > other.y,
      );
      if (collisions.length === 0) break;
      box.y = Math.max(...collisions.map((other) => other.y + other.height)) + metrics.gapY;
    }
    placed.push(box);
  }

  const resolvedById = new Map(boxes.map((box) => [box.id, { x: box.x, y: box.y }]));

  return nodes.map((node) => {
    const resolved = resolvedById.get(node.id);
    if (!resolved || (resolved.x === node.position.x && resolved.y === node.position.y)) {
      return node;
    }
    return { ...node, position: resolved };
  });
}

export type MergeRelationshipNodeOptions = {
  joins?: JoinConfig[];
  drivingTableId?: string | null;
};

export function mergeRelationshipNodePositions<
  T extends { id: string; position: { x: number; y: number } },
>(
  nextNodes: T[],
  previousNodes: T[],
  layoutPositions: Record<string, { x: number; y: number }>,
  metrics: RelationshipLayoutMetrics = RELATIONSHIP_LAYOUT_FULL,
  options: MergeRelationshipNodeOptions = {},
): T[] {
  const joins = options.joins ?? [];
  const drivingTableId = options.drivingTableId;
  const occupiedPositions = previousNodes.map((node) => node.position);

  const newNodes = nextNodes
    .filter((node) => !previousNodes.some((previous) => previous.id === node.id))
    .sort((left, right) => left.id.localeCompare(right.id));

  const resolvedNewPositions = new Map<string, { x: number; y: number }>();

  for (const node of newNodes) {
    const position = findNearPlacementForNewNode(
      node.id,
      previousNodes,
      occupiedPositions,
      layoutPositions,
      metrics,
      joins,
      drivingTableId,
    );
    resolvedNewPositions.set(node.id, position);
    occupiedPositions.push(position);
  }

  const merged = nextNodes.map((node) => {
    const existing = previousNodes.find((previous) => previous.id === node.id);
    if (existing) {
      return { ...node, position: existing.position };
    }

    return {
      ...node,
      position: resolvedNewPositions.get(node.id) ?? {
        x: metrics.startX,
        y: metrics.startY,
      },
    };
  });

  // Cards vary in height (column lists expand), so settle the graph with the
  // sizes React Flow has already measured rather than the layout estimate.
  return resolveRelationshipNodeOverlaps(
    merged,
    metrics,
    collectRelationshipNodeSizes(previousNodes),
  );
}

export function getRelationshipViewportPadding(
  metrics: RelationshipLayoutMetrics = RELATIONSHIP_LAYOUT_FULL,
) {
  return {
    left: Math.max(16, metrics.startX - 24),
    top: Math.max(16, metrics.startY - 24),
  };
}
