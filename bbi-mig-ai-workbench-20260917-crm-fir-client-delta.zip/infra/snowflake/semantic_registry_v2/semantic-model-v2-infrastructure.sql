-- Supporting objects required by AGT_SEMANTIC_MODEL_V2.
-- Exported from the validated V2 environment; namespaces and warehouse are rendered by bootstrap.

-- SEM_SCHEMA_VIEWS
CREATE TABLE IF NOT EXISTS __STTM_METADATA_NAMESPACE__.SEM_SCHEMA_VIEWS (
	VIEW_ID VARCHAR(16777216) NOT NULL DEFAULT UUID_STRING(),
	DATABASE_NAME VARCHAR(16777216) NOT NULL,
	SCHEMA_NAME VARCHAR(16777216) NOT NULL,
	GENERATED_AT TIMESTAMP_NTZ(9) NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	GENERATED_BY VARCHAR(16777216) NOT NULL DEFAULT 'schema_semantic_layer_agent',
	STATUS VARCHAR(16777216) NOT NULL DEFAULT 'ACTIVE',
	VERSION VARCHAR(16777216) NOT NULL DEFAULT '1.0',
	TABLE_COUNT NUMBER(38,0),
	SCHEMA_HASH VARCHAR(16777216),
	LAST_ALTERED_TS TIMESTAMP_NTZ(9),
	SCHEMA_SUMMARY VARIANT,
	constraint PK_SCHEMA_VIEWS primary key (VIEW_ID)
)COMMENT='Tier 2: Schema-level semantic summaries. One ACTIVE row per DB+schema.'
;

-- SEM_TABLE_VIEWS
CREATE TABLE IF NOT EXISTS __STTM_METADATA_NAMESPACE__.SEM_TABLE_VIEWS (
	VIEW_ID VARCHAR(16777216) NOT NULL DEFAULT UUID_STRING(),
	DATABASE_NAME VARCHAR(16777216) NOT NULL,
	SCHEMA_NAME VARCHAR(16777216) NOT NULL,
	TABLE_NAME VARCHAR(16777216) NOT NULL,
	FQN VARCHAR(16777216) NOT NULL,
	GENERATED_AT TIMESTAMP_NTZ(9) NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	GENERATED_BY VARCHAR(16777216) NOT NULL DEFAULT 'schema_semantic_layer_agent',
	STATUS VARCHAR(16777216) NOT NULL DEFAULT 'ACTIVE',
	VERSION VARCHAR(16777216) NOT NULL DEFAULT '1.0',
	ROW_COUNT NUMBER(38,0),
	COLUMN_COUNT NUMBER(38,0),
	COLUMN_SET_HASH VARCHAR(16777216),
	LAST_ALTERED_TS TIMESTAMP_NTZ(9),
	SEMANTIC_VIEW VARIANT NOT NULL,
	constraint PK_TABLE_VIEWS primary key (VIEW_ID)
)COMMENT='Tier 3 (primary): Per-table semantic view JSON. One ACTIVE row per DB+schema+table. SUPERSEDED rows are kept for audit. Never hard-delete.'
;

-- SEM_COLUMN_VIEWS
CREATE TABLE IF NOT EXISTS __STTM_METADATA_NAMESPACE__.SEM_COLUMN_VIEWS (
	VIEW_ID VARCHAR(16777216) NOT NULL DEFAULT UUID_STRING(),
	DATABASE_NAME VARCHAR(16777216) NOT NULL,
	SCHEMA_NAME VARCHAR(16777216) NOT NULL,
	TABLE_NAME VARCHAR(16777216) NOT NULL,
	COLUMN_NAME VARCHAR(16777216) NOT NULL,
	FQN VARCHAR(16777216) NOT NULL,
	TABLE_VIEW_ID VARCHAR(16777216) NOT NULL,
	GENERATED_AT TIMESTAMP_NTZ(9) NOT NULL DEFAULT CURRENT_TIMESTAMP(),
	GENERATED_BY VARCHAR(16777216) NOT NULL DEFAULT 'schema_semantic_layer_agent',
	STATUS VARCHAR(16777216) NOT NULL DEFAULT 'ACTIVE',
	DATA_TYPE VARCHAR(16777216),
	COLUMN_HASH VARCHAR(16777216),
	ATTRIBUTE_VIEW VARIANT NOT NULL,
	COLUMN_DESCRIPTION VARCHAR(16777216) COMMENT 'Plain-text 1-sentence description of this column. Extracted from\nattribute_semantic_model[i].description at save time. Used by\nREFRESH_COLUMN_SEARCH_INDEX as Priority 1 in the description chain\n(SEM_COLUMN_VIEWS > LLM_GENERATED > COLUMN_NAME_FALLBACK).',
	constraint PK_COLUMN_VIEWS primary key (VIEW_ID)
)COMMENT='Tier 4: Per-column attribute_semantic_model JSON. One ACTIVE row per DB+schema+table+column. TABLE_VIEW_ID is a soft link to the SEM_TABLE_VIEWS row that triggered this generation. SUPERSEDED rows are kept for audit. Never hard-delete.'
;

ALTER TABLE __STTM_METADATA_NAMESPACE__.SEM_COLUMN_VIEWS
    ADD COLUMN IF NOT EXISTS COLUMN_DESCRIPTION VARCHAR;

-- SEM_NATIVE_VIEWS
CREATE TABLE IF NOT EXISTS __STTM_METADATA_NAMESPACE__.SEM_NATIVE_VIEWS (
	NATIVE_VIEW_ID VARCHAR(16777216) NOT NULL DEFAULT UUID_STRING() COMMENT 'Unique row identifier (UUID).',
	DATABASE_NAME VARCHAR(16777216) NOT NULL COMMENT 'Source database name (uppercased).',
	SCHEMA_NAME VARCHAR(16777216) NOT NULL COMMENT 'Source schema name (uppercased).',
	TABLE_NAME VARCHAR(16777216) NOT NULL COMMENT 'Source table name (uppercased).',
	SOURCE_FQN VARCHAR(16777216) NOT NULL COMMENT 'Fully qualified source table: DB.SCHEMA.TABLE.',
	TABLE_VIEW_ID VARCHAR(16777216) COMMENT 'Soft FK to SEM_TABLE_VIEWS.VIEW_ID. Identifies which semantic JSON version was consumed.',
	VIEW_NAME VARCHAR(16777216) NOT NULL COMMENT 'Name of the created semantic view object. Pattern: SV_{SCHEMA}_{TABLE}, e.g. SV_RAW_FACT_SALES.',
	TARGET_DB VARCHAR(16777216) NOT NULL DEFAULT '__STTM_METADATA_DATABASE__' COMMENT 'Database where the semantic view was created.',
	TARGET_SCHEMA VARCHAR(16777216) NOT NULL DEFAULT '__STTM_METADATA_SCHEMA__' COMMENT 'Schema where the semantic view was created.',
	TARGET_FQN VARCHAR(16777216) NOT NULL COMMENT 'Fully qualified semantic view: TARGET_DB.TARGET_SCHEMA.VIEW_NAME.',
	DDL_TEXT VARCHAR(16777216) NOT NULL COMMENT 'The complete CREATE OR REPLACE SEMANTIC VIEW DDL statement that was executed to create this view.',
	FACTS_COUNT NUMBER(38,0) COMMENT 'Number of metric columns placed in the facts block.',
	DIMENSIONS_COUNT NUMBER(38,0) COMMENT 'Number of non-metric columns placed in the dimensions block.',
	JOINS_COUNT NUMBER(38,0) COMMENT 'Number of related tables added to the tables clause as joins.',
	HAS_LOW_CONFIDENCE_JOINS BOOLEAN COMMENT 'TRUE when at least one LOW-confidence outgoing relationship was included as a structural join.',
	HAS_FLAGGED_EXCLUDED BOOLEAN COMMENT 'TRUE when at least one FLAGGED relationship was excluded from joins (noted in table comment only).',
	PK_CONFIRMED BOOLEAN COMMENT 'Mirrors pk_detection.pk_confirmed from the source JSON. FALSE means no confirmed PK — composite PK may be suspected.',
	PHASE2_ENABLED BOOLEAN COMMENT 'TRUE when Phase 2 FK enrichment was run for this table.',
	STATUS VARCHAR(16777216) NOT NULL DEFAULT 'ACTIVE' COMMENT 'Row lifecycle status: ACTIVE | SUPERSEDED | FAILED. Only one ACTIVE row per source table at any time.',
	CREATED_AT TIMESTAMP_NTZ(9) NOT NULL DEFAULT CURRENT_TIMESTAMP() COMMENT 'UTC timestamp when this row was inserted.',
	GENERATED_BY VARCHAR(16777216) NOT NULL DEFAULT CURRENT_USER() COMMENT 'Snowflake user or role that triggered generation.',
	ERROR_MESSAGE VARCHAR(16777216) COMMENT 'Populated only when STATUS = FAILED. Contains the SQLERRM from the failed DDL execution.',
	CA_YAML_MODEL VARCHAR(16777216) COMMENT 'The Cortex Analyst YAML semantic model definition natively generated by Snowflake from the semantic view.',
	constraint PK_SEM_NATIVE_VIEWS primary key (NATIVE_VIEW_ID)
)COMMENT='Stores every generated native Snowflake CREATE SEMANTIC VIEW DDL for each source table. Each row represents one generation attempt. STATUS tracks lifecycle: ACTIVE = current live view, SUPERSEDED = replaced by newer run, FAILED = DDL error. Populated by __STTM_METADATA_NAMESPACE__.CREATE_TABLE_SEMANTIC_VIEW procedure.'
;

-- COLUMN_SEMANTIC_INDEX
CREATE TABLE IF NOT EXISTS __STTM_METADATA_NAMESPACE__.COLUMN_SEMANTIC_INDEX (
	DB_NAME VARCHAR(16777216) NOT NULL COMMENT 'Source database name',
	SCHEMA_NAME VARCHAR(16777216) NOT NULL COMMENT 'Source schema name',
	TABLE_NAME VARCHAR(16777216) NOT NULL COMMENT 'Source table name',
	COLUMN_NAME VARCHAR(16777216) NOT NULL COMMENT 'Source column name',
	DATA_TYPE VARCHAR(16777216) COMMENT 'Snowflake data type (VARCHAR, NUMBER, etc.)',
	SEARCH_TEXT VARCHAR(16777216) NOT NULL COMMENT 'Indexed text for Cortex Search semantic matching',
	DESCRIPTION_SOURCE VARCHAR(16777216) COMMENT 'Source of description in SEARCH_TEXT: SEM_COLUMN_VIEWS | LLM_GENERATED | COLUMN_NAME_FALLBACK',
	LAST_UPDATED TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP() COMMENT 'Timestamp of last refresh by REFRESH_COLUMN_SEARCH_INDEX',
	primary key (DB_NAME, SCHEMA_NAME, TABLE_NAME, COLUMN_NAME)
)COMMENT='Backing table for COLUMN_SEARCH_SVC Cortex Search Service - populated by REFRESH_COLUMN_SEARCH_INDEX - do not modify manually'
;

ALTER TABLE __STTM_METADATA_NAMESPACE__.COLUMN_SEMANTIC_INDEX SET CHANGE_TRACKING = TRUE;

-- COLUMN_PROFILE_CACHE
CREATE TABLE IF NOT EXISTS __STTM_METADATA_NAMESPACE__.COLUMN_PROFILE_CACHE (
	DB_NAME VARCHAR(16777216) NOT NULL COMMENT 'Source database name',
	SCHEMA_NAME VARCHAR(16777216) NOT NULL COMMENT 'Source schema name',
	TABLE_NAME VARCHAR(16777216) NOT NULL COMMENT 'Source table name',
	COLUMN_NAME VARCHAR(16777216) NOT NULL COMMENT 'Source column name',
	DATA_TYPE VARCHAR(16777216) COMMENT 'Snowflake data type',
	DISTINCT_COUNT NUMBER(38,0) COMMENT 'COUNT(DISTINCT col) from GET_TABLE_STATS',
	NULL_PCT NUMBER(5,2) COMMENT '% of rows where col IS NULL (0-100)',
	MIN_LENGTH NUMBER(38,0) COMMENT 'LENGTH(min_val::VARCHAR) — precise for numeric, approx for text',
	MAX_LENGTH NUMBER(38,0) COMMENT 'LENGTH(max_val::VARCHAR) — precise for numeric, approx for text',
	PATTERN_CLASS VARCHAR(16777216) COMMENT 'Character class of column values: NUMERIC|ALPHA|ALPHANUMERIC|FORMATTED|EMPTY (V9)',
	SAMPLE_VALUES VARIANT COMMENT 'JSON array of up to 10 distinct non-null sample values. NOT sent to LLM.',
	ROW_COUNT NUMBER(38,0) COMMENT 'Total row count at time of refresh (from GET_TABLE_STATS)',
	NULL_COUNT NUMBER(38,0) COMMENT 'Absolute null count (null_count from GET_TABLE_STATS)',
	DISTINCT_RATIO NUMBER(7,6) COMMENT 'distinct_count / row_count (0.0–1.0); used in Gate 2.1',
	NULL_RATIO NUMBER(7,6) COMMENT 'null_count / row_count (0.0–1.0); finer signal than NULL_PCT',
	IS_LIKELY_KEY BOOLEAN COMMENT 'TRUE if distinct_count = row_count AND null_count = 0; pre-flags PK candidates for Phase 2A',
	LAST_REFRESHED TIMESTAMP_NTZ(9) DEFAULT CURRENT_TIMESTAMP() COMMENT 'Timestamp of last refresh. Procedure checks if > 7 days old (D3 staleness rule).',
	primary key (DB_NAME, SCHEMA_NAME, TABLE_NAME, COLUMN_NAME)
)COMMENT='Pre-computed column profiling cache for Phase 2 Gate 2 compatibility checks. Populated by REFRESH_COLUMN_SEARCH_INDEX using GET_TABLE_STATS (V9). PATTERN_CLASS activated in V9 via SQL regex on SAMPLE_VALUES. SAMPLE_VALUES stored here but never forwarded to Cortex Complete (D5). IS_LIKELY_KEY used by Phase 2A PK fuzzy identification.'
;

-- COLUMN_SEARCH_SVC
create or replace cortex search service __STTM_METADATA_NAMESPACE__.COLUMN_SEARCH_SVC
	ON SEARCH_TEXT
	attributes DB_NAME,SCHEMA_NAME,TABLE_NAME,COLUMN_NAME,DATA_TYPE
	warehouse='__WAREHOUSE_NAME__'
	target_lag='1 day'
	refresh_mode=INCREMENTAL
	as (
    SELECT
        DB_NAME,
        SCHEMA_NAME,
        TABLE_NAME,
        COLUMN_NAME,
        DATA_TYPE,
        SEARCH_TEXT
    FROM __STTM_METADATA_NAMESPACE__.COLUMN_SEMANTIC_INDEX
);
