"use client";

import { useEffect, useState, type ReactNode } from "react";
import { AiaBox } from "@/components/ui";
import { AiaText } from "@/components/ui/aia-text";
import { textStyleCssVars } from "@/config/typography-tokens";
import { AppError } from "@/api/errors/app-error";
import { authService, clearBrowserWorkbenchSession } from "@/services/authService";
import { onSessionFailure } from "@/services/session-cache-scope";

type SessionStatus = "checking" | "ready" | "signed-out" | "denied" | "unavailable";

// Session answers that mean "not signed in to the workbench yet".
const NOT_SIGNED_IN_STATUSES = new Set([401]);

function isNotSignedIn(error: unknown) {
  return error instanceof AppError && NOT_SIGNED_IN_STATUSES.has(error.payload.statusCode ?? 0);
}

/**
 * Coordinates identity-scoped page reads without blocking the app shell.
 * - Bootstrap has no separate loading screen; header/navigation render immediately.
 * - 401 clears the rejected cookie before returning to the public sign-in page.
 * - Permission denial and temporary failures remain distinct, without redirecting.
 */
export default function SessionGate({ children }: { children: ReactNode }) {
  const [status, setStatus] = useState<SessionStatus>("checking");

  useEffect(() => {
    let cancelled = false;
    let signingOut = false;
    const handleFailure = async (error: unknown) => {
      if (cancelled || signingOut) return;
      if (isNotSignedIn(error)) {
        signingOut = true;
        setStatus("signed-out");
        clearBrowserWorkbenchSession();
        try {
          await fetch(`/api/v1/auth/clear-session`, {method: "POST", signal: AbortSignal.timeout(8000)});
        } catch {
          // Sign in remains reachable even if cookie clearing is unavailable.
        }
        if (!cancelled) window.location.replace("/home");
        return;
      }
      setStatus(error instanceof AppError && error.payload.statusCode === 403 ? "denied" : "unavailable");
    };
    const unsubscribe = onSessionFailure(handleFailure);
    authService
      .getSession()
      .then(() => {
        if (!cancelled && !signingOut) setStatus("ready");
      })
      .catch(handleFailure);
    return () => {
      cancelled = true;
      unsubscribe();
    };
  }, []);

  if (status === "ready") {
    return <>{children}</>;
  }
  if (status === "checking" || status === "signed-out") return null;

  // Only genuine permission/service failures need a page-level explanation.
  return (
    <AiaBox
      role="status"
      aria-live="polite"
      sx={{
        flex: 1,
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: 1.5,
        backgroundColor: "var(--color-app-bg)",
      }}
    >
      <AiaText sx={{ ...textStyleCssVars("secondaryText") }}>
        {status === "denied" ? "Your account does not have permission to access this workspace. Contact your administrator."
          : "Session verification is unavailable. Please reload to retry."}
      </AiaText>
    </AiaBox>
  );
}
