-- ============================================================
-- SP_FIR_STORE_QA_PAIR
-- Stores a Q&A pair from user notification responses into
-- the semantic view's QA_HISTORY and the active curated version.
-- ============================================================

CREATE OR REPLACE PROCEDURE __STTM_METADATA_NAMESPACE__.SP_FIR_STORE_QA_PAIR(
    "SEMANTIC_VIEW_FQN" VARCHAR,
    "QUESTION" VARCHAR,
    "ANSWER" VARCHAR,
    "CONFIDENCE" FLOAT,
    "SOURCE_FIR_RECORD_ID" VARCHAR DEFAULT NULL,
    "AGENT_NOTES" VARCHAR DEFAULT NULL
)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.12'
PACKAGES = ('snowflake-snowpark-python')
HANDLER = 'store_qa_pair'
EXECUTE AS OWNER
AS
$$
import json
import uuid
from datetime import datetime


def store_qa_pair(
    session,
    semantic_view_fqn: str,
    question: str,
    answer: str,
    confidence: float,
    source_fir_record_id: str = None,
    agent_notes: str = None
) -> dict:
    """Store a Q&A pair into semantic view QA_HISTORY and active curated version."""

    qa_id = str(uuid.uuid4())
    qa_pair = {
        'qa_id': qa_id,
        'question': question,
        'answer': answer,
        'confidence': confidence,
        'source_fir_record_id': source_fir_record_id,
        'agent_notes': agent_notes,
        'created_at': datetime.utcnow().isoformat()
    }

    # Update SEM_TABLE_VIEWS.QA_HISTORY (append to array)
    session.sql("""
        UPDATE __STTM_METADATA_NAMESPACE__.SEM_TABLE_VIEWS
        SET QA_HISTORY = ARRAY_APPEND(COALESCE(QA_HISTORY, ARRAY_CONSTRUCT()), PARSE_JSON(?)),
            UPDATED_AT = CURRENT_TIMESTAMP()
        WHERE TABLE_FQN = ?
    """, [json.dumps(qa_pair), semantic_view_fqn]).collect()

    # Update active curated version's QA_PAIRS
    session.sql("""
        UPDATE __STTM_METADATA_NAMESPACE__.TBL_SEMANTIC_VIEW_VERSIONS
        SET QA_PAIRS = ARRAY_APPEND(COALESCE(QA_PAIRS, ARRAY_CONSTRUCT()), PARSE_JSON(?)),
            AGENT_NOTES = COALESCE(AGENT_NOTES, '') || '\n[QA] ' || ?,
            UPDATED_AT = CURRENT_TIMESTAMP()
        WHERE SEMANTIC_VIEW_FQN = ?
          AND STATUS = 'active'
          AND VERSION_LABEL LIKE 'CURATED_%'
    """, [json.dumps(qa_pair), question[:100], semantic_view_fqn]).collect()

    return {
        'status': 'success',
        'qa_id': qa_id,
        'semantic_view_fqn': semantic_view_fqn,
        'question': question[:100],
        'answer': answer[:100]
    }
$$;
