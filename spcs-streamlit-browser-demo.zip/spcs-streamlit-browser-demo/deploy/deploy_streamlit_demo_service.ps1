param(
    [string]$EnvFile = "",
    [string]$ImageTag = ""
)

$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "common.ps1")

if (-not $EnvFile) {
    $EnvFile = Get-DefaultEnvFile
}

$snowExe = Ensure-SnowInstalled
$cfg = Import-DemoEnv -Path $EnvFile

Require-ConfigValues -Config $cfg -RequiredKeys @(
    "SNOWFLAKE_CONNECTION",
    "SNOWFLAKE_ACCOUNT",
    "SNOWFLAKE_HOST",
    "SNOWFLAKE_WAREHOUSE",
    "SNOWFLAKE_DATABASE",
    "SNOWFLAKE_SCHEMA",
    "SNOWFLAKE_IMAGE_REPOSITORY",
    "SNOWFLAKE_DEPLOY_STAGE",
    "SNOWFLAKE_COMPUTE_POOL",
    "STREAMLIT_DEMO_SERVICE_NAME",
    "SNOWFLAKE_EGRESS_INTEGRATION"
) -EnvFile $EnvFile

$bundleRoot = Get-BundleRoot
$resolvedImageTag = Get-ImageTag -Config $cfg -Preferred $ImageTag
$renderedSpec = Get-RenderedSpecPath -ImageTag $resolvedImageTag
$templatePath = Join-Path $PSScriptRoot "service-specs\spcs-streamlit-browser.yaml.tmpl"
$pythonCmd = Resolve-Python

$dbLower = Get-LowerValue -Value $cfg["SNOWFLAKE_DATABASE"]
$schemaLower = Get-LowerValue -Value $cfg["SNOWFLAKE_SCHEMA"]
$repoLower = Get-LowerValue -Value $cfg["SNOWFLAKE_IMAGE_REPOSITORY"]
$demoTitle = if ($cfg.ContainsKey("DEMO_TITLE") -and $cfg["DEMO_TITLE"]) {
    [string]$cfg["DEMO_TITLE"]
} else {
    "Snowflake Access Browser Demo"
}

[System.Environment]::SetEnvironmentVariable("SNOWFLAKE_DATABASE_LOWER", $dbLower, "Process")
[System.Environment]::SetEnvironmentVariable("SNOWFLAKE_SCHEMA_LOWER", $schemaLower, "Process")
[System.Environment]::SetEnvironmentVariable("SNOWFLAKE_IMAGE_REPOSITORY_LOWER", $repoLower, "Process")
[System.Environment]::SetEnvironmentVariable("IMAGE_TAG", $resolvedImageTag, "Process")
[System.Environment]::SetEnvironmentVariable("DEMO_TITLE", $demoTitle, "Process")
[System.Environment]::SetEnvironmentVariable("SNOWFLAKE_ACCOUNT", [string]$cfg["SNOWFLAKE_ACCOUNT"], "Process")
[System.Environment]::SetEnvironmentVariable("SNOWFLAKE_HOST", [string]$cfg["SNOWFLAKE_HOST"], "Process")
[System.Environment]::SetEnvironmentVariable("SNOWFLAKE_WAREHOUSE", [string]$cfg["SNOWFLAKE_WAREHOUSE"], "Process")
[System.Environment]::SetEnvironmentVariable("SNOWFLAKE_DATABASE", [string]$cfg["SNOWFLAKE_DATABASE"], "Process")
[System.Environment]::SetEnvironmentVariable("SNOWFLAKE_SCHEMA", [string]$cfg["SNOWFLAKE_SCHEMA"], "Process")

Write-Host "Rendering service spec to $renderedSpec"
& $pythonCmd (Join-Path $PSScriptRoot "render_spcs_spec.py") --template $templatePath --output $renderedSpec

$specLeafName = Split-Path -Leaf $renderedSpec
$specNativePath = [System.IO.Path]::GetFullPath($renderedSpec)
$specUrl = "file:///{0}" -f ($specNativePath -replace "\\", "/")

Write-Host ""
Write-Host "Uploading spec to stage $($cfg["SNOWFLAKE_DEPLOY_STAGE"])"
Invoke-SnowSql -SnowExe $snowExe -ConnectionName $cfg["SNOWFLAKE_CONNECTION"] -Sql @"
PUT '$specUrl'
  @$($cfg["SNOWFLAKE_DEPLOY_STAGE"])
  AUTO_COMPRESS=FALSE
  OVERWRITE=TRUE;
"@

Write-Host ""
Write-Host "Creating service $($cfg["STREAMLIT_DEMO_SERVICE_NAME"]) from staged spec"
Invoke-SnowSql -SnowExe $snowExe -ConnectionName $cfg["SNOWFLAKE_CONNECTION"] -Sql @"
CREATE SERVICE IF NOT EXISTS $($cfg["STREAMLIT_DEMO_SERVICE_NAME"])
  IN COMPUTE POOL $($cfg["SNOWFLAKE_COMPUTE_POOL"])
  FROM @$($cfg["SNOWFLAKE_DEPLOY_STAGE"])
  SPECIFICATION_FILE='$specLeafName'
  EXTERNAL_ACCESS_INTEGRATIONS = ($($cfg["SNOWFLAKE_EGRESS_INTEGRATION"]))
  MIN_INSTANCES = 1
  MAX_INSTANCES = 1;
"@

Write-Host ""
Write-Host "Refreshing service to latest spec"
Invoke-SnowSql -SnowExe $snowExe -ConnectionName $cfg["SNOWFLAKE_CONNECTION"] -Sql @"
ALTER SERVICE $($cfg["STREAMLIT_DEMO_SERVICE_NAME"])
  FROM @$($cfg["SNOWFLAKE_DEPLOY_STAGE"])
  SPECIFICATION_FILE='$specLeafName';
"@

Write-Host ""
Write-Host "Current endpoints"
Invoke-SnowSql -SnowExe $snowExe -ConnectionName $cfg["SNOWFLAKE_CONNECTION"] -Sql @"
SHOW ENDPOINTS IN SERVICE $($cfg["STREAMLIT_DEMO_SERVICE_NAME"]);
"@

Write-Host ""
Write-Host "Service deployment complete."
Write-Host "Rendered spec: $renderedSpec"
