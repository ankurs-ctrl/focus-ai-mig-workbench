"""Exact, request-local Auto-map evidence with identity-based, bounded reads.

Search is a discovery callback, never an authority or an authorization boundary.
The store is rebuilt from the governed worker request; no shared artifact handle
or model-supplied project/filter can expand its scope.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
import re
from typing import Any, Callable

import yaml
from sqlglot import exp, parse_one
from sqlglot.errors import ParseError, TokenError

from app.core.agent_payload_budget import AgentPayloadBudgetError
from app.core.mapping_context import _targets


def encoded(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def digest(value: Any) -> str:
    return hashlib.sha256(encoded(value).encode("utf-8")).hexdigest()


def factor_exact_records(payload: dict[str, Any]) -> dict[str, Any]:
    """Intern repeated complete records without dropping any field or rule."""
    counts: dict[str, int] = {}
    values: dict[str, Any] = {}
    reserved = False

    def count(value):
        nonlocal reserved
        if isinstance(value, (dict, list)):
            if isinstance(value, dict) and any(key in value for key in (
                "$exact_record", "exact_record_dictionary", "exact_record_encoding"
            )):
                reserved = True
            text = encoded(value)
            if len(text) >= 256:
                counts[text] = counts.get(text, 0) + 1
                values[text] = value
            children = value.values() if isinstance(value, dict) else value
            for child in children:
                count(child)

    count(payload)
    if reserved:
        return payload
    repeated = {text for text, count in counts.items() if count > 1}
    dictionary = []
    indices = {}

    def replace(value):
        if isinstance(value, (dict, list)):
            text = encoded(value)
            if text in repeated:
                if text not in indices:
                    indices[text] = len(dictionary)
                    index = indices[text]
                    dictionary.append(None)
                    # Intern nested repeated records too. Otherwise a repeated
                    # recipe array hides its large shared CTE bodies in the dictionary.
                    dictionary[index] = ({key: replace(child) for key, child in value.items()}
                                         if isinstance(value, dict) else [replace(child) for child in value])
                return {"$exact_record": indices[text]}
            if isinstance(value, dict):
                return {key: replace(child) for key, child in value.items()}
            return [replace(child) for child in value]
        return value

    result = replace(payload)
    if dictionary:
        result["exact_record_dictionary"] = dictionary
        result["exact_record_encoding"] = (
            "A {$exact_record:N} object means the complete EXACT object/array at "
            "exact_record_dictionary[N]. Resolve references before reasoning. "
            "Return ordinary values, not references. No content was summarized."
        )
    return result if len(encoded(result)) < len(encoded(payload)) else payload


def table_name(value: Any) -> str:
    if isinstance(value, dict):
        return ".".join(str(value.get(key) or "") for key in ("database", "schema", "table"))
    return str(value or "")


def reference_parts(value: str) -> tuple[str, str]:
    try:
        tree = parse_one(value, read="snowflake")
    except (ParseError, TokenError) as exc:
        # Callers handle ValueError; a raw sqlglot error used to fail whole batches.
        raise ValueError("Expected one exact column reference") from exc
    if not isinstance(tree, exp.Column):
        raise ValueError("Expected one exact column reference")
    return ".".join(part.sql(dialect="snowflake") for part in tree.parts[:-1]), tree.parts[-1].sql(dialect="snowflake")


def target_name(value: str) -> str:
    return reference_parts(value)[1]


def batch_messages(packet: dict[str, Any]) -> list[dict[str, Any]]:
    return [{"role": "user", "content": [
        {"type": "text", "text": encoded(packet)},
        {"type": "text", "text": (
            "Perform sttm.auto_map now for every data.attributes target in the preceding JSON. "
            "Return the mapping JSON envelope or a typed retrieval delegation, not a question or prose. "
            "Use each relation's sql_qualifier plus its exact column for source_attributes and "
            "source_dependencies; internal relation IDs are retrieval handles, not SQL. "
            "source_dependencies contains columns, never relation-only handles. "
            "confidence_score must be a number from 0.0 to 1.0, never a percentage. "
            "Choose only exact registry column names; SQL body names are not necessarily output columns. "
            "Follow batch_evidence_deficits on retries; schema failures must be corrected. "
            "Use exact supplied Value placeholders and include constant_value for VALUE mappings. "
            "PROJECT_VALUE requires allow_project_specific_value=true and a $placeholder; an uploaded "
            "SQL literal or expression is not a project attribute. "
            "Read missing semantics before deciding. Do not invent a source column or cite rejected history. "
            "Preserve the target's exact business meaning, not just its topic or datatype: past/completed "
            "and future/scheduled events, original and current values, and other contrasting concepts "
            "are not interchangeable. A source for a neighboring target is not evidence for this target; "
            "abstain when the exact concept is absent. Compare current_mapping_rows for this exact target "
            "and retain supported existing expression semantics rather than simplifying them to a direct pick. "
            "Lineage origins inside column metadata explain provenance; they are NOT executable qualifiers. "
            "If an origin is exposed through a selected derived output, bind the selected sql_qualifier.output "
            "and keep its complete dependency evidence; never emit the origin as an unselected SQL binding."
        )},
    ]}]


def scoped_record(value: Any, target: str) -> Any:
    """Preserve shared precedent authority while excluding foreign mapping rows."""
    if isinstance(value, list):
        return [scoped_record(child, target) for child in value
                if not isinstance(child, dict) or not (_targets(child) - {""}) or target.upper() in _targets(child)]
    if isinstance(value, dict):
        return {key: scoped_record(child, target) for key, child in value.items()}
    return deepcopy(value)


def focused_population(workspace: dict[str, Any]) -> dict[str, Any]:
    """Current query-shaping clauses, not unrelated target SELECT expressions."""
    result = {key: deepcopy(value) for key, value in workspace.items() if key not in {
        "relation_graph", "selected_columns_by_table", "source_tables", "variable_bindings",
    }}
    for key, value in list(result.items()):
        if isinstance(value, dict):
            result[key] = focused_population(value)
            continue
        if key not in {"raw_mapping_sql", "mapping_sql", "mapping_preview_sql", "source_query_sql", "base_query_sql"} or not value:
            continue
        try:
            tree = parse_one(value, read="snowflake")
            if not isinstance(tree, exp.Select):
                continue  # Unknown shape is not proof that a clause is disposable.
            result[key] = {"population_clauses": {
                clause: child.sql(dialect="snowflake")
                for clause, child in tree.args.items()
                if clause not in {"expressions", "with", "with_"} and isinstance(child, exp.Expression)
            }, "joins": [join.sql(dialect="snowflake") for join in tree.args.get("joins") or []]}
        except Exception:
            continue
    return result


STRATEGY_VERSION = "bounded_learning_batch_v4"

PROTOCOL = """AUTO_MAP_CONTEXT is an application-handled response delegation, not a registered native tool.
Reason over ALL requested targets together. Return only JSON with top-level
meta.delegation={tool:"AUTO_MAP_CONTEXT",snapshot_hash:<exact hash>,operation:"multi_read",
reads:[{operation:<operation>,...},...]}. At most 64 exact reads per delegation.
The backend validates every operation and invokes you again on a fresh thread.
Operations: discover(target); evidence(target,category[,cursor]); columns(relation[,cursor]); column(relation,column[,cursor]); profile(relation,column[,cursor]);
table(relation[,cursor]); contract(relation[,cursor]); dependency(relation_id[,cursor]). Use exact listed identities, not offsets,
SQL, project IDs, Search filters, or arbitrary artifact IDs. Continue a paged read using next_cursor
verbatim and the same operation/arguments. Pages contain exact path/value fragments; combine them,
never treat a partial fragment as a complete rule. All omitted content remains available.
For each target first discover historical candidates and read all mandatory evidence categories,
target-column semantics, chosen source-column semantics, and any selected derived dependency SQL.
Search failure is not no evidence. Search hits require canonical hydration and applicability checks.
Do not select by names alone: inspect semantic meanings for plausible alternatives, including obscure
columns. Current graph bindings, joins, filters, grain and Value bindings govern every decision.
Do not invent unseen evidence or columns. Cite only supplied evidence IDs. If needed evidence cannot
be read within the budget, return that target unresolved with a concrete reason, never guess.
CORTEX_ANALYST is a separate optional backend delegation for an actual data question; use only the
prepared semantic bundle and report SQL generation separately from successful execution.
Return the normal source-mapping envelope after required evidence is read; never return a retrieval
request as a completed mapping. Return all requested targets in one mapping envelope. Shared source,
contract and population reads may be reused across this batch; historical citations are target-specific."""


class AutoMapContext:
    def __init__(self, payload: dict[str, Any]):
        self.original = deepcopy(payload)
        self.snapshot_hash = digest(payload)
        context = self.original.get("context") or {}
        from app.core.automap_policy import POLICY_VERSION
        self.focused = (context.get("learning_context") or {}).get("automap_policy_version") == POLICY_VERSION
        self.targets = {
            target_name(str(item["target_attribute"])): item
            for item in (self.original.get("data") or {}).get("attributes") or []
        }
        if len(self.targets) != len((self.original.get("data") or {}).get("attributes") or []):
            raise ValueError("Duplicate prepared target identity")
        self.target_table = table_name(context.get("target_table"))
        self.tables: dict[str, list[Any]] = {}
        self.columns: dict[str, dict[str, list[Any]]] = {}
        self.aliases: dict[str, set[str]] = {}
        self.node_owners: dict[str, str] = {}
        self.dependencies: dict[str, Any] = {}
        self.evidence: dict[str, dict[str, list[Any]]] = {}
        self.reads: set[tuple[str, ...]] = set()
        self.discovered: dict[str, Any] = {}
        self.available_evidence: dict[str, dict[str, list[Any]]] = {}
        self.search_cache: dict[str, Any] = {}
        self.search_rounds = 0
        self.primary_evidence_ids: set[str] = set()
        self.rejected_evidence_ids: set[str] = set()
        self.evidence_versions: dict[str, str] = {}
        self.search_work = {"query_count": 0, "returned_hit_count": 0, "returned_id_count": 0, "canonical_read_count": 0}
        self.cursors: dict[str, tuple[str, int, int]] = {}
        self.pages_read: dict[str, set[int]] = {}
        self.inventory: dict[str, dict[str, Any]] = {}
        self.contracts: dict[str, list[Any]] = {}
        self.deferred_contracts: set[str] = set()
        self.historical_dependencies: dict[str, Any] = {}
        self.historical_dependency_owners: dict[str, tuple[str, str, set[str]]] = {}
        for target, attribute in self.targets.items():
            requirements = {key: deepcopy(attribute[key]) for key in ("target_data_type", "target_description")
                            if attribute.get(key) is not None}
            if requirements and self.target_table:
                self.columns.setdefault(self.target_table, {}).setdefault(target, []).append({"name": target, **requirements})
                self.inventory.setdefault(self.target_table, {})[target] = requirements.get("target_data_type")
        for item in context.get("semantic_context") or []:
            relation = table_name(item.get("table"))
            model = item.get("semantic_model")
            self._index_model(relation, model)
        graph = context.get("relation_graph") or {}
        for node in graph.get("nodes") or []:
            relation = table_name(node.get("table")) or str(node.get("relation_id"))
            for alias in (relation, node.get("relation_id"), node.get("alias")):
                if alias:
                    self.aliases.setdefault(str(alias), set()).add(relation)
            derived_id = node.get("derived_source_id")
            if derived_id:
                for item in context.get("semantic_context") or []:
                    model = item.get("semantic_model")
                    if isinstance(model, dict) and model.get("derived_source_id") == derived_id:
                        self.aliases.setdefault(str(node["relation_id"]), set()).add(table_name(item.get("table")))
            # Every handle of one node (relation, relation_id, SQL alias) names the
            # same relation, so exact reads through any handle satisfy citations
            # through any other (e.g. CTE alias vs derived relation id).
            names = {str(name) for name in (relation, node.get("relation_id"), node.get("alias")) if name}
            owners = set().union(*(self.aliases.get(name, set()) for name in names))
            for name in names:
                self.aliases[name] = set(owners)
                self.node_owners.setdefault(name, relation)
            for column in node.get("output_columns") or []:
                if isinstance(column, dict) and column.get("name"):
                    name = str(column["name"])
                    self.inventory.setdefault(relation, {}).setdefault(name, column.get("data_type"))
                    if self.focused and self.inventory[relation][name] is None and column.get("data_type") is not None:
                        self.inventory[relation][name] = column["data_type"]
                    self.columns.setdefault(relation, {}).setdefault(name, []).append(deepcopy(column))
            for column in node.get("column_semantics") or []:
                name = column.get("name") or column.get("column_name") if isinstance(column, dict) else None
                if name:
                    self.columns.setdefault(relation, {}).setdefault(str(name), []).append(deepcopy(column))
            if node.get("sql_text"):
                self.dependencies[str(node["relation_id"])] = deepcopy(node)
        self.nodes = {str(node["relation_id"]): deepcopy(node) for node in graph.get("nodes") or []}
        # Saved uploaded SQL can wrap private CTE parents inside a selected
        # derived node. They are dependency evidence, not additional legal
        # mapping sources. Recover only exact AST bodies already in that SQL.
        for node in list(self.nodes.values()):
            missing_parents = [str(parent) for parent in node.get("parent_relation_ids") or []
                               if str(parent) not in self.nodes]
            if not missing_parents or not node.get("sql_text"):
                continue
            try:
                tree = parse_one(node["sql_text"], read="snowflake")
                with_clause = tree.args.get("with") or tree.args.get("with_")
                embedded = {cte.alias: cte for cte in (with_clause.expressions if with_clause else [])}
                for parent in missing_parents:
                    name = parent.rsplit(":", 1)[-1]
                    cte = embedded.get(name)
                    if cte is not None:
                        self.nodes[parent] = {"relation_id": parent, "kind": "CTE",
                            "alias": name, "sql_text": cte.this.sql(dialect="snowflake"),
                            "embedded_in_relation_id": node["relation_id"], "parent_relation_ids": []}
            except Exception:
                pass  # Unparseable or genuinely missing parents remain unresolved.
        for relation in self.tables.keys() | self.inventory.keys():
            self.aliases.setdefault(relation, set()).add(relation)
        learning = context.get("learning_context") or {}
        execution = context.get("execution_context") or {}
        if self.focused:
            from app.core.automap_policy import focused_learning
            learning = focused_learning(learning)
            self.original["context"]["learning_context"] = learning
            execution = {}
        for target in self.targets:
            self.evidence[target] = {}
            for category, value in learning.items():
                if isinstance(value, list) and value:
                    relevant = [scoped_record(item, target) for item in value
                                if not (_targets(item) - {""}) or target.upper() in _targets(item)]
                    if relevant:
                        self.evidence[target][category] = relevant
            for category in ("curated_inferences", "exact_fir_recommendations", "target_mapping_patterns",
                             "linked_mapping_precedents", "linked_project_patterns"):
                relevant = [scoped_record(item, target) for item in execution.get(category) or []
                            if not (_targets(item) - {""}) or target.upper() in _targets(item)]
                if relevant and relevant != self.evidence[target].get(category):
                    self.evidence[target][f"execution:{category}"] = relevant
            for key in (() if self.focused else ("datahub_context", "derived_source_lineage")):
                if context.get(key):
                    self.evidence[target][f"workspace:{key}"] = [deepcopy(context[key])]
            if execution:
                self.evidence[target]["workspace:execution_context"] = [deepcopy(execution)]

    def _evidence_projection(self, target: str, category: str):
        """Defer historical CTE bodies, never corrections or linked precedent rules."""
        if "target_mapping_patterns" not in category:
            return self.evidence[target][category]
        records = deepcopy(self.evidence[target][category])
        for index, candidate in enumerate(records):
            pattern = candidate.get("pattern", candidate) if isinstance(candidate, dict) else {}
            identifiers = {str(pattern[key]) for key in ("pattern_id", "learning_id") if pattern.get(key)}
            if self.focused:
                essential = {"pattern_id", "learning_id", "target_contract", "mapping_recipe", "exclusions",
                             "provenance", "validation_status", "support_count", "contradiction_count",
                             "confidence", "scope", "project_id", "sttm_id", "superseded_by",
                             "query_shaping_dependencies", "relationship_dependencies", "derived_dependencies", "source_system_profile"}
                for field in list(pattern):
                    if field in essential or not pattern[field] or len(encoded(pattern[field])) <= 256:
                        continue
                    body = pattern[field]
                    identity = f"historical:{digest([target, category, index, field, body])[:24]}"
                    self.historical_dependencies[identity] = deepcopy(body)
                    self.historical_dependency_owners[identity] = (target, category, identifiers)
                    pattern[field] = {"exact_dependency_id": identity, "content_hash": digest(body),
                                      "read_required_if_recipe_used": field not in {"generation_history", "audit_history", "support_keys", "evidence_ids"}}
                    if field in {"generation_history", "audit_history", "support_keys", "evidence_ids"}:
                        self.historical_dependency_owners.pop(identity, None)
            action = candidate.get("prepare_source_action")
            if isinstance(action, dict) and len(encoded(action)) > 512:
                identity = f"historical:{digest([target, category, index, 'prepare_source_action', action])[:24]}"
                self.historical_dependencies[identity] = deepcopy(action)
                self.historical_dependency_owners[identity] = (target, category, identifiers)
                candidate["prepare_source_action"] = {"action_kind": action.get("action_kind"),
                    "exact_dependency_id": identity, "content_hash": digest(action),
                    "read_required_before_proposing_action": True}
            for field in ("query_shaping_dependencies", "relationship_dependencies", "derived_dependencies", "source_system_profile"):
                body = pattern.get(field)
                if self.focused and field == "derived_dependencies":
                    from app.core.automap_dependencies import dependency_projection, recipe_output_names
                    original_body = deepcopy(body)
                    body = dependency_projection(body, required_outputs=recipe_output_names(pattern.get("mapping_recipe") or {}))
                    if body != original_body:
                        original_id = f"historical-original:{digest([target, category, sorted(identifiers), original_body])[:24]}"
                        self.historical_dependencies[original_id] = original_body
                        pattern["original_dependency_snapshot"] = {"exact_dependency_id": original_id,
                            "content_hash": digest(original_body), "read_required_if_recipe_used": False}
                    pattern[field] = body
                if body and len(encoded(body)) > 512:
                    identity = f"historical:{digest([target, category, index, field, body])[:24]}"
                    self.historical_dependencies[identity] = deepcopy(body)
                    self.historical_dependency_owners[identity] = (target, category, identifiers)
                    pattern[field] = {"exact_dependency_id": identity, "content_hash": digest(body),
                                      "read_required_if_recipe_used": True, "record_count": len(body)}
            dependencies = pattern.get("derived_dependencies") or []
            if not isinstance(dependencies, list):
                continue
            for position, dependency in enumerate(dependencies):
                if not isinstance(dependency, dict) or len(encoded(dependency)) < 512:
                    continue
                body = deepcopy(dependency)
                identity = f"historical:{digest([target, category, index, position, body])[:24]}"
                self.historical_dependencies[identity] = body
                self.historical_dependency_owners[identity] = (target, category, identifiers)
                dependencies[position] = {**{key: dependency[key] for key in ("name", "alias", "relation_id") if key in dependency},
                    "exact_dependency_id": identity, "content_hash": digest(body), "read_required_if_recipe_used": True}
        return records

    def mandatory_results(self, *, max_bytes: int, max_operations: int) -> list[dict[str, Any]]:
        operations = []
        for target in self.targets:
            operations.extend(operation for operation in self.required_operations(target, {"source_attributes": []})
                              if operation["operation"] != "discover")
        pending = list({encoded(operation): operation for operation in operations}.values())
        results, count = [], 0
        while pending:
            if count >= max_operations:
                raise AgentPayloadBudgetError("Mandatory exact-read operation budget exceeded")
            operation = pending.pop(0)
            result = self.read({"tool": "AUTO_MAP_CONTEXT", "snapshot_hash": self.snapshot_hash, **operation}, max_bytes=max_bytes)
            count += 1
            if result.get("next_cursor"):
                pending.append({**operation, "cursor": result["next_cursor"]})
            else:
                exact_operation = {key: value for key, value in operation.items() if key != "cursor"}
                results.append({"read_key": encoded(exact_operation), "request": exact_operation,
                                "result": self.exact_completed_result(exact_operation)})
        return results

    def _index_model(self, relation: str, value: Any) -> None:
        """Index known column containers recursively; leave every other field exact."""
        column_keys = {"attributes", "columns", "column_semantics", "output_columns",
                       "attribute_semantic_model", "dimensions", "time_dimensions", "facts", "metrics"}

        def visit(model):
            if isinstance(model, list):
                return [visit(item) for item in model]
            if not isinstance(model, dict):
                return deepcopy(model)
            result = {}
            for key, child in model.items():
                if key == "historical_semantics":
                    # Preserve old/similar knowledge verbatim, without admitting
                    # its identifiers as selectable current inventory.
                    result[key] = deepcopy(child)
                elif key in column_keys and isinstance(child, list):
                    remainder = []
                    for column in child:
                        name = (column.get("name") or column.get("column_name")) if isinstance(column, dict) else None
                        if name:
                            name = str(name)
                            self.columns.setdefault(relation, {}).setdefault(name, []).append(deepcopy(column))
                            self.inventory.setdefault(relation, {}).setdefault(name, column.get("data_type"))
                        else:
                            remainder.append(deepcopy(column))
                    if remainder:
                        result[key] = remainder
                elif key == "yaml" and isinstance(child, str):
                    # Index native semantics structurally; preserve the original
                    # serialization under the exact table reader as well.
                    try:
                        parsed = yaml.safe_load(child)
                        visit(parsed)
                    except yaml.YAMLError:
                        pass
                    result[key] = child
                else:
                    result[key] = visit(child) if isinstance(child, (dict, list)) else deepcopy(child)
            return result

        self.tables.setdefault(relation, []).append(visit(value))
        contracts = []

        def contract(model):
            if isinstance(model, dict):
                rules = {key: deepcopy(child) for key, child in model.items() if key in {
                    "grain", "description", "business_meaning", "entity_meaning", "null_behavior",
                    "business_rules", "filters", "filter_rules", "relationship_rules", "relationships",
                    "semantic_notes", "domain_summary", "keys", "primary_key",
                }}
                primary_key = model.get("pk_detection")
                if isinstance(primary_key, dict):
                    rules["pk_detection"] = {key: deepcopy(primary_key[key]) for key in (
                        "confirmed_pk", "pk_confirmed", "pk_note", "human_review_required",
                        "alternate_keys_review_required", "additional_unique_columns", "composite_pk_candidates",
                    ) if key in primary_key}
                if rules:
                    contracts.append(rules)
                for child in model.values():
                    if isinstance(child, dict):
                        contract(child)

        contract(value)
        self.contracts.setdefault(relation, []).extend(contracts)

    def manifest(self) -> dict[str, Any]:
        result = deepcopy(self.original)
        context = result.setdefault("context", {})
        # Bodies are accessible by domain identity, not sent speculatively.
        for key in ("semantic_context", "learning_context", "execution_context", "datahub_context", "derived_source_lineage"):
            context.pop(key, None)
        original_context = self.original.get("context") or {}
        learning = original_context.get("learning_context") or {}
        context["learning_context"] = {key: deepcopy(learning[key]) for key in
                                       ("mapping_intent", "project_context", "linked_project_ids", "linked_mapping_ids", "retrieval_diagnostics")
                                       if learning.get(key)}
        workspace = context.get("workspace_context") or {}
        # The exact workspace is available as a dependency, including SQL and filters.
        if workspace:
            # Population dependency does not require unrelated chat history or
            # mappings for other targets. Preserve every exact query-shaping field.
            self.dependencies["workspace"] = {key: deepcopy(workspace[key]) for key in (
                "context_key", "snapshot_id", "driving_relation_id", "relation_graph",
                "filters", "selected_columns_by_table", "source_tables",
                "raw_mapping_sql", "mapping_sql", "mapping_preview_sql",
                "source_query_sql", "source_group_by_sql", "source_order_by_sql",
                "source_query_modifiers", "relationships", "variable_bindings", "variable_approval",
            ) if key in workspace}
            if self.focused:
                self.dependencies["workspace:original"] = deepcopy(self.dependencies["workspace"])
                self.dependencies["workspace"] = focused_population(self.dependencies["workspace"])
            context["workspace_context"] = {key: deepcopy(workspace[key]) for key in
                                            ("context_key", "snapshot_id", "driving_relation_id", "filters", "selected_columns_by_table")
                                            if key in workspace}
        graph = context.get("relation_graph") or {}
        for node in graph.get("nodes") or []:
            node.pop("sql_text", None)
            node.pop("column_semantics", None)
            # Names/types are the complete legal output namespace, not clipped descriptions.
            node["output_columns"] = [{key: column[key] for key in ("name", "data_type") if key in column}
                                      for column in node.get("output_columns") or []]
        # Large multitable contracts duplicate descriptions and relationship
        # bodies. Keep them exact behind table reads, not in every target packet.
        contracts = {}
        for relation, records in self.contracts.items():
            if len(encoded(records).encode("utf-8")) > 256:
                self.deferred_contracts.add(relation)
                contracts[relation] = {"exact_table_read_required": True,
                                       "content_hash": digest(records)}
            else:
                contracts[relation] = deepcopy(records)
        context["auto_map_retrieval"] = {
            "version": STRATEGY_VERSION, "snapshot_hash": self.snapshot_hash,
            "column_catalog": {relation: ({name: value for name, value in columns.items() if name in self.targets}
                                        if relation == self.target_table else columns)
                               for relation, columns in self.inventory.items()},
            "table_contracts": contracts,
            "dependency_ids": sorted(self.dependencies),
            "historical_dependency_protocol": "Historical recipe sql_text handles retain exact bodies. Read their dependency IDs before citing or adapting that recipe; they are not selectable current sources.",
            "relation_aliases": {alias: sorted(owners) for alias, owners in self.aliases.items()},
            "evidence_categories": {target: sorted(categories) for target, categories in self.evidence.items()},
            "mandatory_categories": {target: self.mandatory_categories(target) for target in self.targets},
            "protocol": PROTOCOL,
            "response_template": {"meta": {"delegation": {"tool": "AUTO_MAP_CONTEXT",
                                  "snapshot_hash": self.snapshot_hash, "operation": "multi_read",
                                  "reads": [{"operation": "discover", "target": target} for target in self.targets]}}},
        }
        discovered = all(("discover", target) in self.reads for target in self.targets)
        result["retrieval_instruction"] = (
            "This invocation requires progressive retrieval before any mapping. Semantic bodies are stored "
            "by the application, not missing user input. "
            + ("Discovery is complete. Read mandatory evidence and exact target/source semantics next. " if discovered else
               "Your first response must be the JSON response_template to discover all requested targets. ")
            + "Do not return a mapping while required reads remain incomplete. The backend executes your "
            "meta.delegation and resumes you. This does not call a native tool."
        )
        return self._focused_manifest(result) if self.focused else result

    def _dependency_projection(self, node: dict[str, Any]) -> dict[str, Any]:
        if not self.focused:
            return node
        # Names/types belong to the registry; rich column meanings are exact
        # column/profile reads. Keep full SQL and node execution contracts.
        return {key: deepcopy(value) for key, value in node.items()
                if key not in {"output_columns", "column_semantics", "dependency_hash", "definition_sql", "query_scope"}}

    def _focused_manifest(self, result: dict[str, Any]) -> dict[str, Any]:
        from app.core.automap_policy import TASK, evidence_route

        original = self.original.get("context") or {}
        workspace = original.get("workspace_context") or {}
        selected = original.get("selected_columns_by_table") or workspace.get("selected_columns_by_table") or {}
        registry = {}
        # Keep ambiguous aliases attached to every owner, never choose an owner by
        # display name. The exact reader and compiler still enforce binding scope.
        for relation, columns in self.inventory.items():
            aliases = sorted(alias for alias, owners in self.aliases.items() if relation in owners and alias != relation)
            nodes = [node for node in (original.get("relation_graph") or {}).get("nodes", [])
                     if any(alias in aliases or alias == relation for alias in
                            (node.get("relation_id"), node.get("alias"), table_name(node.get("table"))))]
            selectable = bool(nodes) or relation == self.target_table
            selected_columns = set(selected.get(relation) or [])
            for alias in aliases:
                selected_columns.update(selected.get(alias) or [])
            registry[relation] = {
                "aliases": aliases, "role": "target" if relation == self.target_table else "source",
                "selectable": selectable,
                "sql_qualifier": nodes[0].get("alias") if len(nodes) == 1 else (relation if not nodes else None),
                "contract": deepcopy(self.contracts.get(relation, [])) if relation not in self.deferred_contracts
                            else {"exact_contract_read_required": True},
                "columns": {name: {"data_type": value, "selected": name in selected_columns}
                            for name, value in columns.items()
                            if relation != self.target_table or name in self.targets},
            }
        graph = original.get("relation_graph") or {}
        driver = workspace.get('driving_relation_id')
        connected = {driver} if driver else set()
        for _ in graph.get('nodes') or []:
            for edge in graph.get('edges') or []:
                if not (edge.get('conditions') or edge.get('additional_predicate')):
                    continue
                endpoints = {edge.get('left_relation_id'), edge.get('right_relation_id')}
                if endpoints & connected:
                    connected.update(endpoints)
        if driver:
            connected_aliases = {str(node.get('alias')) for node in graph.get('nodes') or []
                                 if node.get('relation_id') in connected}
            for relation, contract in registry.items():
                owners = self.aliases.get(relation, {relation})
                executable = bool(set(owners) & connected or relation in connected or relation in connected_aliases)
                contract['outer_mapping_source'] = executable
                contract['scope_usage'] = ('Use exposed columns under this outer binding.' if executable else
                    'Lineage or target context only; do not select these raw columns unless explicitly connected in the outer graph.')
        retrieval = result["context"]["auto_map_retrieval"]
        for key in ("column_catalog", "relation_aliases", "table_contracts"):
            retrieval.pop(key, None)
        retrieval["relation_registry"] = registry
        retrieval["evidence_route"] = evidence_route(original.get("learning_context") or {})
        retrieval["goal"] = TASK
        from app.core.automap_tools import tool_manifest
        retrieval["tools"] = tool_manifest()
        learning = original.get("learning_context") or {}
        project = learning.get("project_context") or {}
        project_fields = ("project_id", "project_name", "project_description", "domain", "intended_outcome",
                          "business_process", "source_system_key", "sttm_id", "sttm_name", "sttm_description", "sttm_status")
        def target_identity(value):
            identifier = parse_one(str(value), read="snowflake").parts[-1]
            # Snowflake folds unquoted identifiers, but quoted case is exact.
            return identifier.name if identifier.args.get("quoted") else identifier.name.upper()

        target_identities = {target_identity(target) for target in self.targets}
        current_rows = []
        for row in workspace.get("mapping_rows") or []:
            if not isinstance(row, dict) or not row.get("target_column"):
                continue
            if target_identity(row["target_column"]) not in target_identities:
                continue
            current_rows.append({key: deepcopy(row[key]) for key in (
                "target_column", "target_type", "source_columns", "source_dependencies", "mapping_mode",
                "constant_value", "attribute_name", "value_binding_ids", "expression", "rule", "natural_language_rule",
                "status", "manually_saved", "accepted",
            ) if key in row})
        result["context"] = {
            "auto_map_retrieval": retrieval,
            "project_id": original.get("project_id"), "sttm_id": original.get("sttm_id"),
            "snapshot_id": workspace.get("snapshot_id"),
            "project_context": {key: deepcopy(project[key]) for key in project_fields if key in project},
            "project_context_status": (learning.get("retrieval_diagnostics") or {}).get("project_context", {}),
            "semantic_bundle_id": original.get("semantic_bundle_id"),
            "mapping_intent": original.get("mapping_intent") or workspace.get("mapping_intent") or learning.get("mapping_intent"),
            "current_mapping_rows": current_rows,
            "current_mapping_policy": "Current rows describe this snapshot, not independent historical proof. Preserve explicit user decisions; unaccepted generated rows remain proposals.",
            "population": {"driving_relation_id": workspace.get("driving_relation_id"),
                           "query_modifiers": graph.get("query_modifiers") or {},
                           "relationships": deepcopy(graph.get("edges") or original.get("relationships") or []),
                           "exact_dependency_id": "workspace" if workspace else None},
            "value_bindings": [{key: deepcopy(value) for key, value in binding.items() if key != "resolved_value"}
                               for binding in graph.get("value_bindings") or []],
        }
        # Target semantics are exact reads. Avoid a second copy of the same
        # descriptions/table namespace in the task request.
        result["data"]["attributes"] = [{key: deepcopy(item[key]) for key in ("target_attribute", "selected_mapping") if key in item}
                                         for item in result["data"].get("attributes") or []]
        return result

    def mandatory_categories(self, target: str) -> list[str]:
        # Unranked corrections and exact linked precedent cannot be hidden by Search.
        def negative(value):
            if isinstance(value, dict):
                if any(key in value for key in ("correction_id", "incorrect_source", "prevention_hint", "negative_conditions")):
                    return True
                return any(negative(child) for child in value.values())
            return any(negative(child) for child in value) if isinstance(value, list) else False
        return sorted(category for category, values in self.evidence[target].items()
                      if category != "workspace:execution_context" and (
                          category in {"mandatory_negative_evidence", "search_hydrated_evidence"}
                          or any(token in category for token in ("correction", "precedent", "semantic_version", "curated", "exact_fir", "target_mapping_patterns"))
                          or negative(values)))

    def _relations(self, relation: str) -> list[str]:
        owners = self.aliases.get(relation, set())
        if not owners and '"' not in relation:
            matches = [value for alias, value in self.aliases.items()
                       if '"' not in alias and alias.upper() == relation.upper()]
            if matches and all(value == matches[0] for value in matches):
                owners = matches[0]
        if not owners:
            raise ValueError("Unknown prepared relation identity")
        return sorted(owners)

    def _column_name(self, owner: str, column: str) -> str | None:
        columns = self.columns.get(owner, {})
        if column.startswith('"') and column.endswith('"'):
            exact = column[1:-1].replace('""', '"')
            return exact if exact in columns else None
        if column in columns:
            if column == column.upper() or column.upper() not in columns:
                return column
            return column.upper()
        matches = [name for name in columns if name.upper() == column.upper()]
        return matches[0] if len(matches) == 1 else None

    def _value(self, request: dict[str, Any]) -> tuple[tuple[str, ...], Any]:
        operation = request.get("operation")
        if operation == "evidence":
            target, category = request.get("target"), request.get("category")
            if target not in self.targets or category not in self.evidence[target]:
                raise ValueError("Unknown target evidence identity")
            return (operation, target, category), self._evidence_projection(target, category)
        if operation in {"column", "columns", "table", "contract", "profile"}:
            relation = request.get("relation")
            if not isinstance(relation, str):
                raise ValueError("A prepared relation is required")
            owners = self._relations(relation)
            if operation == "table":
                return (operation, relation), {owner: self.tables.get(owner, []) for owner in owners}
            if operation == "contract":
                return (operation, relation), {owner: self.contracts.get(owner, []) for owner in owners}
            if operation == "columns":
                records = {owner: self.columns.get(owner, {}) for owner in owners}
                if self.focused:
                    from app.core.automap_policy import semantic_projection
                    records = semantic_projection(records)
                return (operation, relation), records
            column = request.get("column")
            if not isinstance(column, str):
                raise ValueError("A prepared column is required")
            records = {owner: self.columns[owner][name] for owner in owners
                       if (name := self._column_name(owner, column)) is not None}
            if not records:
                raise ValueError("Unknown prepared column identity")
            if self.focused and operation != "profile":
                from app.core.automap_policy import semantic_projection
                records = semantic_projection(records)
            return (operation, relation, column), records
        if operation == "dependency" and request.get("relation_id") in self.historical_dependencies:
            relation_id = request["relation_id"]
            owner = self.historical_dependency_owners.get(relation_id)
            if owner and not owner[2] & self.active_evidence_ids(owner[0]):
                raise ValueError("Historical dependency belongs to an inactive evidence version")
            return (operation, relation_id), self.historical_dependencies[relation_id]
        if operation == "dependency" and request.get("relation_id") in self.dependencies:
            relation_id = request["relation_id"]
            if relation_id in {"workspace", "workspace:original"}:
                return (operation, relation_id), self.dependencies[relation_id]
            closure = {}
            pending = [relation_id]
            while pending:
                current = pending.pop()
                if current in closure:
                    continue
                node = self.nodes.get(current)
                if node is None:
                    raise ValueError("Prepared dependency parent is unavailable")
                closure[current] = self._dependency_projection(node)
                pending.extend(node.get("parent_relation_ids") or [])
            return (operation, relation_id), closure
        raise ValueError("Unsupported Auto-map context operation")

    def read(self, request: dict[str, Any], *, max_bytes: int,
             discover: Callable[[str], dict[str, Any]] | None = None) -> dict[str, Any]:
        allowed = {"tool", "snapshot_hash", "operation", "target", "category", "relation", "column", "relation_id", "cursor"}
        if set(request) - allowed or request.get("tool") != "AUTO_MAP_CONTEXT" or request.get("snapshot_hash") != self.snapshot_hash:
            raise ValueError("Unavailable or stale Auto-map snapshot")
        self._validate_operation({key: value for key, value in request.items() if key not in {"tool", "snapshot_hash"}})
        if request.get("operation") == "discover":
            target = request.get("target")
            if target not in self.targets or request.get("cursor"):
                raise ValueError("Unknown discovery target")
            if target not in self.discovered:
                if self.focused:
                    raise ValueError("Focused initial discovery must use the owning batch admission path")
                result = discover(target) if discover else {"diagnostics": {"status": "unavailable"}}
                self.discovered[target] = deepcopy(result)
                for category, values in (result.get("evidence") or {}).items():
                    self.evidence[target][category] = deepcopy(values)
            value = {"diagnostics": self.discovered[target].get("diagnostics"),
                     "source_candidates": self.discovered[target].get("source_candidates", {}),
                     "evidence_categories": sorted(self.evidence[target]),
                     "mandatory_categories": self.mandatory_categories(target)}
            response = self._bounded({"operation": "discover", "target": target, "complete": True,
                                      "snapshot_hash": self.snapshot_hash, "data": value}, max_bytes)
            self.reads.add(("discover", target))
            return response
        identity, value = self._value(request)
        signature = digest([self.snapshot_hash, identity, value])
        cursor = request.get("cursor")
        index = 0
        page_bytes = max_bytes - 1100
        if cursor:
            if not isinstance(cursor, str) or cursor not in self.cursors or self.cursors[cursor][0] != signature:
                raise ValueError("Unknown or stale retrieval cursor")
            index = self.cursors[cursor][1]
            page_bytes = self.cursors[cursor][2]
            if page_bytes > max_bytes - 1100:
                raise AgentPayloadBudgetError("Cursor page requires its original allowance; request fewer operations")
        # Aggregate chunks may shrink between reads. A cursor must retain its
        # original page plan, otherwise the same offset skips exact fragments.
        page_signature = digest([signature, page_bytes])
        pages = self._pages(value, max_bytes=page_bytes)
        if index >= len(pages):
            raise ValueError("Invalid retrieval page")
        next_cursor = None
        if index + 1 < len(pages):
            next_cursor = digest([page_signature, index + 1])
            self.cursors[next_cursor] = (signature, index + 1, page_bytes)
        response = self._bounded({"operation": identity[0], "identity": list(identity[1:]),
                              "snapshot_hash": self.snapshot_hash, "content_hash": digest(value),
                              "page": index, "page_count": len(pages), "complete": next_cursor is None,
                              "next_cursor": next_cursor, "fragments": pages[index]}, max_bytes)
        self.pages_read.setdefault(page_signature, set()).add(index)
        if self.pages_read[page_signature] == set(range(len(pages))):
            self.reads.add(identity)
        return response

    def discover_batch(self, discover: Callable[[list[str]], dict[str, Any]]) -> None:
        """Prepare applicability once using the caller's session, not per model turn."""
        pending = [target for target in self.targets if target not in self.discovered]
        if not pending:
            return
        discovered = discover(pending)
        if set(discovered) != set(pending):
            raise ValueError("Discovery must return exactly the requested batch targets")
        self._record_search_work(discovered, len(pending))
        self._freeze_evidence_versions(discovered)
        for target, result in discovered.items():
            self.discovered[target] = deepcopy(result)
            self.available_evidence[target] = deepcopy(result.get("available_evidence") or result.get("evidence") or {})
            from app.core.automap_policy import select_positive_evidence
            allowance = 0 if self.evidence[target].get("mapping_precedents") else 1
            selected = select_positive_evidence(result.get("evidence") or {}, limit=allowance) if self.focused else result.get("evidence") or {}
            for category, values in selected.items():
                if category == "mandatory_negative_evidence":
                    existing = self.evidence[target].setdefault(category, [])
                    seen = {digest(record) for record in existing}
                    existing.extend(deepcopy(record) for record in values if digest(record) not in seen)
                else:
                    self.evidence[target][category] = deepcopy(values)
            from app.core.automap_policy import record_identity
            self.primary_evidence_ids.update(record_identity(record) for category, records in selected.items()
                if category != "mandatory_negative_evidence" for record in records)

    def _record_search_work(self, discovered: dict, target_count: int) -> None:
        # Service diagnostics are shared by every target in one physical call.
        diagnostics = next((result.get("diagnostics", {}) for result in discovered.values()
                            if result.get("diagnostics", {}).get("route") != "selected_precedent"), {})
        # The per-target parallel Search fallback sums one hydration pass per target
        # (up to four kinds each) plus one shared read; one physical call keeps five.
        reads = 4 * target_count + 1 if diagnostics.get("parallel_fallback") is True else 5
        ceilings = {"query_count": 3 * target_count, "returned_hit_count": 24 * target_count,
                    "returned_id_count": 12 * target_count, "canonical_read_count": reads}
        for key, ceiling in ceilings.items():
            count = int(diagnostics.get(key) or 0)
            if count < 0 or count > ceiling:
                raise ValueError("Physical Search/hydration work exceeded the bounded discovery contract")
            self.search_work[key] += count

    def _freeze_evidence_versions(self, discovered: dict) -> None:
        from app.core.automap_policy import record_identity
        versions = dict(self.evidence_versions)
        for result in discovered.values():
            for records in (result.get("available_evidence") or result.get("evidence") or {}).values():
                for record in records:
                    if not isinstance(record, dict):
                        continue
                    identity = record_identity(record)
                    if not identity:
                        continue
                    # Applicability wrappers may vary by target, canonical bodies may not.
                    content = record.get("pattern") or record.get("payload") or record
                    version = digest(content)
                    if identity in versions and versions[identity] != version:
                        raise ValueError("Canonical evidence changed within the frozen run; restart affected batch")
                    versions[identity] = version
        self.evidence_versions = versions

    def check_positive_budget(self, max_chars: int) -> int:
        """Bound exact positive learning without clipping rules or mandatory negatives."""
        positive = {target: {category: self._evidence_projection(target, category)
                             for category in ("canonical_target_mapping_patterns", "search_hydrated_evidence")
                             if self.evidence[target].get(category)} for target in self.targets}
        size = len(encoded(positive))
        if size > max_chars:
            raise AgentPayloadBudgetError("Active positive learning exceeds its serialized budget; exact rules were not truncated")
        return size

    def search_more(self, delegation: dict[str, Any], search: Callable[..., dict], *, max_rounds: int, max_bytes: int,
                    active_limit: int = 2) -> dict:
        from app.core.automap_tools import normalize_delegation
        from app.core.automap_policy import record_identity, select_positive_evidence
        request = normalize_delegation(delegation, self.snapshot_hash)
        targets = list(dict.fromkeys(request["targets"]))
        if any(target not in self.targets for target in targets):
            raise ValueError("Search-more target is outside the owning batch")
        key = digest(request)
        if key in self.search_cache:
            cached = deepcopy(self.search_cache[key])
            for target, output in cached.get("targets", {}).items():
                output["active_positive_ids"] = sorted({record_identity(record) for category, records in self.evidence[target].items()
                    if category in {"canonical_target_mapping_patterns", "search_hydrated_evidence"} for record in records})
            return cached
        rejected_ids = set(request["rejected_ids"])
        owned_positive_ids = {record_identity(record) for target in targets for category, records in self.evidence[target].items()
                              if category in {"canonical_target_mapping_patterns", "search_hydrated_evidence"} for record in records}
        if rejected_ids - owned_positive_ids or rejected_ids & self.primary_evidence_ids:
            raise ValueError("Only owned active alternatives can be replaced; primary/mandatory evidence is immutable")
        if self.search_rounds >= max_rounds:
            return {"operation": "search_more", "status": "budget_exhausted", "additional_rounds": self.search_rounds}
        excluded = sorted({record_identity(record) for target in targets
                           for records in self.evidence[target].values() for record in records
                           if isinstance(record, dict) and record_identity(record)} | self.rejected_evidence_ids)
        self.search_rounds += 1
        discovered = search(targets, query_refinement=request["query"], excluded_ids=excluded, followup=True)
        if set(discovered) != set(targets):
            raise ValueError("Search-more must return exactly the owned requested targets")
        self._record_search_work(discovered, len(targets))
        self._freeze_evidence_versions(discovered)
        state = deepcopy((self.evidence, self.available_evidence, self.discovered, self.reads, self.rejected_evidence_ids))
        self.rejected_evidence_ids.update(rejected_ids)
        output = {}
        for target, result in discovered.items():
            self.available_evidence.setdefault(target, {})
            combined = {}
            for category, records in (result.get("available_evidence") or result.get("evidence") or {}).items():
                available = self.available_evidence[target].setdefault(category, [])
                seen = {digest(record) for record in available}
                available.extend(deepcopy(record) for record in records if digest(record) not in seen)
                combined[category] = deepcopy(records)
            for category in ("canonical_target_mapping_patterns", "search_hydrated_evidence"):
                combined.setdefault(category, []).extend(deepcopy(self.evidence[target].get(category, [])))
            # Keep the original primary and one newly requested alternative.
            primary = {category: [deepcopy(record) for record in self.evidence[target].get(category, [])
                                  if record_identity(record) not in rejected_ids] for category in
                       ("canonical_target_mapping_patterns", "search_hydrated_evidence")}
            initial_ids = {record_identity(record) for records in primary.values() for record in records}
            remaining = {category: [record for record in records if record_identity(record) not in initial_ids | self.rejected_evidence_ids]
                         for category, records in combined.items()}
            allowance = max(0, active_limit - len(initial_ids) - int(bool(self.evidence[target].get("mapping_precedents"))))
            selected = select_positive_evidence(remaining, limit=allowance)
            for category, records in selected.items():
                if category == "mandatory_negative_evidence":
                    negatives = self.evidence[target].setdefault(category, [])
                    negative_ids = {digest(record) for record in negatives}
                    negatives.extend(record for record in records if digest(record) not in negative_ids)
                else:
                    primary.setdefault(category, []).extend(records)
            for category, records in primary.items():
                if records != self.evidence[target].get(category, []):
                    self.reads.discard(("evidence", target, category))
                    self.evidence[target][category] = records
            if selected.get("mandatory_negative_evidence"):
                self.reads.discard(("evidence", target, "mandatory_negative_evidence"))
            diagnostics = deepcopy(result.get("diagnostics") or {})
            self.discovered[target] = {**self.discovered.get(target, {}), "diagnostics": diagnostics,
                                       "source_candidates": deepcopy(result.get("source_candidates") or {})}
            self.reads.discard(("discover", target))
            output[target] = {"diagnostics": diagnostics, "evidence_categories": sorted(self.evidence[target]),
                              "active_positive_ids": sorted({record_identity(record) for records in primary.values() for record in records}),
                              "available_candidate_count": sum(map(len, self.available_evidence[target].values()))}
        response = {"operation": "search_more", "snapshot_hash": self.snapshot_hash,
                    "additional_rounds": self.search_rounds, "targets": output}
        try:
            self._bounded(response, max_bytes)
        except AgentPayloadBudgetError:
            self.evidence, self.available_evidence, self.discovered, self.reads, self.rejected_evidence_ids = state
            raise
        self.search_cache[key] = deepcopy(response)
        return response

    def read_many(self, request: dict[str, Any], *, max_bytes: int,
                  max_operations: int = 64, max_total_bytes: int = 131072) -> dict[str, Any]:
        if (set(request) != {"tool", "snapshot_hash", "operation", "reads"}
                or request.get("tool") != "AUTO_MAP_CONTEXT"
                or request.get("snapshot_hash") != self.snapshot_hash
                or request.get("operation") != "multi_read"):
            raise ValueError("Invalid batch snapshot delegation")
        operations = request.get("reads")
        if not isinstance(operations, list) or not 1 <= len(operations) <= min(64, max_operations):
            raise ValueError("Multi-read requires a bounded nonempty operation list")
        # Validate all scopes/cursors BEFORE returning any content or marking reads.
        for operation in operations:
            if not isinstance(operation, dict) or set(operation) - {
                "operation", "target", "category", "relation", "column", "relation_id", "cursor"
            }:
                raise ValueError("Invalid exact read operation")
            self._validate_operation(operation)
            if operation.get("operation") == "discover":
                if operation.get("target") not in self.targets or operation.get("cursor"):
                    raise ValueError("Unknown discovery target")
            else:
                identity, value = self._value(operation)
                cursor = operation.get("cursor")
                if cursor and self.cursors.get(cursor, (None,))[0] != digest([self.snapshot_hash, identity, value]):
                    raise ValueError("Unknown or stale retrieval cursor")
        # Budget the whole response, including operation echoes, before changing
        # read state. Each exact body is paged within its allotted share.
        overhead = len(encoded({"operation": "multi_read", "snapshot_hash": self.snapshot_hash,
                                "results": [{"request": operation, "result": {}} for operation in operations]}).encode("utf-8"))
        required = {index: self.cursors[operation["cursor"]][2] + 1100
                    for index, operation in enumerate(operations) if operation.get("cursor")}
        remaining_bytes = max_total_bytes - overhead - 512 - sum(required.values())
        unpaged_count = len(operations) - len(required)
        allowance = min(max_bytes, remaining_bytes // max(1, unpaged_count))
        if remaining_bytes < 0 or any(value > max_bytes for value in required.values()):
            raise AgentPayloadBudgetError("Aggregate cursor pages need more allowance; request fewer operations")
        if unpaged_count and allowance < 2048:
            raise AgentPayloadBudgetError("Aggregate multi-read budget is too small; request fewer operations")
        results = []
        state = {key: deepcopy(getattr(self, key)) for key in (
            "reads", "cursors", "pages_read", "discovered", "evidence", "historical_dependencies", "historical_dependency_owners",
        )}
        for index, operation in enumerate(operations):
            query = {"tool": "AUTO_MAP_CONTEXT", "snapshot_hash": self.snapshot_hash, **operation}
            try:
                result = self.read(query, max_bytes=required.get(index, allowance))
            except (ValueError, AgentPayloadBudgetError) as exc:
                result = {"error": "INVALID_AUTO_MAP_CONTEXT_REQUEST", "detail": str(exc), "content_returned": False}
            results.append({"request": deepcopy(operation), "result": result})
        try:
            return self._bounded({"operation": "multi_read", "snapshot_hash": self.snapshot_hash, "results": results}, max_total_bytes)
        except AgentPayloadBudgetError:
            for key, value in state.items():
                setattr(self, key, value)
            raise

    def exact_completed_result(self, operation: dict[str, Any]) -> dict[str, Any]:
        """Reassemble completed pages before interning repeated complete SQL/rules."""
        if operation.get("operation") == "discover":
            target = operation["target"]
            if ("discover", target) not in self.reads:
                raise ValueError("Discovery was not completed")
            return {"operation": "discover", "target": target, "complete": True,
                    "data": {"diagnostics": self.discovered[target].get("diagnostics"),
                             "source_candidates": self.discovered[target].get("source_candidates", {})}}
        identity, value = self._value(operation)
        if identity not in self.reads:
            raise ValueError("Exact read was not completed")
        return {"operation": identity[0], "identity": list(identity[1:]),
                "content_hash": digest(value), "complete": True, "data": deepcopy(value)}

    def required_operations(self, target: str, mapping: dict[str, Any]) -> list[dict[str, Any]]:
        operations = []
        source_reads: dict[str, tuple[str, str]] = {}
        for identity in self.missing_reads(target, mapping, source_reads=source_reads):
            operation = None
            if identity == "historical discovery":
                operation = {"operation": "discover", "target": target}
            elif identity.startswith("mandatory evidence:"):
                operation = {"operation": "evidence", "target": target, "category": identity.split(":", 1)[1]}
            elif identity.startswith("target semantics:"):
                operation = {"operation": "column", "relation": self.target_table, "column": target}
            elif identity.startswith("table contract:"):
                operation = {"operation": "contract", "relation": identity.split(":", 1)[1]}
            elif identity.startswith("source semantics:"):
                relation, column = source_reads[identity]
                operation = {"operation": "column", "relation": relation, "column": column}
            elif identity.startswith("derived dependency:"):
                operation = {"operation": "dependency", "relation_id": identity.split(":", 1)[1]}
            elif identity.startswith("unparsed population predicate"):
                operation = {"operation": "dependency", "relation_id": "workspace"}
            if operation:
                operations.append(operation)
        return operations

    @staticmethod
    def _validate_operation(operation: dict[str, Any]) -> None:
        fields = {
            "discover": {"target"}, "evidence": {"target", "category"},
            "column": {"relation", "column"}, "profile": {"relation", "column"},
            "columns": {"relation"}, "contract": {"relation"}, "table": {"relation"},
            "dependency": {"relation_id"},
        }
        required = fields.get(operation.get("operation"))
        if (required is None or set(operation) - {"operation", "cursor", *required}
                or not required <= set(operation)
                or any(not isinstance(operation[key], str) or not operation[key] for key in required)):
            raise ValueError("Invalid typed Auto-map read arguments")

    @staticmethod
    def _bounded(value: Any, max_bytes: int) -> Any:
        if len(encoded(value).encode("utf-8")) > max_bytes:
            raise AgentPayloadBudgetError("Exact Auto-map read exceeds retrieval allowance")
        return value

    @staticmethod
    def _pages(value: Any, *, max_bytes: int) -> list[list[dict[str, Any]]]:
        if max_bytes < 1024:
            raise AgentPayloadBudgetError("Insufficient Auto-map retrieval allowance")
        fragments = []

        def split(child, path):
            fragment = {"path": path, "value": child}
            if len(encoded([fragment]).encode("utf-8")) <= max_bytes:
                fragments.append(fragment)
            elif isinstance(child, dict):
                for key, item in child.items():
                    split(item, [*path, key])
            elif isinstance(child, list):
                for index, item in enumerate(child):
                    split(item, [*path, index])
            elif isinstance(child, str):
                start = 0
                while start < len(child):
                    end = min(len(child), start + max_bytes // 8)
                    part = {"path": path, "text_start": start, "text_length": len(child), "value": child[start:end]}
                    AutoMapContext._bounded([part], max_bytes)
                    fragments.append(part)
                    start = end
            else:
                raise AgentPayloadBudgetError("An indivisible exact Auto-map value exceeds allowance")

        split(value, [])
        pages = [[]]
        for fragment in fragments:
            if len(encoded([*pages[-1], fragment]).encode("utf-8")) > max_bytes:
                pages.append([])
            pages[-1].append(fragment)
        return pages

    def missing_reads(self, target: str, mapping: dict[str, Any], *,
                      source_reads: dict[str, tuple[str, str]] | None = None) -> list[str]:
        missing = []
        draft_generation = (self.original.get('meta') or {}).get('automap_generation_policy') == 'draft-v3'

        def require_source(relation: str, column: str, reference: str) -> None:
            identity = f"source semantics:{reference}"
            missing.append(identity)
            if source_reads is not None:
                source_reads[identity] = (relation, column)

        used_ids = set(mapping.get("used_learning_ids", []) + mapping.get("used_inference_ids", [])
                       + mapping.get("used_recommendation_ids", []) + mapping.get("override_evidence", []))
        if mapping.get("precedent_mapping_id"):
            used_ids.add(mapping["precedent_mapping_id"])
        for relation_id, (owner, _category, identifiers) in self.historical_dependency_owners.items():
            if owner == target and used_ids & identifiers and ("dependency", relation_id) not in self.reads:
                missing.append(f"derived dependency:{relation_id}")
        if ("discover", target) not in self.reads:
            missing.append("historical discovery")
        diagnostics = self.discovered.get(target, {}).get("diagnostics") or {}
        learning = (self.original.get("context") or {}).get("learning_context") or {}
        if diagnostics.get("status") in {"unavailable", "degraded", "error"}:
            prepared_checks = learning.get("retrieval_diagnostics") or {}
            mandatory_available = all(
                isinstance(prepared_checks.get(category), dict)
                and prepared_checks[category].get("status") in {"available", "no_match"}
                for category in ("correction_history", "project_context")
            )
            # Search is supplemental only when no historical rule is cited and
            # mandatory caller-scoped corrections/project constraints were read.
            # Exact current source, target and population checks still run below.
            current_only = (mandatory_available and not used_ids
                            and not learning.get("linked_mapping_ids")
                            and not learning.get("linked_project_ids")
                            and diagnostics.get("route") == "search")
            if not current_only and not draft_generation:
                missing.append("historical retrieval unavailable")
        if not draft_generation and any(isinstance(item, dict) and item.get("status") == "error"
               for item in (learning.get("retrieval_diagnostics") or {}).values()):
            missing.append("prepared evidence retrieval failed")
        for category in self.mandatory_categories(target):
            if ("evidence", target, category) not in self.reads:
                missing.append(f"mandatory evidence:{category}")
        if self._column_name(self.target_table, target) is not None and not self._has_column_read({self.target_table}, target):
            missing.append(f"target semantics:{target}")
        required_contracts = {self.target_table}
        graph = (self.original.get("context") or {}).get("relation_graph") or {}
        from app.core.learning_evidence import repeats_rejected_decision

        workspace = (self.original.get("context") or {}).get("workspace_context") or {}
        for correction in self.evidence[target].get("correction_history", []):
            if isinstance(correction, dict) and repeats_rejected_decision(correction, mapping, workspace):
                missing.append(f"rejected corrected source:{correction.get('correction_id')}")
        for reference in [*mapping.get("source_attributes", []), *mapping.get("source_dependencies", [])]:
            try:
                relation, column = reference_parts(str(reference))
                owners = set(self._relations(relation)) if relation else set()
            except ValueError:
                owners = set()
            if not owners:
                missing.append(f"unknown source binding:{reference}")
                continue
            required_contracts.update(owners)
            column_read = self._has_column_read(owners, column)
            if not column_read:
                require_source(relation, column, str(reference))
            if not any(self._column_name(owner, column) is not None for owner in owners):
                missing.append(f"unknown source column:{reference}")
            for node in graph.get("nodes") or []:
                if str(node.get("relation_id")) in self.dependencies and (
                    any(set(self._relations(alias)) == owners for alias in
                        (str(node.get("relation_id")), str(node.get("alias") or ""), table_name(node.get("table")))
                        if alias in self.aliases)
                ) and ("dependency", str(node["relation_id"])) not in self.reads:
                    missing.append(f"derived dependency:{node['relation_id']}")
        structural = []
        for edge in graph.get("edges") or []:
            for condition in edge.get("conditions") or []:
                for side in ("left", "right"):
                    relation, column = edge.get(f"{side}_relation_id"), condition.get(f"{side}_column")
                    if relation and column:
                        structural.append((str(relation), str(column)))
        workspace = (self.original.get("context") or {}).get("workspace_context") or {}
        if self.focused and workspace and ("dependency", "workspace") not in self.reads:
            missing.append("derived dependency:workspace")
        if self.focused:
            driving = workspace.get("driving_relation_id")
            if driving in self.dependencies and ("dependency", driving) not in self.reads:
                missing.append(f"derived dependency:{driving}")
        predicates = [edge.get("additional_predicate") for edge in graph.get("edges") or []]
        predicates.extend(value for key, value in (graph.get("query_modifiers") or {}).items()
                          if key in {"where", "where_sql", "qualify", "qualify_sql", "group_by_sql", "order_by_sql", "having", "having_sql"}
                          and isinstance(value, str))
        filters = workspace.get("filters") or {}
        if isinstance(filters, dict):
            predicates.extend(value for key, value in filters.items() if key.endswith("sql") and isinstance(value, str))
        for predicate in predicates:
            if not predicate:
                continue
            try:
                tree = parse_one(predicate, read="snowflake")
                for column in tree.find_all(exp.Column):
                    qualifier, name = reference_parts(column.sql(dialect="snowflake"))
                    if qualifier:
                        structural.append((qualifier, name))
                    else:
                        structural.extend((relation, column.name) for relation, columns in self.columns.items()
                                          if column.name in columns and relation != self.target_table)
            except Exception:
                if ("dependency", "workspace") not in self.reads:
                    missing.append("unparsed population predicate; exact workspace dependency required")
        for relation, column in structural:
            try:
                owners = set(self._relations(relation))
            except ValueError:
                owners = set()
            required_contracts.update(owners)
            if owners and not self._has_column_read(owners, column):
                # Relation IDs are opaque retrieval handles, not SQL qualifiers.
                require_source(relation, column, f"{relation}.{column}")
        for relation in sorted(required_contracts & self.deferred_contracts):
            owners = self.aliases.get(relation, set())
            if not any(identity[0] in {"table", "contract"} and set(self._relations(identity[1])) == owners
                       for identity in self.reads):
                missing.append(f"table contract:{relation}")
        return sorted(set(missing))

    def _has_column_read(self, owners: set[str], column: str) -> bool:
        # Owners lacking the column (e.g. a sparse semantic projection) cannot
        # contradict a read; at least one owner must resolve it identically.
        resolving = [owner for owner in owners if self._column_name(owner, column) is not None]
        return bool(resolving) and any(identity[0] in {"column", "columns"}
                   and set(self._relations(identity[1])) == owners
                   and (identity[0] == "columns" or all(
                       self._column_name(owner, identity[2]) == self._column_name(owner, column)
                       for owner in resolving)) for identity in self.reads)

    def primary_owner(self, relation: str) -> str:
        """The graph node relation behind a handle that also has semantic owners."""
        owners = self._relations(relation)
        if len(owners) == 1:
            return owners[0]
        primary = self.node_owners.get(relation)
        if primary is None and '"' not in relation:
            matches = {value for name, value in self.node_owners.items()
                       if '"' not in name and name.upper() == relation.upper()}
            primary = matches.pop() if len(matches) == 1 else None
        if primary not in owners:
            raise ValueError("Ambiguous transformation source")
        return primary

    def active_evidence_ids(self, target: str) -> set[str]:
        from app.core.automap_policy import record_identity
        return {record_identity(record) for records in self.evidence[target].values()
                for record in records if isinstance(record, dict) and record_identity(record)}

    def evidence_ids(self, target: str) -> set[str]:
        identifiers = set()

        def visit(value):
            if isinstance(value, dict):
                for key, child in value.items():
                    if key in {"pattern_id", "learning_id", "correction_id", "inference_id", "recommendation_id",
                               "mapping_id", "knowledge_id", "precedent_sttm_id"} and child:
                        identifiers.add(str(child))
                    else:
                        visit(child)
            elif isinstance(value, list):
                for child in value:
                    visit(child)

        for identity in self.reads:
            if identity[0] == "evidence" and identity[1] == target:
                visit(self._evidence_projection(identity[1], identity[2]))
            elif identity[0] == "dependency" and identity[1] in self.historical_dependency_owners:
                owner, _category, ids = self.historical_dependency_owners[identity[1]]
                if owner == target and ids & self.active_evidence_ids(target):
                    visit(self.historical_dependencies[identity[1]])
        return identifiers

    def recipe_ids(self, target: str) -> set[str]:
        identifiers = set()
        for identity in self.reads:
            if identity[0] != "evidence" or identity[1] != target or "target_mapping_patterns" not in identity[2]:
                continue
            for record in self.evidence[target][identity[2]]:
                pattern = record.get("pattern", record)
                if pattern.get("pattern_id"):
                    identifiers.add(str(pattern["pattern_id"]))
        return identifiers

    def precedent_ids(self, target: str) -> set[str]:
        identifiers = set()
        for identity in self.reads:
            if identity[0] == "evidence" and identity[1] == target and "precedent" in identity[2]:
                for record in self.evidence[target][identity[2]]:
                    if isinstance(record, dict) and record.get("precedent_sttm_id"):
                        identifiers.add(str(record["precedent_sttm_id"]))
                    for row in record.get("mappings", []) if isinstance(record, dict) else []:
                        if row.get("mapping_id"):
                            identifiers.add(str(row["mapping_id"]))
        return identifiers


class ParallelRegistryProjection:
    """Request-local serialization filter; never prune the authoritative store."""

    def __init__(self, store: AutoMapContext, preparation):
        from app.core.automap_parallel import ParallelPreparation
        if not isinstance(preparation, ParallelPreparation) or preparation.store is not store:
            raise ValueError("Parallel preparation must belong to this exact store")
        if preparation.scope.snapshot_id != store.snapshot_hash or preparation.coverage.mapping_blocked:
            raise ValueError("Parallel preparation is stale or mandatory context is blocked")
        self.preparation = preparation
        self._state = self._fingerprint(store)
        self._columns = {store.target_table: set(store.targets)}
        self.read_operations = []
        self.validate(store)
        for source in preparation.selected_source_identities:
            self._include(store, source.relation, source.column)
        # Whole-table support includes structural/parent columns, not just winners.
        for card in preparation.support_cards:
            body = card.body
            if isinstance(body, dict) and card.kind in {"source_column", "lineage_column", "target_column"}:
                self._include(store, body["relation"], body["column"])
        # Capture mandatory structural columns even if an earlier caller read them.
        unread = deepcopy(store)
        unread.reads.clear()
        for target in unread.targets:
            for operation in unread.required_operations(target, {"source_attributes": []}):
                if operation["operation"] == "column":
                    self._include(store, operation["relation"], operation["column"])
        for source in preparation.selected_source_identities:
            for target in unread.targets:
                self.read_operations.extend(unread.required_operations(target, {
                    "source_attributes": [f"{source.sql_qualifier}.{source.column}"]}))
        # Driver population contracts remain mandatory even if no candidate uses it.
        context = store.original.get("context") or {}
        driver = (context.get("workspace_context") or {}).get("driving_relation_id")
        if not driver and context.get("driving_table"):
            driver = table_name(context["driving_table"])
        if driver:
            self.read_operations.append({"operation": "contract", "relation": driver})

    @staticmethod
    def _fingerprint(store):
        return digest({key: getattr(store, key) for key in (
            "snapshot_hash", "original", "inventory", "columns", "nodes", "contracts",
            "evidence", "discovered", "available_evidence", "evidence_versions",
        )} | {"aliases": {key: sorted(value) for key, value in store.aliases.items()}})

    def validate(self, store):
        from app.core.automap_scan_context import _bindings
        preparation = self.preparation
        if preparation.store is not store or self._fingerprint(store) != self._state:
            raise ValueError("Parallel evidence generation changed; restart the batch")
        manifest = preparation.candidate_manifest
        if (manifest.get("snapshot_hash") != store.snapshot_hash or preparation.scan is None
                or manifest.get("generation") != preparation.scan.generation
                or preparation.scan.scope != preparation.scope):
            raise ValueError("Parallel preparation scope/generation mismatch")
        bindings, _ = _bindings(store, store.original.get("context") or {})
        for source in preparation.selected_source_identities:
            owners = [owner for owner in bindings.get(source.relation, [])
                      if owner["relation_id"] == source.relation_id
                      and owner["sql_qualifier"] == source.sql_qualifier
                      and owner["outer_mapping_source"] and owner["unique_qualifier"]
                      and source.name in owner["outputs"]]
            if (len(owners) != 1 or source.relation == store.target_table
                    or store._column_name(source.relation, source.column) != source.name
                    or not any(card.body.get("relation") == source.relation
                               and card.body.get("column") == source.column
                               and (card.body.get("binding") or {}).get("relation_id") == source.relation_id
                               and card.body.get("eligible") is True
                               for card in preparation.bounded_source_cards)):
                raise ValueError("Parallel selected source binding is unavailable")

    def _include(self, store, relation, column):
        for owner in store._relations(relation):
            name = store._column_name(owner, column)
            if name is None:
                raise ValueError("Parallel support column is unavailable")
            self._columns.setdefault(owner, set()).add(name)

    def apply(self, store, packet):
        self.validate(store)
        if not store.focused:
            raise ValueError("Parallel projection requires the focused mapping manifest")
        retrieval = packet["context"]["auto_map_retrieval"]
        for relation, descriptor in retrieval["relation_registry"].items():
            columns = descriptor["columns"]
            descriptor["columns"] = {name: value for name, value in columns.items()
                                     if name in self._columns.get(relation, set())}
            descriptor["omitted_column_count"] = len(columns) - len(descriptor["columns"])
            if not descriptor["columns"]:
                descriptor["contract"] = {"exact_contract_read_required": True}
                descriptor["scope_usage"] = "Not selected by this preparation; exact evidence remains available, not absent."
        retrieval["parallel_preparation"] = self.preparation.candidate_manifest
        retrieval["parallel_preparation"]["search_more_policy"] = (
            "Evidence generation is frozen. Do not request search_more; return affected targets unresolved "
            "with a concrete missing-evidence reason. A new batch is required for new discovery.")
        return packet


def batch_packet(store: AutoMapContext, results: list[Any], *, missing=None,
                 registry_projection: ParallelRegistryProjection | None = None) -> dict[str, Any]:
    """Lossless exact reads, with an optional validated serialization-only registry filter."""
    from app.core.agent_payload_budget import _factor_repeated_context_values
    packet = store.manifest()
    if registry_projection is not None:
        packet = registry_projection.apply(store, packet)
    packet["retrieved_auto_map_context"] = [
        {key: deepcopy(value) for key, value in result.items() if key != "read_key"}
        for result in results
    ]
    if missing:
        packet["batch_evidence_deficits"] = missing
    if not store.focused:
        packet["data"]["message"] = ((packet["data"].get("message") or "")
            + "\nApplication batch retrieval contract: " + PROTOCOL)
    packet = factor_exact_records(packet)
    _factor_repeated_context_values(packet)
    packet = factor_exact_text_lines(packet)
    return factor_exact_object_shapes(packet)


def factor_exact_text_lines(payload: dict[str, Any]) -> dict[str, Any]:
    """Share verbatim text segments across nonidentical historical snapshots."""
    counts: dict[str, int] = {}
    reserved = False

    def segments(value):
        # Delimiters and whitespace stay in their original segment. This is text
        # interning, not SQL parsing/rewriting, including commas inside literals.
        # A leading unanchored greedy alternative retries at every character
        # on a long delimiter-free suffix (quadratic work). Locate delimiters
        # once instead; retain each delimiter and its trailing spaces verbatim.
        chunks, start = [], 0
        for match in re.finditer(r"[,;\n][ \t]*", value):
            chunks.append(value[start:match.end()])
            start = match.end()
        if start < len(value):
            chunks.append(value[start:])
        # Standalone historical wrappers often render their shared joins on one
        # long line, unlike the current graph SQL. Split at reproducible word
        # boundaries too; this is lossless text segmentation, not SQL rewriting.
        return [piece for chunk in chunks for piece in re.split(
            r"(?=\b(?:LEFT\s+(?:OUTER\s+)?JOIN|INNER\s+JOIN|RIGHT\s+(?:OUTER\s+)?JOIN|"
            r"FULL\s+(?:OUTER\s+)?JOIN|CROSS\s+JOIN|WHERE|QUALIFY|GROUP\s+BY|ORDER\s+BY|UNION)\b)",
            chunk, flags=re.IGNORECASE) if piece]

    def count(value):
        nonlocal reserved
        if isinstance(value, str) and len(value) >= 256:
            for line in segments(value):
                if len(line) >= 40:
                    counts[line] = counts.get(line, 0) + 1
        elif isinstance(value, dict):
            reserved |= any(key in value for key in ("$exact_text", "$exact_line", "exact_text_lines", "exact_text_encoding"))
            for child in value.values():
                count(child)
        elif isinstance(value, list):
            for child in value:
                count(child)

    count(payload)
    if reserved:
        return payload
    lines = [line for line, count in counts.items() if count > 1 and (len(encoded(line)) - 20) * count > len(encoded(line)) + 8]
    indices = {line: index for index, line in enumerate(lines)}

    def replace(value):
        if isinstance(value, str) and len(value) >= 256:
            pieces = [{"$exact_line": indices[line]} if line in indices else line
                      for line in segments(value)]
            candidate = {"$exact_text": pieces}
            return candidate if len(encoded(candidate)) < len(encoded(value)) else value
        if isinstance(value, dict):
            return {key: replace(child) for key, child in value.items()}
        return [replace(child) for child in value] if isinstance(value, list) else value

    factored = replace(payload)
    if lines:
        factored["exact_text_lines"] = lines
        factored["exact_text_encoding"] = (
            "A {$exact_text:[pieces]} means the EXACT string formed by concatenating pieces "
            "in order without separators. A {$exact_line:N} piece is exact_text_lines[N]. "
            "Whitespace/newlines are already included. Resolve all other dictionary references "
            "recursively first. No SQL or rules were removed. Return ordinary strings."
        )
    return factored if len(encoded(factored)) < len(encoded(payload)) else payload


def factor_exact_object_shapes(payload: dict[str, Any]) -> dict[str, Any]:
    """Intern repeated JSON keys; values/order/types remain exactly reversible."""
    counts: dict[tuple[str, ...], int] = {}
    reserved = False

    def count(value):
        nonlocal reserved
        if isinstance(value, dict):
            if any(key in value for key in ("$exact_object", "exact_object_shapes", "exact_object_encoding")):
                reserved = True
            shape = tuple(value)
            counts[shape] = counts.get(shape, 0) + 1
            for child in value.values():
                count(child)
        elif isinstance(value, list):
            for child in value:
                count(child)

    count(payload)
    if reserved:
        return payload
    shapes = [shape for shape, count in counts.items() if len(shape) >= 2 and count > 1
              and (len(encoded(list(shape))) - 24) * count > len(encoded(list(shape))) + 16]
    indices = {shape: index for index, shape in enumerate(shapes)}

    def replace(value, *, root=False):
        if isinstance(value, dict):
            shape = tuple(value)
            children = [replace(child) for child in value.values()]
            if not root and shape in indices:
                return {"$exact_object": [indices[shape], children]}
            return dict(zip(shape, children))
        return [replace(child) for child in value] if isinstance(value, list) else value

    factored = replace(payload, root=True)
    if shapes:
        factored["exact_object_shapes"] = [list(shape) for shape in shapes]
        factored["exact_object_encoding"] = (
            "A {$exact_object:[N,values]} means the EXACT object whose ordered keys are "
            "exact_object_shapes[N] and corresponding values are values. Expand recursively, "
            "including $ctx and $exact_record references, before reasoning. Nulls and all "
            "rules are retained. Return ordinary JSON objects, never encoded references."
        )
    return factored if len(encoded(factored)) < len(encoded(payload)) else payload
