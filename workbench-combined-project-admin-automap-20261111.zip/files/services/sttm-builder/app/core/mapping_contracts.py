"""Shared identity and attribute-expression contracts for learning and compilation."""

from typing import Any
import json

from sqlglot import exp, parse

from app.core.join_connector import join_connector


def has_mapping_definition(row: dict[str, Any]) -> bool:
    """Presence only: named rule categories and candidate guidance are not definitions."""
    def text(value: Any) -> bool:
        return isinstance(value, str) and bool(value.strip())

    sources = row.get("source_columns")
    named_rules = {"", "DIRECT", "IDENTITY", "VALUE", "SELECT...", "CUSTOM", "UPPER", "LOWER",
                   "TRIM", "CAST", "COALESCE", "DATE_FORMAT", "SUBSTRING", "REPLACE", "NULLIF", "CONCATENATE"}
    return bool(text(row.get("source_column"))
                or (isinstance(sources, list) and any(text(source) for source in sources))
                or (row.get("mapping_mode") == "constant" and row.get("constant_value") is not None)
                or any(text(row.get(key)) for key in ("attribute_name", "expression", "natural_language_rule"))
                or (text(row.get("rule")) and row["rule"].strip().upper() not in named_rules))


def mapping_transformation_text(row: dict[str, Any]) -> str:
    """Persist actual draft content; category labels are never transformation text."""
    labels = {'DIRECT', 'IDENTITY', 'VALUE', 'SELECT...', 'CUSTOM', 'UPPER', 'LOWER',
              'TRIM', 'CAST', 'COALESCE', 'DATE_FORMAT', 'SUBSTRING', 'REPLACE', 'NULLIF', 'CONCATENATE'}
    for field in ('expression', 'transformation_expr', 'natural_language_rule', 'rule', 'preprocessing_rule'):
        value = row.get(field)
        if isinstance(value, str) and value.strip() and value.strip().upper() not in labels:
            return value
    if row.get('mapping_mode') in {'constant', 'attribute'} and row.get('constant_value') is not None:
        return f"CONSTANT({json.dumps(row['constant_value'])})"
    return ''


def optional_identifier(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return None if text.casefold() in {"", "none", "null", "undefined", "nan"} else text


def column_identity(value: Any) -> tuple[str, ...]:
    """Snowflake identifier identity without collapsing quoted mixed-case names."""
    text = str(value or "")
    try:
        parsed = exp.to_column(text, dialect="snowflake")
        return tuple(part.name if part.args.get("quoted") else part.name.upper()
                     for part in parsed.parts)
    except Exception:
        return (text,)


def semantic_column_profiles(relation: str, model: Any) -> list[dict[str, Any]]:
    """Read explicit column contracts, including nested registry payloads."""
    profiles: dict[tuple[str, ...], dict[str, Any]] = {}
    conflicts: set[tuple[tuple[str, ...], str]] = set()

    def visit(value: Any, inherited_grain: Any = None) -> None:
        if not isinstance(value, dict):
            return
        grain = value.get("grain") or inherited_grain
        for key, children in value.items():
            if key in {"attributes", "columns", "output_columns", "attribute_semantic_model", "column_semantics"} and isinstance(children, list):
                for column in children:
                    if not isinstance(column, dict):
                        continue
                    name = column.get("name") or column.get("column_name")
                    if not name:
                        continue
                    physical_name = f"{relation}.{name}"
                    identity = column_identity(physical_name)
                    profile = profiles.setdefault(identity, {"physical_name": physical_name})
                    fields = {
                        "type": column.get("data_type") or column.get("type"),
                        "grain": column.get("grain") or grain,
                        "semantic_role": column.get("semantic_role"),
                        "business_meaning": column.get("business_meaning") or column.get("summary") or column.get("description"),
                        "synonyms": column.get("synonyms") or [],
                    }
                    for field, item in fields.items():
                        if item in (None, "", []):
                            continue
                        conflict_key = (identity, field)
                        if conflict_key in conflicts:
                            continue
                        if field in {"type", "grain", "semantic_role"} and profile.get(field) not in (None, item):
                            # Contradictory metadata is unknown, not last-writer-wins.
                            profile[field] = None
                            conflicts.add(conflict_key)
                        else:
                            profile[field] = item
            elif isinstance(children, dict):
                visit(children, grain)

    visit(model)
    return list(profiles.values())


def valid_attribute_expression(value: Any) -> bool:
    text = str(value or "").strip()
    if not text or text.upper() in {
        "DIRECT", "IDENTITY", "CUSTOM", "CAST", "CONCAT", "CONCATENATE",
        "COALESCE", "FORMATTING", "TRANSFORM", "NONE", "UNRESOLVED",
        "UPPER", "LOWER", "TRIM", "DATE_FORMAT", "SUBSTRING", "REPLACE", "NULLIF",
    }:
        return False
    try:
        expressions = parse(text, read="snowflake")
        if len(expressions) != 1 or expressions[0] is None:
            return False
        if any(isinstance(node, exp.Anonymous) and node.name.upper() == "CONCATENATE"
               for node in expressions[0].walk()):
            return False  # Rule label, not Snowflake's CONCAT function.
        return not any(isinstance(node, (exp.Query, exp.DDL, exp.DML, exp.Command))
                       for node in expressions[0].walk())
    except Exception:
        return False


def published_expression(row: dict[str, Any]) -> str:
    for key in ("expression", "source_expression", "transformation", "preprocessing_rule", "rule"):
        value = row.get(key)
        if valid_attribute_expression(value):
            return str(value).strip()
    return ""


def relationship_signature(value: Any) -> str:
    """Compare structured joins using the same representation at both boundaries."""
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except ValueError:
            return " ".join(value.upper().split())
    if not isinstance(value, dict):
        return ""

    def relation(item: Any) -> str:
        if isinstance(item, dict):
            return str(item.get("table") or "").upper()
        return str(item or "").rsplit(".", 1)[-1].strip('"').upper()

    left = relation(value.get("left_table") or value.get("left_relation_id"))
    right = relation(value.get("right_table") or value.get("right_relation_id"))
    conditions = []
    for index, condition in enumerate(value.get("conditions") or []):
        if isinstance(condition, dict):
            triple = (str(condition.get("left_column") or "").upper(),
                      str(condition.get("operator") or "=").upper(),
                      str(condition.get("right_column") or "").upper())
            if join_connector(condition.get("connector"), applies=index > 0) == "OR":
                triple = (*triple, "OR")
            conditions.append(triple)
    if left and right and conditions:
        has_or = any(len(item) == 4 for item in conditions)
        ordered = conditions if has_or else sorted(conditions)
        return json.dumps([left, right, str(value.get("join_type") or "INNER").upper(),
                           ordered, str(value.get("additional_predicate") or "").strip()], separators=(",", ":"))
    return " ".join(str(value.get("path") or value.get("condition") or value.get("relationship") or "").upper().split())