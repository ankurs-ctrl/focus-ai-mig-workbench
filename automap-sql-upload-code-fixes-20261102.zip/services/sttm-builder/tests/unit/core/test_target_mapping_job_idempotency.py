from app.core.config import Settings
from app.core.target_mapping_patterns import TargetMappingPatternService
from app.schema.fir_patterns import TargetMappingPatternV2


class _Row:
    def __init__(self, values: dict) -> None:
        self._values = values

    def as_dict(self) -> dict:
        return self._values


class _Query:
    def __init__(self, session: "_Session", statement: str) -> None:
        self._session = session
        self._statement = statement

    def collect(self):
        if "SELECT PATTERN_ID FROM" in self._statement:
            return [_Row({"PATTERN_ID": "canonical_1"})]
        if "SELECT LEARNING_JOB_ID, ASSET_ID" in self._statement:
            return [
                _Row(
                    {
                        "LEARNING_JOB_ID": self._session.job_ids[-1],
                        "ASSET_ID": "asset_1",
                        "PROJECT_ID": "project_1",
                        "STATUS": "running",
                        "STAGE": "semantic_enrichment",
                        "DISCOVERED_PATTERN_COUNT": 1,
                        "COMPLETED_PATTERN_COUNT": 0,
                        "FAILED_PATTERN_COUNT": 0,
                    }
                )
            ]
        return []


class _Session:
    def __init__(self) -> None:
        self.statements: list[str] = []
        self.job_ids: list[str] = []
        self.work_batches = []

    def sql(self, statement: str, params=None):
        self.statements.append(statement)
        if 'AS WORK_ITEM_TYPE' in statement and params:
            import json
            self.work_batches.extend(json.loads(params[0]))
        marker = "AS LEARNING_JOB_ID"
        if marker in statement and "MERGE INTO" in statement and "TBL_FIR_LEARNING_JOBS" in statement:
            prefix = statement.split(marker, 1)[0]
            self.job_ids.append(prefix.rsplit("'", 2)[1])
        return _Query(self, statement)


def _pattern() -> TargetMappingPatternV2:
    return TargetMappingPatternV2(
        pattern_id="pattern_1",
        target_contract={
            "target_table": "CURATED.CRM.CUSTOMER",
            "target_column": "CUSTOMER_ID",
        },
        source_compatibility_signature="source-signature",
        mapping_recipe={"mode": "direct"},
        content_hash="pattern-content-hash",
    )


def test_identical_asset_and_extraction_reuses_learning_job() -> None:
    session = _Session()
    service = TargetMappingPatternService(session, Settings())

    first = service.create_learning_job(
        asset_id="asset_1",
        project_id="project_1",
        patterns=[_pattern()],
    )
    second = service.create_learning_job(
        asset_id="asset_1",
        project_id="project_1",
        patterns=[_pattern()],
    )

    assert first.learning_job_id == second.learning_job_id
    assert first.learning_job_id.startswith("firjob_")
    assert len(set(session.job_ids)) == 1
    assert all(
        "MERGE INTO" in statement
        for statement in session.statements
        if "TBL_FIR_LEARNING_JOBS" in statement
        and "SELECT LEARNING_JOB_ID, ASSET_ID" not in statement
        and not statement.startswith("UPDATE")
    )
    assert "'initializing', 'target_row_extraction'" in session.statements[1]
    activation = next(index for index, sql in enumerate(session.statements) if sql.startswith("UPDATE"))
    assert activation == 3  # Canonical read, job, one bound work-item batch, activation.
    assert "STATUS = 'initializing'" in session.statements[activation]
    assert any(item['WORK_ITEM_TYPE'] == 'agent_semantic_enrichment' for item in session.work_batches)


def test_queue_uses_persisted_id_instead_of_transient_extracted_id():
    session = _Session()
    service = TargetMappingPatternService(session, Settings())
    service.create_learning_job(asset_id="asset", project_id="project", patterns=[_pattern()])
    payloads = [item['PAYLOAD'] for item in session.work_batches if item['WORK_ITEM_TYPE']=='semantic_enrichment']
    assert payloads == [{'pattern_id': 'canonical_1', 'content_hash': 'pattern-content-hash'}]
    assert sum('AS WORK_ITEM_TYPE' in sql for sql in session.statements) == 1


def test_missing_canonical_pattern_does_not_enqueue_orphan_work():
    from unittest.mock import Mock
    import pytest
    session = Mock()
    session.sql.return_value.collect.return_value = []
    service = TargetMappingPatternService(session, Settings())
    with pytest.raises(ValueError, match="persisted canonical"):
        service.create_learning_job(asset_id="asset", project_id="project", patterns=[_pattern()])
    assert session.sql.call_count == 1
    assert session.sql.call_args.args[0].startswith("SELECT")


def test_retry_classifier_only_retries_transient_failures() -> None:
    assert TargetMappingPatternService._is_transient_failure(
        TimeoutError("Cortex request timeout")
    )
    assert TargetMappingPatternService._is_transient_failure(
        RuntimeError("Too many requests")
    )
    assert not TargetMappingPatternService._is_transient_failure(
        ValueError("Target mapping pattern is invalid")
    )


def test_processing_generations_separate_failed_reuploads_but_resume_same_run():
    session=_Session(); service=TargetMappingPatternService(session,Settings())
    def job(generation):
        return service.create_learning_job(asset_id='asset',project_id='project',patterns=[_pattern()],
            processing_generation=generation).learning_job_id
    assert job('old-failed-request')!=job('new-explicit-request')
    assert job('new-explicit-request')==job('new-explicit-request')
