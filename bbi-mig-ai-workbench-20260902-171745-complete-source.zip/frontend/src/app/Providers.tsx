"use client";

import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import dynamic from "next/dynamic";
import { Provider as ReduxProvider } from "react-redux";
import { store } from "@/store/store";
import { GlobalErrorProvider } from "@/components/error/global-error-provider";
import { AppSidebarProvider } from "@/features/layout/app-sidebar-context";
import AppThemeProvider from "@/theme/ThemeProvider";
import { type AppThemeMode } from "@/theme/theme";
import AppBootstrapFallback from "./app-bootstrap-fallback";
import { ChunkErrorRecovery } from "./chunk-error-recovery";

const WorkspaceShell = dynamic(() => import("./workspace-shell"), {
  ssr: false,
  loading: () => <AppBootstrapFallback />,
});

type ThemeModeContextValue = {
  mode: AppThemeMode;
  toggleMode: () => void;
  setMode: (mode: AppThemeMode) => void;
};

const ThemeModeContext = createContext<ThemeModeContextValue | null>(null);

function readSavedThemeMode(): AppThemeMode | null {
  if (typeof window === "undefined") {
    return null;
  }

  const savedMode = window.localStorage.getItem("theme-mode");
  return savedMode === "dark" ? "dark" : savedMode === "light" ? "light" : null;
}

export function useThemeMode() {
  const context = useContext(ThemeModeContext);

  if (!context) {
    throw new Error("useThemeMode must be used inside Providers");
  }

  return context;
}

export default function Providers({ children }: { children: ReactNode }) {
  const [mode, setMode] = useState<AppThemeMode>("light");

  useEffect(() => {
    const savedMode = readSavedThemeMode();
    if (savedMode) {
      setMode(savedMode);
    }
  }, []);

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", mode);
    window.localStorage.setItem("theme-mode", mode);
  }, [mode]);

  const value = useMemo(
    () => ({
      mode,
      setMode,
      toggleMode: () => {
        setMode((prev) => (prev === "light" ? "dark" : "light"));
      },
    }),
    [mode],
  );

  return (
    <>
      <ChunkErrorRecovery />
      <ThemeModeContext.Provider value={value}>
        <ReduxProvider store={store}>
          <AppThemeProvider mode={mode}>
            <GlobalErrorProvider>
              <AppSidebarProvider>
                <WorkspaceShell>{children}</WorkspaceShell>
              </AppSidebarProvider>
            </GlobalErrorProvider>
          </AppThemeProvider>
        </ReduxProvider>
      </ThemeModeContext.Provider>
    </>
  );
}
