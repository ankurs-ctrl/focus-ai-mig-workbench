"""Frozen packets cross the worker hop by a scoped durable reference."""
from copy import deepcopy
import json
from types import SimpleNamespace

import pytest

from app.core.automap_batch import freeze_fast_handoff, canonical_model_wire_request
from app.core.automap_frozen_packet import worker_reference, hydrate_worker_reference
from tests.test_automap_fast_job import proxy
from tests.unit.core.test_automap_fast_batch import prepared_request


def fixture():
    client=proxy(AGENT_OUTBOUND_MESSAGE_MAX_CHARS=180000,AGENT_OUTBOUND_MESSAGE_MAX_BYTES=180000)
    req=prepared_request()
    req.meta.update(auto_map_resolution_mode='reeval_all',automap_generation_policy='draft-v3',automap_rules_policy='rules-v2')
    root=client._freeze_resolution(req)
    plan=client._trusted_resolution_plan(root)
    pending=client._pending_resolution_request(root)
    handoff=freeze_fast_handoff(pending)
    plan.update(handoff=handoff,handoff_hash=client._resolution_digest(handoff))
    client._build_batches(root)
    pending=client._pending_resolution_request(root)
    packet=plan['preflight']['batches'][0]['frozen_packet']
    pending.meta.update(auto_mapping_batch_index=0,_automap_frozen_packet=packet,
        _automap_fast_handoff={**pending.meta['_automap_fast_handoff'],'packet_digest':packet['receipt_digest']})
    state={'request_envelope':root.model_dump(mode='json')}
    queries=[]
    def sql(query,params):
        queries.append((query,params))
        return SimpleNamespace(collect=lambda:[{'JOB_STATE':json.dumps(state)}])
    service=SimpleNamespace(_settings=client._settings,_session=SimpleNamespace(sql=sql))
    return pending, state, service, queries


def test_durable_reference_rejoins_exact_targets_and_request_without_inline_catalog():
    req,_,service,queries=fixture()
    small=worker_reference(req)
    assert len(json.dumps(small.to_worker_payload()).encode())<10000
    assert not small.context.semantic_context and small.context.execution_context is None
    restored=hydrate_worker_reference(service,small)
    assert restored.model_dump(mode='json')==req.model_dump(mode='json')
    assert 'OWNER_ID = CURRENT_USER()' in queries[0][0]
    assert 'CURRENT_ROLE()' in queries[0][0] and 'EXPIRES_AT > CURRENT_TIMESTAMP()' in queries[0][0]


@pytest.mark.parametrize('mutation',['digest','target','project','index','absent'])
def test_reference_cannot_choose_another_packet_or_target_scope(mutation):
    req,_,service,_=fixture()
    small=worker_reference(req)
    if mutation=='digest':small.meta['_automap_packet_ref']['receipt_digest']='bad'
    elif mutation=='target':small.data.attributes[0].target_attribute='OTHER'
    elif mutation=='project':small.context.project_id='OTHER'
    elif mutation=='index':small.meta['_automap_packet_ref']['batch_index']=99
    else:service._session=SimpleNamespace(sql=lambda *a,**kw:SimpleNamespace(collect=lambda:[]))
    with pytest.raises(ValueError):hydrate_worker_reference(service,small)
