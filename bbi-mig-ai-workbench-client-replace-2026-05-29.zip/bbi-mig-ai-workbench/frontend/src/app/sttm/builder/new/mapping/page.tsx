"use client";

import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { useRouter } from 'next/navigation';
import {
  Alert,
  Box,
  Button,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Typography,
} from '@mui/material';
import ChecklistRtlRoundedIcon from '@mui/icons-material/ChecklistRtlRounded';
import TerminalRoundedIcon from '@mui/icons-material/TerminalRounded';
import AccountTreeOutlinedIcon from '@mui/icons-material/AccountTreeOutlined';
import TableRowsRoundedIcon from '@mui/icons-material/TableRowsRounded';
import { useSidebarSlot } from '@/features/sttm/layout/sidebar-slot-context';
import SourceTargetAttributeList from '@/features/sttm/mapping/source-target-attribute-list';
import SourceTargetAttributeMapping from '@/features/sttm/mapping/source-target-attribute-mapping';
import PreProcessModal from '@/features/sttm/mapping/pre-process-modal';
import LineageTab from '@/features/sttm/lineage/lineage-tab';
import { useSttmBuilderContext } from '@/features/sttm/context/sttm-builder-context';
import { useAppDispatch } from '@/store/hooks';
import { fetchAttributes } from '@/features/sttm/store/sttm-builder-slice';
import { dbService } from '@/services/dbService';
import {
  buildMappingInsertSql,
  buildMappingSelectSql,
  buildSourceQueryPreviewSql,
  generateMappingDescription,
  parseSourceColumns,
} from '@/features/sttm/mapping/mapping-utils';
import { MappingSqlPreview } from '@/components/sql';
import { MappingProgressIndicator } from '@/features/sttm/shared/mapping-progress-indicator';
import { BuilderWorkspaceTabBar } from '@/features/sttm/shared/builder-workspace-tab-bar';
import type {
  MappingSqlPreviewResponse,
  MappingSqlReviewResponse,
  TableRef,
} from '@/types/api-contract';

type MappingTab = 'mapping' | 'sql-preview' | 'data-preview' | 'data-lineage';

type PreviewDisplayRow = {
  mappingId: string;
  targetColumn: string;
  targetType: string;
  sourceColumn: string;
  sourceValue: string;
  transformedValue: string;
  description: string;
  expressionLabel: string | null;
  rowCount: number;
  rowIndex: number;
  displayIndex: number;
};

type SqlDiffRow = {
  original: string;
  optimized: string;
  originalKind: 'context' | 'removed' | 'empty';
  optimizedKind: 'context' | 'added' | 'empty';
};

function countFilterConditions(
  groups: Array<{ type?: string; children?: unknown[] }>,
): number {
  return groups.reduce((count, group) => {
    if (group.type === 'condition') {
      return count + 1;
    }
    const children = Array.isArray(group.children)
      ? (group.children as Array<{ type?: string; children?: unknown[] }>)
      : [];
    return count + countFilterConditions(children);
  }, 0);
}

function qualifiedNameToTableRef(qualifiedName: string): TableRef | null {
  const [database, schema, table] = qualifiedName.split('.', 3);
  if (!database || !schema || !table) {
    return null;
  }
  return { database, schema, table };
}

function stringifyPreviewValue(value: unknown): string {
  if (value === null || value === undefined || value === '') {
    return '—';
  }
  if (typeof value === 'object') {
    try {
      return JSON.stringify(value);
    } catch {
      return String(value);
    }
  }
  return String(value);
}

function buildSqlDiffRows(originalSql: string, optimizedSql: string): SqlDiffRow[] {
  const originalLines = originalSql.split('\n');
  const optimizedLines = optimizedSql.split('\n');
  const dp: number[][] = Array.from({ length: originalLines.length + 1 }, () =>
    Array.from({ length: optimizedLines.length + 1 }, () => 0),
  );

  for (let i = originalLines.length - 1; i >= 0; i -= 1) {
    for (let j = optimizedLines.length - 1; j >= 0; j -= 1) {
      dp[i][j] =
        originalLines[i] === optimizedLines[j]
          ? dp[i + 1][j + 1] + 1
          : Math.max(dp[i + 1][j], dp[i][j + 1]);
    }
  }

  const rows: SqlDiffRow[] = [];
  let i = 0;
  let j = 0;

  while (i < originalLines.length && j < optimizedLines.length) {
    if (originalLines[i] === optimizedLines[j]) {
      rows.push({
        original: originalLines[i],
        optimized: optimizedLines[j],
        originalKind: 'context',
        optimizedKind: 'context',
      });
      i += 1;
      j += 1;
      continue;
    }

    if (dp[i + 1][j] >= dp[i][j + 1]) {
      rows.push({
        original: originalLines[i],
        optimized: '',
        originalKind: 'removed',
        optimizedKind: 'empty',
      });
      i += 1;
      continue;
    }

    rows.push({
      original: '',
      optimized: optimizedLines[j],
      originalKind: 'empty',
      optimizedKind: 'added',
    });
    j += 1;
  }

  while (i < originalLines.length) {
    rows.push({
      original: originalLines[i],
      optimized: '',
      originalKind: 'removed',
      optimizedKind: 'empty',
    });
    i += 1;
  }

  while (j < optimizedLines.length) {
    rows.push({
      original: '',
      optimized: optimizedLines[j],
      originalKind: 'empty',
      optimizedKind: 'added',
    });
    j += 1;
  }

  return rows;
}

function getReviewAgentLabel(reviewAgent: string | null | undefined): string {
  return reviewAgent === 'CORTEX_ANALYST' ? 'Cortex Analyst' : 'Snowflake validation repair';
}

export default function MappingPage() {
  const router = useRouter();
  const { setContent } = useSidebarSlot();
  const dispatch = useAppDispatch();
  const [activeTab, setActiveTab] = useState<MappingTab>('mapping');
  const [previewLoading, setPreviewLoading] = useState(false);
  const [previewError, setPreviewError] = useState<string | null>(null);
  const [reviewLoading, setReviewLoading] = useState(false);
  const [reviewError, setReviewError] = useState<string | null>(null);
  const [reviewStage, setReviewStage] = useState<string | null>(null);
  const [reviewResult, setReviewResult] = useState<MappingSqlReviewResponse | null>(null);
  const [reviewDialogOpen, setReviewDialogOpen] = useState(false);
  const [approvedVariant, setApprovedVariant] = useState<'original' | 'optimized'>('original');
  const [reviewSelectionVariant, setReviewSelectionVariant] = useState<'original' | 'optimized' | null>(null);
  const [approvedPreviewSql, setApprovedPreviewSql] = useState<string | null>(null);
  const [approvedGeneratedSql, setApprovedGeneratedSql] = useState<string | null>(null);
  const [validatedPreviewData, setValidatedPreviewData] = useState<MappingSqlPreviewResponse | null>(null);
  const {
    mappings,
    targetAttributeGroup,
    initializeMappings,
    sources,
    targets,
    loadState,
    relationships,
    derivedSources,
    drivingTableId,
    sourceAttributeGroups,
    sourceFilterSql,
    sourceFilterGroups,
    sourceQuerySql,
    sourceGroupBySql,
    sourceOrderBySql,
    semanticBundleId,
    semanticBundleLabel,
    semanticViewName,
  } = useSttmBuilderContext();

  const hasSelectedSources = useMemo(
    () => sources.some((table) => table.isSelected),
    [sources],
  );
  const hasSelectedDerivedSources = useMemo(
    () => derivedSources.some((source) => source.isSelected),
    [derivedSources],
  );
  const hasSelectedInputs = hasSelectedSources || hasSelectedDerivedSources;

  const hasSelectedTarget = useMemo(
    () => targets.some((table) => table.isSelected),
    [targets],
  );

  const hasTargetColumns = useMemo(
    () => (targetAttributeGroup?.columns?.filter((col) => col.name).length ?? 0) > 0,
    [targetAttributeGroup],
  );

  const totalCount = mappings.length;
  const mappedCount = mappings.filter((m) => m.status === 'MAPPED').length;
  const selectedInputCount = useMemo(
    () =>
      sources.filter((table) => table.isSelected).length +
      derivedSources.filter((source) => source.isSelected).length,
    [derivedSources, sources],
  );
  const filterCount = useMemo(
    () => countFilterConditions(sourceFilterGroups as Array<{ type?: string; children?: unknown[] }>),
    [sourceFilterGroups],
  );

  useEffect(() => {
    setContent(<SourceTargetAttributeList />);
    return () => setContent(null);
  }, [setContent]);

  useEffect(() => {
    if (!hasSelectedInputs || !hasSelectedTarget) {
      router.replace('/sttm/builder/new');
      return;
    }

    if (loadState.attributes === 'loading' || loadState.attributes === 'idle') {
      return;
    }

    if (!hasTargetColumns) {
      router.replace('/sttm/builder/new');
    }
  }, [
    hasSelectedInputs,
    hasSelectedTarget,
    hasTargetColumns,
    loadState.attributes,
    router,
  ]);

  const targetTableKey = targetAttributeGroup?.qualifiedName ?? '';
  const targetColumnsSignature = useMemo(
    () =>
      (targetAttributeGroup?.columns ?? [])
        .filter((col) => col.name)
        .map((col) => `${col.name}:${col.type ?? ''}`)
        .join('|'),
    [targetAttributeGroup],
  );

  useEffect(() => {
    if (!targetAttributeGroup || !targetColumnsSignature) {
      return;
    }

    const targetColumns = targetAttributeGroup.columns
      .filter((col) => col.name)
      .map((col) => col.name as string);
    const targetColumnSet = new Set(targetColumns);

    const matchesCurrentTarget =
      mappings.length === targetColumns.length &&
      mappings.every((m) => targetColumnSet.has(m.targetColumn));

    if (matchesCurrentTarget) {
      return;
    }

    const initialMappings = targetAttributeGroup.columns
      .filter((col) => col.name)
      .map((col, idx) => ({
        id: `${targetTableKey}-${idx}`,
        targetColumn: col.name as string,
        targetType: col.type || 'VARCHAR',
        sourceColumn: null,
        sourceType: null,
        expression: null,
        rule: 'Select...' as const,
        status: 'UNMAPPED' as const,
        nlRule: null,
        loadOrder: null,
        description: null,
        confidenceScore: null,
        confidenceReason: null,
        candidateSourceColumns: [],
        unmatchedReason: null,
        aiSuggestedRule: null,
        aiSuggestedRuleType: null,
      }));
    initializeMappings(initialMappings);
  }, [
    targetAttributeGroup,
    targetTableKey,
    targetColumnsSignature,
    mappings,
    initializeMappings,
  ]);

  const selectedSourceKey = useMemo(
    () =>
      sources
        .filter((table) => table.isSelected)
        .map((table) => table.qualifiedName)
        .sort()
        .join('|'),
    [sources],
  );

  const selectedTargetKey =
    targets.find((table) => table.isSelected)?.qualifiedName ?? '';

  useEffect(() => {
    if (selectedSourceKey) {
      dispatch(
        fetchAttributes({
          qualifiedNames: selectedSourceKey.split('|'),
          side: 'source',
        }),
      );
    }
    if (selectedTargetKey) {
      dispatch(
        fetchAttributes({
          qualifiedNames: [selectedTargetKey],
          side: 'target',
        }),
      );
    }
  }, [dispatch, selectedSourceKey, selectedTargetKey]);

  const selectedTargetQualifiedName =
    targets.find((table) => table.isSelected)?.qualifiedName ??
    targetAttributeGroup?.qualifiedName ??
    null;

  const selectedSourceTables = useMemo(
    () =>
      sources
        .filter((table) => table.isSelected)
        .map((table) => qualifiedNameToTableRef(table.qualifiedName))
        .filter((table): table is TableRef => Boolean(table)),
    [sources],
  );

  const selectedTargetTableRef = useMemo(
    () =>
      selectedTargetQualifiedName
        ? qualifiedNameToTableRef(selectedTargetQualifiedName)
        : null,
    [selectedTargetQualifiedName],
  );

  const drivingTableRef = useMemo(
    () => (drivingTableId ? qualifiedNameToTableRef(drivingTableId) : null),
    [drivingTableId],
  );

  const generatedSql = useMemo(
    () =>
      buildMappingInsertSql({
        mappings,
        targetQualifiedName: selectedTargetQualifiedName,
        sourceQuerySql,
        sourceFilterSql,
        sourceGroupBySql,
        sourceOrderBySql,
      }),
    [
      mappings,
      selectedTargetQualifiedName,
      sourceQuerySql,
      sourceFilterSql,
      sourceGroupBySql,
      sourceOrderBySql,
    ],
  );

  const previewSql = useMemo(
    () =>
      buildMappingSelectSql({
        mappings,
        sourceQuerySql,
        sourceFilterSql,
        sourceGroupBySql,
        sourceOrderBySql,
      }),
    [mappings, sourceFilterSql, sourceGroupBySql, sourceOrderBySql, sourceQuerySql],
  );

  const sourceQueryPreviewSql = useMemo(
    () =>
      buildSourceQueryPreviewSql({
        sourceQuerySql,
        sourceFilterSql,
        sourceGroupBySql,
        sourceOrderBySql,
      }),
    [sourceFilterSql, sourceGroupBySql, sourceOrderBySql, sourceQuerySql],
  );

  const selectedColumnsByTable = useMemo(
    () =>
      Object.fromEntries(
        sourceAttributeGroups
          .map((group) => [
            group.qualifiedName,
            group.columns.map((column) => String(column.name)).filter(Boolean),
          ])
          .filter(([, columns]) => columns.length > 0),
      ),
    [sourceAttributeGroups],
  );

  const relationshipPayload = useMemo(
    () =>
      relationships
        .filter((join) => join.leftTableId && join.rightTableId && join.conditions?.length)
        .map((join) => {
          const leftTable = qualifiedNameToTableRef(String(join.leftTableId));
          const rightTable = qualifiedNameToTableRef(String(join.rightTableId));
          return leftTable && rightTable
            ? {
                left_table: leftTable,
                right_table: rightTable,
                join_type: join.joinType ?? 'INNER',
                constraint_name: join.constraintName ?? null,
                source: join.source ?? 'USER_DEFINED',
                locked: join.locked ?? false,
                conditions: (join.conditions ?? [])
                  .filter((condition) => condition.leftColumn && condition.rightColumn)
                  .map((condition) => ({
                    left_column: String(condition.leftColumn),
                    right_column: String(condition.rightColumn),
                    operator: condition.operator ?? '=',
                  })),
              }
            : null;
        })
        .filter((join): join is NonNullable<typeof join> => Boolean(join)),
    [relationships],
  );

  const mappedMappings = useMemo(
    () =>
      mappings
        .filter((mapping) => mapping.status === 'MAPPED')
        .map((mapping) => ({
          target_column: mapping.targetColumn,
          target_type: mapping.targetType,
          source_column: mapping.sourceColumn,
          source_columns:
            mapping.sourceColumns && mapping.sourceColumns.length
              ? mapping.sourceColumns
              : parseSourceColumns(mapping.sourceColumn),
          expression: mapping.expression,
          rule: mapping.rule,
          status: mapping.status,
          nl_rule: mapping.nlRule,
          description: mapping.description,
        })),
    [mappings],
  );

  const mappingSqlRequestPayload = useMemo(
    () => ({
      source_tables: selectedSourceTables,
      target_table: selectedTargetTableRef,
      driving_table: drivingTableRef,
      selected_derived_sources: derivedSources
        .filter((source) => source.isSelected)
        .map((source) => source.id),
      relationships: relationshipPayload,
      selected_columns_by_table: selectedColumnsByTable,
      semantic_bundle_id: semanticBundleId,
      semantic_bundle_label: semanticBundleLabel,
      semantic_view_name: semanticViewName,
      source_query_sql: sourceQueryPreviewSql,
      preview_sql:
        reviewSelectionVariant === 'optimized' && approvedPreviewSql
          ? approvedPreviewSql
          : previewSql,
      generated_sql:
        reviewSelectionVariant === 'optimized' && approvedGeneratedSql
          ? approvedGeneratedSql
          : generatedSql,
      mappings: mappedMappings,
      preview_limit: 5,
    }),
    [
      approvedGeneratedSql,
      approvedPreviewSql,
      reviewSelectionVariant,
      derivedSources,
      drivingTableRef,
      generatedSql,
      mappedMappings,
      previewSql,
      relationshipPayload,
      selectedColumnsByTable,
      selectedSourceTables,
      selectedTargetTableRef,
      semanticBundleId,
      semanticBundleLabel,
      semanticViewName,
      sourceQueryPreviewSql,
    ],
  );

  useEffect(() => {
    setApprovedVariant('original');
    setReviewSelectionVariant(null);
    setApprovedPreviewSql(null);
    setApprovedGeneratedSql(null);
    setValidatedPreviewData(null);
    setPreviewError(null);
    setReviewResult(null);
  }, [generatedSql, previewSql]);

  useEffect(() => {
    const handleRunValidation = () => setActiveTab('sql-preview');
    window.addEventListener('sttm:run-validation', handleRunValidation);
    return () => window.removeEventListener('sttm:run-validation', handleRunValidation);
  }, []);

  const runValidatedPreview = async (
    variant: 'original' | 'optimized',
    review: MappingSqlReviewResponse,
  ) => {
    setPreviewLoading(true);
    setPreviewError(null);
    setReviewStage(
      variant === 'optimized'
        ? 'Running the Cortex Analyst-approved SQL preview in Snowflake...'
        : 'Running the approved SQL preview in Snowflake...'
    );
    const approvedPreview = variant === 'optimized'
      ? review.optimized_preview_sql ?? review.original_preview_sql
      : review.original_preview_sql;
    const approvedGenerated = variant === 'optimized'
      ? review.optimized_generated_sql ?? review.original_generated_sql
      : review.original_generated_sql;

    try {
      const result = await dbService.previewMappingSql({
        ...mappingSqlRequestPayload,
        chosen_variant: variant,
        approved_preview_sql: approvedPreview,
        approved_generated_sql: approvedGenerated,
      });
      setApprovedVariant(variant);
      setApprovedPreviewSql(approvedPreview);
      setApprovedGeneratedSql(approvedGenerated);
      setValidatedPreviewData(result);
      setActiveTab('data-preview');
      setReviewStage(
        `${result.variant_used === 'optimized' ? 'Optimized' : 'Original'} SQL preview finished. ${result.preview_rows.length} sample row(s) were returned.`
      );
    } catch (error) {
      setPreviewError(
        error instanceof Error ? error.message : 'Unable to run validated SQL preview.',
      );
      setValidatedPreviewData(null);
      setActiveTab('data-preview');
      setReviewStage('Preview execution failed. Review the error details below.');
    } finally {
      setPreviewLoading(false);
    }
  };

  const handleRunPreview = async () => {
    if (!reviewResult) {
      return;
    }
    const variant = reviewResult.requires_approval
      ? reviewSelectionVariant
      : (reviewSelectionVariant ?? 'original');
    if (!variant) {
      setReviewDialogOpen(true);
      return;
    }
    await runValidatedPreview(variant, reviewResult);
  };

  const handleValidateSql = async () => {
    if (!mappedMappings.length) {
      setReviewError('Map at least one target attribute before validating SQL.');
      setActiveTab('sql-preview');
      return;
    }
    setReviewLoading(true);
    setReviewError(null);
    setPreviewError(null);
    setValidatedPreviewData(null);
    setReviewResult(null);
    setApprovedVariant('original');
    setReviewStage('Checking the generated SQL in Snowflake for syntax and execution readiness...');
    try {
      const result = await dbService.reviewMappingSql(mappingSqlRequestPayload);
      setReviewResult(result);
      setReviewSelectionVariant(null);
      setApprovedPreviewSql(
        result.requires_approval
          ? null
          : (result.optimized_preview_sql ?? result.original_preview_sql),
      );
      setApprovedGeneratedSql(
        result.requires_approval
          ? null
          : (result.optimized_generated_sql ?? result.original_generated_sql),
      );
      setActiveTab('sql-preview');
      if (result.review_agent === 'CORTEX_ANALYST') {
        setReviewStage(
          result.requires_approval
            ? 'Cortex Analyst found an optimization suggestion. Review the proposed SQL before running the preview.'
            : 'Cortex Analyst reviewed the SQL and found no required optimization changes. You can run the preview now.'
        );
      } else {
        setReviewStage(
          result.requires_approval
            ? 'Snowflake validation found an optimized SQL option. Review it before running the preview.'
            : 'Snowflake validation completed successfully. No SQL optimization changes were required.'
        );
      }
      if (result.requires_approval && result.optimized_preview_sql) {
        setReviewDialogOpen(true);
      }
    } catch (error) {
      setReviewError(
        error instanceof Error ? error.message : 'Unable to validate the generated SQL.',
      );
      setReviewStage('SQL review failed. Fix the issue and try validation again.');
    } finally {
      setReviewLoading(false);
    }
  };

  const handleApproveReviewedSql = async (variant: 'original' | 'optimized') => {
    if (!reviewResult) {
      setReviewDialogOpen(false);
      return;
    }
    setReviewDialogOpen(false);
    setApprovedVariant(variant);
    setReviewSelectionVariant(variant);
    if (variant === 'optimized') {
      setApprovedPreviewSql(reviewResult.optimized_preview_sql ?? reviewResult.original_preview_sql);
      setApprovedGeneratedSql(reviewResult.optimized_generated_sql ?? reviewResult.original_generated_sql);
      setReviewStage('Optimized SQL applied. Run the preview when you are ready.');
    } else {
      setApprovedPreviewSql(reviewResult.original_preview_sql);
      setApprovedGeneratedSql(reviewResult.original_generated_sql);
      setReviewStage('Original SQL selected. Run the preview when you are ready.');
    }
  };

  const previewDisplayRows = useMemo<PreviewDisplayRow[]>(() => {
    if (!validatedPreviewData || !validatedPreviewData.preview_rows?.length) {
      return [];
    }
    const sourceRow = validatedPreviewData.source_sample_rows?.[0]?.values ?? {};
    const transformedRow = validatedPreviewData.preview_rows?.[0]?.values ?? {};
    let displayIndex = 1;

    return mappings.flatMap((mapping) => {
      if (mapping.status !== 'MAPPED') {
        return [];
      }
      const sourceColumns =
        mapping.sourceColumns && mapping.sourceColumns.length
          ? mapping.sourceColumns
          : parseSourceColumns(mapping.sourceColumn);
      const effectiveSources = sourceColumns.length ? sourceColumns : ['—'];
      const description =
        mapping.description?.trim() ||
        generateMappingDescription({
          rule: mapping.rule,
          sourceColumns: sourceColumns.filter(Boolean),
          targetColumn: mapping.targetColumn,
          expression: mapping.expression,
        }) ||
        '—';
      const transformedValue = stringifyPreviewValue(transformedRow[mapping.targetColumn]);
      const expressionLabel =
        mapping.expression?.trim() ||
        (mapping.rule && mapping.rule !== 'Direct' && mapping.rule !== 'Select...' ? mapping.rule : null);

      return effectiveSources.map((sourceColumn, index) => {
        const alias = validatedPreviewData.source_sample_aliases?.[sourceColumn];
        const sourceValue =
          sourceColumn === '—'
            ? '—'
            : stringifyPreviewValue(alias ? sourceRow[alias] : undefined);
        const row: PreviewDisplayRow = {
          mappingId: mapping.id,
          targetColumn: mapping.targetColumn,
          targetType: mapping.targetType,
          sourceColumn,
          sourceValue,
          transformedValue,
          description,
          expressionLabel,
          rowCount: effectiveSources.length,
          rowIndex: index,
          displayIndex,
        };
        if (index === effectiveSources.length - 1) {
          displayIndex += 1;
        }
        return row;
      });
    });
  }, [mappings, validatedPreviewData]);

  const tabs: Array<{ key: MappingTab; label: string; icon: ReactNode; badge?: number }> = [
    { key: 'mapping', label: 'Mapping', icon: <ChecklistRtlRoundedIcon sx={{ fontSize: 17 }} /> },
    {
      key: 'sql-preview',
      label: 'SQL Preview',
      icon: <TerminalRoundedIcon sx={{ fontSize: 17 }} />,
      badge: mappedCount > 0 ? mappedCount : undefined,
    },
    { key: 'data-preview', label: 'Data Preview', icon: <TableRowsRoundedIcon sx={{ fontSize: 17 }} /> },
    { key: 'data-lineage', label: 'Data Lineage', icon: <AccountTreeOutlinedIcon sx={{ fontSize: 17 }} /> },
  ];

  const progressTrailing = (
    <MappingProgressIndicator mappedCount={mappedCount} totalCount={totalCount} />
  );

  const compactReviewSummary = useMemo(() => {
    if (!reviewResult?.review_summary) return null;
    const firstSentence = reviewResult.review_summary.split(/(?<=[.!?])\s+/)[0]?.trim();
    return firstSentence || reviewResult.review_summary;
  }, [reviewResult]);

  const reviewDiffRows = useMemo(
    () =>
      reviewResult?.optimized_preview_sql
        ? buildSqlDiffRows(reviewResult.original_preview_sql, reviewResult.optimized_preview_sql)
        : [],
    [reviewResult],
  );

  const reviewDiffSummary = useMemo(() => {
    const removals = reviewDiffRows.filter((row) => row.originalKind === 'removed').length;
    const additions = reviewDiffRows.filter((row) => row.optimizedKind === 'added').length;
    return { removals, additions };
  }, [reviewDiffRows]);

  const sqlReviewStatusPanel = useMemo(() => {
    if (!reviewError && !reviewStage && !reviewResult && !previewError) {
      return null;
    }

    const tone = reviewError
      ? 'error'
      : previewError
        ? 'warning'
        : reviewResult?.requires_approval
          ? 'warning'
          : reviewLoading || previewLoading
            ? 'info'
            : 'success';

    return (
      <Stack spacing={1.25}>
        {reviewStage ? (
          <Alert
            severity={tone}
            sx={{ borderRadius: 2, alignItems: 'center', py: 0.25 }}
            action={
              reviewLoading || previewLoading ? (
                <CircularProgress size={18} color="inherit" />
              ) : null
            }
          >
            <Typography sx={{ fontSize: '0.82rem', fontWeight: 700 }}>
              {reviewStage}
            </Typography>
          </Alert>
        ) : null}

        {reviewResult && !reviewLoading ? (
          <Alert
            severity={reviewResult.requires_approval ? 'warning' : 'success'}
            sx={{ borderRadius: 2, py: 0.25 }}
            action={
              reviewResult.requires_approval ? (
                <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
                  <Button
                    color="inherit"
                    size="small"
                    sx={{ textTransform: 'none', fontWeight: 700 }}
                    onClick={() => setReviewDialogOpen(true)}
                  >
                    View diff
                  </Button>
                  <Button
                    color="inherit"
                    size="small"
                    disabled={reviewSelectionVariant === 'optimized'}
                    sx={{ textTransform: 'none', fontWeight: 700 }}
                    onClick={() => {
                      void handleApproveReviewedSql('optimized');
                    }}
                  >
                    {reviewSelectionVariant === 'optimized' ? 'Applied' : 'Apply'}
                  </Button>
                </Box>
              ) : (
                <Typography sx={{ fontSize: '0.76rem', fontWeight: 700, opacity: 0.9 }}>
                  No changes required
                </Typography>
              )
            }
          >
            <Typography sx={{ fontSize: '0.82rem', fontWeight: 700, mb: 0.4 }}>
              Reviewed by {getReviewAgentLabel(reviewResult.review_agent)}
            </Typography>
            <Typography sx={{ fontSize: '0.8rem', lineHeight: 1.5 }}>
              {compactReviewSummary}
            </Typography>
            {reviewResult.warnings?.length ? (
              <Typography sx={{ fontSize: '0.76rem', lineHeight: 1.45, mt: 0.5 }}>
                {reviewResult.warnings.join(' ')}
              </Typography>
            ) : null}
          </Alert>
        ) : null}

        {reviewError ? (
          <Alert severity="error" sx={{ borderRadius: 2 }}>
            {reviewError}
          </Alert>
        ) : null}
      </Stack>
    );
  }, [
    compactReviewSummary,
    previewError,
    previewLoading,
    reviewError,
    reviewLoading,
    reviewResult,
    reviewStage,
  ]);

  return (
    <div className="flex h-full min-h-0 w-full min-w-0 flex-1 flex-col overflow-hidden bg-white">
      <BuilderWorkspaceTabBar
        tabs={tabs}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        trailing={progressTrailing}
      />

      <Box
        sx={{
          display: 'flex',
          flex: 1,
          minHeight: 0,
          minWidth: 0,
          overflow: 'hidden',
        }}
      >
        <Box
          sx={{
            flex: 1,
            minWidth: 0,
            minHeight: 0,
            overflow: 'hidden',
            display: 'flex',
            flexDirection: 'column',
          }}
        >
        {activeTab === 'mapping' ? (
          <Box sx={{ minWidth: 0, flex: 1, overflow: 'hidden' }}>
            <SourceTargetAttributeMapping />
          </Box>
        ) : null}

        {activeTab === 'sql-preview' ? (
          <Box sx={{ flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column' }}>
            <MappingSqlPreview
              targetLabel={selectedTargetQualifiedName?.split('.').pop() ?? null}
              mappedCount={mappedCount}
              tableCount={selectedInputCount}
              filterCount={filterCount}
              joinCount={relationships.length}
              sourceQuerySql={sourceQueryPreviewSql}
              generatedSql={approvedVariant === 'optimized' && approvedGeneratedSql ? approvedGeneratedSql : generatedSql}
              onValidate={() => {
                void handleValidateSql();
              }}
              validateDisabled={reviewLoading || mappedCount === 0}
              validateLoading={reviewLoading}
              validateLabel={reviewLoading ? 'Reviewing SQL...' : 'Validate SQL'}
              onRunPreview={() => {
                void handleRunPreview();
              }}
              runDisabled={
                previewLoading ||
                !reviewResult ||
                (reviewResult.requires_approval && !reviewSelectionVariant)
              }
              runLoading={previewLoading}
              runLabel={previewLoading ? 'Running...' : 'Run Preview'}
              statusPanel={sqlReviewStatusPanel}
            />
          </Box>
        ) : null}

        {activeTab === 'data-preview' ? (
          <Box sx={{ flex: 1, width: '100%', minWidth: 0, minHeight: 0, overflow: 'auto', p: 2, backgroundColor: '#fff' }}>
            <Paper
              elevation={0}
              sx={{ border: '1px solid #e5e7eb', borderRadius: 3, overflow: 'hidden', width: '100%' }}
            >
              <Box sx={{ px: 2, py: 1.5, borderBottom: '1px solid #e5e7eb', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Typography sx={{ fontSize: '0.85rem', fontWeight: 800, color: '#111827' }}>
                  Result preview
                </Typography>
                <Typography sx={{ fontSize: '0.76rem', color: '#64748b' }}>
                  {validatedPreviewData?.preview_rows?.length ?? 0} sample rows
                </Typography>
              </Box>
              {validatedPreviewData ? (
                <Box sx={{ px: 2, py: 1.25, borderBottom: '1px solid #e5e7eb', bgcolor: '#f8fafc' }}>
                  <Typography sx={{ fontSize: '0.76rem', color: '#475569', lineHeight: 1.5 }}>
                    Sample values below come from executing the approved SQL in Snowflake. They are not AI-generated values.
                    {reviewResult
                      ? ` The approved SQL variant came from ${getReviewAgentLabel(reviewResult.review_agent)}.`
                      : ''}
                  </Typography>
                </Box>
              ) : null}
              {previewLoading ? (
                <Box sx={{ display: 'flex', justifyContent: 'center', py: 8 }}>
                  <CircularProgress size={28} />
                </Box>
              ) : previewError ? (
                <Box sx={{ p: 2.5 }}>
                  <Typography sx={{ fontSize: '0.82rem', color: '#b91c1c' }}>
                    {previewError}
                  </Typography>
                </Box>
              ) : !validatedPreviewData ? (
                <Box sx={{ p: 2.5 }}>
                  <Typography sx={{ fontSize: '0.82rem', color: '#64748b' }}>
                    Validate the generated SQL first to preview actual sample output values.
                  </Typography>
                  <Button
                    variant="outlined"
                    size="small"
                    sx={{ mt: 1.5, textTransform: 'none', fontWeight: 700 }}
                    onClick={() => {
                      setActiveTab('sql-preview');
                    }}
                  >
                    Go to SQL preview
                  </Button>
                </Box>
              ) : previewDisplayRows.length === 0 ? (
                <Box sx={{ p: 2.5 }}>
                  <Typography sx={{ fontSize: '0.82rem', color: '#64748b' }}>
                    The approved SQL executed successfully, but it returned 0 preview rows for this sample run.
                  </Typography>
                  <Typography sx={{ fontSize: '0.76rem', color: '#94a3b8', mt: 0.75, lineHeight: 1.5 }}>
                    This usually means the current joins, filters, or transformed expressions did not produce matching sample output rows yet.
                  </Typography>
                </Box>
              ) : (
                <Box sx={{ overflow: 'auto' }}>
                  <Table size="small" stickyHeader>
                    <TableHead>
                      <TableRow>
                        <TableCell sx={{ width: 52, fontWeight: 800 }}>#</TableCell>
                        <TableCell sx={{ minWidth: 220, fontWeight: 800 }}>Target Attr</TableCell>
                        <TableCell sx={{ minWidth: 220, fontWeight: 800 }}>Source Column</TableCell>
                        <TableCell sx={{ minWidth: 170, fontWeight: 800 }}>Source Value</TableCell>
                        <TableCell sx={{ minWidth: 200, fontWeight: 800 }}>Transformed Value</TableCell>
                        <TableCell sx={{ minWidth: 280, fontWeight: 800 }}>Description</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {previewDisplayRows.map((row) => (
                        <TableRow key={`${row.mappingId}-${row.rowIndex}`} hover>
                          {row.rowIndex === 0 ? (
                            <TableCell rowSpan={row.rowCount} sx={{ fontSize: '0.82rem', color: '#64748b', verticalAlign: 'top' }}>
                              {row.displayIndex}
                            </TableCell>
                          ) : null}
                          {row.rowIndex === 0 ? (
                            <TableCell rowSpan={row.rowCount} sx={{ verticalAlign: 'top' }}>
                              <Typography sx={{ fontSize: '0.92rem', fontWeight: 800, color: '#111827' }}>
                                {row.targetColumn}
                              </Typography>
                              <Typography sx={{ fontSize: '0.72rem', color: '#94a3b8', mt: 0.25 }}>
                                {row.targetType || '—'}
                              </Typography>
                            </TableCell>
                          ) : null}
                          <TableCell sx={{ verticalAlign: 'top' }}>
                            <Typography sx={{ fontSize: '0.84rem', fontWeight: 700, color: '#111827' }}>
                              {row.sourceColumn}
                            </Typography>
                          </TableCell>
                          <TableCell sx={{ verticalAlign: 'top' }}>
                            <Box
                              sx={{
                                display: 'inline-flex',
                                alignItems: 'center',
                                px: 1.25,
                                py: 0.5,
                                borderRadius: 1.5,
                                bgcolor: '#111827',
                                color: '#f8fafc',
                                fontSize: '0.78rem',
                                fontWeight: 700,
                              }}
                            >
                              {row.sourceValue}
                            </Box>
                          </TableCell>
                          {row.rowIndex === 0 ? (
                            <TableCell rowSpan={row.rowCount} sx={{ verticalAlign: 'top' }}>
                              <Box
                                sx={{
                                  display: 'inline-flex',
                                  flexDirection: 'column',
                                  gap: 0.5,
                                  px: 1.25,
                                  py: 0.65,
                                  borderRadius: 1.5,
                                  bgcolor: '#f5f3ff',
                                  color: '#6d28d9',
                                  minWidth: 160,
                                }}
                              >
                                <Typography sx={{ fontSize: '0.84rem', fontWeight: 700 }}>
                                  {row.transformedValue}
                                </Typography>
                                {row.expressionLabel ? (
                                  <Typography sx={{ fontSize: '0.7rem', fontWeight: 700, textTransform: 'uppercase' }}>
                                    {row.expressionLabel}
                                  </Typography>
                                ) : null}
                              </Box>
                            </TableCell>
                          ) : null}
                          {row.rowIndex === 0 ? (
                            <TableCell rowSpan={row.rowCount} sx={{ verticalAlign: 'top' }}>
                              <Typography sx={{ fontSize: '0.82rem', color: '#475569', lineHeight: 1.5 }}>
                                {row.description}
                              </Typography>
                            </TableCell>
                          ) : null}
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </Box>
              )}
            </Paper>
          </Box>
        ) : null}
        {activeTab === 'data-lineage' ? (
          <LineageTab />
        ) : null}
        </Box>
      </Box>
      <Dialog
        open={reviewDialogOpen}
        onClose={() => setReviewDialogOpen(false)}
        fullWidth
        maxWidth="lg"
        slotProps={{
          paper: {
            sx: {
              borderRadius: 3,
            },
          },
        }}
      >
        <DialogTitle sx={{ fontWeight: 800 }}>
          Review optimized SQL
        </DialogTitle>
        <DialogContent dividers sx={{ display: 'grid', gap: 2 }}>
          {reviewResult ? (
            <>
              <Alert severity="info" sx={{ borderRadius: 2 }}>
                {reviewResult.review_summary}
              </Alert>
              {reviewResult.warnings?.length ? (
                <Alert severity="warning" sx={{ borderRadius: 2 }}>
                  {reviewResult.warnings.join(' ')}
                </Alert>
              ) : null}
              <Box sx={{ display: 'grid', gap: 2, gridTemplateColumns: { xs: '1fr', lg: '1fr 1fr' } }}>
                <Paper variant="outlined" sx={{ borderRadius: 2, overflow: 'hidden' }}>
                  <Box sx={{ px: 2, py: 1.25, borderBottom: '1px solid #e5e7eb', bgcolor: '#f8fafc' }}>
                    <Typography sx={{ fontSize: '0.82rem', fontWeight: 800 }}>Original SQL</Typography>
                  </Box>
                  <Box component="pre" sx={{ m: 0, p: 2, overflow: 'auto', fontSize: '0.76rem', lineHeight: 1.6, whiteSpace: 'pre-wrap' }}>
                    {reviewResult.original_preview_sql}
                  </Box>
                </Paper>
                <Paper variant="outlined" sx={{ borderRadius: 2, overflow: 'hidden' }}>
                  <Box sx={{ px: 2, py: 1.25, borderBottom: '1px solid #e5e7eb', bgcolor: '#f8fafc' }}>
                    <Typography sx={{ fontSize: '0.82rem', fontWeight: 800 }}>Optimized SQL</Typography>
                  </Box>
                  <Box component="pre" sx={{ m: 0, p: 2, overflow: 'auto', fontSize: '0.76rem', lineHeight: 1.6, whiteSpace: 'pre-wrap' }}>
                    {reviewResult.optimized_preview_sql ?? reviewResult.original_preview_sql}
                  </Box>
                </Paper>
              </Box>
              {reviewDiffRows.length ? (
                <Paper variant="outlined" sx={{ borderRadius: 2, overflow: 'hidden' }}>
                  <Box sx={{ px: 2, py: 1.25, borderBottom: '1px solid #e5e7eb', bgcolor: '#f8fafc' }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 2, flexWrap: 'wrap' }}>
                      <Typography sx={{ fontSize: '0.82rem', fontWeight: 800 }}>Suggested SQL changes</Typography>
                      <Box sx={{ display: 'flex', gap: 1.5, flexWrap: 'wrap' }}>
                        <Typography sx={{ fontSize: '0.74rem', fontWeight: 700, color: '#b91c1c' }}>
                          - {reviewDiffSummary.removals} removal{reviewDiffSummary.removals === 1 ? '' : 's'}
                        </Typography>
                        <Typography sx={{ fontSize: '0.74rem', fontWeight: 700, color: '#15803d' }}>
                          + {reviewDiffSummary.additions} addition{reviewDiffSummary.additions === 1 ? '' : 's'}
                        </Typography>
                      </Box>
                    </Box>
                  </Box>
                  <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', fontFamily: 'ui-monospace, SFMono-Regular, monospace', fontSize: '0.74rem' }}>
                    <Box sx={{ borderRight: '1px solid #e5e7eb' }}>
                      {reviewDiffRows.map((row, index) => (
                        <Box
                          key={`orig-${index}`}
                          sx={{
                            px: 1.5,
                            py: 0.5,
                            bgcolor:
                              row.originalKind === 'removed'
                                ? '#fef2f2'
                                : row.originalKind === 'empty'
                                  ? '#fafafa'
                                  : '#ffffff',
                            color:
                              row.originalKind === 'removed'
                                ? '#991b1b'
                                : row.originalKind === 'empty'
                                  ? '#cbd5e1'
                                  : '#111827',
                            whiteSpace: 'pre-wrap',
                            borderBottom: '1px solid #f3f4f6',
                          }}
                        >
                          {row.originalKind === 'removed' ? `- ${row.original}` : row.original || ' '}
                        </Box>
                      ))}
                    </Box>
                    <Box>
                      {reviewDiffRows.map((row, index) => (
                        <Box
                          key={`opt-${index}`}
                          sx={{
                            px: 1.5,
                            py: 0.5,
                            bgcolor:
                              row.optimizedKind === 'added'
                                ? '#f0fdf4'
                                : row.optimizedKind === 'empty'
                                  ? '#fafafa'
                                  : '#ffffff',
                            color:
                              row.optimizedKind === 'added'
                                ? '#166534'
                                : row.optimizedKind === 'empty'
                                  ? '#cbd5e1'
                                  : '#111827',
                            whiteSpace: 'pre-wrap',
                            borderBottom: '1px solid #f3f4f6',
                          }}
                        >
                          {row.optimizedKind === 'added' ? `+ ${row.optimized}` : row.optimized || ' '}
                        </Box>
                      ))}
                    </Box>
                  </Box>
                </Paper>
              ) : null}
            </>
          ) : null}
        </DialogContent>
        <DialogActions sx={{ px: 3, py: 2 }}>
          <Button onClick={() => setReviewDialogOpen(false)} sx={{ textTransform: 'none', fontWeight: 700 }}>
            Cancel
          </Button>
          <Button
            variant="outlined"
            onClick={() => {
              void handleApproveReviewedSql('original');
            }}
            disabled={reviewSelectionVariant === 'original'}
            sx={{ textTransform: 'none', fontWeight: 700 }}
          >
            {reviewSelectionVariant === 'original' ? 'Original selected' : 'Keep original and run preview'}
          </Button>
          <Button
            variant="contained"
            onClick={() => {
              void handleApproveReviewedSql('optimized');
            }}
            disabled={reviewSelectionVariant === 'optimized'}
            sx={{ textTransform: 'none', fontWeight: 700 }}
          >
            {reviewSelectionVariant === 'optimized' ? 'Optimized SQL applied' : 'Use optimized and run preview'}
          </Button>
        </DialogActions>
      </Dialog>
      <PreProcessModal />
    </div>
  );
}
