"use client";

import { useEffect, useState, type ReactNode } from "react";
import { AiaBox, AiaButton, AiaCircularProgress } from "@/components/ui";
import { AiaText } from "@/components/ui/aia-text";
import { textStyleCssVars } from "@/config/typography-tokens";
import { AppError } from "@/api/errors/app-error";
import { authService } from "@/services/authService";

type SessionStatus = "checking" | "ready" | "expired";

function isUnauthorized(error: unknown) {
  return error instanceof AppError && error.payload.statusCode === 401;
}

/**
 * Blocks signed-in screens until `/api/v1/auth/session` answers.
 * - While it loads: a spinner (screens would otherwise render with empty data).
 * - 401: the session has expired; the only way forward is to sign in again.
 * - Any other failure: the app continues and shows its usual error handling.
 */
export default function SessionGate({ children }: { children: ReactNode }) {
  const [status, setStatus] = useState<SessionStatus>("checking");

  useEffect(() => {
    let cancelled = false;
    authService
      .getSession()
      .then(() => {
        if (!cancelled) setStatus("ready");
      })
      .catch((error) => {
        if (!cancelled) setStatus(isUnauthorized(error) ? "expired" : "ready");
      });
    return () => {
      cancelled = true;
    };
  }, []);

  if (status === "ready") {
    return <>{children}</>;
  }

  if (status === "checking") {
    return (
      <AiaBox
        role="status"
        aria-live="polite"
        sx={{
          flex: 1,
          minHeight: "100vh",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          gap: 1.5,
          backgroundColor: "var(--color-app-bg)",
        }}
      >
        <AiaCircularProgress size={32} />
        <AiaText sx={{ ...textStyleCssVars("secondaryText") }}>
          Checking your session…
        </AiaText>
      </AiaBox>
    );
  }

  // Expired: only the "Sign in again" button acts (signs out so the user can sign in
  // again). Backdrop clicks do nothing and there is no way to dismiss the popup.
  return <SessionExpiredDialog onSignInAgain={() => authService.logout()} />;
}

function SessionExpiredDialog({ onSignInAgain }: { onSignInAgain: () => void }) {
  return (
    <AiaBox
      role="alertdialog"
      aria-modal="true"
      aria-labelledby="session-expired-title"
      aria-describedby="session-expired-message"
      sx={{
        position: "fixed",
        inset: 0,
        zIndex: 1500,
        px: 2,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "rgba(15, 23, 42, 0.42)",
        backdropFilter: "blur(4px)",
      }}
    >
      <AiaBox
        sx={{
          width: "100%",
          maxWidth: 440,
          borderRadius: "16px",
          border: "1px solid rgba(15, 23, 42, 0.08)",
          boxShadow: "0 30px 60px rgba(15, 23, 42, 0.18)",
          backgroundColor: "#FFFFFF",
          overflow: "hidden",
        }}
      >
        <AiaBox sx={{ px: 2.5, pt: 2.25, pb: 1 }}>
          <AiaText
            id="session-expired-title"
            sx={{ ...textStyleCssVars("cardTitle"), letterSpacing: "-0.01em" }}
          >
            Session expired
          </AiaText>
        </AiaBox>
        <AiaBox sx={{ px: 2.5, pb: 2.25 }}>
          <AiaText
            id="session-expired-message"
            sx={{ fontSize: 14, color: "var(--aia-text-color)", lineHeight: 1.6 }}
          >
            Your session is no longer valid. Sign in again with Snowflake to continue.
          </AiaText>
        </AiaBox>
        <AiaBox
          sx={{
            px: 2.5,
            py: 2,
            borderTop: "1px solid #EEF2F7",
            display: "flex",
            justifyContent: "flex-end",
          }}
        >
          <AiaButton
            variant="contained"
            color="primary"
            autoFocus
            onClick={onSignInAgain}
            sx={{
              minWidth: 140,
              height: 38,
              borderRadius: "10px",
              fontSize: 14,
              fontWeight: 700,
              textTransform: "none",
            }}
          >
            Sign in again
          </AiaButton>
        </AiaBox>
      </AiaBox>
    </AiaBox>
  );
}
