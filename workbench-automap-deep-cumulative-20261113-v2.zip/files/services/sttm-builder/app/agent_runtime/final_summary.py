"""Per-target summaries and the final answer of a Deep Agent migration run.

One summary is produced for every requested target, including those that never
got a mapping (no source found, blocked source design), so the review pane can
show a tab and a status for each. The answer leads with what is ready, then a
table per target, what the agent fixed on its own, cross-target dependencies,
and the decisions still open, grouped so each column is asked about once.
Only read-only extraction scripts are shown: optional SET declarations and a
SELECT query. Nothing is published.
"""
from __future__ import annotations

import json
from typing import Any, Iterable

from app.agent_runs.review_tiers import target_is_ready

READY = "ready"
NEEDS_REVIEW = "needs_review"
PREVIEW_FAILED = "preview_failed"
COMPILE_FAILED = "compile_failed"
BLOCKED = "blocked"
NO_SOURCE = "no_source"

_STATUS_LABEL = {
    READY: "Draft generated", NEEDS_REVIEW: "Draft generated", PREVIEW_FAILED: "Preview failed", COMPILE_FAILED: "Compile failed",
    BLOCKED: "Blocked", NO_SOURCE: "No source",
}


def _leaf(table: Any) -> str:
    return str(table or "").replace('"', "").rsplit(".", 1)[-1]


def _cell(value: Any) -> str:
    return str(value if value not in (None, "") else "—").replace("|", "\\|").replace("\n", " ").strip()


def _review_key(item: dict[str, Any]) -> tuple[str, str, str]:
    details = dict(item.get("details") or {})
    return (str(item.get("category") or ""), _leaf(details.get("target_table") or ""),
            str(details.get("target_column") or item.get("safe_summary") or "").upper())


def dedupe_review_items(items: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    """One item per (category, target, column); the blocking copy wins."""
    kept: dict[tuple[str, str, str], dict[str, Any]] = {}
    for item in items:
        key = _review_key(item)
        if key not in kept or (item.get("blocking") and not kept[key].get("blocking")):
            kept[key] = item
    return list(kept.values())


def mapping_summaries(result: dict[str, Any], requested_targets: Iterable[str] = ()) -> list[dict[str, Any]]:
    mappings = list(result.get("mapping_results") or [])
    by_target = {_leaf(item.get("target_table")).upper(): item for item in mappings}
    preparation = dict((result.get("source_preparation_result") or {}).get("mappings") or {})
    manifest = {str(item.get("mapping_key") or ""): item for item in result.get("manifest") or []}
    # Targets named in the request may be written SCHEMA.TABLE or bare; one
    # summary per table name, keeping the most qualified spelling.
    ordered: dict[str, str] = {}
    for value in [
        *[str(item.get("target_table") or "") for item in manifest.values() if item.get("target_table")],
        *[str(item.get("target_table") or "") for item in mappings if item.get("target_table")],
        *[str(value) for value in requested_targets if value],
    ]:
        key = _leaf(value).upper()
        if key and (key not in ordered or value.count(".") > ordered[key].count(".")):
            ordered[key] = value
    requested_order = [_leaf(value).upper() for value in requested_targets if value]
    targets = [ordered[key] for key in dict.fromkeys([*requested_order, *ordered])]
    summaries: list[dict[str, Any]] = []
    for target in targets:
        mapping = by_target.get(_leaf(target).upper())
        if mapping is None:
            planned = next((item for item in manifest.values()
                            if _leaf(item.get("target_table")).upper() == _leaf(target).upper()), None)
            prep = preparation.get(str((planned or {}).get("mapping_key") or ""), {})
            unresolved = list(prep.get("unresolved") or [])
            summaries.append({
                "target_table": target, "mapping_key": (planned or {}).get("mapping_key"),
                "mapping_name": (planned or {}).get("mapping_name") or _leaf(target), "sttm_id": (planned or {}).get("sttm_id"),
                "status": BLOCKED if planned else NO_SOURCE, "mapped": 0, "unresolved": 0, "total": 0,
                "compile_valid": False, "preview_valid": False, "select_sql": None, "error": None,
                "reason": "; ".join(str(value) for value in unresolved) or (
                    "Source preparation did not finish." if planned else "No driving source was found for this target."),
                "ctes": [], "repairs": [], "dependencies": [], "preview_rows": [],
                "next_action": "settle_sources" if planned else "find_sources",
            })
            continue
        rows = list(mapping.get("mapping_rows") or [])
        validation = dict(mapping.get("sql_validation") or {})
        mapped_rows = [row for row in rows if row.get("status") == "draft"]
        select_sql = str(
            validation.get("compiled_mapping_script")
            or validation.get("compiled_mapping_preview_sql")
            or ""
        ).strip() or None
        compile_ok = bool(validation.get("compile_valid"))
        preview_ok = bool(validation.get("preview_valid"))
        ready = target_is_ready(mapping)
        unresolved_count = sum(1 for row in rows if row.get("status") == "unresolved")
        status = (
            READY if ready else NEEDS_REVIEW if compile_ok and preview_ok
            else PREVIEW_FAILED if compile_ok else COMPILE_FAILED
        )
        repairs = list(validation.get("sql_repairs") or [])
        ctes = sorted({
            str(repair.get("evidence", {}).get("derived_source_id") or "")
            for repair in repairs if repair.get("root_cause") == "aggregate_grain"
        } - {""})
        confidences = [float(row.get("confidence") or 0.0) for row in mapped_rows]
        summaries.append({
            "target_table": target, "mapping_key": mapping.get("mapping_key"),
            "mapping_name": mapping.get("mapping_name") or _leaf(target), "sttm_id": mapping.get("sttm_id"),
            "status": status, "mapped": len(mapped_rows),
            "unresolved": unresolved_count, "total": len(rows),
            "compile_valid": compile_ok, "preview_valid": preview_ok, "select_sql": select_sql,
            "error": validation.get("error_summary") or validation.get("safe_error"),
            "failed_phase": validation.get("failed_phase"),
            "reason": None, "ctes": ctes, "repairs": repairs,
            "dependencies": list(mapping.get("dependency_resolutions") or []),
            "attachment_rows": sum(1 for row in rows if row.get("attachment_evidence")),
            "confidence": round(sum(confidences) / len(confidences), 3) if confidences else None,
            "preview_rows": list(validation.get("preview_rows") or [])[:5],
            "next_action": ("review" if status in {READY, NEEDS_REVIEW} else "fix_sql"),
        })
    return summaries


def render_answer(summaries: list[dict[str, Any]], review_items: Iterable[dict[str, Any]], *,
                  project_name: str | None = None) -> str:
    counts = {key: sum(1 for item in summaries if item["status"] == key) for key in _STATUS_LABEL}
    generated = counts[READY] + counts[NEEDS_REVIEW]
    lines = [
        f"**{generated} draft mapping{'s' if generated != 1 else ''} generated; "
        f"{sum(item['mapped'] for item in summaries)}/{sum(item['total'] for item in summaries)} target columns mapped.**"
        f"{f' Project: {project_name}.' if project_name else ''}",
        "", "| Target | Draft | Columns mapped | Compile | Preview | Confidence |",
        "| --- | --- | ---: | --- | --- | ---: |",
    ]
    for item in summaries:
        confidence = f"{item['confidence']:.0%}" if item.get("confidence") is not None else "—"
        lines.append(
            f"| **{_cell(_leaf(item['target_table']))}** | {_STATUS_LABEL[item['status']]} | "
            f"{item['mapped']}/{item['total']} | {'passed' if item['compile_valid'] else '—' if item['status'] in {BLOCKED, NO_SOURCE} else 'failed'} | "
            f"{'passed' if item['preview_valid'] else '—' if not item['compile_valid'] else 'failed'} | {confidence} |"
        )
    fixed = [(item, repair) for item in summaries for repair in item.get("repairs") or []]
    if fixed:
        lines += ["", "### What I fixed automatically"]
        for item, repair in fixed[:20]:
            lines.append(f"- {_leaf(item['target_table'])}.{repair.get('target_column')}: {repair.get('explanation')}")
        if len(fixed) > 20:
            lines.append(f"- …and {len(fixed) - 20} more, listed in each mapping's trace.")
    dependencies = [(item, dependency) for item in summaries for dependency in item.get("dependencies") or []]
    if dependencies:
        lines += ["", "### Dependencies between targets"]
        for item, dependency in dependencies:
            lines.append(f"- {_leaf(item['target_table'])}.{dependency.get('target_column')} ← "
                         f"{dependency.get('producer_mapping')}.{dependency.get('producer_column')}: {dependency.get('reason')}")
    gaps = [item for item in summaries if item.get("unresolved") or item.get("reason") or item.get("error")]
    if gaps:
        lines += ["", "Missing results: " + "; ".join(
            f"{_leaf(item['target_table'])}: " + (str(item.get("error") or item.get("reason"))
            if item.get("error") or item.get("reason") else f"{item['unresolved']} columns lack an executable source or rule")
            for item in gaps) + "."]
    sections = []
    for item in summaries:
        if not item.get("select_sql"):
            continue
        # This block's exact form is what the chat UI lifts into the review
        # pane (agent-artifact-text.ts); an error line follows it.
        block = (
            f"### {item['mapping_name']}: compiled SQL\n"
            f"Compile {'passed' if item['compile_valid'] else 'not passed'}; "
            f"sample preview {'passed' if item['preview_valid'] else 'not passed'}.\n"
            f"```sql\n{item['select_sql'][:30000]}\n```"
        )
        if item.get("preview_rows"):
            block += "\n\nSample results (up to 5 rows):\n```text\n" + "\n".join(
                str(row)[:2000] for row in item["preview_rows"]) + "\n```"
        if item.get("error") and not item["preview_valid"]:
            block += f"\n\n{_leaf(item['target_table'])} {item.get('failed_phase') or 'validation'} error: {_cell(item['error'])}"
        sections.append(block)
    # Status of every requested target in a comment the chat UI reads back
    # (agent-artifact-text.ts), so reopening the conversation from history
    # still shows a tab and a badge per target, including unmapped ones.
    statuses = [{
        "mapping_name": item["mapping_name"], "target_table": item["target_table"], "status": item["status"],
        "compile_valid": item["compile_valid"], "preview_valid": item["preview_valid"], "mapped": item["mapped"],
        "unresolved": item["unresolved"], "total": item["total"], "sttm_id": item.get("sttm_id"),
        "error": (str(item.get("error") or "")[:300] or None), "reason": (str(item.get("reason") or "")[:300] or None),
    } for item in summaries]
    marker = "\n\n<!--aia:mapping-summaries:" + json.dumps(statuses, separators=(",", ":")).replace("--", "- -") + "-->"
    return "\n".join(lines) + ("\n\n" + "\n\n".join(sections) if sections else "") + (marker if statuses else "")
