import { invalidateDatabaseMetadataCache } from "@/services/dbService";
import { invalidateProjectMetadataCache } from "@/services/projectService";

/** Clear user-visible read caches. Durable drafts and authenticated session state remain intact. */
export function refreshAllWorkbenchData() {
  invalidateProjectMetadataCache();
  invalidateDatabaseMetadataCache();
}
