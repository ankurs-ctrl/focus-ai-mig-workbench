'use client';

import { useMemo, useState, type ReactNode } from 'react';
import { AiaBox, AiaButton, AiaStack } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import type { ReviewTable, ReviewTableRow } from '@/services/migrationAgentService';

const CLOSED = new Set(['ANSWERED', 'RESOLVED', 'DISMISSED', 'ACCEPTED', 'AUTO_APPROVED']);

function confidencePresentation(value: number | null) {
  const percentage = value == null ? null : Math.round(value * 100);
  if (percentage == null) return { percentage, label: 'Not scored', color: '#64748b', background: '#f1f5f9' };
  if (percentage >= 80) return { percentage, label: 'High', color: '#166534', background: '#dcfce7' };
  if (percentage >= 60) return { percentage, label: 'Medium', color: '#92400e', background: '#fef3c7' };
  return { percentage, label: 'Low', color: '#991b1b', background: '#fee2e2' };
}

function attentionRank(row: ReviewTableRow) {
  if (row.tier === 'blocker') return 0;
  if (row.status === 'UNRESOLVED' || row.actionability === 'required') return 1;
  if (row.kind === 'check') return 2;
  return 3;
}

function rowMatchesMapping(row: ReviewTableRow, mapping: ReviewTable['mappings'][number]) {
  if (row.sttm_id && mapping.sttm_id) return row.sttm_id === mapping.sttm_id;
  if (row.mapping_key && mapping.mapping_key) return row.mapping_key === mapping.mapping_key;
  const target = String(mapping.target_table || mapping.mapping_name || '').toUpperCase();
  return row.target_keys.some((value) => value.toUpperCase() === target)
    || row.targets.some((value) => target.endsWith(`.${value.toUpperCase()}`) || target === value.toUpperCase());
}

function DecisionRow({ row, expanded, busy, selectedReviewItemId, decisionContent, onToggle, onOpenDecision, onAccept }: {
  row: ReviewTableRow;
  expanded: boolean;
  busy: boolean;
  selectedReviewItemId: string | null;
  decisionContent?: ReactNode;
  onToggle: () => void;
  onOpenDecision: (reviewItemId: string) => void;
  onAccept: (rows: ReviewTableRow[]) => void;
}) {
  const confidence = confidencePresentation(row.confidence);
  const reviewItemId = row.review_item_ids[0] ?? null;
  const optionsOpen = Boolean(reviewItemId && selectedReviewItemId === reviewItemId);
  return (
    <AiaBox sx={{ borderTop: '1px solid #e2e8f0' }}>
      <AiaBox component="button" type="button" onClick={onToggle} aria-expanded={expanded}
        sx={{ width: '100%', minHeight: 54, display: 'grid', gridTemplateColumns: 'minmax(0, 1fr) auto auto', gap: 1,
          alignItems: 'center', border: 0, backgroundColor: expanded ? '#f8fafc' : '#fff', textAlign: 'left', cursor: 'pointer', px: 1, py: 1,
          '&:hover': { backgroundColor: '#f8fafc' }, '&:focus-visible': { outline: '2px solid #2563eb', outlineOffset: -2 } }}>
        <AiaBox sx={{ minWidth: 0 }}>
          <AiaText sx={{ fontSize: 13, lineHeight: 1.4, fontWeight: 700, color: '#0f172a', overflowWrap: 'anywhere' }}>
            {row.column || row.why || row.category}
          </AiaText>
          <AiaText sx={{ mt: 0.2, fontSize: 11.25, lineHeight: 1.4, color: '#64748b' }}>
            {row.status === 'UNRESOLVED' ? 'Mapping required' : row.kind === 'check' ? 'Validation check' : row.category.replaceAll('_', ' ')}
          </AiaText>
        </AiaBox>
        {confidence.percentage != null ? <AiaBox component="span" title={`${confidence.label} confidence`} sx={{ px: 0.8, py: 0.3,
          borderRadius: 999, backgroundColor: confidence.background, color: confidence.color, fontSize: 11, fontWeight: 800,
          fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>{confidence.percentage}%</AiaBox> : null}
        <AiaText component="span" aria-hidden sx={{ width: 18, textAlign: 'center', fontSize: 16, color: '#64748b' }}>{expanded ? '−' : '+'}</AiaText>
      </AiaBox>
      {expanded ? <AiaBox sx={{ px: 1, pt: 0.8, pb: 1.25 }}>
        {row.why ? <AiaText sx={{ fontSize: 12, lineHeight: 1.55, color: '#475569' }}>{row.why}</AiaText> : null}
        {row.current_choice ? <AiaBox sx={{ mt: 0.8, px: 1, py: 0.8, backgroundColor: '#f8fafc', borderLeft: '3px solid #cbd5e1' }}>
          <AiaText sx={{ fontSize: 10.25, fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Current mapping</AiaText>
          <AiaBox component="code" sx={{ display: 'block', mt: 0.25, fontSize: 11.5, lineHeight: 1.5, color: '#0f172a', overflowWrap: 'anywhere' }}>{row.current_choice}</AiaBox>
        </AiaBox> : null}
        <AiaStack direction="row" spacing={0.75} useFlexGap sx={{ mt: 1, flexWrap: 'wrap' }}>
          {reviewItemId ? <AiaButton size="small" variant={optionsOpen ? 'contained' : 'outlined'} disabled={busy}
            aria-expanded={optionsOpen} onClick={() => onOpenDecision(reviewItemId)} sx={{ textTransform: 'none' }}>
            {optionsOpen ? 'Hide options' : 'Review options'}
          </AiaButton> : null}
          {row.accept_eligible ? <AiaButton size="small" variant="outlined" disabled={busy} onClick={() => onAccept([row])}
            sx={{ textTransform: 'none' }}>Approve current mapping</AiaButton> : null}
        </AiaStack>
        {optionsOpen && decisionContent ? <AiaBox sx={{ mt: 1 }}>{decisionContent}</AiaBox> : null}
      </AiaBox> : null}
    </AiaBox>
  );
}

export function AgentReviewTable({ table, busy, error, selectedReviewItemId, decisionContent, onAccept, onOpenDecision }: {
  table: ReviewTable;
  busy: boolean;
  error: string | null;
  selectedReviewItemId: string | null;
  decisionContent?: ReactNode;
  onAccept: (rows: ReviewTableRow[]) => void;
  onOpenDecision: (reviewItemId: string) => void;
}) {
  const activeRows = useMemo(() => table.rows.filter((row) => !CLOSED.has(row.status)), [table.rows]);
  const auditRows = useMemo(() => table.rows.filter((row) => CLOSED.has(row.status)), [table.rows]);
  const groups = useMemo(() => {
    const mapped = table.mappings.map((mapping) => ({
      mapping,
      rows: activeRows.filter((row) => rowMatchesMapping(row, mapping)).sort((left, right) =>
        attentionRank(left) - attentionRank(right)
        || (left.confidence ?? -1) - (right.confidence ?? -1)
        || String(left.column || left.why).localeCompare(String(right.column || right.why))),
    }));
    const assigned = new Set(mapped.flatMap((group) => group.rows.map((row) => row.row_id)));
    const runRows = activeRows.filter((row) => !assigned.has(row.row_id));
    return runRows.length ? [{
      mapping: { mapping_key: null, mapping_name: 'Run-level decisions', target_table: null, sttm_id: null,
        mapped_count: 0, unresolved_count: 0, total_count: 0, compile_valid: false, preview_valid: false },
      rows: runRows,
    }, ...mapped] : mapped;
  }, [activeRows, table.mappings]);
  const firstGroup = groups.find((group) => group.rows.length)?.mapping.mapping_key
    ?? groups.find((group) => group.rows.length)?.mapping.mapping_name ?? null;
  const firstRow = groups.flatMap((group) => group.rows)[0]?.row_id ?? null;
  const [openGroups, setOpenGroups] = useState<Set<string>>(() => new Set(firstGroup ? [String(firstGroup)] : []));
  const [expandedRow, setExpandedRow] = useState<string | null>(firstRow);
  const [showAudit, setShowAudit] = useState(false);

  return <AiaBox>
    <AiaText sx={{ fontSize: 16, fontWeight: 800, color: '#0f172a' }}>
      {table.summary.actionable} action{table.summary.actionable === 1 ? '' : 's'} need attention
    </AiaText>
    <AiaText sx={{ mt: 0.3, fontSize: 12, lineHeight: 1.5, color: '#64748b' }}>
      {table.summary.targets_ready}/{table.summary.targets} mappings ready · {table.summary.auto_approved} validated high-confidence rows omitted from this queue
    </AiaText>
    {error ? <AiaText role="alert" sx={{ mt: 1, fontSize: 12, color: '#b91c1c' }}>{error}</AiaText> : null}
    <AiaStack spacing={1} sx={{ mt: 1.5 }}>
      {groups.filter((group) => group.rows.length).map(({ mapping, rows }) => {
        const groupId = String(mapping.mapping_key || mapping.mapping_name);
        const open = openGroups.has(groupId);
        const scored = rows.map((row) => row.confidence).filter((value): value is number => value != null);
        const lowest = scored.length ? Math.round(Math.min(...scored) * 100) : null;
        const required = rows.filter((row) => row.actionability === 'required' || row.tier === 'blocker').length;
        return <AiaBox component="section" key={groupId} aria-label={`${mapping.mapping_name} review`} sx={{ border: '1px solid #dbe2ea', borderRadius: 1.5, overflow: 'hidden' }}>
          <AiaBox component="button" type="button" onClick={() => setOpenGroups((current) => {
            const next = new Set(current); if (next.has(groupId)) next.delete(groupId); else next.add(groupId); return next;
          })} aria-expanded={open} sx={{ width: '100%', display: 'grid', gridTemplateColumns: 'minmax(0, 1fr) auto', gap: 1,
            alignItems: 'center', px: 1.25, py: 1, border: 0, backgroundColor: '#fff', textAlign: 'left', cursor: 'pointer',
            '&:hover': { backgroundColor: '#f8fafc' }, '&:focus-visible': { outline: '2px solid #2563eb', outlineOffset: -2 } }}>
            <AiaBox sx={{ minWidth: 0 }}>
              <AiaText sx={{ fontSize: 13.5, fontWeight: 800, color: '#0f172a', overflowWrap: 'anywhere' }}>{mapping.mapping_name}</AiaText>
              <AiaText sx={{ mt: 0.2, fontSize: 11, color: '#64748b' }}>
                {mapping.total_count ? `${mapping.mapped_count}/${mapping.total_count} mapped · ${mapping.unresolved_count} unresolved · ` : ''}
                {required ? `${required} required · ` : ''}{rows.length} open{lowest != null ? ` · lowest ${lowest}%` : ''}
              </AiaText>
            </AiaBox>
            <AiaText component="span" aria-hidden sx={{ fontSize: 16, color: '#64748b' }}>{open ? '−' : '+'}</AiaText>
          </AiaBox>
          {open ? <AiaBox>{rows.map((row) => <DecisionRow key={row.row_id} row={row} expanded={expandedRow === row.row_id}
            busy={busy} selectedReviewItemId={selectedReviewItemId} decisionContent={decisionContent}
            onToggle={() => setExpandedRow((current) => current === row.row_id ? null : row.row_id)}
            onOpenDecision={onOpenDecision} onAccept={onAccept} />)}</AiaBox> : null}
        </AiaBox>;
      })}
    </AiaStack>
    {!activeRows.length ? <AiaText sx={{ mt: 1.5, fontSize: 12.5, color: '#166534' }}>No low-confidence or unresolved review actions remain.</AiaText> : null}
    {auditRows.length ? <AiaButton size="small" variant="text" onClick={() => setShowAudit((value) => !value)} aria-expanded={showAudit}
      sx={{ mt: 1.25, px: 0, textTransform: 'none' }}>{showAudit ? 'Hide' : 'Show'} approved audit rows · {auditRows.length}</AiaButton> : null}
    {showAudit ? <AiaStack spacing={0.4} sx={{ mt: 0.5 }}>{auditRows.map((row) => <AiaText key={row.row_id} sx={{ fontSize: 11.5, color: '#64748b' }}>
      {row.mapping_name || row.targets.join(', ')} · {row.column || row.why} · {row.status.replaceAll('_', ' ').toLowerCase()}
    </AiaText>)}</AiaStack> : null}
  </AiaBox>;
}