"""Deep Agent sends the mapping specialists the same FIR recipes and recommendations Auto Map does."""
from __future__ import annotations

import json

from app.agent_tools.specialists import CortexSpecialistAdapter, SpecialistRequest
from app.core.learning_retrieval import LearningRetrievalService, _compact_pattern
from app.schema.fir_patterns import TargetMappingPatternCandidate, TargetMappingPatternV2


def _candidate(column: str, *, mode: str = "direct", contradictions: int = 0) -> TargetMappingPatternCandidate:
    return TargetMappingPatternCandidate(
        pattern=TargetMappingPatternV2(
            pattern_id=f"p-{column}", scope="source_system", content_hash=f"h-{column}",
            source_compatibility_signature="sig",
            target_contract={"target_table": "DB.T.HOUSEHOLD", "target_column": column},
            source_system_profile={"vendor_family": "REDTAIL"},
            mapping_recipe={"mode": mode, "source_dependencies": ["CONTACTS.ID"], "expression": "CONTACTS.ID"},
            derived_dependencies=[{"name": "HH_GRAIN"}] if mode == "complex" else [],
            contradiction_count=contradictions, provenance={"evidence_class": "validated_imported_sql"},
        ),
        compatibility_tier=2, compatibility_score=0.8, decision="adapt_pattern",
        adapted_source_columns=["CONTACTS.ID"],
    )


def _request(columns: list[str], **extra) -> SpecialistRequest:
    return SpecialistRequest(
        run_id="run-1", step_id="map", project_id="p", sttm_id="s", snapshot_id="draft:s",
        target_contract={"target_table": "DB.T.HOUSEHOLD", "columns": [{"name": c, "type": "VARCHAR"} for c in columns]},
        target_columns=columns, allowed_source_tables=["DB.S.CONTACTS"],
        actor_user_id="1", effective_role="EDITOR", tenant_id="default", **extra,
    )


def test_compact_pattern_keeps_escalation_signals_and_drops_empty_fields() -> None:
    compact = _compact_pattern(_candidate("NAME", mode="complex", contradictions=2))
    assert compact["mode"] == "complex"
    assert compact["contradiction_count"] == 2
    assert compact["derived_dependencies"] == [{"name": "HH_GRAIN"}]
    assert compact["compatibility_decision"] == "adapt_pattern"
    assert compact["vendor_family"] == "REDTAIL"
    assert "missing_dependencies" not in compact


def test_specialist_learning_limits_patterns_per_column_and_reads_recommendations() -> None:
    class _Patterns:
        def retrieve_candidates(self, **_kwargs):
            return [_candidate("NAME"), _candidate("NAME"), _candidate("NAME"), _candidate("ID")]

    service = object.__new__(LearningRetrievalService)
    service._target_pattern_service = _Patterns()
    service._get_fir_recommendations_for_context = lambda **_kwargs: [
        {"recommendation_id": f"r{i}"} for i in range(12)]
    result = service.get_specialist_learning(
        project_id="p", target_table="DB.T.HOUSEHOLD", target_columns=["NAME", "ID"],
        source_tables=["DB.S.CONTACTS"])
    assert [item["target_column"] for item in result["target_mapping_patterns"]] == ["NAME", "NAME", "ID"]
    assert len(result["fir_recommendations"]) == 8
    assert result["retrieved_recommendation_ids"][0] == "r0"


def test_specialist_learning_survives_unavailable_sources() -> None:
    class _Broken:
        def retrieve_candidates(self, **_kwargs):
            raise RuntimeError("table missing")

    def fail(**_kwargs):
        raise RuntimeError("procedure missing")

    service = object.__new__(LearningRetrievalService)
    service._target_pattern_service = _Broken()
    service._get_fir_recommendations_for_context = fail
    result = service.get_specialist_learning(
        project_id="p", target_table="DB.T.HOUSEHOLD", target_columns=["NAME"], source_tables=["DB.S.CONTACTS"])
    assert result["target_mapping_patterns"] == [] and result["fir_recommendations"] == []


def test_source_mapping_payload_carries_patterns_and_recommendations() -> None:
    request = _request(["NAME"], target_mapping_patterns=[_compact_pattern(_candidate("NAME"))],
                       fir_recommendations=[{"recommendation_id": "r1", "type": "pattern_reuse"}])
    payload = CortexSpecialistAdapter._source_mapping_payload(request)
    learning = payload["context"]["learning_context"]
    assert learning["target_mapping_patterns"][0]["pattern_id"] == "p-NAME"
    assert learning["fir_recommendations"][0]["recommendation_id"] == "r1"
    assert learning["retrieved_recommendation_ids"] == ["r1"]


def test_each_batch_sees_only_its_own_columns_patterns() -> None:
    class _Client:
        def __init__(self):
            self.seen: list[dict] = []

        def run_detailed(self, messages, **_kwargs):
            request = json.loads(messages[0]["content"][0]["text"])["request"]
            self.seen.append(request)
            return "", "thread", {"decisions": [{"target_column": c, "decision": "unresolved", "confidence": 0,
                                                 "decision_reason": "test"} for c in request["target_columns"]]}

    columns = list("ABCDEFG")
    client = _Client()
    adapter = CortexSpecialistAdapter(client, source_mapping_agent="AGT_SOURCE_MAPPING",
                                      transformation_rule_agent="AGT_TRANSFORMATION_RULE")
    # current_mapping_rows marks the request complex, so the adapter batches six columns at a time.
    request = _request(columns, current_mapping_rows=[{"target_column": "A"}],
                       target_mapping_patterns=[{"pattern_id": f"p-{c}", "target_column": c} for c in columns])
    request.target_contract.pop("target_table")  # use the narrow contract so the request is visible
    adapter.map_targets(request, max_workers=1, before_call=lambda _operation: None)
    assert len(client.seen) == 2
    for call in client.seen:
        assert {item["target_column"] for item in call["target_mapping_patterns"]} == set(call["target_columns"])
