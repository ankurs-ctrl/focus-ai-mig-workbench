-- ============================================================
-- FIR Cortex Search Services
-- Enables semantic search over FIR inferences, recommendations,
-- and curated semantic view versions.
-- ============================================================

-- ============================================================
-- View for FIR 360 Inferences Search
-- ============================================================
CREATE OR REPLACE VIEW __STTM_METADATA_NAMESPACE__.VW_FIR_INFERENCES_SEARCH AS
SELECT
    FIR_RECORD_ID,
    INFERENCE_ID,
    SOURCE_TYPE,
    SOURCE_EVENT_TYPE,
    ENTITY_TYPE,
    PROJECT_ID,
    STTM_ID,
    SEMANTIC_BUNDLE_ID,
    CURRENT_CONFIDENCE,
    TARGET_AGENTS,
    PROCESSING_STAGE,
    CREATED_AT,
    -- Composite search text for semantic matching
    COALESCE(INFERENCE_PAYLOAD:summary::STRING, '') || ' ' ||
    COALESCE(INFERENCE_PAYLOAD:inference_type::STRING, '') || ' ' ||
    COALESCE(SOURCE_EVENT_TYPE, '') || ' ' ||
    COALESCE(ENTITY_TYPE, '') || ' ' ||
    COALESCE(INFERENCE_PAYLOAD:business_understanding:column_relationship:source::STRING, '') || ' ' ||
    COALESCE(INFERENCE_PAYLOAD:business_understanding:column_relationship:target::STRING, '') || ' ' ||
    COALESCE(INFERENCE_PAYLOAD:business_understanding:column_relationship:rationale::STRING, '') || ' ' ||
    COALESCE(INFERENCE_PAYLOAD:business_understanding:derived_source:name::STRING, '') || ' ' ||
    COALESCE(INFERENCE_PAYLOAD:business_understanding:derived_source:purpose::STRING, '') || ' ' ||
    COALESCE(INFERENCE_PAYLOAD:business_understanding:derived_source:business_description::STRING, '')
    AS SEARCH_TEXT
FROM __STTM_METADATA_NAMESPACE__.TBL_AGENT_FIR_360
WHERE PROCESSING_STAGE = 'completed'
  AND INFERENCE_ID IS NOT NULL;

-- ============================================================
-- CSS_FIR_INFERENCES_360 - FIR Inferences Search Service
-- ============================================================
CREATE OR REPLACE CORTEX SEARCH SERVICE __STTM_METADATA_NAMESPACE__.CSS_FIR_INFERENCES_360
ON SEARCH_TEXT
ATTRIBUTES
    FIR_RECORD_ID,
    INFERENCE_ID,
    SOURCE_TYPE,
    SOURCE_EVENT_TYPE,
    ENTITY_TYPE,
    PROJECT_ID,
    CURRENT_CONFIDENCE,
    CREATED_AT
WAREHOUSE = __WAREHOUSE_NAME__
TARGET_LAG = '1 hour'
AS (
    SELECT * FROM __STTM_METADATA_NAMESPACE__.VW_FIR_INFERENCES_SEARCH
);


-- ============================================================
-- View for Agent Recommendations Search
-- ============================================================
CREATE OR REPLACE VIEW __STTM_METADATA_NAMESPACE__.VW_FIR_RECOMMENDATIONS_SEARCH AS
SELECT
    AGENT_RECOMMENDATION_ID,
    FIR_RECORD_ID,
    TARGET_AGENT,
    TRIGGER_TYPE,
    RECOMMENDATION_TYPE,
    RECOMMENDATION_PRIORITY,
    CONFIDENCE,
    USAGE_COUNT,
    SUCCESS_COUNT,
    STATUS,
    CREATED_AT,
    -- Composite search text
    COALESCE(RECOMMENDATION_TYPE, '') || ' ' ||
    COALESCE(TARGET_AGENT, '') || ' ' ||
    COALESCE(TRIGGER_TYPE, '') || ' ' ||
    COALESCE(AGENT_PAYLOAD:inference_summary::STRING, '') || ' ' ||
    COALESCE(AGENT_PAYLOAD:mapping_pattern:source_column::STRING, '') || ' ' ||
    COALESCE(AGENT_PAYLOAD:mapping_pattern:target_column::STRING, '') || ' ' ||
    COALESCE(AGENT_PAYLOAD:mapping_pattern:rationale::STRING, '') || ' ' ||
    COALESCE(AGENT_PAYLOAD:suggested_derived_source:name::STRING, '') || ' ' ||
    COALESCE(AGENT_PAYLOAD:suggested_derived_source:purpose::STRING, '') || ' ' ||
    COALESCE(AGENT_PAYLOAD:transformation_pattern:expression::STRING, '')
    AS SEARCH_TEXT
FROM __STTM_METADATA_NAMESPACE__.TBL_FIR_AGENT_RECOMMENDATIONS
WHERE STATUS = 'active';

-- ============================================================
-- CSS_FIR_AGENT_RECOMMENDATIONS - Recommendations Search Service
-- ============================================================
CREATE OR REPLACE CORTEX SEARCH SERVICE __STTM_METADATA_NAMESPACE__.CSS_FIR_AGENT_RECOMMENDATIONS
ON SEARCH_TEXT
ATTRIBUTES
    AGENT_RECOMMENDATION_ID,
    TARGET_AGENT,
    TRIGGER_TYPE,
    RECOMMENDATION_TYPE,
    RECOMMENDATION_PRIORITY,
    CONFIDENCE,
    USAGE_COUNT,
    SUCCESS_COUNT,
    CREATED_AT
WAREHOUSE = __WAREHOUSE_NAME__
TARGET_LAG = '1 hour'
AS (
    SELECT * FROM __STTM_METADATA_NAMESPACE__.VW_FIR_RECOMMENDATIONS_SEARCH
);


-- ============================================================
-- View for Semantic View Versions Search
-- ============================================================
CREATE OR REPLACE VIEW __STTM_METADATA_NAMESPACE__.VW_FIR_SEMANTIC_VERSIONS_SEARCH AS
SELECT
    VERSION_ID,
    SEMANTIC_VIEW_FQN,
    VERSION_NUMBER,
    VERSION_LABEL,
    PARENT_VERSION_ID,
    CONFIDENCE,
    VALIDATION_STATUS,
    STATUS,
    CREATED_AT,
    -- Composite search text from semantic content.
    -- Subquery expressions with change tracking are unsupported; cast VARIANT to STRING instead.
    COALESCE(SEMANTIC_VIEW_FQN, '') || ' ' ||
    COALESCE(VERSION_LABEL, '') || ' ' ||
    COALESCE(PROMOTION_REASON, '') || ' ' ||
    COALESCE(BUSINESS_GLOSSARY::STRING, '') || ' ' ||
    COALESCE(COLUMN_SEMANTICS::STRING, '') || ' ' ||
    COALESCE(TRANSFORMATION_PATTERNS::STRING, '') || ' ' ||
    COALESCE(RELATIONSHIP_RULES::STRING, '') || ' ' ||
    COALESCE(DERIVED_SOURCE_PATTERNS::STRING, '')
    AS SEARCH_TEXT
FROM __STTM_METADATA_NAMESPACE__.TBL_SEMANTIC_VIEW_VERSIONS
WHERE STATUS = 'active';

-- ============================================================
-- CSS_FIR_SEMANTIC_VERSIONS - Semantic Versions Search Service
-- ============================================================
CREATE OR REPLACE CORTEX SEARCH SERVICE __STTM_METADATA_NAMESPACE__.CSS_FIR_SEMANTIC_VERSIONS
ON SEARCH_TEXT
ATTRIBUTES
    VERSION_ID,
    SEMANTIC_VIEW_FQN,
    VERSION_NUMBER,
    VERSION_LABEL,
    CONFIDENCE,
    VALIDATION_STATUS,
    CREATED_AT
WAREHOUSE = __WAREHOUSE_NAME__
TARGET_LAG = '1 hour'
AS (
    SELECT * FROM __STTM_METADATA_NAMESPACE__.VW_FIR_SEMANTIC_VERSIONS_SEARCH
);
