import type { JoinConfig, TableMeta } from "../types/sttm.types";
import { scopedJoinEditing, type ScopedJoin } from '@/features/sttm/shared/scoped-join';

type IdentifierPart = { name: string; quoted: boolean };
type ScopedColumn = {
  qualifier: string; name: string; name_sql: string; quoted: boolean; qualifier_quoted: boolean;
};
export type ScopedOutput = {
  name: string; sql: string; ordinal: number; direct_column: ScopedColumn | null;
  star: boolean; plain_star: boolean; star_qualifier: string | null; source_columns: ScopedColumn[];
};
export type QueryScope = {
  scope_id: string; parent_scope_id: string | null; name: string | null; kind: string;
  query_kind: string; definition_sql: string; definition_hash: string; projection_sql: string;
  relations: Array<{
    relation_instance_id: string; relation_name: string; source_scope_id: string | null;
    alias: string; alias_sql: string; sql: string; identifier_parts: IdentifierPart[];
  }>;
  joins: Array<ScopedJoin & {
    join_id: string; right_relation_id: string; referenced_relation_ids: string[];
    join_type: string; predicate: string | null; using: string[];
  }>;
  clauses: Record<string, string | null>;
  outputs: ScopedOutput[];
};

function matchesIdentifier(actual: string, expected: IdentifierPart) {
  return expected.quoted ? actual === expected.name : actual.toUpperCase() === expected.name.toUpperCase();
}

/** Resolve local CTE dependencies by parser identity, never by alias-name guessing. */
export function localScopeSourceTables(scope: QueryScope, scopes: QueryScope[], tables: TableMeta[]) {
  const visited = new Set<string>();
  const visiting = new Set<string>();
  const tableIds = new Set<string>();
  const visit = (current: QueryScope) => {
    if (visiting.has(current.scope_id)) throw new Error("Recursive CTEs require SQL-only dependency review.");
    if (visited.has(current.scope_id)) return;
    visiting.add(current.scope_id);
    for (const relation of current.relations) {
      if (relation.source_scope_id) {
        const dependency = scopes.find((candidate) => candidate.scope_id === relation.source_scope_id);
        if (!dependency) throw new Error(`Missing local SQL scope: ${relation.source_scope_id}`);
        visit(dependency);
      } else {
        const bound = bindScopeRelations({ ...current, relations: [relation], joins: [] }, tables);
        for (const tableId of bound.relationIds.values()) tableIds.add(tableId);
      }
    }
    visiting.delete(current.scope_id);
    visited.add(current.scope_id);
  };
  visit(scope);
  return [...tableIds];
}

export function bindScopeRelations(scope: QueryScope, tables: TableMeta[]) {
  const relationIds = new Map<string, string>();
  const aliases: Record<string, string> = {};
  const references: Record<string, string> = {};
  for (const relation of scope.relations) {
    const parts = relation.identifier_parts;
    const exact = tables.filter((table) => String(table.id) === relation.relation_name);
    const matches = exact.length ? exact : tables.filter((table) => {
      if (!parts.length) return table.name === relation.relation_name;
      const components = [table.database ?? "", table.schema ?? "", table.name ?? ""];
      return parts.every((part, index) => matchesIdentifier(components[3 - parts.length + index], part));
    });
    if (matches.length !== 1) {
      throw new Error(`${matches.length ? "Ambiguous" : "Unavailable"} source identity: ${relation.relation_name}`);
    }
    const tableId = String(matches[0].id);
    if ([...relationIds.values()].includes(tableId)) {
      throw new Error("This scope uses the same table more than once. Its SQL is preserved; separate relation-instance controls are required before visual editing.");
    }
    relationIds.set(relation.relation_instance_id, tableId);
    aliases[tableId] = relation.alias_sql;
    references[tableId] = relation.sql;
  }
  const joins: JoinConfig[] = scope.joins.map((join, index) => {
    const joinType = join.join_type.replace(/\s+OUTER$/, "");
    if (!["INNER", "LEFT", "RIGHT", "FULL"].includes(joinType) || !join.predicate || join.using.length) {
      throw new Error(`This ${join.join_type} join needs SQL editing; it cannot be converted to an ON-predicate control without changing its semantics.`);
    }
    const leftInstance = join.structured?.left_relation_id ?? join.referenced_relation_ids.find((id) => id !== join.right_relation_id)
      ?? scope.relations[index]?.relation_instance_id;
    const leftTableId = relationIds.get(leftInstance);
    const rightTableId = relationIds.get(join.right_relation_id);
    if (!leftTableId || !rightTableId) throw new Error("The join's relation identity could not be resolved.");
    return {
      id: join.join_id, leftTableId, rightTableId,
      joinType: joinType as JoinConfig["joinType"],
      ...scopedJoinEditing(join, leftInstance, join.right_relation_id, join.predicate),
      source: "USER_DEFINED", locked: false,
    };
  });
  return { relationIds, aliases, references, joins };
}

function resolveColumn(scope: QueryScope, binding: ReturnType<typeof bindScopeRelations>, column: ScopedColumn, tables: TableMeta[]) {
  const candidates = scope.relations.filter((relation) => !column.qualifier || matchesIdentifier(
    relation.alias, { name: column.qualifier, quoted: column.qualifier_quoted },
  ));
  const matches = candidates.flatMap((relation) => {
    const tableId = binding.relationIds.get(relation.relation_instance_id)!;
    const table = tables.find((item) => String(item.id) === tableId)!;
    return (table.columns ?? []).filter((item) => item.name && matchesIdentifier(item.name, column))
      .map((item) => ({ tableId, name: item.name as string }));
  });
  return matches.length === 1 ? matches[0] : null;
}

export function scopeSelectedColumns(scope: QueryScope, binding: ReturnType<typeof bindScopeRelations>, tables: TableMeta[]) {
  const selected: Record<string, string[]> = {};
  for (const output of scope.outputs) {
    for (const column of output.source_columns) {
      const resolved = resolveColumn(scope, binding, column, tables);
      if (resolved) selected[resolved.tableId] = [...new Set([...(selected[resolved.tableId] ?? []), resolved.name])];
    }
    if (output.star) {
      for (const relation of scope.relations.filter((item) => !output.star_qualifier || item.alias === output.star_qualifier)) {
        const tableId = binding.relationIds.get(relation.relation_instance_id)!;
        selected[tableId] = tables.find((table) => String(table.id) === tableId)?.columns
          ?.map((column) => column.name).filter((name): name is string => Boolean(name)) ?? [];
      }
    }
  }
  return selected;
}

function quoteIdentifier(value: string) {
  return `"${value.replaceAll('"', '""')}"`;
}

export function scopeHasIncompleteColumnCatalog(scope: QueryScope, selectedTableIds: string[], tables: TableMeta[]) {
  return scope.outputs.some((output) => output.star || output.source_columns.length > 0)
    && selectedTableIds.some((id) => !tables.find((table) => String(table.id) === id)?.columns?.length);
}

/** Column toggles change direct outputs only, not computed expressions or aliases. */
export function scopeProjection(scope: QueryScope, binding: ReturnType<typeof bindScopeRelations>, tables: TableMeta[], selected: Record<string, string[]>, baseline: Record<string, string[]>, aliases = binding.aliases) {
  if (JSON.stringify(selected) === JSON.stringify(baseline)) return scope.projection_sql;
  if (scopeHasIncompleteColumnCatalog(scope, [...binding.relationIds.values()], tables)) {
    throw new Error("The complete source-column catalog is required before changing output selections. SQL has not been simplified.");
  }
  const outputs: string[] = [];
  const emitted = new Set<string>();
  const key = (tableId: string, name: string) => JSON.stringify([tableId, name]);
  for (const output of scope.outputs) {
    if (output.star) {
      if (!output.plain_star) throw new Error("Edit EXCLUDE/REPLACE/RENAME wildcard projections in SQL to preserve their output contract.");
      for (const relation of scope.relations.filter((item) => !output.star_qualifier || item.alias === output.star_qualifier)) {
        const tableId = binding.relationIds.get(relation.relation_instance_id)!;
        for (const name of selected[tableId] ?? []) {
          outputs.push(`${binding.aliases[tableId]}.${quoteIdentifier(name)}`);
          emitted.add(key(tableId, name));
        }
      }
    } else if (output.direct_column) {
      const resolved = resolveColumn(scope, binding, output.direct_column, tables);
      if (!resolved) throw new Error(`Cannot safely edit unresolved output: ${output.sql}`);
      if (selected[resolved.tableId]?.includes(resolved.name)) {
        outputs.push(output.sql);
        emitted.add(key(resolved.tableId, resolved.name));
      }
    } else {
      outputs.push(output.sql);
    }
  }
  for (const [tableId, columns] of Object.entries(selected)) {
    for (const name of columns) {
      if (!baseline[tableId]?.includes(name) && !emitted.has(key(tableId, name))) {
        if (!aliases[tableId]) throw new Error(`Missing SQL alias for selected source ${tableId}`);
        outputs.push(`${aliases[tableId]}.${quoteIdentifier(name)}`);
        emitted.add(key(tableId, name));
      }
    }
  }
  if (!outputs.length) throw new Error("Select at least one output column.");
  return outputs.join(", ");
}