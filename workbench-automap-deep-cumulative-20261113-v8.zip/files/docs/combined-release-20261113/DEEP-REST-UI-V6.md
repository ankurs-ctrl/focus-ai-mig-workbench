# Deep REST routing and Quick/Deep UI — cumulative v6

Deep supervisor, specialist agent and Analyst REST clients now use the same configured OAuth REST host as the application. Delegated user token and role are retained. Local session-token development retains its connector host. Service-owned worker housekeeping remains separate.

The Quick Assistant / Deep Agent selector uses the shared dropdown from the supplied (3) ZIP, including menu typography and placement above the composer. The dedicated page and sidebar share the existing combined panel. Quick sends use the Quick handler; Deep sends use the durable Deep service. Switching is disabled during active work and retains the existing new-chat boundary. Plan/Agent, effort/model settings and the right-side plan/SQL/review/results workspace remain available. Durable live paragraph updates are displayed on the dedicated page, with event deduplication and existing animated final rendering. This is milestone/paragraph streaming, not a new per-token transport. Shared assistant Markdown safeguards remain in effect.

## Deployment

1. Apply the cumulative overlay files to the existing repository, preserving client environment files and secure settings.
2. Keep the existing SNOWFLAKE_REST_HOST set to the account public OAuth REST host (UAT report: mhsuejt-ffp-hdp-snow-account-prod.snowflakecomputing.com). No new environment variables, OAuth login, tables, grants or migrations are introduced by this follow-up.
3. Rebuild and deploy matching frontend, backend and Deep worker images. Existing bootstrap and Deep migrations from earlier cumulative instructions still apply on installations that have not applied them.
4. Start a new isolated Deep run. The safe `Deep REST routing` log identifies run, selected host, auth mode and role, without tokens or payloads. Verify successful supervisor and specialist calls under the initiating user.

## Verification and limits

332 targeted backend tests passed, including REST routing, worker identity, OAuth/session handling, publication and Auto-map job regressions. Frontend regression results and TypeScript status are recorded in DEEP-REST-UI-V6-RESULTS.json.

Local browser verification used the actual changed frontend with a clearly labeled UI Fixture backend at http://localhost:13815/ai-agent. Both dropdown choices were selected; a synthetic durable progress update, final Markdown/SQL answer and right-side SQL workspace were verified. It made no Snowflake/model calls and changed no client mappings. The fixture server and its fake session are not packaged or deployed.

The configured-host defect is corrected. A real delegated OAuth run in client SPCS is still needed to establish whether this resolves the reported 395090 rejection; the failed run destination was not captured. No failed client runs were replayed. The older ZIP was used as a UI reference rather than overwriting later backend, authorization or recovery fixes. PR #63 and all prior cumulative overlay files remain included.
