/** Parse Snowflake identifier components without splitting quoted dots. */
export function sqlIdentifierParts(value: unknown): string[] {
  const text = String(value ?? '').trim();
  if (!text) return [];
  const parts: string[] = [];
  let offset = 0;
  while (offset < text.length) {
    const match = /^\s*("(?:""|[^"])+"|[A-Za-z_][A-Za-z0-9_$]*)\s*/.exec(text.slice(offset));
    if (!match) return [];
    const token = match[1];
    parts.push(token.startsWith('"') ? token.slice(1, -1).replaceAll('""', '"') : token.toUpperCase());
    offset += match[0].length;
    if (offset === text.length) break;
    if (text[offset] !== '.') return [];
    offset += 1;
    if (offset === text.length) return [];
  }
  return parts;
}

export function sqlIdentifierKey(value: unknown) {
  return JSON.stringify(sqlIdentifierParts(value));
}

export function renderSqlIdentifier(parts: string[]) {
  return parts.map(part => /^[A-Z_][A-Z0-9_$]*$/.test(part) ? part : `"${part.replaceAll('"', '""')}"`).join('.');
}

export function sqlIdentifierSuffixMatches(candidate: unknown, suffix: unknown) {
  const full = sqlIdentifierParts(candidate);
  const end = sqlIdentifierParts(suffix);
  return end.length > 0 && end.length <= full.length
    && end.every((part, index) => part === full[full.length - end.length + index]);
}
/** Keep catalog components as safe SQL identifiers, preserving quoted dots/case. */
export function sqlTableReference(value: string) {
  const parts = sqlIdentifierParts(value);
  if (parts.length !== 3) return null;
  const [database,schema,table] = parts.map(part => renderSqlIdentifier([part]));
  return {database,schema,table};
}
