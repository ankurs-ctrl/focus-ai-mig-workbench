"""Caller-scoped durable SQL upload acceptance and generation-fenced recovery.

No provider calls run here. A preview and enrichment state are stored separately;
GET recovery may schedule queued work, but never re-posts the original upload.
"""
from __future__ import annotations
import hashlib
import json
import re
import uuid

class UploadConfigurationError(RuntimeError):
    code = 'sql_upload_dependency_unavailable'


def is_upload_configuration_error(exc):
    native = getattr(exc, 'conn_error', None)
    return (
        isinstance(exc, UploadConfigurationError)
        or any(getattr(error, 'sqlstate', None) in {'42000', '42S02', '42501', '42S22'}
               for error in (exc, native))
        or any(str(code or '').lstrip('0') in {'2003', '904', '3001'} for code in (
            getattr(exc, 'sql_error_code', None), getattr(exc, 'errno', None), getattr(native, 'errno', None),
        ))
    )


def verify_upload_schema(session, table):
    """Read-only deployment/readiness check; never repairs runtime infrastructure."""
    required = {'REQUEST_ID','PROJECT_ID','REQUESTED_BY','REQUESTED_ROLE','CONTENT_IDENTITY',
        'PROCESSOR_VERSION','PROCESSING_ID','REQUEST_PAYLOAD','RESULT_PAYLOAD','STATUS',
        'STAGE','ERROR_CODE','GENERATION','LEASE_TOKEN','LEASE_EXPIRES_AT','CREATED_AT','UPDATED_AT'}
    try:
        rows = session.sql(f'DESCRIBE TABLE {table}').collect()
        descriptors = [{str(key).lower():value for key,value in (row.as_dict() if hasattr(row,'as_dict') else dict(row)).items()} for row in rows]
        columns = {str(row.get('name','')).upper() for row in descriptors}
        for row in descriptors:
            name, kind = str(row.get('name','')).upper(), str(row.get('type','')).upper().split('(')[0]
            expected = {'VARIANT'} if name in {'REQUEST_PAYLOAD','RESULT_PAYLOAD'} else {'NUMBER','DECIMAL'} if name == 'GENERATION' else {'TIMESTAMP_LTZ'} if name in {'CREATED_AT','UPDATED_AT','LEASE_EXPIRES_AT'} else {'VARCHAR','TEXT','STRING'}
            if name in required and kind not in expected:
                raise UploadConfigurationError('Upload recovery column types do not match the required schema')
        if required - columns:
            raise UploadConfigurationError('Upload recovery schema is incomplete; administrator migration required')
        rows = session.sql(f"SELECT COUNT(*) N FROM {table} WHERE REQUEST_ID='__admission_lock__'").collect()
        data = rows[0].as_dict() if hasattr(rows[0],'as_dict') else dict(rows[0])
        if data['N'] != 1:
            raise UploadConfigurationError('Upload recovery requires exactly one admission lock')
    except Exception as exc:
        if is_upload_configuration_error(exc):
            raise UploadConfigurationError('SQL upload dependencies are unavailable; administrator migration or access review required') from exc
        raise


PROCESSOR_VERSION = 'sql-upload-6-preview'

def fingerprint(content: bytes, project_id: str, options: dict) -> str:
    return hashlib.sha256(json.dumps([PROCESSOR_VERSION, str(project_id),
        hashlib.sha256(content).hexdigest(), options], sort_keys=True, separators=(',', ':')).encode()).hexdigest()

def document(value):
    return json.loads(value) if isinstance(value, str) else value

class SqlUploadJobs:
    def __init__(self, session, settings):
        self.session = session
        self.table = settings.qualify_metadata_object_name('TBL_SQL_UPLOAD_REQUESTS')

    def get(self, request_id, project_id):
        try:
            rows = self.session.sql(f'''SELECT * FROM {self.table}
              WHERE REQUEST_ID=? AND PROJECT_ID=? AND REQUESTED_BY=CURRENT_USER()
              AND REQUESTED_ROLE=CURRENT_ROLE()''', [request_id, project_id]).collect()
        except Exception as exc:
            if is_upload_configuration_error(exc):
                raise UploadConfigurationError('SQL upload request storage is unavailable') from exc
            raise
        if len(rows) > 1:
            raise RuntimeError('Conflicting upload identities; no processing was started')
        if not rows:
            return None
        row = rows[0].as_dict() if hasattr(rows[0], 'as_dict') else dict(rows[0])
        return {**row, 'REQUEST_PAYLOAD': document(row.get('REQUEST_PAYLOAD')),
                'RESULT_PAYLOAD': document(row.get('RESULT_PAYLOAD'))}

    def list_saved(self, project_id: str, sttm_id: str) -> list[dict]:
        """List recent reusable previews without exposing any SQL in the picker."""
        try:
            rows = self.session.sql(f"""
                SELECT request.REQUEST_ID, preview.RESULT_PAYLOAD:filename::STRING AS FILENAME,
                       request.CREATED_AT,
                       ROW_NUMBER() OVER (
                           PARTITION BY LOWER(preview.RESULT_PAYLOAD:filename::STRING)
                           ORDER BY request.CREATED_AT, request.REQUEST_ID
                       ) AS COPY_NUMBER
                FROM {self.table} request
                JOIN {self.table} preview
                  ON preview.REQUEST_ID = COALESCE(request.REQUEST_PAYLOAD:reuse_request_id::STRING, request.REQUEST_ID)
                 AND preview.PROJECT_ID = request.PROJECT_ID
                 AND preview.REQUESTED_BY = request.REQUESTED_BY
                 AND preview.REQUESTED_ROLE = request.REQUESTED_ROLE
                WHERE request.PROJECT_ID=? AND request.REQUESTED_BY=CURRENT_USER()
                  AND request.REQUESTED_ROLE=CURRENT_ROLE() AND request.PROCESSOR_VERSION=?
                  AND preview.PROCESSOR_VERSION=request.PROCESSOR_VERSION
                  AND NULLIF(preview.PROCESSING_ID, '') IS NOT NULL
                  AND COALESCE(preview.REQUEST_PAYLOAD:options:sttm_id::STRING, '')=?
                  AND preview.RESULT_PAYLOAD:asset_id::STRING IS NOT NULL
                  AND preview.RESULT_PAYLOAD:filename::STRING IS NOT NULL
                ORDER BY request.CREATED_AT DESC, request.REQUEST_ID DESC
                LIMIT 30
            """, [project_id, PROCESSOR_VERSION, sttm_id]).collect()
        except Exception as exc:
            if is_upload_configuration_error(exc):
                raise UploadConfigurationError("SQL upload request storage is unavailable") from exc
            raise
        uploads = []
        for row in rows:
            filename = row["FILENAME"]
            stem, dot, extension = filename.rpartition(".")
            copy_index = int(row["COPY_NUMBER"]) - 1
            label = filename if not copy_index else f"{stem or filename} ({copy_index}){dot}{extension}"
            uploads.append({"request_id": row["REQUEST_ID"], "filename": label, "created_at": row["CREATED_AT"]})
        return uploads

    def accept(self, **kwargs):
        # A provisioned singleton serializes only short admission transactions.
        # Snowflake standard tables do not enforce UNIQUE/PK constraints.
        self.session.sql('BEGIN TRANSACTION').collect()
        try:
            lock = self.session.sql(f"UPDATE {self.table} SET UPDATED_AT=CURRENT_TIMESTAMP() WHERE REQUEST_ID='__admission_lock__'",
                []).collect(statement_params={'STATEMENT_TIMEOUT_IN_SECONDS': 10})
            data = lock[0].as_dict() if lock and hasattr(lock[0], 'as_dict') else dict(lock[0]) if lock else {}
            if data.get('number of rows updated', data.get('updated', 0)) != 1 or data.get('number of multi-joined rows updated', 0):
                raise UploadConfigurationError('SQL upload recovery schema is not initialized')
            row = self._accept(**kwargs)
            self.session.sql('COMMIT').collect()
            return row
        except Exception:
            self.session.sql('ROLLBACK').collect()
            raise

    def _accept(self, *, request_id, project_id, identity, payload):
        if not isinstance(request_id, str) or not re.fullmatch(r'[A-Za-z0-9_-]{16,80}', request_id):
            raise ValueError('Invalid SQL upload request identity')
        current = self.get(request_id, project_id)
        if current:
            if current['CONTENT_IDENTITY'] != identity:
                raise ValueError('Upload request identity was reused with different content or options')
            return current
        # Serialize a logical upload's generations using the existing row lock.
        # A failed generation keeps its failure history; a later explicit upload
        # gets a fresh ID. Completed compatible work can be reused.
        rows = self.session.sql(f'''SELECT REQUEST_ID FROM {self.table}
          WHERE PROJECT_ID=? AND CONTENT_IDENTITY=? AND REQUESTED_BY=CURRENT_USER()
            AND REQUESTED_ROLE=CURRENT_ROLE() AND STATUS IN ('queued','running','preview_ready','completed')
            AND REQUEST_PAYLOAD:reuse_request_id IS NULL
          ORDER BY CREATED_AT DESC LIMIT 1''', [project_id, identity]).collect()
        if rows:
            original = rows[0]['REQUEST_ID']
            # A durable alias makes the client's pre-POST identity recoverable.
            payload = {'reuse_request_id': original}
        self.session.sql(f'''MERGE INTO {self.table} target USING (
            SELECT ? REQUEST_ID, ? PROJECT_ID, ? CONTENT_IDENTITY) source
          ON target.REQUEST_ID=source.REQUEST_ID AND target.PROJECT_ID=source.PROJECT_ID
             AND target.REQUESTED_BY=CURRENT_USER() AND target.REQUESTED_ROLE=CURRENT_ROLE()
          WHEN NOT MATCHED THEN INSERT (REQUEST_ID,PROJECT_ID,REQUESTED_BY,REQUESTED_ROLE,
            CONTENT_IDENTITY,PROCESSOR_VERSION,PROCESSING_ID,REQUEST_PAYLOAD,STATUS,GENERATION)
          VALUES(source.REQUEST_ID,source.PROJECT_ID,CURRENT_USER(),CURRENT_ROLE(),
            source.CONTENT_IDENTITY,?,?,PARSE_JSON(?),'queued',0)''',
          [request_id, project_id, identity, PROCESSOR_VERSION, uuid.uuid4().hex, json.dumps(payload)]).collect()
        return self.get(request_id, project_id)

    def claim(self, request_id, project_id):
        token = uuid.uuid4().hex
        self.session.sql(f'''UPDATE {self.table} SET STATUS='running', STAGE='parsing', LEASE_TOKEN=?,
          GENERATION=GENERATION+1, LEASE_EXPIRES_AT=DATEADD('minute',20,CURRENT_TIMESTAMP()),
          UPDATED_AT=CURRENT_TIMESTAMP()
          WHERE REQUEST_ID=? AND PROJECT_ID=? AND REQUESTED_BY=CURRENT_USER()
          AND REQUESTED_ROLE=CURRENT_ROLE() AND (STATUS='queued'
            OR (STATUS IN ('running','preview_ready') AND LEASE_EXPIRES_AT<CURRENT_TIMESTAMP()))''',
          [token, request_id, project_id]).collect()
        row = self.get(request_id, project_id)
        return row if row and row.get('LEASE_TOKEN') == token else None

    def publish(self, row, operation):
        self.session.sql('BEGIN TRANSACTION').collect()
        try:
            self.lock_publication(row)
            result = operation()
            self.session.sql('COMMIT').collect()
            return result
        except Exception:
            self.session.sql('ROLLBACK').collect()
            raise

    def lock_publication(self, row):
        rows = self.session.sql(f"""UPDATE {self.table} SET UPDATED_AT=CURRENT_TIMESTAMP()
          WHERE REQUEST_ID=? AND PROJECT_ID=? AND REQUESTED_BY=CURRENT_USER()
          AND REQUESTED_ROLE=CURRENT_ROLE() AND PROCESSING_ID=? AND GENERATION=? AND LEASE_TOKEN=?
          AND LEASE_EXPIRES_AT>CURRENT_TIMESTAMP() AND STATUS IN ('running','preview_ready')""",
          [row['REQUEST_ID'],row['PROJECT_ID'],row['PROCESSING_ID'],row['GENERATION'],row['LEASE_TOKEN']]).collect()
        data = rows[0].as_dict() if rows and hasattr(rows[0],'as_dict') else dict(rows[0]) if rows else {}
        if data.get('number of rows updated', data.get('updated',0)) != 1:
            raise RuntimeError('Stale upload worker cannot publish evidence')

    def save(self, row, *, status, result=None, stage=None, error=None):
        rows = self.session.sql(f'''UPDATE {self.table} SET STATUS=?, STAGE=?,
          RESULT_PAYLOAD=COALESCE(PARSE_JSON(?),RESULT_PAYLOAD), ERROR_CODE=?,
          UPDATED_AT=CURRENT_TIMESTAMP()
          WHERE REQUEST_ID=? AND PROJECT_ID=? AND REQUESTED_BY=CURRENT_USER()
          AND REQUESTED_ROLE=CURRENT_ROLE() AND GENERATION=? AND LEASE_TOKEN=?
          AND LEASE_EXPIRES_AT>CURRENT_TIMESTAMP() AND STATUS IN ('running','preview_ready')''',
          [status, stage or status, json.dumps(result) if result is not None else None, error,
           row['REQUEST_ID'], row['PROJECT_ID'], row['GENERATION'], row['LEASE_TOKEN']]).collect()
        data = rows[0].as_dict() if rows and hasattr(rows[0], 'as_dict') else dict(rows[0]) if rows else {}
        if data.get('number of rows updated', data.get('updated', 0)) != 1 or data.get('number of multi-joined rows updated', 0):
            raise RuntimeError('SQL upload generation lease was lost; stale delivery rejected')

    @staticmethod
    def is_current(row):
        return row.get('PROCESSOR_VERSION') == PROCESSOR_VERSION and bool(row.get('PROCESSING_ID'))

    @staticmethod
    def public(row):
        if not SqlUploadJobs.is_current(row):
            return {'request_id': row['REQUEST_ID'], 'status': 'needs_reupload',
                    'stage': 'processor_changed', 'result': None, 'error_code': 'processor_changed'}
        return {'request_id': row['REQUEST_ID'], 'status': row['STATUS'],
                'stage': row.get('STAGE') or row['STATUS'], 'result': row.get('RESULT_PAYLOAD'),
                'error_code': row.get('ERROR_CODE')}
