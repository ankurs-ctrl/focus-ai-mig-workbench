"""Opt-in PAT credentials and independent local session capacity."""

from types import SimpleNamespace
import pytest
from app.core.snowflake import _direct_connection_kwargs, get_local_transaction_pool
from app.core.config import Settings
from app.core.exceptions import SnowflakeConnectionError
from app.core import snowflake


def settings(**updates):
    return Settings(
        _env_file=None,
        SNOWFLAKE_ACCOUNT="ORG-ACCOUNT",
        SNOWFLAKE_USER="TEST",
        SNOWFLAKE_PASSWORD="test-secret",
        SNOWFLAKE_AUTHENTICATOR="PROGRAMMATIC_ACCESS_TOKEN",
        SNOWFLAKE_DATABASE="D",
        SNOWFLAKE_SCHEMA="M",
        **updates
    )


def test_pat_is_explicit_and_does_not_turn_password_login_into_a_token():
    configured = settings()
    kwargs = _direct_connection_kwargs(configured)
    assert (
        kwargs["authenticator"] == "PROGRAMMATIC_ACCESS_TOKEN"
        and kwargs["token"] == "test-secret"
        and "password" not in kwargs
    )
    ordinary = configured.model_copy(update={"snowflake_authenticator": "snowflake"})
    kwargs = _direct_connection_kwargs(ordinary)
    assert kwargs["password"] == "test-secret" and "token" not in kwargs
    with pytest.raises(SnowflakeConnectionError):
        _direct_connection_kwargs(
            configured.model_copy(update={"snowflake_password": ""})
        )


def test_native_local_pool_does_not_change_existing_default_or_mix_capacity(
    monkeypatch,
):
    monkeypatch.setattr(snowflake, "_LOCAL_TRANSACTION_POOLS", {})
    created = []

    def pool(**kw):
        created.append(kw)
        return SimpleNamespace(**kw)

    monkeypatch.setattr(snowflake, "SnowflakeSessionLeasePool", pool)
    configured = settings()
    default = get_local_transaction_pool(configured, "APP")
    native = get_local_transaction_pool(configured, "APP", purpose="native", maximum=16)
    assert default.maximum == 2 and native.maximum == 16 and default is not native
    assert (
        get_local_transaction_pool(configured, "APP", purpose="native", maximum=16)
        is native
    )
    assert len(created) == 2
    with pytest.raises(SnowflakeConnectionError):
        get_local_transaction_pool(configured, "APP", maximum=True)
