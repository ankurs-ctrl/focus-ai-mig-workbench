"use client";
import { AiaBox, AiaButton, AiaStack } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import React from "react";
import SourceTargetList from "./source-target-list";

import { AddIcon } from '@/utils/icons';
import { SttmSidebarSectionIcon } from '@/features/sttm/layout/sttm-sidebar-icons';
import { CAPTION_SX, textStyleCssVars, TYPOGRAPHY_TOKENS } from '@/config/typography-tokens';

import { useSttmBuilderContext } from "@/features/sttm/context/sttm-builder-context";
import { AiaSearchbox } from "@/components/ui/aia-searchbox";
import { AddDerivedModal } from "./add-derived-modal";
import { TOUR_TARGETS } from "@/features/tour/constants/tour-targets";

export default function SourceTargetPanel({ type }: { type: "source" | "target" }) {
  const {
    selectAllSources,
    clearSources,
    fullData,
    drivingTableId,
    addDerivedSource,
    pendingDerivedSourceDraft,
    derivedSourceDraftRequested,
    acknowledgePendingDerivedSourceDraft,
    dismissPendingDerivedSourceDraft,
  } = useSttmBuilderContext();
  const [isDerivedModalOpen, setIsDerivedModalOpen] = React.useState(false);
  const [searchTerm, setSearchTerm] = React.useState("");

  React.useEffect(() => {
    if (type === "source" && derivedSourceDraftRequested && pendingDerivedSourceDraft) {
      setIsDerivedModalOpen(true);
      acknowledgePendingDerivedSourceDraft();
    }
  }, [
    acknowledgePendingDerivedSourceDraft,
    derivedSourceDraftRequested,
    pendingDerivedSourceDraft,
    type,
  ]);

  const title = type === "source" ? "Source tables" : "Target tables";
  const selectedCount = React.useMemo(() => {
    const branch = type === "source" ? fullData?.sources : fullData?.targets;
    let count = 0;
    for (const db of branch ?? []) {
      for (const sch of db.schemas ?? []) {
        for (const tbl of sch.tables ?? []) {
          if (tbl.isSelected) count += 1;
        }
      }
    }
    return count;
  }, [fullData, type]);

  const drivingTableDetails = React.useMemo(() => {
    if (type !== 'source' || !fullData?.sources || !drivingTableId) return null;
    for (const db of fullData.sources) {
      for (const sch of db.schemas ?? []) {
        for (const tbl of sch.tables ?? []) {
          if (tbl.tableId === drivingTableId) {
            return { dbName: db.dbName, schemaName: sch.schemaName, tableName: tbl.tableName };
          }
        }
      }
    }
    return null;
  }, [fullData, drivingTableId, type]);

  const onSelectAll = () => {
    if (type === "source") selectAllSources();
  };

  const onClear = () => {
    if (type === "source") clearSources();
  };

  return (
    <AiaBox
      sx={{
        width: "100%",
        maxWidth: "100%",
        flex: 1,
        display: "flex",
        flexDirection: "column",
        backgroundColor: "transparent",
        p: 2,
      }}
    >
      <AiaBox
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          mt: -2,
          mx: -2,
          px: 2,
          mb: 1.5,
          minHeight: "var(--aia-workspace-section-header-min-height)",
          borderBottom: "1px solid #e5e7eb",
          gap: 2,
          overflow: "visible",
        }}
      >
        <AiaBox
          sx={{
            display: "flex",
            alignItems: "center",
            gap: 1,
            minWidth: 0,
            overflow: "visible",
          }}
        >
          <AiaBox
            sx={{
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center",
              width: 24,
              height: 24,
              flexShrink: 0,
              overflow: "visible",
              color: TYPOGRAPHY_TOKENS.cardTitle.color,
              "& .MuiSvgIcon-root": { color: "inherit" },
            }}
          >
            <SttmSidebarSectionIcon
              kind={type}
              sx={{
                fontSize: "calc(var(--aia-card-title-font-size) + 2px)",
                color: "var(--aia-card-title-color)",
                flexShrink: 0,
              }}
            />
          </AiaBox>
          <AiaText
            sx={{
              ...textStyleCssVars("cardTitle"),
              textTransform: "capitalize",
              letterSpacing: "-0.01em",
            }}
          >
            {title}
          </AiaText>
        </AiaBox>
        <AiaBox sx={{ display: "flex", alignItems: "center", gap: 1.25, flexShrink: 0 }}>
          <AiaText sx={CAPTION_SX}>
            {selectedCount} selected
          </AiaText>
          {type === "source" ? (
            <>
              <AiaButton
                variant="text"
                size="small"
                onClick={onSelectAll}
                sx={{
                  minWidth: 0,
                  px: 0.75,
                  py: 0.25,
                  fontSize: "var(--aia-caption-font-size)",
                  fontWeight: 600,
                  textTransform: "none",
                  color: "var(--aia-button-color)",
                  backgroundColor: "transparent",
                  boxShadow: "none",
                  "&:hover": {
                    backgroundColor: "color-mix(in srgb, var(--aia-button-color) 6%, transparent)",
                    color: "var(--aia-button-color)",
                    boxShadow: "none",
                  },
                }}
              >
                Select all
              </AiaButton>
              <AiaButton
                variant="text"
                size="small"
                onClick={onClear}
                sx={{
                  minWidth: 0,
                  px: 0.75,
                  py: 0.25,
                  fontSize: "var(--aia-caption-font-size)",
                  fontWeight: 600,
                  textTransform: "none",
                  color: "var(--aia-button-color)",
                  backgroundColor: "transparent",
                  boxShadow: "none",
                  "&:hover": {
                    backgroundColor: "color-mix(in srgb, var(--aia-button-color) 6%, transparent)",
                    color: "var(--aia-button-color)",
                    boxShadow: "none",
                  },
                }}
              >
                Clear all
              </AiaButton>
            </>
          ) : null}
        </AiaBox>
      </AiaBox>

      <AiaBox
        sx={{
          display: "flex",
          alignItems: "stretch",
          gap: 1,
          mb: 1.25,
        }}
      >
        <AiaSearchbox
          value={searchTerm}
          onChange={setSearchTerm}
          placeholder="search tables or tags"
          sx={{ flex: 1, mb: 0 }}
        />

        {/* <AiaButton
          variant="text"
          size="small"
          startIcon={<FilterListRoundedIcon sx={{ fontSize: 18, color: "#6b7280" }} />}
          sx={filtersControlSx}
        >
          Filters
        </AiaButton> */}
      </AiaBox>

      {type === "source" && (
        <AiaBox sx={{ mx: -2, borderBottom: "1px solid #eef2f7", mb: 1.5 }}>
          <AiaBox
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              pb: 1.5,
              px: 2,
              flexWrap: "wrap",
              gap: 1,
            }}
          >
            {drivingTableDetails ? (
              <AiaBox sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                <AiaText
                  sx={{
                    fontSize: 14,
                    fontWeight: 400,
                    color: "#9ca3af",
                    letterSpacing: "0.05em",
                    textTransform: "uppercase",
                  }}
                >
                  Driving table:
                </AiaText>
                <AiaText
                  sx={{
                    fontSize: 14,
                    fontWeight: 400,
                    color: "#1e293b",
                    px: 1,
                    py: 0.25,
                    borderRadius: "4px",
                  }}
                >
                  {drivingTableDetails.dbName} &bull; {drivingTableDetails.schemaName} &bull;{" "}
                  {drivingTableDetails.tableName}
                </AiaText>
              </AiaBox>
            ) : (
              <AiaBox />
            )}
            <AiaButton
              data-tour={TOUR_TARGETS.sttmAddDerived}
              size="small"
              variant="outlined"
              startIcon={<AddIcon sx={{ fontSize: 18 }} />}
              onClick={() => setIsDerivedModalOpen(true)}
              sx={{ minWidth: 0, boxShadow: "none" }}
              customBorderColor="var(--aia-state-success-color)"
              customColor="var(--aia-state-success-color)"
              customHoverBackgroundColor="var(--aia-state-success-hover-bg)"
            >
              Add Derived
            </AiaButton>
          </AiaBox>
        </AiaBox>
      )}

      <AiaBox sx={{ pr: 0.5 }}>
        <AiaStack spacing={0.5}>
          <SourceTargetList type={type} searchTerm={searchTerm} />
        </AiaStack>
      </AiaBox>

      {type === "source" && (
        <AddDerivedModal
          isOpen={isDerivedModalOpen}
          onClose={() => setIsDerivedModalOpen(false)}
          draftSource={pendingDerivedSourceDraft}
          onConfirm={(source) => {
            addDerivedSource(source);
            dismissPendingDerivedSourceDraft();
            setIsDerivedModalOpen(false);
          }}
        />
      )}
    </AiaBox>
  );
}
