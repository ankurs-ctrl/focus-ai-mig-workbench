import { AiaBox, AiaTooltip } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import React, { useMemo } from 'react';

export type RunProgressPhase = 'queued' | 'preparing' | 'mapping' | 'compiling' | 'done' | 'needs_review';

export type RunProgressSnapshot = {
  targets: Record<string, RunProgressPhase>;
  done: number;
  total: number;
  elapsedSeconds: number;
};

type ProgressEvent = { kind: string; timestamp: string; details: Record<string, unknown> };

const PHASE_STYLE: Record<RunProgressPhase, { label: string; color: string; background: string }> = {
  queued: { label: 'Queued', color: '#64748b', background: '#f1f5f9' },
  preparing: { label: 'Preparing sources', color: '#1d4ed8', background: '#eff6ff' },
  mapping: { label: 'Mapping', color: '#1d4ed8', background: '#dbeafe' },
  compiling: { label: 'Compiling and previewing', color: '#7c3aed', background: '#ede9fe' },
  done: { label: 'Done', color: '#15803d', background: '#dcfce7' },
  needs_review: { label: 'Needs review', color: '#b45309', background: '#fef3c7' },
};

function elapsed(seconds: number): string {
  const minutes = Math.floor(seconds / 60);
  return minutes ? `${minutes}m ${String(seconds % 60).padStart(2, '0')}s` : `${seconds}s`;
}

/** The newest run snapshot carried by `automap.progress` activity events. */
export function latestRunProgress(events: ProgressEvent[]): RunProgressSnapshot | null {
  let latest: ProgressEvent | null = null;
  for (const event of events) {
    if (event.kind !== 'progress' || !event.details.progress) continue;
    if (!latest || event.timestamp >= latest.timestamp) latest = event;
  }
  const raw = latest?.details.progress as Record<string, unknown> | undefined;
  if (!raw || typeof raw.targets !== 'object' || !raw.targets) return null;
  return {
    targets: raw.targets as Record<string, RunProgressPhase>,
    done: Number(raw.done ?? 0),
    total: Number(raw.total ?? 0),
    elapsedSeconds: Number(raw.elapsed_seconds ?? 0),
  };
}

/** One chip per target with its phase; overall done/total and elapsed time. */
export function MigrationProgressStrip({ progress }: { progress: RunProgressSnapshot }) {
  const targets = useMemo(() => Object.entries(progress.targets), [progress.targets]);
  if (!targets.length) return null;
  return (
    <AiaBox role="status" aria-live="polite" sx={{ px: 1, pb: 0.75 }}>
      <AiaText sx={{ fontSize: 10, color: '#475569', mb: 0.5 }}>
        {progress.done}/{progress.total} targets finished · {elapsed(progress.elapsedSeconds)}
      </AiaText>
      <AiaBox sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
        {targets.map(([target, phase]) => {
          const style = PHASE_STYLE[phase] ?? PHASE_STYLE.queued;
          return (
            <AiaTooltip key={target} title={`${target}: ${style.label}`}>
              <AiaBox
                component="span"
                sx={{
                  fontSize: 10, lineHeight: '18px', px: 0.75, borderRadius: 999,
                  color: style.color, backgroundColor: style.background, border: `1px solid ${style.color}33`,
                }}
              >
                {target}
              </AiaBox>
            </AiaTooltip>
          );
        })}
      </AiaBox>
    </AiaBox>
  );
}
