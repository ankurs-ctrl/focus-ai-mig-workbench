FIR 2.0 final cumulative hotfix for the 20260717-1730 client source release

Included fixes
- Project and mapping precedent-link storage and creation UI.
- Recommendation impressions are batched and background FIR telemetry is non-blocking.
- Duplicate global errors are shown once instead of being queued repeatedly.
- Metadata, relationship, semantic refresh, and derived-source requests use endpoint-specific timeouts.
- Stale relationship results are removed when the selected table set changes.
- Auto-map remains AGT_SOURCE_MAPPING-driven when selected joins cannot be published to Cortex Analyst.
- Selected joins and FIR context are still passed directly to the source-mapping service.
- Snowflake SET variables and IDENTIFIER($variable) expressions are resolved for visual SQL parsing.
- Imported mapping rows are merged with target metadata instead of being replaced by blank rows.
- SQL Edit starts with the displayed SQL and SELECT preview edits retain the selected target.
- SQL aliases resolve to physical source tables during parse and diff.
- Preprocessing and derived-source dialogs reserve space for the docked AI Assistant.
- Derived-source validation and save failures remain inline instead of opening repeated global dialogs.

Apply over the 17:30 source
1. Extract this ZIP over the already extracted 20260717-1730 source tree.
2. If the FIR linking migration was already bootstrapped, do not run bootstrap again.
3. If it was not applied, run only:
   .\scripts\bootstrap_sttm_metadata_infra.ps1 -EnvFile ".\infra\snowflake\env\client.env" -LinkingMigrationOnly
4. Rebuild and redeploy the main SPCS application and the separate Auto-map service from this same source version.

Important notes
- No semantic-agent specification or semantic-agent write procedure is included or changed.
- Existing FIR inferences, recommendations, mappings, and learnings must not be deleted.
- Re-importing the same historical asset is idempotent and refreshes its structural projection.
- A shared physical target table is correct when target schema and grain are genuinely shared.
