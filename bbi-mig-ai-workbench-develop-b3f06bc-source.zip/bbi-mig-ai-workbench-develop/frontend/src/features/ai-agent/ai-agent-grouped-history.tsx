"use client";

import { useMemo } from "react";
import { AiaBox, AiaStack } from "@/components/ui";
import { AiaText } from "@/components/ui/aia-text";
import type { StoredChatSession } from "@/features/ai-agent/ai-chat-session-utils";
import { formatSessionRelativeTime } from "@/features/ai-agent/ai-chat-session-utils";
import { ChatBubbleOutlineRoundedIcon } from "@/utils/icons";

type HistoryGroup = {
  label: string;
  sessions: StoredChatSession[];
};

function startOfDay(date: Date) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime();
}

function groupSessionsByRecency(sessions: StoredChatSession[]): HistoryGroup[] {
  const now = new Date();
  const todayStart = startOfDay(now);
  const yesterdayStart = todayStart - 24 * 60 * 60 * 1000;

  const today: StoredChatSession[] = [];
  const yesterday: StoredChatSession[] = [];
  const older: StoredChatSession[] = [];

  for (const session of sessions) {
    if (session.updatedAt >= todayStart) today.push(session);
    else if (session.updatedAt >= yesterdayStart) yesterday.push(session);
    else older.push(session);
  }

  return [
    { label: "TODAY", sessions: today },
    { label: "YESTERDAY", sessions: yesterday },
    { label: "OLDER", sessions: older },
  ].filter((group) => group.sessions.length > 0);
}

type AiAgentGroupedHistoryProps = {
  sessions: StoredChatSession[];
  searchQuery: string;
  activeSessionId: string | null;
  onSelectSession: (session: StoredChatSession) => void;
};

export function AiAgentGroupedHistory({
  sessions,
  searchQuery,
  activeSessionId,
  onSelectSession,
}: AiAgentGroupedHistoryProps) {
  const normalizedQuery = searchQuery.trim().toLowerCase();
  const filteredSessions = useMemo(
    () =>
      normalizedQuery
        ? sessions.filter((session) => session.title.toLowerCase().includes(normalizedQuery))
        : sessions,
    [normalizedQuery, sessions],
  );
  const groups = useMemo(() => groupSessionsByRecency(filteredSessions), [filteredSessions]);

  if (filteredSessions.length === 0) {
    return (
      <AiaBox sx={{ flex: 1, minHeight: 0, px: 2, py: 4, textAlign: "center" }}>
        <AiaText sx={{ fontSize: 13, color: "#94A3B8" }}>
          {normalizedQuery ? "No chats match your search." : "No chat history yet."}
        </AiaText>
      </AiaBox>
    );
  }

  return (
    <AiaBox sx={{ flex: 1, minHeight: 0, overflowY: "auto", px: 1.5, pb: 2 }}>
      {groups.map((group) => (
        <AiaBox key={group.label} sx={{ mb: 2 }}>
          <AiaText
            sx={{
              px: 1,
              mb: 0.75,
              fontSize: 11,
              fontWeight: 700,
              letterSpacing: 0.6,
              color: "#94A3B8",
            }}
          >
            {group.label}
          </AiaText>
          <AiaStack spacing={0.25}>
            {group.sessions.map((session) => {
              const isActive = session.id === activeSessionId;
              return (
                <AiaBox
                  key={session.id}
                  component="button"
                  type="button"
                  onClick={() => onSelectSession(session)}
                  sx={{
                    width: "100%",
                    textAlign: "left",
                    border: "none",
                    cursor: "pointer",
                    borderRadius: "10px",
                    px: 1,
                    py: 1,
                    display: "flex",
                    alignItems: "flex-start",
                    gap: 1,
                    backgroundColor: isActive ? "#F1F5F9" : "transparent",
                    "&:hover": { backgroundColor: isActive ? "#F1F5F9" : "#F8FAFC" },
                  }}
                >
                  <ChatBubbleOutlineRoundedIcon
                    sx={{ fontSize: 16, color: "#94A3B8", mt: 0.2, flexShrink: 0 }}
                  />
                  <AiaBox sx={{ minWidth: 0, flex: 1 }}>
                    <AiaText
                      sx={{
                        fontSize: 13,
                        fontWeight: 600,
                        color: "#0F172A",
                        lineHeight: 1.35,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                      }}
                    >
                      {session.title}
                    </AiaText>
                    <AiaText sx={{ mt: 0.2, fontSize: 11, color: "#94A3B8" }}>
                      {formatSessionRelativeTime(session.updatedAt)}
                    </AiaText>
                  </AiaBox>
                </AiaBox>
              );
            })}
          </AiaStack>
        </AiaBox>
      ))}
    </AiaBox>
  );
}
