'use client';
import { AiaBox, AiaButton, AiaIconButton, AiaChip, AiaPaper, AiaTableBody, AiaTableCellPrimitive, AiaTableContainer, AiaTableHead, AiaTablePagination, AiaTablePrimitive, AiaTableRowPrimitive } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { CheckRoundedIcon, CloseRoundedIcon, DeleteOutlinedIcon, FileUploadOutlinedIcon, UndoRoundedIcon } from '@/utils/icons';
import { TOUR_TARGETS } from '@/features/tour/constants/tour-targets';
import { useAiChatLayout } from '@/features/ai-agent/ai-chat-layout-context';
import { useTour } from '@/features/tour/engine/tour-context';

import { useSttmBuilderContext } from '@/features/sttm/context/sttm-builder-context';
import type { MappingMode, MappingState } from '@/features/sttm/types/sttm.types';
import {
  buildSourceColumnOptions,
  manualSourceScopeWarning,
  formatSqlType,
  generateMappingDescription,
  parseSourceColumns,
} from './mapping-utils';
import { firmValueConflictMessage, type NewAttributeFormValues } from '@/features/attributes/attributes-data';
import NewAttributeModal from '@/features/attributes/new-attribute-modal';
import { createProjectAttribute, type ProjectAttributeRecord } from '@/services/projectService';
import { toProjectAttributeSelectOptions, belongsToProject, filterAttributesForProject, notifyProjectAttributesChanged, readFirmValueEdits, resolveMappedFirmValue } from './project-attribute-utils';
import { useProjectAttributes } from './use-project-attributes';
import { AiaCheckbox } from '@/components/ui/aia-checkbox';
import { AiaInput } from '@/components/ui/aia-input';
import { AiaCheckboxCell, AiaInputCell } from '@/components/ui/aia-table';
import {
  MappingConfidenceCell,
  MappingExpandableTextCell,
  MappingRuleCell,
  MappingSourceColumnsCell,
  MappingStatusCell,
  MappingTargetColumnCell,
  MappingTypePreviewCell,
} from './cells';
import type { FIRMappingCandidate } from './cells/mapping-source-columns-cell';
import {
  recommendationService,
  type ApplicableRecommendation,
} from '@/services/recommendationService';
import { MappingDataPreviewCell } from './data-preview';
import { firmValueNamesInExpression } from './firm-value-literal';
import {
  MAPPING_TABLE_CHECKBOX_SX,
  MAPPING_TABLE_CONTAINER_SX,
  MAPPING_SELECTION_BAR_SX,
  MAPPING_TABLE_HEADER_CELL_SX,
  MAPPING_TABLE_HEADER_ROW_HEIGHT,
  MAPPING_TABLE_PAGINATION_SX,
  MAPPING_TABLE_ROW_SX,
  MAPPING_TABLE_SECONDARY_INPUT_SX,
  MAPPING_TABLE_SECONDARY_INPUT_TYPOGRAPHY,
  mappingTableSx,
} from './mapping-table-styles';
import { MappingResizableHeaderCell } from './mapping-resizable-header-cell';
import { MappingHeaderSearchLabel } from './mapping-header-search-label';
import { mappingColumnDividerSx } from './mapping-column-divider';
import {
  getVisibleMappingColumnKeys,
  useMappingColumnWidths,
} from './use-mapping-column-widths';
import {
  CONFIDENCE_GROUP_ORDER,
  countMappingsByConfidenceGroup,
  getConfidenceGroup,
  hasConfidenceScore,
  isSavedManualMapping,
  sortMappingsByConfidenceGroups,
  withPreservedAutoMapConfidence,
  type ConfidenceGroupId,
} from './mapping-confidence-groups';
import { MappingConfidenceGroupHeaderRow } from './mapping-confidence-group-header';
import { MappingChangeConfirmDialog } from './mapping-change-confirm-dialog';
import {
  MAPPED_ROW_CHANGE_MESSAGES,
  useConfirmMappedRowChange,
} from './use-confirm-mapped-row-change';
import { useMappingUndo } from './use-mapping-undo';
import { MappingRowCandidates } from "./mapping-row-candidates";
import { reviewCatalog, mappingDisplayStatus } from './mapping-review-model';
import { useSearchParams } from 'next/navigation';
import DirectSourcePickerModal from './direct-source-picker-modal';

const MAPPING_ACTION_OUTLINED_BUTTON_SX = {
  color: '#0f172a',
  textTransform: 'none',
  fontSize: '0.78rem',
  fontWeight: 600,
  px: 1.25,
  borderColor: '#cbd5e1',
  borderRadius: '8px',
  bgcolor: 'transparent',
  '&:hover': {
    bgcolor: 'rgba(15, 23, 42, 0.06)',
    borderColor: '#94a3b8',
  },
} as const;

const DEFAULT_EXPANDED_CONFIDENCE_GROUPS: Record<ConfidenceGroupId, boolean> = {
  high: true,
  medium: true,
  low: true,
  unmapped: true,
};

const MAPPING_TYPE_DIRECT = 'direct';
const MAPPING_TYPE_ATTRIBUTE = 'attribute';
const MAPPING_TYPE_CUSTOM = 'custom';
const MAPPING_TYPE_UPPER = 'upper';
const MAPPING_TYPE_LOWER = 'lower';
const MAPPING_TYPE_TRIM = 'trim';

const DIRECT_LIKE_MAPPING_TYPES = new Set([
  MAPPING_TYPE_DIRECT,
  MAPPING_TYPE_UPPER,
  MAPPING_TYPE_LOWER,
  MAPPING_TYPE_TRIM,
]);

const AUTO_MAP_NOTICE_DOT_COLOR: Record<string, string> = {
  success: '#4ade80',
  warning: '#fbbf24',
  error: '#f87171',
};

const MAPPING_TYPE_OPTIONS = [
  { label: 'Attribute', value: MAPPING_TYPE_ATTRIBUTE },
  { label: 'Custom', value: MAPPING_TYPE_CUSTOM },
  { label: 'Direct', value: MAPPING_TYPE_DIRECT },
  { label: 'Upper', value: MAPPING_TYPE_UPPER },
  { label: 'Lower', value: MAPPING_TYPE_LOWER },
  { label: 'Trim', value: MAPPING_TYPE_TRIM },
];

const MAPPING_TYPE_FILTER_OPTIONS = [
  { label: 'All', value: '' },
  ...MAPPING_TYPE_OPTIONS,
];

const MAPPING_TYPE_TO_RULE: Record<string, string> = {
  [MAPPING_TYPE_DIRECT]: 'Direct',
  [MAPPING_TYPE_ATTRIBUTE]: 'Direct',
  [MAPPING_TYPE_CUSTOM]: 'Custom',
  [MAPPING_TYPE_UPPER]: 'Upper',
  [MAPPING_TYPE_LOWER]: 'Lower',
  [MAPPING_TYPE_TRIM]: 'Trim',
};

function resolveMappingRuleSelectValue(rule: string | null | undefined): string {
  return rule && rule !== 'Select...' ? rule : '';
}

function resolveMappingTypeSelectValue(row: {
  rule?: string | null;
  mappingMode?: MappingMode | null;
}): string {
  const resolvedRule = resolveMappingRuleSelectValue(row.rule);
  const normalizedRule = resolvedRule.trim().toUpperCase();
  if (normalizedRule === 'CUSTOM') {
    return MAPPING_TYPE_CUSTOM;
  }
  if (row.mappingMode === 'attribute') {
    return MAPPING_TYPE_ATTRIBUTE;
  }
  if (normalizedRule === 'UPPER') {
    return MAPPING_TYPE_UPPER;
  }
  if (normalizedRule === 'LOWER') {
    return MAPPING_TYPE_LOWER;
  }
  if (normalizedRule === 'TRIM') {
    return MAPPING_TYPE_TRIM;
  }
  return MAPPING_TYPE_DIRECT;
}

function isDirectLikeMappingType(mappingType: string): boolean {
  return DIRECT_LIKE_MAPPING_TYPES.has(mappingType);
}

function resolveMappingDescription(
  row: {
    targetColumn: string;
    expression?: string | null;
    description?: string | null;
    descriptionEdited?: boolean;
  },
  sourceColumns: string[],
  resolvedRule: string,
): string {
  const autoDescription = resolvedRule
    ? generateMappingDescription({
        rule: resolvedRule,
        sourceColumns,
        targetColumn: row.targetColumn,
        expression: row.expression,
      })
    : '';

  return row.descriptionEdited ? (row.description ?? '') : autoDescription;
}

const DEFAULT_ROWS_PER_PAGE = 25;
const ROWS_PER_PAGE_OPTIONS = [10, 25, 50, 100];

type MappingColumnFilters = {
  targetColumn: string;
  sourceColumn: string;
  typePreview: string;
  preProcessRule: string;
  nlRule: string;
  order: string;
  description: string;
  status: string;
};

const EMPTY_COLUMN_FILTERS: MappingColumnFilters = {
  targetColumn: '',
  sourceColumn: '',
  typePreview: '',
  preProcessRule: '',
  nlRule: '',
  order: '',
  description: '',
  status: '',
};

const STATUS_FILTER_OPTIONS = [
  { label: 'All', value: '' },
  { label: 'Mapped', value: 'MAPPED' },
  { label: 'Unmapped', value: 'UNMAPPED' },
];

const headerCellSx = MAPPING_TABLE_HEADER_CELL_SX;

/** Default column widths on first render. */
const MAPPING_COLUMN_DEFAULT_WIDTH = {
  checkbox: 52,
  targetColumn: 320,
  sourceColumn: 320,
  preProcessRule: 200,
  confidence: 140,
  typePreview: 190,
  nlRule: 240,
  order: 150,
  description: 280,
  status: 170,
  dataPreview: 180,
} as const;

/** Resize floor — columns can shrink below the default down to these values. */
const MAPPING_COLUMN_MIN_WIDTH = {
  checkbox: 48,
  targetColumn: 220,
  sourceColumn: 200,
  preProcessRule: 180,
  confidence: 120,
  typePreview: 160,
  nlRule: 140,
  order: 120,
  description: 200,
  status: 150,
  dataPreview: 150,
} as const;

const FROZEN_CHECKBOX_LEFT = 0;

const multilineCellInputSx = {
  ...MAPPING_TABLE_SECONDARY_INPUT_SX,
  '& .MuiOutlinedInput-root': {
    ...MAPPING_TABLE_SECONDARY_INPUT_TYPOGRAPHY,
    alignItems: 'flex-start',
    minHeight: 0,
    height: 'auto',
  },
  '& .MuiInputBase-input, & .MuiInputBase-inputMultiline': {
    ...MAPPING_TABLE_SECONDARY_INPUT_TYPOGRAPHY,
    whiteSpace: 'pre-wrap',
    overflowWrap: 'anywhere',
    overflow: 'hidden !important',
  },
} as const;

const mappingBodyInputSx = {
  ...MAPPING_TABLE_SECONDARY_INPUT_SX,
  '& .MuiOutlinedInput-root': {
    ...MAPPING_TABLE_SECONDARY_INPUT_TYPOGRAPHY,
    minHeight: 36,
    borderRadius: '6px',
    bgcolor: '#fff',
  },
  '& .MuiInputBase-input': {
    ...MAPPING_TABLE_SECONDARY_INPUT_TYPOGRAPHY,
    paddingY: '8px !important',
  },
} as const;

function mappingFrozenCellSx(
  left: number,
  options: { header?: boolean; lastFrozen?: boolean; searchRow?: boolean } = {},
) {
  const { header = false, lastFrozen = false, searchRow = false } = options;
  const backgroundColor = header || searchRow ? '#fafafa' : '#fff';

  const zIndex = (() => {
    if (header) {
      return lastFrozen ? 9 : 8;
    }
    if (searchRow) {
      return lastFrozen ? 9 : 8;
    }
    return lastFrozen ? 5 : 4;
  })();

  return {
    position: 'sticky' as const,
    left,
    top: header ? 0 : searchRow ? MAPPING_TABLE_HEADER_ROW_HEIGHT : undefined,
    zIndex,
    bgcolor: backgroundColor,
    backgroundColor,
  };
}

const scrollableBodyCellSx = {
  position: 'relative' as const,
  zIndex: 1,
  bgcolor: '#fff',
  backgroundColor: '#fff',
  ...mappingColumnDividerSx,
} as const;

const scrollableHeaderCellSx = {
  position: 'sticky' as const,
  top: 0,
  zIndex: 2,
  bgcolor: '#fafafa',
  backgroundColor: '#fafafa',
} as const;

const SourceTargetAttributeMapping = () => {
  const { openChat, setPanelView } = useAiChatLayout();
  const {
    mappings,
    sources,
    selectedMappingIds,
    toggleMappingSelection,
    selectAllMappings,
    bulkMarkMapped,
    bulkClearMappings,
    updateMapping,
    cancelPendingManualMappingEdits,
    commitPendingManualMappingEdits,
    setPreProcessModalOpen,
    mappingLoading,
    autoMapStatusMessage,
    autoMapCompletionNotice,
    dismissAutoMapCompletionNotice,
    autoMapProcessingIds,
    autoMapGroupingEnabled,
    pendingManualEditSnapshots,
    sourceAttributeGroups,
    derivedSources,
    drivingTableId,
    relationships,
    fullData,
    activeProjectId,
    activeProjectName,
    activeSttmId,
    flushWorkspace,
    getWorkspaceSnapshot,
  } = useSttmBuilderContext();
  const { notifyTourContextChanged } = useTour();
  const reviewNames = useMemo(() => reviewCatalog(sources, derivedSources), [sources, derivedSources]);
  const reviewSearch = useSearchParams();
  const [reviewFocus, setReviewFocus] = useState<{mappingId: string; section: string; nonce: number} | null>(null);
  const reviewScrollDone = useRef<number | null>(null);
  useEffect(() => {
    const focus = (event?: Event) => {
      const detail = (event as CustomEvent)?.detail;
      const mappingId = detail?.mappingId ?? reviewSearch.get('reviewRow');
      if (!mappingId || !mappings.some(row => row.id === mappingId)) return;
      setReviewFocus({mappingId, section: detail?.section ?? reviewSearch.get('reviewSection') ?? 'candidates', nonce: Date.now()});
      setExpandedConfidenceGroups(DEFAULT_EXPANDED_CONFIDENCE_GROUPS);
    };
    focus(); window.addEventListener('sttm:review-row',focus);
    return () => window.removeEventListener('sttm:review-row',focus);
  }, [reviewSearch, mappings.length]);

  // Keep completion counts available until explicitly dismissed or the next run.

  const [columnFilters, setColumnFilters] = useState<MappingColumnFilters>(EMPTY_COLUMN_FILTERS);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(DEFAULT_ROWS_PER_PAGE);
  const [expandedConfidenceGroups, setExpandedConfidenceGroups] = useState<
    Record<ConfidenceGroupId, boolean>
  >(DEFAULT_EXPANDED_CONFIDENCE_GROUPS);
  const [applicableRecommendations, setApplicableRecommendations] = useState<ApplicableRecommendation[]>([]);
  const [recommendationsUnavailable, setRecommendationsUnavailable] = useState(false);
  const [recommendationRetry, setRecommendationRetry] = useState(0);
  const [recommendationUndoByRow, setRecommendationUndoByRow] = useState<Record<string, {
    sourceColumn: string | null;
    sourceColumns: string[];
    status: import("../types/sttm.types").MappingStatus;
    confidenceScore: number | null;
    confidenceReason: string | null;
    manuallyEditedAfterAutoMap?: boolean;
    usedRecommendationIds: string[];
  }>>({});
  const [recommendationActionErrors, setRecommendationActionErrors] = useState<Record<string, string>>({});
  const [directPickerMappingId, setDirectPickerMappingId] = useState<string | null>(null);
  const [saveConfirmOpen, setSaveConfirmOpen] = useState(false);
  const [savingMappingCount, setSavingMappingCount] = useState(0);
  const [cancelConfirmOpen, setCancelConfirmOpen] = useState(false);
  const [isSavingManualEdits, setIsSavingManualEdits] = useState(false);
  const {
    projectAttributes,
    isLoadingProjectAttributes,
    reloadProjectAttributes,
  } = useProjectAttributes(activeProjectId);
  const {
    pendingChange: pendingMappedRowChange,
    confirmIfMappedRowChange,
    closeConfirm: closeMappedRowChangeConfirm,
    confirmChange: confirmMappedRowChange,
  } = useConfirmMappedRowChange();
  const {
    undoCount,
    canUndo,
    updateMappingWithUndo,
    undoLastChange,
    clearUndoStack,
  } = useMappingUndo(mappings, updateMapping);
  const directPickerMapping = useMemo(
    () => mappings.find((mapping) => mapping.id === directPickerMappingId) ?? null,
    [directPickerMappingId, mappings],
  );
  const dirtyMappingIds = useMemo(
    () => Object.keys(pendingManualEditSnapshots ?? {}),
    [pendingManualEditSnapshots],
  );
  const hasUnsavedManualEdits = dirtyMappingIds.length > 0;
  const manualSaveMappingCount = isSavingManualEdits || !dirtyMappingIds.length
    ? savingMappingCount : dirtyMappingIds.length;
  // Pre-edit rows that decide group and position. Kept through a Save until it
  // succeeds, so edited rows only move to High once they are saved.
  const [savingRankSnapshots, setSavingRankSnapshots] = useState<Record<string, MappingState>>({});
  const confidenceRankSource = useCallback(
    (row: MappingState) => pendingManualEditSnapshots?.[row.id] ?? savingRankSnapshots[row.id] ?? row,
    [pendingManualEditSnapshots, savingRankSnapshots],
  );

  const showConfidenceColumn = useMemo(
    () =>
      autoMapGroupingEnabled
      || hasUnsavedManualEdits
      || mappings.some(
        (row) => hasConfidenceScore(row.confidenceScore) || Boolean(row.manuallySaved),
      ),
    [autoMapGroupingEnabled, hasUnsavedManualEdits, mappings],
  );
  // Rows are always grouped, so a new mapping starts with everything under Unmapped.
  const confidenceGroupingActive = true;
  const visibleColumnKeys = useMemo(
    () => getVisibleMappingColumnKeys(showConfidenceColumn),
    [showConfidenceColumn],
  );
  const { columnWidths, onResizeStart, tableMinWidth, frozenTargetColumnLeft } =
    useMappingColumnWidths(
      MAPPING_COLUMN_DEFAULT_WIDTH,
      MAPPING_COLUMN_MIN_WIDTH,
      visibleColumnKeys,
    );

  const sortedMappings = mappings;
  const { sources: sourceRelations } = useSttmBuilderContext();
  const sourceColumnOptions = buildSourceColumnOptions(sourceAttributeGroups, derivedSources, sourceRelations);
  const [firmValueCreateRowId, setFirmValueCreateRowId] = useState<string | null>(null);
  const [createdFirmValues, setCreatedFirmValues] = useState<ProjectAttributeRecord[]>([]);
  const projectAttributesForActiveProject = useMemo(() => {
    const loaded = filterAttributesForProject(projectAttributes, activeProjectId);
    const seen = new Set(loaded.map((item) => item.attribute_name.trim().toUpperCase()));
    const extras = createdFirmValues.filter(
      (item) => belongsToProject(item, activeProjectId) && !seen.has(item.attribute_name.trim().toUpperCase()),
    );
    return [...loaded, ...extras].sort((left, right) => left.attribute_name.localeCompare(right.attribute_name));
  }, [activeProjectId, createdFirmValues, projectAttributes]);
  const attributeOptions = useMemo(
    () => toProjectAttributeSelectOptions(projectAttributesForActiveProject),
    [projectAttributesForActiveProject],
  );

  useEffect(() => {
    clearUndoStack();
  }, [activeSttmId, clearUndoStack]);

  const allSelected = mappings.length > 0 && selectedMappingIds.length === mappings.length;
  const someSelected = selectedMappingIds.length > 0 && selectedMappingIds.length < mappings.length;
  const selectedMappedCount = mappings.filter(
    (row) => selectedMappingIds.includes(row.id) && row.status === 'MAPPED',
  ).length;
  const clearSelection = () =>
    selectAllMappings(
      mappings.map((row) => row.id),
      false,
    );

  const mappingsRef = useRef(mappings);
  mappingsRef.current = mappings;

  useEffect(() => {
    if (isLoadingProjectAttributes || !activeProjectId) {
      return;
    }
    const notes = readFirmValueEdits(activeProjectId);
    for (const row of mappingsRef.current) {
      if (row.mappingMode !== 'attribute') {
        continue;
      }
      const name = row.attributeName?.trim();
      if (!name) {
        continue;
      }
      const attribute = resolveMappedFirmValue(name, projectAttributesForActiveProject, notes);
      if (!attribute) {
        continue;
      }
      const nextName = attribute.attribute_name;
      const nextValue = attribute.attribute_value ?? '';
      const nextType = attribute.attribute_type || null;
      const updates: Partial<typeof row> = {};
      if (row.attributeName !== nextName) {
        updates.attributeName = nextName;
      }
      if ((row.constantValue ?? '') !== nextValue) {
        updates.constantValue = nextValue;
      }
      if ((row.sourceType ?? null) !== nextType) {
        updates.sourceType = nextType;
      }
      if (updates.attributeName && !row.descriptionEdited) {
        updates.description = `Assign the firm value ${nextName} to ${row.targetColumn}.`;
      }
      if (Object.keys(updates).length > 0) {
        updateMapping(row.id, updates);
      }
    }
  }, [
    activeProjectId,
    isLoadingProjectAttributes,
    mappings,
    projectAttributesForActiveProject,
    updateMapping,
  ]);

  const handleMappingTypeChange = useCallback((id: string, mappingType: string) => {
    const row = mappingsRef.current.find((mapping) => mapping.id === id);
    if (!row) return;

    const previousType = resolveMappingTypeSelectValue(row);
    const preserveDirectLikeSource =
      isDirectLikeMappingType(previousType) && isDirectLikeMappingType(mappingType);

    const updates: Partial<typeof row> = preserveDirectLikeSource
      ? {
          // Keep Direct / Upper / Lower / Trim source pick; only swap the rule wrapper.
          expression: null,
          constantValue: null,
          attributeName: null,
          mappingMode: 'source',
        }
      : {
          // Leaving Direct-like (or entering Attribute/Custom) clears source bindings.
          sourceColumn: null,
          sourceColumns: [],
          sourceType: null,
          expression: null,
          constantValue: null,
          attributeName: null,
          candidateSourceColumns: [],
          usedInferenceIds: [],
          usedRecommendationIds: [],
          usedLearningIds: [],
          status: 'UNMAPPED',
        };

    if (mappingType === MAPPING_TYPE_CUSTOM) {
      updates.rule = MAPPING_TYPE_TO_RULE[MAPPING_TYPE_CUSTOM];
      updates.mappingMode = 'source';
    } else if (mappingType === MAPPING_TYPE_ATTRIBUTE) {
      updates.rule = MAPPING_TYPE_TO_RULE[MAPPING_TYPE_ATTRIBUTE];
      updates.mappingMode = 'attribute';
    } else if (isDirectLikeMappingType(mappingType)) {
      updates.rule = MAPPING_TYPE_TO_RULE[mappingType] ?? 'Direct';
      updates.mappingMode = 'source';
      if (preserveDirectLikeSource) {
        const hasSource = Boolean(
          String(row.sourceColumn ?? '').trim()
          || (row.sourceColumns ?? []).some((column) => Boolean(String(column ?? '').trim())),
        );
        updates.status = hasSource ? 'MAPPED' : 'UNMAPPED';
      }
    } else {
      updates.rule = 'Direct';
      updates.mappingMode = 'source';
    }

    const nextRule = (updates.rule ?? row.rule) as string;
    if (!row.descriptionEdited) {
      updates.description =
        generateMappingDescription({
          rule: nextRule,
          sourceColumns: preserveDirectLikeSource
            ? (row.sourceColumns?.length
              ? row.sourceColumns
              : parseSourceColumns(row.sourceColumn))
            : [],
          targetColumn: row.targetColumn,
          expression: null,
        }) || null;
    }

    updateMappingWithUndo(id, withPreservedAutoMapConfidence(row, updates));
  }, [updateMappingWithUndo]);

  const handleCancelManualEdits = useCallback(() => {
    cancelPendingManualMappingEdits();
    setSavingRankSnapshots({});
    clearUndoStack();
    setSaveConfirmOpen(false);
    setCancelConfirmOpen(false);
  }, [cancelPendingManualMappingEdits, clearUndoStack]);

  const handleConfirmSaveManualEdits = useCallback(async () => {
    if ((!hasUnsavedManualEdits && !saveConfirmOpen) || isSavingManualEdits) return;
    setSavingMappingCount(dirtyMappingIds.length || savingMappingCount);
    setIsSavingManualEdits(true);
    setSavingRankSnapshots((held) => ({ ...held, ...pendingManualEditSnapshots }));
    try {
      commitPendingManualMappingEdits();
      await flushWorkspace();
      setSavingRankSnapshots({});
      clearUndoStack();
      setSaveConfirmOpen(false);
      setCancelConfirmOpen(false);
    } catch (error) {
      // The provider displays the save error; keep this dialog open for retry.
      console.warn('Unable to save manual mapping edits.', error);
    } finally {
      setIsSavingManualEdits(false);
    }
  }, [
    clearUndoStack,
    commitPendingManualMappingEdits,
    flushWorkspace,
    hasUnsavedManualEdits,
    isSavingManualEdits,
    pendingManualEditSnapshots,
    saveConfirmOpen,
    dirtyMappingIds.length,
    savingMappingCount,
  ]);

  const filteredMappings = useMemo(() => {
    const includes = (value: string | null | undefined, query: string) =>
      String(value ?? '').toLowerCase().includes(query.trim().toLowerCase());

    return sortedMappings.filter((row) => {
      if (row.id === reviewFocus?.mappingId) return true;
      const previewType = formatSqlType(row.sourceType ?? row.targetType ?? undefined);
      const sourceColumns =
        row.sourceColumns && row.sourceColumns.length
          ? row.sourceColumns
          : parseSourceColumns(row.sourceColumn);
      const resolvedRule = resolveMappingRuleSelectValue(row.rule);
      const descriptionValue = resolveMappingDescription(row, sourceColumns, resolvedRule);

      if (columnFilters.targetColumn && !includes(row.targetColumn, columnFilters.targetColumn)) {
        return false;
      }
      if (
        columnFilters.sourceColumn
        && !includes(
          row.mappingMode === "constant"
            ? row.constantValue
            : row.mappingMode === "attribute"
              ? row.attributeName
              : row.sourceColumn,
          columnFilters.sourceColumn,
        )
      ) {
        return false;
      }
      if (columnFilters.typePreview && !includes(previewType, columnFilters.typePreview)) {
        return false;
      }
      if (columnFilters.preProcessRule) {
        if (resolveMappingTypeSelectValue(row) !== columnFilters.preProcessRule) {
          return false;
        }
      }
      if (columnFilters.nlRule && !includes(row.nlRule, columnFilters.nlRule)) {
        return false;
      }
      if (columnFilters.order && !includes(row.loadOrder, columnFilters.order)) {
        return false;
      }
      if (columnFilters.description && !includes(descriptionValue, columnFilters.description)) {
        return false;
      }
      if (columnFilters.status && mappingDisplayStatus(row) !== columnFilters.status) {
        return false;
      }
      return true;
    });
  }, [columnFilters, sortedMappings, reviewFocus]);

  useEffect(() => {
    if (selectedMappingIds.length > 0) {
      notifyTourContextChanged();
    }
  }, [notifyTourContextChanged, selectedMappingIds.length]);

  const sortedForDisplay = useMemo(() => {
    if (!confidenceGroupingActive) {
      return filteredMappings;
    }
    return sortMappingsByConfidenceGroups(filteredMappings, confidenceRankSource);
  }, [confidenceGroupingActive, confidenceRankSource, filteredMappings]);

  const confidenceGroupCounts = useMemo(
    () => countMappingsByConfidenceGroup(filteredMappings, confidenceRankSource),
    [confidenceRankSource, filteredMappings],
  );

  const toggleConfidenceGroup = (groupId: ConfidenceGroupId) => {
    setExpandedConfidenceGroups((prev) => ({
      ...prev,
      [groupId]: !prev[groupId],
    }));
    setPage(0);
  };

  /** Rows that remain visible after collapsing confidence groups (pagination counts these). */
  const expandableRowsForDisplay = useMemo(() => {
    if (!confidenceGroupingActive) {
      return sortedForDisplay;
    }
    return sortedForDisplay.filter((row) => {
      const groupId = getConfidenceGroup(confidenceRankSource(row));
      return expandedConfidenceGroups[groupId] !== false;
    });
  }, [confidenceGroupingActive, confidenceRankSource, sortedForDisplay, expandedConfidenceGroups]);

  type MappingTableBodyItem =
    | { kind: 'header'; groupId: ConfidenceGroupId }
    | { kind: 'row'; row: (typeof sortedForDisplay)[number] };

  const mappingTableBodyItems = useMemo((): MappingTableBodyItem[] => {
    if (!confidenceGroupingActive) {
      return expandableRowsForDisplay.map((row) => ({ kind: 'row' as const, row }));
    }

    const items: MappingTableBodyItem[] = [];
    for (const groupId of CONFIDENCE_GROUP_ORDER) {
      const groupRows = sortedForDisplay.filter(
        (row) => getConfidenceGroup(confidenceRankSource(row)) === groupId,
      );
      if (!groupRows.length) {
        continue;
      }
      items.push({ kind: 'header', groupId });
      if (expandedConfidenceGroups[groupId] !== false) {
        for (const row of groupRows) {
          items.push({ kind: 'row', row });
        }
      }
    }
    return items;
  }, [
    confidenceGroupingActive,
    confidenceRankSource,
    expandableRowsForDisplay,
    sortedForDisplay,
    expandedConfidenceGroups,
  ]);

  useEffect(() => {
    if (confidenceGroupingActive) {
      setPage(0);
    }
  }, [confidenceGroupingActive]);

  const maxPage = Math.max(0, Math.ceil(expandableRowsForDisplay.length / rowsPerPage) - 1);
  const safePage = Math.min(page, maxPage);

  const paginatedBodyItems = useMemo((): MappingTableBodyItem[] => {
    if (!confidenceGroupingActive) {
      const start = safePage * rowsPerPage;
      return mappingTableBodyItems.slice(start, start + rowsPerPage);
    }

    const start = safePage * rowsPerPage;
    const end = start + rowsPerPage;
    const pageItems: MappingTableBodyItem[] = [];
    let rowIndex = 0;
    let pendingHeader: MappingTableBodyItem | null = null;

    for (const item of mappingTableBodyItems) {
      if (item.kind === 'header') {
        const isExpanded = expandedConfidenceGroups[item.groupId] !== false;
        if (!isExpanded) {
          // Collapsed groups still show their header in the correct order without using a row slot.
          const isOnPage =
            (rowIndex >= start && rowIndex < end)
            || (
              rowIndex === end
              && end === expandableRowsForDisplay.length
              && end > start
              && safePage === maxPage
            );
          if (isOnPage) {
            pageItems.push(item);
          }
          pendingHeader = null;
          continue;
        }
        pendingHeader = item;
        continue;
      }

      if (rowIndex >= start && rowIndex < end) {
        if (pendingHeader) {
          pageItems.push(pendingHeader);
          pendingHeader = null;
        }
        pageItems.push(item);
      } else {
        pendingHeader = null;
      }
      rowIndex += 1;
    }

    return pageItems;
  }, [
    confidenceGroupingActive,
    mappingTableBodyItems,
    safePage,
    rowsPerPage,
    expandedConfidenceGroups,
    expandableRowsForDisplay.length,
    maxPage,
  ]);

  useEffect(() => {
    if (!reviewFocus || reviewScrollDone.current === reviewFocus.nonce) return;
    const index = expandableRowsForDisplay.findIndex(row => row.id === reviewFocus.mappingId);
    if (index < 0) return;
    const destination = Math.floor(index / rowsPerPage);
    if (page !== destination) { setPage(destination); return; }
    const frame = requestAnimationFrame(() => {
      const element = document.getElementById(`mapping-row-${reviewFocus.mappingId}`);
      if (element) { element.scrollIntoView({block:'center',behavior:'smooth'}); reviewScrollDone.current = reviewFocus.nonce; }
    });
    return () => cancelAnimationFrame(frame);
  }, [reviewFocus, expandableRowsForDisplay, rowsPerPage, page, paginatedBodyItems]);

  const paginatedMappings = useMemo(
    () =>
      paginatedBodyItems
        .filter((item): item is Extract<MappingTableBodyItem, { kind: 'row' }> => item.kind === 'row')
        .map((item) => item.row),
    [paginatedBodyItems],
  );

  // Depend on target identity, not row object churn from Auto-map/progress.
  const recommendationTargetsKey = JSON.stringify(paginatedMappings.map((row) => row.targetColumn));
  useEffect(() => {
    setApplicableRecommendations([]);
    setRecommendationsUnavailable(false);
  }, [activeProjectId, activeSttmId]);

  useEffect(() => {
    const targetColumns: string[] = JSON.parse(recommendationTargetsKey);
    if (!activeProjectId || !activeSttmId || !targetColumns.length) {
      return;
    }
    const controller = new AbortController();
    void recommendationService.listApplicable({
      projectId: activeProjectId,
      sttmId: activeSttmId,
      workflowStage: 'mapping',
      targetColumns,
      limit: Math.min(200, targetColumns.length * 3),
      signal: controller.signal,
    }).then((items) => {
      if (controller.signal.aborted) return;
      setApplicableRecommendations(items);
      setRecommendationsUnavailable(false);
    }).catch(() => {
      if (!controller.signal.aborted) setRecommendationsUnavailable(true);
    });
    return () => controller.abort();
  }, [activeProjectId, activeSttmId, recommendationTargetsKey, recommendationRetry]);

  const firCandidatesByTarget = useMemo(() => {
    const result = new Map<string, FIRMappingCandidate[]>();
    if (!activeProjectId || !activeSttmId) return result;
    for (const recommendation of applicableRecommendations) {
      const target = String(
        recommendation.target_entity.target_column
        ?? recommendation.target_entity.column
        ?? '',
      ).toUpperCase();
      if (!target) continue;
      const payload = recommendation.action_payload;
      const rawSources = payload.source_columns
        ?? payload.candidate_source_columns
        ?? (payload.source_column
          ? [payload.source_column]
          : recommendation.candidate_sources);
      const sources = Array.isArray(rawSources) ? rawSources : [rawSources];
      const sourceColumn = sources
        .map((item) => (
          typeof item === 'string'
            ? item
            : item && typeof item === 'object'
              ? String(
                  (item as Record<string, unknown>).source_column
                  ?? (item as Record<string, unknown>).column
                  ?? (item as Record<string, unknown>).fqn
                  ?? '',
                )
              : ''
        ))
        .find(Boolean);
      const candidate: FIRMappingCandidate = {
        recommendationId: recommendation.recommendation_id,
        sourceColumn: sourceColumn ?? null,
        title: recommendation.title,
        businessRationale: recommendation.business_rationale,
        evidenceSummary: recommendation.evidence_summary,
        confidence: recommendation.confidence,
        compatibilityTier: recommendation.compatibility_tier,
        missingDependencies: recommendation.missing_dependencies,
        canApply: recommendation.can_apply,
        blockedReasons: recommendation.blocked_reasons,
        actionKind: recommendation.action_kind,
        expectedWorkspaceHash: recommendation.expected_workspace_hash,
      };
      result.set(target, [...(result.get(target) ?? []), candidate].slice(0, 3));
    }
    return result;
  }, [activeProjectId, activeSttmId, applicableRecommendations]);

  const handleCreateFirmValue = async (values: NewAttributeFormValues) => {
    if (!activeProjectId || !firmValueCreateRowId) {
      throw new Error("Project context is required.");
    }
    const conflict = firmValueConflictMessage(
      projectAttributesForActiveProject.map((item) => ({
        id: item.attribute_id,
        attributeName: item.attribute_name,
        attributeValue: item.attribute_value,
      })),
      {
        attributeName: values.attributeName,
        attributeValue: values.attributeValue,
      },
    );
    if (conflict) {
      throw new Error(conflict);
    }
    const record = await createProjectAttribute(activeProjectId, {
      attribute_name: values.attributeName,
      attribute_type: values.attributeType,
      attribute_value: values.attributeValue,
    });
    setCreatedFirmValues((current) => [...current, record]);
    notifyProjectAttributesChanged(activeProjectId);
    await reloadProjectAttributes();
    const row = mappingsRef.current.find((mapping) => mapping.id === firmValueCreateRowId);
    if (!row || resolveMappingTypeSelectValue(row) !== MAPPING_TYPE_ATTRIBUTE) {
      return;
    }
    updateMappingWithUndo(
      row.id,
      withPreservedAutoMapConfidence(row, {
        mappingMode: "attribute",
        attributeName: record.attribute_name,
        constantValue: record.attribute_value,
        sourceColumn: null,
        sourceColumns: [],
        sourceType: record.attribute_type,
        expression: null,
        rule: "Direct",
        status: "MAPPED",
        confidenceReason: "A firm value was assigned manually.",
        usedInferenceIds: [],
        usedRecommendationIds: [],
        usedLearningIds: [],
        description: row.descriptionEdited
          ? row.description
          : `Assign the firm value ${record.attribute_name.trim()} to ${row.targetColumn}.`,
      }),
    );
  };

  const updateColumnFilter = (key: keyof MappingColumnFilters, value: string) => {
    setPage(0);
    setColumnFilters((current) => ({
      ...current,
      [key]: value,
    }));
  };

  return (
    <AiaBox
      sx={{
        width: '100%',
        flex: 1,
        minHeight: 0,
        minWidth: 0,
        display: 'flex',
        flexDirection: 'column',
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      {recommendationsUnavailable && (
        <AiaBox role="status" sx={{ display: 'flex', alignItems: 'center', gap: 1, px: 1 }}>
          <AiaText>Optional recommendations are unavailable. Mapping and saving remain available.</AiaText>
          <AiaButton size="small" onClick={() => setRecommendationRetry((value) => value + 1)}>Retry recommendations</AiaButton>
        </AiaBox>
      )}
      {(selectedMappingIds.length > 0 || canUndo || hasUnsavedManualEdits) && (
      <AiaBox data-tour={TOUR_TARGETS.sttmRowSelectionBar} sx={MAPPING_SELECTION_BAR_SX}>
        <AiaBox sx={{ display: 'flex', alignItems: 'center', gap: 1.25, minWidth: 0 }}>
          {selectedMappingIds.length > 0 ? (
            <>
              <AiaText sx={{ fontSize: '0.85rem', fontWeight: 700, color: '#0f172a', whiteSpace: 'nowrap' }}>
                {selectedMappingIds.length} row{selectedMappingIds.length === 1 ? '' : 's'} selected
              </AiaText>
              <AiaText
                sx={{ fontSize: '0.78rem', fontWeight: 500, color: '#64748b', whiteSpace: 'nowrap' }}
              >
                ({selectedMappedCount} mapped)
              </AiaText>
            </>
          ) : hasUnsavedManualEdits ? (
            <AiaText sx={{ fontSize: '0.85rem', fontWeight: 700, color: '#0f172a', whiteSpace: 'nowrap' }}>
              {dirtyMappingIds.length} unsaved edit{dirtyMappingIds.length === 1 ? '' : 's'}
            </AiaText>
          ) : null}
        </AiaBox>

        <AiaBox sx={{ display: 'flex', alignItems: 'center', gap: 0.75 }}>
          <AiaButton
            variant="outlined"
            size="small"
            disabled={!canUndo}
            startIcon={<UndoRoundedIcon sx={{ fontSize: 16 }} />}
            onClick={undoLastChange}
            sx={MAPPING_ACTION_OUTLINED_BUTTON_SX}
          >
            Undo{undoCount > 0 ? ` (${undoCount})` : ''}
          </AiaButton>
          {hasUnsavedManualEdits ? (
            <>
              <AiaButton
                variant="outlined"
                size="small"
                disabled={isSavingManualEdits}
                onClick={() => setCancelConfirmOpen(true)}
                sx={MAPPING_ACTION_OUTLINED_BUTTON_SX}
              >
                Cancel
              </AiaButton>
              <AiaButton
                size="small"
                disabled={isSavingManualEdits}
                startIcon={<CheckRoundedIcon sx={{ fontSize: 16 }} />}
                onClick={() => setSaveConfirmOpen(true)}
                sx={{
                  color: 'var(--aia-primary-bg-text-color)',
                  bgcolor: 'var(--aia-primary-bg-color)',
                  textTransform: 'none',
                  fontSize: '0.78rem',
                  fontWeight: 700,
                  px: 1.5,
                  borderRadius: '8px',
                  boxShadow: 'none',
                  '&:hover': {
                    bgcolor: 'var(--aia-primary-bg-hover-color)',
                    boxShadow: 'none',
                  },
                  '&.Mui-disabled': {
                    bgcolor: '#cbd5e1',
                    color: '#64748b',
                  },
                }}
              >
                {isSavingManualEdits ? 'Saving...' : 'Save'}
              </AiaButton>
            </>
          ) : null}
          {selectedMappingIds.length > 0 ? (
            <>
            <AiaButton
              variant="outlined"
              size="small"
              disabled={selectedMappedCount === 0}
              startIcon={<DeleteOutlinedIcon sx={{ fontSize: 16 }} />}
              onClick={() => bulkClearMappings(selectedMappingIds)}
              sx={MAPPING_ACTION_OUTLINED_BUTTON_SX}
            >
              Clear Mapping
            </AiaButton>
            <AiaButton
              data-tour={TOUR_TARGETS.sttmMarkMapped}
              variant="outlined"
              size="small"
              startIcon={<CheckRoundedIcon sx={{ fontSize: 16 }} />}
              onClick={() => bulkMarkMapped(selectedMappingIds)}
              sx={MAPPING_ACTION_OUTLINED_BUTTON_SX}
            >
              Mark Mapped
            </AiaButton>
            <AiaButton
              data-tour={TOUR_TARGETS.sttmPublishRowMapping}
              size="small"
              startIcon={<FileUploadOutlinedIcon sx={{ fontSize: 16 }} />}
              sx={{
                color: 'var(--aia-primary-bg-text-color)',
                bgcolor: 'var(--aia-primary-bg-color)',
                textTransform: 'none',
                fontSize: '0.78rem',
                fontWeight: 700,
                px: 1.5,
                ml: 0.5,
                borderRadius: '8px',
                boxShadow: 'none',
                '&:hover': {
                  bgcolor: 'var(--aia-primary-bg-hover-color)',
                  boxShadow: 'none',
                },
              }}
            >
              Publish {selectedMappingIds.length} Mapping{selectedMappingIds.length === 1 ? '' : 's'}
            </AiaButton>
            <AiaIconButton
              size="small"
              onClick={clearSelection}
              sx={{ color: '#64748b', ml: 0.25, '&:hover': { color: '#0f172a', bgcolor: 'rgba(15, 23, 42, 0.06)' } }}
            >
              <CloseRoundedIcon sx={{ fontSize: 18 }} />
            </AiaIconButton>
            </>
          ) : null}
        </AiaBox>
      </AiaBox>
      )}

      <AiaTableContainer
        component={AiaPaper}
        elevation={0}
        data-tour={TOUR_TARGETS.sttmMappingGrid}
        sx={MAPPING_TABLE_CONTAINER_SX}
      >
          <AiaTablePrimitive
            stickyHeader
            size="small"
            sx={mappingTableSx(tableMinWidth)}
          >
          <colgroup>
            {visibleColumnKeys.map((key) => (
              <col key={key} style={{ width: columnWidths[key] }} />
            ))}
          </colgroup>
          <AiaTableHead>
            <AiaTableRowPrimitive>
              <MappingResizableHeaderCell
                padding="none"
                width={columnWidths.checkbox}
                minWidth={MAPPING_COLUMN_MIN_WIDTH.checkbox}
                resizeKey="checkbox"
                onResizeStart={onResizeStart}
                sx={{
                  ...headerCellSx,
                  ...mappingFrozenCellSx(FROZEN_CHECKBOX_LEFT, { header: true }),
                  px: 0,
                  textAlign: 'center',
                  verticalAlign: 'middle',
                }}
              >
                <AiaBox
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    width: '100%',
                    minHeight: MAPPING_TABLE_HEADER_ROW_HEIGHT,
                  }}
                >
                  <AiaCheckbox
                    checked={allSelected}
                    indeterminate={someSelected}
                    checkHandler={(checked: boolean) =>
                      selectAllMappings(
                        mappings.map((row) => row.id),
                        checked,
                      )
                    }
                    sx={MAPPING_TABLE_CHECKBOX_SX}
                  />
                </AiaBox>
              </MappingResizableHeaderCell>
              <MappingResizableHeaderCell
                data-tour={TOUR_TARGETS.sttmTargetColumn}
                width={columnWidths.targetColumn}
                minWidth={MAPPING_COLUMN_MIN_WIDTH.targetColumn}
                resizeKey="targetColumn"
                onResizeStart={onResizeStart}
                sx={{
                  ...headerCellSx,
                  ...mappingFrozenCellSx(frozenTargetColumnLeft, {
                    header: true,
                    lastFrozen: true,
                  }),
                }}
              >
                <MappingHeaderSearchLabel
                  title="Target Column"
                  value={columnFilters.targetColumn}
                  onChange={(value) => updateColumnFilter('targetColumn', value)}
                />
              </MappingResizableHeaderCell>
              <MappingResizableHeaderCell
                width={columnWidths.preProcessRule}
                minWidth={MAPPING_COLUMN_MIN_WIDTH.preProcessRule}
                resizeKey="preProcessRule"
                onResizeStart={onResizeStart}
                sx={{
                  ...headerCellSx,
                  ...scrollableHeaderCellSx,
                }}
              >
                <MappingHeaderSearchLabel
                  title="Transform Rule"
                  data-tour={TOUR_TARGETS.sttmTransformRuleColumn}
                  value={columnFilters.preProcessRule}
                  mode="select"
                  options={MAPPING_TYPE_FILTER_OPTIONS}
                  placeholder="All"
                  onChange={(value) => updateColumnFilter('preProcessRule', value)}
                />
              </MappingResizableHeaderCell>
              <MappingResizableHeaderCell
                width={columnWidths.sourceColumn}
                minWidth={MAPPING_COLUMN_MIN_WIDTH.sourceColumn}
                resizeKey="sourceColumn"
                onResizeStart={onResizeStart}
                sx={{
                  ...headerCellSx,
                  ...scrollableHeaderCellSx,
                }}
              >
                <MappingHeaderSearchLabel
                  title="Source Column"
                  data-tour={TOUR_TARGETS.sttmSourceColumn}
                  value={columnFilters.sourceColumn}
                  onChange={(value) => updateColumnFilter('sourceColumn', value)}
                />
              </MappingResizableHeaderCell>
              {showConfidenceColumn ? (
                <MappingResizableHeaderCell
                  width={columnWidths.confidence}
                  minWidth={MAPPING_COLUMN_MIN_WIDTH.confidence}
                  resizeKey="confidence"
                  onResizeStart={onResizeStart}
                  sx={{
                    ...headerCellSx,
                    ...scrollableHeaderCellSx,
                  }}
                >
                  Confidence
                </MappingResizableHeaderCell>
              ) : null}
              <MappingResizableHeaderCell
                width={columnWidths.typePreview}
                minWidth={MAPPING_COLUMN_MIN_WIDTH.typePreview}
                resizeKey="typePreview"
                onResizeStart={onResizeStart}
                sx={{
                  ...headerCellSx,
                  ...scrollableHeaderCellSx,
                  whiteSpace: 'nowrap',
                }}
              >
                <MappingHeaderSearchLabel
                  title="Type (Preview)"
                  value={columnFilters.typePreview}
                  onChange={(value) => updateColumnFilter('typePreview', value)}
                />
              </MappingResizableHeaderCell>
              <MappingResizableHeaderCell
                data-tour={TOUR_TARGETS.sttmNlRuleColumn}
                width={columnWidths.nlRule}
                minWidth={MAPPING_COLUMN_MIN_WIDTH.nlRule}
                resizeKey="nlRule"
                onResizeStart={onResizeStart}
                sx={{
                  ...headerCellSx,
                  ...scrollableHeaderCellSx,
                }}
              >
                <MappingHeaderSearchLabel
                  title="NL Rule"
                  value={columnFilters.nlRule}
                  onChange={(value) => updateColumnFilter('nlRule', value)}
                />
              </MappingResizableHeaderCell>
              <MappingResizableHeaderCell
                width={columnWidths.order}
                minWidth={MAPPING_COLUMN_MIN_WIDTH.order}
                resizeKey="order"
                onResizeStart={onResizeStart}
                sx={{
                  ...headerCellSx,
                  ...scrollableHeaderCellSx,
                }}
              >
                <MappingHeaderSearchLabel
                  title="Order"
                  value={columnFilters.order}
                  onChange={(value) => updateColumnFilter('order', value)}
                />
              </MappingResizableHeaderCell>
              <MappingResizableHeaderCell
                data-tour={TOUR_TARGETS.sttmDescriptionAi}
                width={columnWidths.description}
                minWidth={MAPPING_COLUMN_MIN_WIDTH.description}
                resizeKey="description"
                onResizeStart={onResizeStart}
                sx={{
                  ...headerCellSx,
                  ...scrollableHeaderCellSx,
                }}
              >
                <MappingHeaderSearchLabel
                  title={(
                    <AiaBox sx={{ display: 'flex', alignItems: 'center', gap: 0.75, minWidth: 0 }}>
                      <AiaText
                        component="span"
                        sx={{
                          fontSize: 'inherit',
                          fontWeight: 'inherit',
                          color: 'inherit',
                          whiteSpace: 'nowrap',
                        }}
                      >
                        Description
                      </AiaText>
                      <AiaChip label="AI" size="small" color="primary" sx={{ height: 18, fontSize: '0.6rem', fontWeight: 800 }} />
                    </AiaBox>
                  )}
                  value={columnFilters.description}
                  onChange={(value) => updateColumnFilter('description', value)}
                />
              </MappingResizableHeaderCell>
              <MappingResizableHeaderCell
                data-tour={TOUR_TARGETS.sttmMappedStatus}
                width={columnWidths.status}
                minWidth={MAPPING_COLUMN_MIN_WIDTH.status}
                resizeKey="status"
                onResizeStart={onResizeStart}
                sx={{
                  ...headerCellSx,
                  ...scrollableHeaderCellSx,
                }}
              >
                <MappingHeaderSearchLabel
                  title="Status"
                  value={columnFilters.status}
                  mode="select"
                  options={STATUS_FILTER_OPTIONS}
                  placeholder="All"
                  onChange={(value) => updateColumnFilter('status', value)}
                />
              </MappingResizableHeaderCell>
              <MappingResizableHeaderCell
                width={columnWidths.dataPreview}
                minWidth={MAPPING_COLUMN_MIN_WIDTH.dataPreview}
                resizeKey="dataPreview"
                onResizeStart={onResizeStart}
                sx={{
                  ...headerCellSx,
                  ...scrollableHeaderCellSx,
                  whiteSpace: 'nowrap',
                }}
              >
                Data Preview
              </MappingResizableHeaderCell>
            </AiaTableRowPrimitive>
          </AiaTableHead>
          <AiaTableBody>
            {paginatedBodyItems.map((item) => {
              if (item.kind === 'header') {
                return (
                  <MappingConfidenceGroupHeaderRow
                    key={`confidence-group-${item.groupId}`}
                    groupId={item.groupId}
                    rowCount={confidenceGroupCounts[item.groupId]}
                    colSpan={visibleColumnKeys.length}
                    expanded={expandedConfidenceGroups[item.groupId] !== false}
                    onToggle={() => toggleConfidenceGroup(item.groupId)}
                  />
                );
              }

              const row = item.row;
              const isSelected = selectedMappingIds.includes(row.id);
              const isProcessing =
                autoMapProcessingIds.includes(row.id) || row.status === 'PROCESSING';
              const previewType = row.sourceType ?? row.targetType ?? undefined;
              const pendingManualEdit = Boolean(
                pendingManualEditSnapshots?.[row.id] || savingRankSnapshots[row.id],
              );
              // Mapped by the user (saved, or edited and not saved yet): no AI review links.
              const isManualMapping = pendingManualEdit
                ? row.status !== 'UNMAPPED'
                : isSavedManualMapping(row);
              const sourceColumns =
                row.sourceColumns && row.sourceColumns.length
                  ? row.sourceColumns
                  : parseSourceColumns(row.sourceColumn);
              const resolvedRule = resolveMappingRuleSelectValue(row.rule);
              const descriptionValue = resolveMappingDescription(row, sourceColumns, resolvedRule);
              const descriptionPlaceholder = 'Add description...';
              return (
                <AiaTableRowPrimitive
                  key={row.id}
                  id={`mapping-row-${row.id}`}
                  sx={{...MAPPING_TABLE_ROW_SX, ...(reviewFocus?.mappingId === row.id ? {outline:'2px solid #93c5fd',outlineOffset:-2} : {})}}
                >
                  <AiaCheckboxCell
                    checked={isSelected}
                    onChange={() => toggleMappingSelection(row.id)}
                    width={columnWidths.checkbox}
                    minWidth={MAPPING_COLUMN_MIN_WIDTH.checkbox}
                    checkboxSx={MAPPING_TABLE_CHECKBOX_SX}
                    sx={{
                      ...mappingFrozenCellSx(FROZEN_CHECKBOX_LEFT),
                      ...mappingColumnDividerSx,
                    }}
                  />

                  <MappingTargetColumnCell
                    name={row.targetColumn}
                    isMapped={row.status === 'MAPPED'}
                    isProcessing={isProcessing}
                    isTouched={Boolean(pendingManualEditSnapshots?.[row.id])}
                    width={columnWidths.targetColumn}
                    minWidth={MAPPING_COLUMN_MIN_WIDTH.targetColumn}
                    sx={{
                      ...mappingFrozenCellSx(frozenTargetColumnLeft, {
                        lastFrozen: true,
                      }),
                      ...mappingColumnDividerSx,
                    }}
                  />

                  <MappingRuleCell
                    value={resolveMappingTypeSelectValue(row)}
                    options={MAPPING_TYPE_OPTIONS}
                    placeholder="Select transform rule..."
                    width={columnWidths.preProcessRule}
                    minWidth={MAPPING_COLUMN_MIN_WIDTH.preProcessRule}
                    onRuleChange={(value) => {
                      const nextType = value || MAPPING_TYPE_DIRECT;
                      const previousType = resolveMappingTypeSelectValue(row);
                      if (nextType === previousType) {
                        return;
                      }
                      const keepsSource =
                        isDirectLikeMappingType(previousType)
                        && isDirectLikeMappingType(nextType);
                      confirmIfMappedRowChange(
                        row,
                        keepsSource
                          ? MAPPED_ROW_CHANGE_MESSAGES.transformRuleKeepSource
                          : MAPPED_ROW_CHANGE_MESSAGES.transformRule,
                        () => handleMappingTypeChange(row.id, nextType),
                        { onlyWhenSourceFilled: true },
                      );
                    }}
                    sx={scrollableBodyCellSx}
                  />

                  <MappingSourceColumnsCell
                    mappingType={
                      resolveMappingTypeSelectValue(row) as
                        | 'direct'
                        | 'attribute'
                        | 'custom'
                        | 'upper'
                        | 'lower'
                        | 'trim'
                    }
                    value={row.sourceColumn}
                    sourceColumns={row.sourceColumns}
                    librarySql={row.libraryRuleId ? row.expression : null}
                    firmValueNames={firmValueNamesInExpression(row.expression, projectAttributesForActiveProject)}
                    options={sourceColumnOptions}
                    attributeName={row.attributeName}
                    attributeOptions={attributeOptions}
                    onCreateAttribute={
                      activeProjectId
                        ? () => setFirmValueCreateRowId(row.id)
                        : undefined
                    }
                    isLoadingAttributeOptions={isLoadingProjectAttributes}
                    onAttributeMenuOpen={() => {
                      void reloadProjectAttributes();
                    }}
                    onPreProcess={() => {
                      setPreProcessModalOpen(true, row.id);
                    }}
                    onDirectSourcePick={() => setDirectPickerMappingId(row.id)}
                    scopeWarning={row.mappingMode !== 'constant' && row.mappingMode !== 'attribute' && row.sourceColumn
                      ? manualSourceScopeWarning(row.sourceColumn, drivingTableId, derivedSources, relationships) : null}
                    onAttributeChange={(nextAttributeName) => {
                      if ((row.attributeName ?? '') === (nextAttributeName ?? '')) {
                        return;
                      }
                      const selectedAttribute = projectAttributesForActiveProject.find(
                        (attribute) => attribute.attribute_name === nextAttributeName,
                      );
                      updateMappingWithUndo(
                        row.id,
                        withPreservedAutoMapConfidence(row, {
                          mappingMode: "attribute",
                          attributeName: nextAttributeName || null,
                          constantValue: selectedAttribute?.attribute_value ?? null,
                          sourceColumn: null,
                          sourceColumns: [],
                          sourceType: selectedAttribute?.attribute_type ?? null,
                          expression: null,
                          rule: "Direct",
                          status: nextAttributeName.trim() ? "MAPPED" : "UNMAPPED",
                          confidenceReason: nextAttributeName.trim()
                            ? "A firm value was assigned manually."
                            : null,
                          usedInferenceIds: [],
                          usedRecommendationIds: [],
                          usedLearningIds: [],
                          description: row.descriptionEdited
                            ? row.description
                            : nextAttributeName.trim()
                              ? `Assign the firm value ${nextAttributeName.trim()} to ${row.targetColumn}.`
                              : null,
                        }),
                      );
                    }}
                    onChange={(nextValue) => {
                      if ((row.sourceColumn ?? '').trim() === nextValue.trim()) {
                        return;
                      }
                      const nextColumns = parseSourceColumns(nextValue);
                      const rule = resolveMappingRuleSelectValue(row.rule);
                      const updates: Partial<typeof row> = {
                        sourceColumn: nextValue.trim() || null,
                        sourceColumns: nextColumns,
                        mappingMode: "source",
                        constantValue: null,
                        attributeName: null,
                        status: nextColumns.length > 0 ? 'MAPPED' : 'UNMAPPED',
                        confidenceReason: nextColumns.length
                          ? 'Source columns were edited manually after the AI suggestion.'
                          : null,
                        usedInferenceIds: row.usedInferenceIds ?? [],
                        usedRecommendationIds: row.usedRecommendationIds ?? [],
                        usedLearningIds: row.usedLearningIds ?? [],
                        sourceType:
                          sourceColumnOptions.find(
                            (option) => option.value.toLowerCase() === nextColumns[0]?.toLowerCase(),
                          )?.dataType ?? row.sourceType ?? null,
                      };

                      if (!row.descriptionEdited && rule) {
                        updates.description =
                          generateMappingDescription({
                            rule,
                            sourceColumns: nextColumns,
                            targetColumn: row.targetColumn,
                            expression: row.expression,
                          }) || null;
                      }

                      updateMappingWithUndo(row.id, withPreservedAutoMapConfidence(row, updates));
                    }}
                    firCandidates={isManualMapping ? [] : firCandidatesByTarget.get(row.targetColumn.toUpperCase()) ?? []}
                    onApplyFirCandidate={(candidate) => {
                      if (!candidate.sourceColumn) return;
                      void (async () => {
                        try {
                          await flushWorkspace();
                          const refreshed = await recommendationService.listApplicable({
                            projectId: activeProjectId || '',
                            sttmId: activeSttmId || '',
                            workflowStage: 'mapping',
                            targetColumns: [row.targetColumn],
                            limit: 3,
                          });
                          const currentRecommendation = refreshed.find(
                            (item) => item.recommendation_id === candidate.recommendationId,
                          );
                          const expectedWorkspaceHash =
                            currentRecommendation?.expected_workspace_hash
                            || candidate.expectedWorkspaceHash
                            || '';
                          if (!expectedWorkspaceHash) {
                            throw new Error('The current workspace hash is unavailable. Refresh the mapping and try again.');
                          }
                          const workspaceSnapshot = {
                            ...getWorkspaceSnapshot(),
                            context_hash: expectedWorkspaceHash,
                          };
                          const preview = await recommendationService.preview(
                            candidate.recommendationId,
                            {
                              sttm_id: activeSttmId || '',
                              workspace_snapshot: workspaceSnapshot,
                              expected_workspace_hash: expectedWorkspaceHash,
                            },
                          );
                          if (!preview.can_apply) {
                            throw new Error(preview.blocked_reasons.join(' '));
                          }
                          setRecommendationUndoByRow((current) => ({
                            ...current,
                            [row.id]: {
                              sourceColumn: row.sourceColumn,
                              sourceColumns: row.sourceColumns ?? [],
                              status: row.status,
                              confidenceScore: row.confidenceScore ?? null,
                              confidenceReason: row.confidenceReason ?? null,
                              manuallyEditedAfterAutoMap: row.manuallyEditedAfterAutoMap,
                              usedRecommendationIds: row.usedRecommendationIds ?? [],
                            },
                          }));
                          const nextColumns = parseSourceColumns(candidate.sourceColumn!);
                          updateMappingWithUndo(row.id, {
                            sourceColumn: candidate.sourceColumn,
                            sourceColumns: nextColumns,
                            mappingMode: "source",
                            constantValue: null,
                            status: nextColumns.length ? "MAPPED" : "UNMAPPED",
                            confidenceScore: candidate.confidence ?? null,
                            confidenceReason:
                              candidate.businessRationale
                              || candidate.evidenceSummary
                              || candidate.title,
                            manuallyEditedAfterAutoMap: false,
                            usedRecommendationIds: Array.from(new Set([
                              ...(row.usedRecommendationIds ?? []),
                              candidate.recommendationId,
                            ])),
                          });
                          setRecommendationActionErrors((current) => {
                            const next = { ...current };
                            delete next[row.id];
                            return next;
                          });
                        } catch (error) {
                          setRecommendationActionErrors((current) => ({
                            ...current,
                            [row.id]: error instanceof Error
                              ? error.message
                              : 'The recommendation could not be previewed against the current workspace.',
                          }));
                        }
                      })();
                    }}
                    onPrepareSource={(candidate) => {
                      window.dispatchEvent(new CustomEvent('sttm:prepare-source', {
                        detail: {
                          targetColumn: row.targetColumn,
                          recommendationId: candidate.recommendationId,
                          missingDependencies: candidate.missingDependencies,
                        },
                      }));
                    }}
                    onKeepUnresolved={() => undefined}
                    recommendationUndoAvailable={Boolean(recommendationUndoByRow[row.id])}
                    recommendationActionError={recommendationActionErrors[row.id] ?? null}
                    onUndoRecommendation={() => {
                      const previous = recommendationUndoByRow[row.id];
                      if (!previous) return;
                      updateMapping(row.id, previous);
                      setRecommendationUndoByRow((current) => {
                        const next = { ...current };
                        delete next[row.id];
                        return next;
                      });
                    }}
                    width={columnWidths.sourceColumn}
                    minWidth={MAPPING_COLUMN_MIN_WIDTH.sourceColumn}
                    confidenceReason={reviewNames.diagnostic(row.confidenceReason ?? '')}
                    businessMeaning={reviewNames.diagnostic(row.description ?? row.nlRule ?? '')}
                    candidateSourceColumns={isManualMapping ? [] : row.candidateSourceColumns}
                    sx={scrollableBodyCellSx}
                    displayText={row.mappingMode === 'constant' || row.mappingMode === 'attribute' ? undefined : reviewNames.display}
                  >
                    <MappingRowCandidates row={row} hideAiReview={isManualMapping} />
                  </MappingSourceColumnsCell>

                  {showConfidenceColumn ? (
                    <MappingConfidenceCell
                      confidenceScore={row.confidenceScore}
                      status={row.status}
                      reason={reviewNames.diagnostic(row.confidenceReason ?? '')}
                      businessMeaning={reviewNames.diagnostic(row.description ?? row.nlRule ?? '')}
                      manuallyEditedAfterAutoMap={Boolean(row.manuallyEditedAfterAutoMap)}
                      manuallySaved={Boolean(row.manuallySaved)}
                      pendingManualEdit={pendingManualEdit}
                      width={columnWidths.confidence}
                      minWidth={MAPPING_COLUMN_MIN_WIDTH.confidence}
                      sx={scrollableBodyCellSx}
                    />
                  ) : null}

                  <MappingTypePreviewCell
                    dataType={previewType}
                    width={columnWidths.typePreview}
                    minWidth={MAPPING_COLUMN_MIN_WIDTH.typePreview}
                    sx={scrollableBodyCellSx}
                  />

                  <MappingExpandableTextCell
                    placeholder="Add NL rule..."
                    value={row.nlRule ?? ''}
                    onChange={(value) => updateMappingWithUndo(row.id, { nlRule: value })}
                    width={columnWidths.nlRule}
                    minWidth={MAPPING_COLUMN_MIN_WIDTH.nlRule}
                    inputSx={multilineCellInputSx}
                    sx={scrollableBodyCellSx}
                  />

                  <AiaInputCell
                    placeholder="Order..."
                    value={row.loadOrder ?? ''}
                    onChange={(value) => updateMappingWithUndo(row.id, { loadOrder: value })}
                    width={columnWidths.order}
                    minWidth={MAPPING_COLUMN_MIN_WIDTH.order}
                    inputSx={mappingBodyInputSx}
                    sx={scrollableBodyCellSx}
                  />

                  <MappingExpandableTextCell
                    placeholder={descriptionPlaceholder}
                    value={descriptionValue}
                    onChange={(value) =>
                      updateMappingWithUndo(row.id, {
                        description: value,
                        descriptionEdited: value.trim().length > 0,
                      })
                    }
                    width={columnWidths.description}
                    minWidth={MAPPING_COLUMN_MIN_WIDTH.description}
                    inputSx={multilineCellInputSx}
                    sx={scrollableBodyCellSx}
                  />

                  <MappingStatusCell
                    status={isProcessing ? 'PROCESSING' : row.status}
                    displayStatus={mappingDisplayStatus(row)}
                    align="left"
                    width={columnWidths.status}
                    minWidth={MAPPING_COLUMN_MIN_WIDTH.status}
                    sx={scrollableBodyCellSx}
                  />

                  <MappingDataPreviewCell
                    mapping={row}
                    width={columnWidths.dataPreview}
                    minWidth={MAPPING_COLUMN_MIN_WIDTH.dataPreview}
                    sx={scrollableBodyCellSx}
                  />
                </AiaTableRowPrimitive>
              );
            })}
            {!paginatedBodyItems.length ? (
              <AiaTableRowPrimitive>
                <AiaTableCellPrimitive colSpan={visibleColumnKeys.length} sx={{ py: 4, textAlign: 'center' }}>
                  <AiaText sx={{ fontSize: '0.82rem', color: '#64748b' }}>
                    No mapping rows match the current column filters.
                  </AiaText>
                </AiaTableCellPrimitive>
              </AiaTableRowPrimitive>
            ) : null}
          </AiaTableBody>
        </AiaTablePrimitive>
      </AiaTableContainer>

      <AiaTablePagination
        component="div"
        count={expandableRowsForDisplay.length}
        page={safePage}
        onPageChange={(_, nextPage) => setPage(nextPage)}
        rowsPerPage={rowsPerPage}
        onRowsPerPageChange={(event) => {
          setRowsPerPage(Number.parseInt(event.target.value, 10));
          setPage(0);
        }}
        rowsPerPageOptions={ROWS_PER_PAGE_OPTIONS}
        sx={MAPPING_TABLE_PAGINATION_SX}
      />

      {mappingLoading && (
        <AiaBox
          sx={{
            position: 'absolute',
            top: 12,
            right: 16,
            maxWidth: 320,
            px: 1.5,
            py: 1,
            bgcolor: 'rgba(15,23,42,0.92)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'flex-start',
            gap: 1,
            zIndex: 5,
            borderRadius: '12px',
            boxShadow: '0 12px 28px rgba(15,23,42,0.18)',
            pointerEvents: 'none',
          }}
        >
          <AiaBox
            sx={{
              width: 18,
              height: 18,
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center',
              borderRadius: '999px',
              bgcolor: 'rgba(37,99,235,0.16)',
              flexShrink: 0,
            }}
          >
            <AiaBox
              component="span"
              sx={{
                width: 10,
                height: 10,
                borderRadius: '999px',
                border: '2px solid #93c5fd',
                borderTopColor: '#eff6ff',
                display: 'inline-block',
                animation: 'sttm-auto-map-spin 0.9s linear infinite',
                '@keyframes sttm-auto-map-spin': {
                  from: { transform: 'rotate(0deg)' },
                  to: { transform: 'rotate(360deg)' },
                },
              }}
            />
          </AiaBox>
          <AiaText sx={{ fontSize: '0.8rem', color: '#e2e8f0', fontWeight: 600 }}>
            {autoMapStatusMessage || 'Running auto-map...'}
          </AiaText>
        </AiaBox>
      )}

      {!mappingLoading && autoMapCompletionNotice && (
        <AiaBox
          role="status"
          sx={{
            position: 'absolute',
            top: 12,
            right: 16,
            maxWidth: 360,
            pl: 1.5,
            pr: 0.5,
            py: 0.5,
            bgcolor: 'rgba(15,23,42,0.92)',
            display: 'flex',
            alignItems: 'center',
            gap: 1,
            zIndex: 5,
            borderRadius: '12px',
            boxShadow: '0 12px 28px rgba(15,23,42,0.18)',
          }}
        >
          <AiaBox
            component="span"
            sx={{
              width: 8,
              height: 8,
              borderRadius: '999px',
              flexShrink: 0,
              bgcolor: AUTO_MAP_NOTICE_DOT_COLOR[autoMapCompletionNotice.severity] ?? '#93c5fd',
            }}
          />
          <AiaText sx={{ fontSize: '0.8rem', color: '#e2e8f0', fontWeight: 600 }}>
            {autoMapCompletionNotice.message}
          </AiaText>
          {!!autoMapCompletionNotice.reviewCount && <AiaButton size="small" sx={{ color: '#93c5fd', flexShrink: 0 }}
            onClick={() => { setPanelView('chat'); openChat(); }}>View proposals</AiaButton>}
          <AiaIconButton
            size="small"
            aria-label="Dismiss auto-map status"
            onClick={dismissAutoMapCompletionNotice}
            sx={{ color: '#94a3b8' }}
          >
            <CloseRoundedIcon sx={{ fontSize: 16 }} />
          </AiaIconButton>
        </AiaBox>
      )}

      <DirectSourcePickerModal
        open={Boolean(directPickerMapping)}
        onClose={() => setDirectPickerMappingId(null)}
        targetColumn={directPickerMapping?.targetColumn ?? ''}
        targetType={directPickerMapping?.targetType}
        initialSourceColumn={directPickerMapping?.sourceColumn}
        sourceDatabases={fullData?.sources ?? []}
        sourceAttributeGroups={sourceAttributeGroups}
        derivedSources={derivedSources}
        drivingId={drivingTableId}
        relationships={relationships}
        onApply={({ sourceColumn, sourceType }) => {
          if (!directPickerMapping) return;
          const nextColumns = parseSourceColumns(sourceColumn);
          const mappingType = resolveMappingTypeSelectValue(directPickerMapping);
          const nextRule = isDirectLikeMappingType(mappingType)
            ? (MAPPING_TYPE_TO_RULE[mappingType] ?? 'Direct')
            : 'Direct';
          updateMappingWithUndo(
            directPickerMapping.id,
            withPreservedAutoMapConfidence(directPickerMapping, {
              sourceColumn: sourceColumn.trim() || null,
              sourceColumns: nextColumns,
              mappingMode: 'source',
              constantValue: null,
              attributeName: null,
              expression: null,
              rule: nextRule,
              status: nextColumns.length > 0 ? 'MAPPED' : 'UNMAPPED',
              confidenceReason: nextColumns.length
                ? 'Source column was selected via Direct pick.'
                : null,
              usedInferenceIds: directPickerMapping.usedInferenceIds ?? [],
              usedRecommendationIds: directPickerMapping.usedRecommendationIds ?? [],
              usedLearningIds: directPickerMapping.usedLearningIds ?? [],
              sourceType: sourceType ?? directPickerMapping.sourceType ?? null,
              description: directPickerMapping.descriptionEdited
                ? directPickerMapping.description
                : generateMappingDescription({
                    rule: nextRule,
                    sourceColumns: nextColumns,
                    targetColumn: directPickerMapping.targetColumn,
                    expression: null,
                  }) || null,
            }),
          );
          setDirectPickerMappingId(null);
        }}
      />

      <MappingChangeConfirmDialog
        open={Boolean(pendingMappedRowChange)}
        targetColumn={pendingMappedRowChange?.targetColumn ?? ''}
        actionDescription={pendingMappedRowChange?.actionDescription ?? ''}
        onClose={closeMappedRowChangeConfirm}
        onConfirm={confirmMappedRowChange}
      />

      <MappingChangeConfirmDialog
        open={saveConfirmOpen}
        title="Save manual mappings?"
        busy={isSavingManualEdits}
        targetColumn={`${manualSaveMappingCount} mapping${manualSaveMappingCount === 1 ? '' : 's'}`}
        leadIn="will be saved."
        actionDescription="This saves your mapping definitions. Existing confidence and execution checks remain separate."
        confirmLabel="Save"
        onClose={() => {
          if (!isSavingManualEdits) {
            setSaveConfirmOpen(false);
          }
        }}
        onConfirm={() => {
          void handleConfirmSaveManualEdits();
        }}
      />

      <NewAttributeModal
        open={Boolean(firmValueCreateRowId)}
        projectName={activeProjectName?.trim() || ""}
        onClose={() => setFirmValueCreateRowId(null)}
        onSubmit={handleCreateFirmValue}
      />

      <MappingChangeConfirmDialog
        open={cancelConfirmOpen}
        title="Discard unsaved changes?"
        targetColumn={`${dirtyMappingIds.length} mapping${dirtyMappingIds.length === 1 ? '' : 's'}`}
        leadIn="will be reverted."
        actionDescription="Your unsaved edits will be discarded and the previous values restored. This cannot be undone."
        confirmLabel="Discard"
        onClose={() => setCancelConfirmOpen(false)}
        onConfirm={handleCancelManualEdits}
      />
    </AiaBox>
  );
};

export default SourceTargetAttributeMapping;
