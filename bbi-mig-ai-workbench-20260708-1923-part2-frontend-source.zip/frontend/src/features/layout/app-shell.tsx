"use client";
import { AiaBox } from '@/components/ui';


import AppSidebar from "./app-sidebar";
import type { AppNavItem } from "./app-sidebar-types";

type AppShellProps = {
  activeNav?: AppNavItem;
  initialNewMappingOpen?: boolean;
  children: React.ReactNode;
};

export default function AppShell({
  activeNav,
  initialNewMappingOpen = false,
  children,
}: AppShellProps) {
  return (
    <AiaBox
      sx={{
        display: "flex",
        flex: 1,
        minHeight: 0,
        overflow: "hidden",
        bgcolor: "#F7F8FA",
      }}
    >
      <AppSidebar activeNav={activeNav} initialNewMappingOpen={initialNewMappingOpen} />
      <AiaBox
        component="main"
        sx={{
          flex: 1,
          minWidth: 0,
          minHeight: 0,
          display: "flex",
          flexDirection: "column",
          overflow: "hidden",
        }}
      >
        {children}
      </AiaBox>
    </AiaBox>
  );
}
