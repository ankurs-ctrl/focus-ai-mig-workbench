const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const ts = require('typescript');

const filename = path.resolve(__dirname, '../src/services/migrationAgentService.ts');
const compiled = ts.transpileModule(fs.readFileSync(filename, 'utf8'), {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 },
}).outputText;
const service = { exports: {} };
vm.runInThisContext(`(function(require,module,exports){${compiled}\n})`, { filename })(
  (name) => {
    if (name === '@/api/axiosInstance') return { resolveApiBaseUrl: () => 'http://local.test/api' };
    throw new Error(`Unexpected import ${name}`);
  }, service, service.exports,
);

test('two completed Deep Agent turns stay in one conversation', async () => {
  const originalFetch = global.fetch;
  const submitted = [];
  try {
    global.fetch = async (url, init) => {
      assert.match(String(url), /\/assistant-conversations\/conversation-1\/turns$/);
      const body = JSON.parse(init.body);
      submitted.push(body);
      return { ok: true, json: async () => ({ turn_id: `turn-${submitted.length}`,
        intent: 'answer', execution_path: 'fast_path', message: `Reply ${submitted.length}`,
        question: submitted.length === 1 ? { prompt: 'Which rule?', options: [
          { label: 'A', description: 'First' }, { label: 'B', description: 'Second' },
        ] } : null }) };
    };
    const client = new service.exports.MigrationAgentSessionClient();
    client.useConversationApi = true;
    client.conversationId = 'conversation-1';
    client.connectionReady = Promise.resolve();
    const emitted = [];
    client.onMessage = (message) => emitted.push(message);
    const snapshot = { context_hash: 'ctx', source_tables: [],
      target_table: { database: 'DB', schema: 'TGT', table: 'HOUSEHOLD' } };
    client.sendMessage('first', snapshot);
    await new Promise((resolve) => setTimeout(resolve, 0));
    client.sendMessage('second', snapshot);
    await new Promise((resolve) => setTimeout(resolve, 0));
    assert.deepEqual(submitted.map((item) => item.message), ['first', 'second']);
    assert.ok(submitted.every((item) => item.authorized_schemas.length === 0));
    assert.deepEqual(emitted.filter((message) => message.type === 'assistant.final')
      .map((message) => message.data.text), ['Reply 1', 'Reply 2']);
    assert.equal(emitted.find((message) => message.type === 'assistant.final').data.question.prompt, 'Which rule?');
    assert.equal(client.conversationId, 'conversation-1');
  } finally {
    global.fetch = originalFetch;
  }
});

test('lost approval response reconciles a committed durable run', async () => {
  const originalFetch = global.fetch;
  try {
    global.fetch = async (url, init) => {
      const address = String(url);
      if (address.endsWith('/agent-runs/run-1/answer') && init.method === 'POST') {
        throw new TypeError('connection lost after commit');
      }
      if (address.endsWith('/agent-runs/run-1')) {
        return { ok: true, json: async () => ({ run: { run_id: 'run-1', status: 'QUEUED' }, review_items: [] }) };
      }
      if (address.includes('/agent-runs/run-1/events?')) {
        return { ok: true, json: async () => [] };
      }
      throw new Error(`Unexpected request ${address}`);
    };
    const client = new service.exports.MigrationAgentSessionClient();
    client.runId = 'run-1';
    client.pendingInterruptId = 'interrupt-1';
    client.pendingActionDigest = 'digest-1';
    client.pendingArtifactRevision = '1';
    const emitted = [];
    client.onMessage = (message) => emitted.push(message);
    client.decidePermission('ctx', 'review-1', 'allow_once', '', 'approve');
    await new Promise((resolve) => setTimeout(resolve, 0));
    assert.equal(client.runId, 'run-1');
    assert.equal(emitted.some((message) => message.type === 'assistant.error'), false);
    assert.ok(emitted.some((message) => message.type === 'assistant.status'
      && String(message.data.status).includes('reconnecting')));
  } finally {
    global.fetch = originalFetch;
  }
});

test('answered workflow checkpoint clears a replayed question', () => {
  const client = new service.exports.MigrationAgentSessionClient();
  const emitted = [];
  client.onMessage = (message) => emitted.push(message);
  const base = { event_id: 'event-1', run_id: 'run-1', sequence: 1,
    status: 'awaiting_input', safe_summary: 'Choose a join', created_at: new Date().toISOString() };
  client.handleRunEvent({ ...base, event_type: 'run.question.required',
    data: { review_item_id: 'review-1', question: 'Which join?', choices: [] } }, 'ctx');
  client.handleRunEvent({ ...base, event_id: 'event-2', sequence: 2,
    event_type: 'run.question.answered', status: 'answered',
    data: { review_item_id: 'review-1' } }, 'ctx');
  assert.deepEqual(emitted.map((message) => message.type), ['permission.requested', 'permission.resolved']);
  assert.equal(emitted[1].data.permission_id, 'review-1');
});

test('join-path checkpoint exposes choices and an explicit rule hint', () => {
  const client = new service.exports.MigrationAgentSessionClient();
  const emitted = [];
  client.onMessage = (message) => emitted.push(message);
  client.handleRunEvent({
    event_id: 'event-join', run_id: 'run-join', sequence: 1,
    event_type: 'run.question.required', status: 'awaiting_input',
    safe_summary: 'Join path 1 of 2 needs a business decision.',
    created_at: new Date().toISOString(),
    data: {
      review_item_id: 'review-join', category: 'source_join_path',
      question: 'Join path 1 of 2: How should ADDRESSES connect to CONTACTS?',
      answer_hint: 'TABLE.COLUMN = TABLE.COLUMN', allow_free_text: true,
      choices: [{ choice_id: 'path_0_0', label: 'Use candidate path: CONTACTS ↔ ADDRESSES',
        description: 'Current columns will be checked.', recommended: false }],
    },
  }, 'context-join');
  const prompt = emitted.find((message) => message.type === 'permission.requested');
  assert.equal(prompt.data.category, 'source_join_path');
  assert.equal(prompt.data.answer_hint, 'TABLE.COLUMN = TABLE.COLUMN');
  assert.equal(prompt.data.questions[0].options[0].id, 'path_0_0');
});
