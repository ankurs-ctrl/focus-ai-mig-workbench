"""Measure a saved Auto-map manifest without executing agents or changing data."""
import argparse
import json
import logging
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "services/sttm-builder"))


def main():
    logging.basicConfig(level=logging.INFO)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--env-file")
    parser.add_argument("--job-id")
    parser.add_argument("--request-file", help="Replay a previously exported durable request without any Snowflake connection")
    parser.add_argument("--live-target", help="Replay one saved target with exact scoped retrieval; no mapping save")
    parser.add_argument("--batch-replay", action="store_true", help="Measure all planned batches and exact mandatory reads without model calls")
    parser.add_argument("--size-breakdown", action="store_true", help="Report exclusive learning/semantic/shared wire-size attribution")
    parser.add_argument("--export-review", help="Write user-requested readable private artifacts under .dev-cache")
    args = parser.parse_args()
    if not args.request_file and (not args.env_file or not args.job_id):
        parser.error("Use --request-file or both --env-file and --job-id")
    if args.request_file and args.live_target:
        parser.error("An offline request-file replay cannot execute live agents")
    if args.export_review:
        review_root = Path(args.export_review).resolve()
        private_root = (ROOT / ".dev-cache").resolve()
        if not args.batch_replay or private_root not in review_root.parents or review_root.exists():
            parser.error("Review export requires --batch-replay and a new folder beneath this checkout's .dev-cache")
        review_root.mkdir(parents=True)
    from app.core.config import Settings
    from app.core.snowflake import SnowflakeClient
    from app.core.automap_retrieval import AutoMapContext, encoded, factor_exact_records
    from app.core.agent_payload_budget import _factor_repeated_context_values
    from app.schema.sttm_builder import STTMBuilderEnvelopeRequest, STTMAgentRequestEnvelope

    settings = Settings(_env_file=args.env_file)
    client = None if args.request_file else SnowflakeClient(settings=settings)
    try:
        if args.request_file:
            value = json.loads(Path(args.request_file).read_text(encoding="utf-8"))
        else:
            row = client.session.sql(
                "SELECT JOB_STATE:request_envelope AS ENVELOPE FROM "
                "FFP_HDP_DLAB_DB_DEV.SCH_STTM_METADATA.TBL_AUTO_MAP_JOBS WHERE JOB_ID = ?",
                params=[args.job_id],
            ).collect()[0]
            value = row["ENVELOPE"]
        if isinstance(value, str):
            value = json.loads(value)
        from app.core.automap_stored_json import context_storage
        value = context_storage(value, restore=True)
        req = STTMBuilderEnvelopeRequest.model_validate(value)
        if args.export_review:
            (review_root / "NOT-SENT-saved-request-envelope.json").write_text(
                json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
        if args.batch_replay:
            from app.core.auto_mapping_proxy import AutoMappingProxyClient
            from app.core.automap_retrieval import batch_packet
            settings = settings.model_copy(update={"automap_context_retrieval_v1": True})
            # Inspect every fixed group even when strict production preflight
            # rejects one. This helper never dispatches a worker or model.
            batches = AutoMappingProxyClient(settings)._balanced_retrieval_batches(req)
            exported = []
            for index, attributes in enumerate(batches):
                batch = req.model_copy(update={"data": req.data.model_copy(update={"attributes": attributes})})
                from app.core.automap_policy import focused_learning
                raw_batch = STTMAgentRequestEnvelope.from_builder_request(batch).model_dump(mode="json", exclude_none=True)
                raw_batch["context"]["learning_context"] = focused_learning(raw_batch["context"].get("learning_context") or {})
                store = AutoMapContext(raw_batch)
                initial = batch_packet(store, [])
                operations = []
                for target in store.targets:
                    operations.extend(operation for operation in store.required_operations(target, {"source_attributes": []})
                                      if operation["operation"] != "discover")
                pending = list({encoded(operation): operation for operation in operations}.values())
                results = []
                exact_results = []
                while pending and len(results) <= settings.automap_context_max_operations:
                    operation = pending.pop(0)
                    try:
                        result = store.read({"tool": "AUTO_MAP_CONTEXT", "snapshot_hash": store.snapshot_hash, **operation},
                                            max_bytes=min(32768, settings.agent_outbound_message_max_bytes // 4))
                    except ValueError as exc:
                        result = {"error": str(exc)}
                    results.append({"request": operation, "result": result})
                    if result.get("next_cursor"):
                        pending.append({**operation, "cursor": result["next_cursor"]})
                    elif not result.get("error"):
                        exact_operation = {key: value for key, value in operation.items() if key != "cursor"}
                        exact_results.append({"request": exact_operation, "result": store.exact_completed_result(exact_operation)})
                full = batch_packet(store, exact_results)
                message = [{"role": "user", "content": [{"type": "text", "text": encoded(full)}]}]
                message_chars = len(encoded(message))
                message_bytes = len(encoded(message).encode())
                if args.export_review:
                    from automap_message_sizes import export_review
                    exported.append(export_review(review_root, index, store, full, encoded))
                    print(json.dumps({"batch_index": index, "exported_folder": exported[-1]["folder"],
                                      "verified_exact_expansion": True, "message_chars": message_chars}), flush=True)
                    continue
                if args.size_breakdown:
                    from automap_message_sizes import breakdown
                    print(json.dumps({"batch_index": index, "target_count": len(attributes),
                                      **breakdown(full, encoded)}, default=str), flush=True)
                    continue
                text_shapes = []
                def inspect_text(value, path):
                    if isinstance(value, str) and len(value) > 1000:
                        text_shapes.append({"path": path, "chars": len(value), "newlines": value.count("\n"),
                                            "escaped_newlines": value.count("\\n")})
                    elif isinstance(value, dict):
                        for key, child in value.items():
                            inspect_text(child, [*path, key])
                    elif isinstance(value, list):
                        for position, child in enumerate(value):
                            inspect_text(child, [*path, position])
                inspect_text(exact_results, [])
                print(json.dumps({"batch_index": index, "targets": list(store.targets),
                    "initial_chars": len(encoded(initial)), "initial_bytes": len(encoded(initial).encode()),
                    "mandatory_chars": len(encoded(full)), "mandatory_bytes": len(encoded(full).encode()),
                    "message_chars": message_chars, "message_bytes": message_bytes,
                    "message_fits": message_chars <= settings.agent_outbound_message_max_chars and message_bytes <= settings.agent_outbound_message_max_bytes,
                    "exact_read_pages": len(results), "remaining_pages": len(pending),
                    "read_errors": [item for item in results if item["result"].get("error")],
                    "largest_text_shapes": sorted(text_shapes, key=lambda item: -item["chars"])[:12],
                    "largest_exact_reads": sorted([{"operation": item["request"], "bytes": len(encoded(item["result"]).encode())}
                        for item in exact_results], key=lambda item: -item["bytes"])[:8],
                    "factored_sections": {key: len(encoded(value)) for key, value in full.items()},
                    "manifest_context_sizes": {key: len(encoded(value)) for key, value in store.manifest()["context"].items()},
                    "workspace_sizes": {key: len(encoded(value)) for key, value in store.manifest()["context"].get("workspace_context", {}).items()},
                    "retrieval_sizes": {key: len(encoded(value)) for key, value in store.manifest()["context"].get("auto_map_retrieval", {}).items()},
                    "modifier_shapes": {key: type(value).__name__ for key, value in (store.original.get("context", {}).get("relation_graph", {}).get("query_modifiers") or {}).items()},
                    "recipe_structure": [{"target": target, "fields": list(record),
                        "sizes": {key: len(encoded(value)) for key, value in record.items()},
                        "nested_fields": {key: list(value) for key, value in record.items() if isinstance(value, dict)}}
                        for target, categories in store.evidence.items() for record in categories.get("target_mapping_patterns", [])][:2],
                    "pattern_field_sizes": [{key: len(encoded(value)) for key, value in record.get("pattern", {}).items()}
                        for categories in store.evidence.values() for record in categories.get("target_mapping_patterns", [])][:6],
                    "largest_read_identities": sorted([{"operation": item["request"], "bytes": len(encoded(item["result"]).encode())}
                        for item in results], key=lambda item: -item["bytes"])[:5],
                    "model_char_budget": settings.agent_outbound_message_max_chars,
                    "model_byte_budget": settings.agent_outbound_message_max_bytes}, default=str), flush=True)
            if exported:
                rows = ["| Batch | Targets | Message chars | Learning | Semantics | Workspace/graph | Shared |",
                        "|---|---:|---:|---:|---:|---:|---:|"]
                for index, record in enumerate(exported, 1):
                    sizes = record["chars"]
                    rows.append(f"| {index} | {len(record['targets'])} | {record['total_message_chars']} | "
                                f"{sizes['learning']} | {sizes['semantics']} | {sizes['workspace_graph']} | {sizes['shared_dictionaries']} |")
                readme = ("# Auto-map context review: project 2301 / mapping 9601\n\n"
                    "Private local customer-data artifacts. Git-ignored; do not share or commit without review.\n\n"
                    f"Saved request: `{args.job_id}`. Rebuilt with the current four-batch code. "
                    "These are diagnostic preflight messages, not successful live model calls. "
                    "No live Search discovery, model execution, mapping save or publication occurred. "
                    "The focused policy projection excludes broad positive learning and defers profiles; "
                    "the saved request and original bundle are retained privately.\n\n"
                    "## Start here\n\nEach batch folder has:\n"
                    "- `01-complete-readable-context.json`: exact context expanded for human reading.\n"
                    "- `review-learning.json`: recipes, corrections, precedents and learning metadata currently sent.\n"
                    "- `review-semantics.json`: catalog, table contracts and completed semantic reads currently sent.\n"
                    "- `review-workspace-graph.json`: selected sources, graph, filters, bindings and workspace identity currently sent.\n"
                    "- `review-targets-and-instructions.json`: targets, guidance and retrieval instructions.\n"
                    "- `02-exact-model-packet.json` and `03-exact-complete-message.json`: unchanged serialized diagnostic inputs.\n"
                    "- `sizes.json`: complete-message attribution; readable pretty-print sizes are NOT model sizes.\n"
                    "- `NOT-SENT-historical-dependency-bodies.json`: exact historical bodies behind handles, not sent yet.\n\n"
                    "`NOT-SENT-original-semantic-bundle.json` at the root is the original full semantic_context, "
                    "not the selected semantic content sent in each batch.\n\n"
                    "## Measured complete-message sizes\n\n" + "\n".join(rows) + "\n\n"
                    "The character limit is 120000. Cross-category dictionaries are reported as Shared, not double-counted.\n\n"
                    "## Suggest exclusions\n\nSend the batch, filename and JSON field path to exclude or defer, "
                    "plus whether the field is irrelevant or duplicated elsewhere. "
                    "Corrections, actual mapping expressions, null handling, population rules, approved Value bindings "
                    "and selected dependency closure need an equivalent source of authority before removal.\n")
                (review_root / "README.md").write_text(readme, encoding="utf-8")
            return
        if args.live_target and not any(item.target_attribute == args.live_target for item in req.data.attributes):
            raise ValueError("Target is not in the saved job")
        attribute = next((item for item in req.data.attributes
                          if item.target_attribute == args.live_target), req.data.attributes[0])
        req = req.model_copy(update={"data": req.data.model_copy(update={
            "attributes": [attribute]
        })})
        raw = STTMAgentRequestEnvelope.from_builder_request(req).model_dump(
            mode="json", exclude_none=True
        )
        manifest = AutoMapContext(raw).manifest()
        factored = factor_exact_records(manifest)
        _factor_repeated_context_values(factored)
        print(json.dumps({"total_chars": len(encoded(manifest)), "sections": {
            key: len(encoded(value)) for key, value in manifest["context"].items()
        }, "retrieval_sections": {
            key: len(encoded(value)) for key, value in
            manifest["context"]["auto_map_retrieval"].items()
        }, "lossless_factored_chars": len(encoded(factored)), "table_contracts": {
            key: len(encoded(value)) for key, value in
            manifest["context"]["auto_map_retrieval"]["table_contracts"].items()
        }}, indent=2))
        if args.live_target:
            from app.core.snowflake_agent import SnowflakeAgentClient
            from app.core.sttm_builder import STTMBuilderService
            from app.guardrails.runtime.model_boundary import ModelBoundaryGuard
            from app.guardrails.config.loader import load_config
            from app.guardrails.contracts.decisions import GovernanceDecision
            rest = client.get_rest_session_context()
            service = STTMBuilderService.__new__(STTMBuilderService)
            service._settings = settings.model_copy(update={"automap_context_retrieval_v1": True})
            service._session = client.session
            service._agent = SnowflakeAgentClient(token=rest.token, host=rest.host,
                auth_mode="snowflake_token", request_timeout=60)
            service._source_mapping_agent_name = settings.resolved_source_mapping_agent
            service._model_guard = ModelBoundaryGuard(load_config(settings=settings))
            decision = GovernanceDecision(trace_id="actual-mapping-readonly-replay",
                request_id=req.request_id, operation=req.operation.value)
            text, thread, metadata = service._invoke_retrieval_auto_map(req, decision)
            print(json.dumps({"thread": thread, "response": json.loads(text),
                "audit": metadata.get("auto_map_retrieval")}, default=str), flush=True)
    finally:
        if client is not None:
            client.session.close()


if __name__ == "__main__":
    main()