'use client';
import { useRouter } from 'next/navigation';
import { useSttmBuilderContext } from '../context/sttm-builder-context';
import type { AutoMapSuggestion } from '@/types/api-contract';
import type { MappingState } from '../types/sttm.types';
import { JOIN_REVIEW_KEY, knownReviewSources, mappingBase, type JoinReviewIntent } from './review-navigation';
/** Navigation only. Source selections remain provisional inside the join editor. */
export function useRowJoinReview() {
  const context=useSttmBuilderContext();const router=useRouter();
  return (row:MappingState,suggestion:AutoMapSuggestion)=>{
    const base=mappingBase(context.activeSttmId,window.location.pathname);
    const intent:JoinReviewIntent={id:`${row.id}:${suggestion.suggestion_id}`,suggestionId:suggestion.suggestion_id,projectId:context.activeProjectId,sttmId:context.activeSttmId,
      mappingId:row.id,targetColumn:row.targetColumn,purpose:suggestion.message,base,recommendation:suggestion.join_recommendation??{},status:'pending'};
    const known=[...context.sources,...(context.fullData?.sources??[]).flatMap(db=>db.schemas.flatMap(schema=>schema.tables))];
    const selected=knownReviewSources(intent,known);
    const resolve=(id?:string|null)=>selected.find(source=>source.tableId===id)?.tableId
      ?? (selected.filter(source=>source.qualifiedName===id).length===1?selected.find(source=>source.qualifiedName===id)?.tableId:undefined)
      ?? context.derivedSources.find(source=>source.id===id)?.id;
    intent.recommendation={...intent.recommendation,left_relation_id:resolve(intent.recommendation.left_relation_id),right_relation_id:resolve(intent.recommendation.right_relation_id)};
    window.sessionStorage.setItem(JOIN_REVIEW_KEY,JSON.stringify(intent));
    router.push(`${base}?joinReview=1`);
  };
}
