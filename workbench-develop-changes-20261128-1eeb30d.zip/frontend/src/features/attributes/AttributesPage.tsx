"use client";
/* eslint-disable react-hooks/set-state-in-effect -- Modal/page state is reset when project context changes. */

import { Suspense, useCallback, useEffect, useMemo, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { AiaBox, AiaButton, AiaLoadingOverlay } from "@/components/ui";
import { MODAL_ABOVE_AI_CHAT_Z_INDEX } from "@/features/ai-agent/ai-chat-layout-constants";

import AttributesHeader from "./attributes-header";
import AttributesTable from "./attributes-table";
import DeleteAttributeModal, { type FirmValueDeleteResult } from "./delete-attribute-modal";
import ImportAttributesModal from "./import-attributes-modal";
import NewAttributeModal from "./new-attribute-modal";
import {
  type HardcodedAttribute,
  firmValueConflictMessage,
  firmValueSharedValueWarnings,
  type NewAttributeFormValues,
} from "./attributes-data";
import {
  createProjectAttribute,
  deleteProjectAttribute,
  importProjectAttributes,
  listProjectAttributes,
  updateProjectAttribute,
  type ProjectAttributeRecord,
} from "@/services/projectService";
import { parseAppError } from "@/api/errors/app-error";
import { authService } from "@/services/authService";
import { belongsToProject, notifyProjectAttributesChanged, rememberFirmValueEdit, STTM_PROJECT_ATTRIBUTES_CHANGED_EVENT } from "@/features/sttm/mapping/project-attribute-utils";

function toHardcodedAttribute(record: ProjectAttributeRecord): HardcodedAttribute {
  return {
    id: record.attribute_id,
    attributeName: record.attribute_name,
    attributeType: record.attribute_type as HardcodedAttribute["attributeType"],
    projectId: record.project_id,
    projectName: record.project_name ?? "",
    importProjectName: record.source_project_name ?? null,
    attributeValue: record.attribute_value,
  };
}

function AttributesPageContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const projectId = searchParams.get("project_id")?.trim() || "";
  const projectName = searchParams.get("project_name")?.trim() || "";

  const [attributes, setAttributes] = useState<HardcodedAttribute[]>([]);
  const [modalMode, setModalMode] = useState<"create" | "edit">("create");
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [editingAttribute, setEditingAttribute] = useState<HardcodedAttribute | null>(null);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [deletingAttributes, setDeletingAttributes] = useState<HardcodedAttribute[]>([]);
  const [deleteResult, setDeleteResult] = useState<FirmValueDeleteResult | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [valueNotice, setValueNotice] = useState<string | null>(null);
  const [reloadToken, setReloadToken] = useState(0);
  // Labels of firm value requests still running; while any remain, the whole
  // app is blocked so the user cannot leave or change data mid-request.
  const [pendingRequests, setPendingRequests] = useState<string[]>([]);
  const [canEdit, setCanEdit] = useState(false);

  useEffect(() => {
    let live = true;
    void authService.getSession().then((session) => {
      if (live) setCanEdit(Boolean(session.ui_permissions?.can_edit));
    }).catch(() => {
      if (live) setCanEdit(false);
    });
    return () => {
      live = false;
    };
  }, []);

  const trackRequest = useCallback(<T,>(label: string, request: Promise<T>): Promise<T> => {
    setPendingRequests((current) => [...current, label]);
    return request.finally(() => {
      setPendingRequests((current) => {
        const index = current.indexOf(label);
        return index === -1 ? current : [...current.slice(0, index), ...current.slice(index + 1)];
      });
    });
  }, []);

  const loadAttributes = useCallback(async () => {
    if (!projectId) {
      setAttributes([]);
      return;
    }
    setLoadError(null);
    try {
      const records = await trackRequest(
        "Loading firm values…",
        listProjectAttributes(projectId, undefined, { bypassCache: true }),
      );
      setAttributes(records.map(toHardcodedAttribute));
    } catch (error) {
      setAttributes([]);
      setLoadError(
        error instanceof Error
          ? error.message
          : "Unable to load firm values from the metadata service.",
      );
    }
  }, [projectId, trackRequest]);

  useEffect(() => {
    if (!projectId) {
      setAttributes([]);
      return;
    }
    void loadAttributes();
  }, [loadAttributes, projectName, reloadToken]);

  useEffect(() => {
    if (!projectId) {
      return;
    }
    const refresh = () => {
      void loadAttributes();
    };
    const handleAttributesChanged = (event: Event) => {
      const detail = (event as CustomEvent<{ projectId?: string }>).detail;
      if (!detail?.projectId || detail.projectId === projectId) {
        refresh();
      }
    };
    window.addEventListener(STTM_PROJECT_ATTRIBUTES_CHANGED_EVENT, handleAttributesChanged);
    window.addEventListener("pageshow", refresh);
    return () => {
      window.removeEventListener(STTM_PROJECT_ATTRIBUTES_CHANGED_EVENT, handleAttributesChanged);
      window.removeEventListener("pageshow", refresh);
    };
  }, [loadAttributes, projectId]);

  const filteredAttributes = useMemo(
    () =>
      projectId
        ? attributes.filter((item) => belongsToProject({ project_id: item.projectId }, projectId))
        : attributes,
    [attributes, projectId],
  );

  const firmValueIdentities = useMemo(
    () =>
      filteredAttributes.map((item) => ({
        id: item.id,
        attributeName: item.attributeName,
        attributeValue: item.attributeValue,
      })),
    [filteredAttributes],
  );

  const handleOpenCreate = () => {
    setModalMode("create");
    setEditingAttribute(null);
    setIsFormModalOpen(true);
  };

  const handleOpenEdit = (row: HardcodedAttribute) => {
    setModalMode("edit");
    setEditingAttribute(row);
    setIsFormModalOpen(true);
  };

  const handleCloseFormModal = () => {
    setIsFormModalOpen(false);
    setEditingAttribute(null);
    setModalMode("create");
  };

  const handleSubmitAttribute = async (values: NewAttributeFormValues[]) => {
    const identities = filteredAttributes.map((item) => ({
      id: item.id,
      attributeName: item.attributeName,
      attributeValue: item.attributeValue,
    }));
    if (modalMode === "edit" && editingAttribute) {
      const item = values[0];
      if (!item) {
        throw new Error("Enter the firm value to save.");
      }
      const conflict = firmValueConflictMessage(identities, {
        attributeName: item.attributeName,
        ignoreId: editingAttribute.id,
      });
      if (conflict) {
        throw new Error(conflict);
      }
      const record = await trackRequest("Saving firm value…", updateProjectAttribute(projectId, editingAttribute.id, {
        attribute_name: item.attributeName,
        attribute_type: item.attributeType,
        attribute_value: item.attributeValue,
      }));
      setAttributes((current) => current.map((row) =>
        row.id === editingAttribute.id ? toHardcodedAttribute(record) : row,
      ));
      rememberFirmValueEdit({
        projectId,
        previousName: editingAttribute.attributeName,
        nextName: record.attribute_name,
        previousValue: editingAttribute.attributeValue,
        nextValue: record.attribute_value,
        previousType: editingAttribute.attributeType,
        nextType: record.attribute_type,
      });
      notifyProjectAttributesChanged(projectId);
      return;
    }
    const seen = new Set<string>();
    for (const item of values) {
      const key = item.attributeName.trim().toUpperCase();
      if (seen.has(key)) {
        throw new Error(`Project value ${item.attributeName} already exists.`);
      }
      seen.add(key);
      const conflict = firmValueConflictMessage(identities, {
        attributeName: item.attributeName,
        attributeValue: item.attributeValue,
      });
      if (conflict) {
        throw new Error(conflict);
      }
    }
    const label = values.length === 1 ? "Creating firm value…" : "Creating firm values…";
    const records = await trackRequest(
      label,
      (async () => {
        const created = [];
        for (const item of values) {
          created.push(
            await createProjectAttribute(projectId, {
              attribute_name: item.attributeName,
              attribute_type: item.attributeType,
              attribute_value: item.attributeValue,
            }),
          );
        }
        return created;
      })(),
    );
    setAttributes((current) => [...records.map(toHardcodedAttribute), ...current]);
    notifyProjectAttributesChanged(projectId);
  };

  const handleImportAttributes = (rows: HardcodedAttribute[]) => {
    const warnings = firmValueSharedValueWarnings(
      firmValueIdentities,
      rows.map((row) => ({
        id: row.id,
        attributeName: row.attributeName,
        attributeValue: row.attributeValue,
      })),
    );
    setValueNotice(warnings.length ? warnings.join(" ") : null);
    const byProject = new Map<string, string[]>();
    rows.forEach((row) => {
      byProject.set(row.projectId, [...(byProject.get(row.projectId) ?? []), row.id]);
    });
    void trackRequest(
      "Importing firm values…",
      Promise.all(
        Array.from(byProject.entries()).map(([sourceProjectId, attributeIds]) =>
          importProjectAttributes(projectId, {
            source_project_id: sourceProjectId,
            attribute_ids: attributeIds,
          }),
        ),
      ).then(() => listProjectAttributes(projectId, undefined, { bypassCache: true })),
    )
      .then((records) => {
        setAttributes(records.map(toHardcodedAttribute));
        notifyProjectAttributesChanged(projectId);
      })
      .catch((error) => {
        setLoadError(error instanceof Error ? error.message : "Unable to import firm values.");
      });
  };

  const handleToggleRow = (row: HardcodedAttribute, checked: boolean) => {
    setSelectedIds((current) => {
      if (checked) {
        return current.includes(row.id) ? current : [...current, row.id];
      }
      return current.filter((id) => id !== row.id);
    });
  };

  const handleToggleAll = (checked: boolean) => {
    setSelectedIds(checked ? filteredAttributes.map((row) => row.id) : []);
  };

  const handleConfirmDelete = () => {
    if (deletingAttributes.length === 0) {
      return;
    }
    const targets = deletingAttributes;
    const attributeIds = targets.map((item) => item.id);
    const label = attributeIds.length === 1 ? "Deleting firm value…" : "Deleting firm values…";
    setDeletingAttributes([]);
    const waitForDraftFlush = () =>
      new Promise<void>((resolve) => {
        const detail = { acknowledged: false, done: resolve };
        window.dispatchEvent(new CustomEvent("sttm:flush-workspace", { detail }));
        if (!detail.acknowledged) {
          resolve();
        }
      });
    void trackRequest(
      label,
      waitForDraftFlush().then(async () => {
        const outcomes = await Promise.all(
          targets.map(async (item) => {
            try {
              await deleteProjectAttribute(projectId, item.id);
              return { item, ok: true as const };
            } catch (error) {
              return {
                item,
                ok: false as const,
                message:
                  parseAppError(error).payload.message
                  || `${item.attributeName} could not be deleted.`,
              };
            }
          }),
        );
        return outcomes;
      }),
    )
      .then((outcomes) => {
        const deleted = outcomes.filter((outcome) => outcome.ok).map((outcome) => outcome.item);
        const blockedMessages = outcomes.flatMap((outcome) =>
          outcome.ok ? [] : [outcome.message],
        );
        const removed = new Set(deleted.map((item) => item.id));
        if (removed.size) {
          setAttributes((current) => current.filter((item) => !removed.has(item.id)));
          setSelectedIds((current) => current.filter((id) => !removed.has(id)));
          notifyProjectAttributesChanged(projectId);
        }
        setDeleteResult({
          deletedNames: deleted.map((item) => item.attributeName),
          blockedMessages: blockedMessages.filter(Boolean),
        });
      });
  };

  if (!projectId || !projectName) {
    return (
      <AiaBox
        sx={{
          flex: 1,
          minHeight: 0,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          gap: 1.5,
          bgcolor: "#F7F8FA",
          px: 3,
          textAlign: "center",
        }}
      >
        <AiaBox sx={{ fontSize: 16, fontWeight: 700, color: "var(--aia-text-color)" }}>
          Project context required
        </AiaBox>
        <AiaBox sx={{ fontSize: 13, color: "#64748B", maxWidth: 420 }}>
          Open Firm Values from a project card so project ID and name are passed in the route.
        </AiaBox>
        <AiaBox
          component="button"
          onClick={() => router.push("/projects")}
          sx={{
            mt: 1,
            border: "1px solid #E5E7EB",
            borderRadius: "10px",
            bgcolor: "#FFFFFF",
            color: "var(--aia-text-color)",
            fontSize: 13,
            fontWeight: 600,
            px: 2,
            py: 1,
            cursor: "pointer",
          }}
        >
          Back to Projects
        </AiaBox>
      </AiaBox>
    );
  }

  return (
    <>
      <AiaBox
        sx={{
          display: "flex",
          flex: 1,
          minHeight: 0,
          flexDirection: "column",
          overflow: "hidden",
          bgcolor: "#F7F8FA",
        }}
      >
        <AiaBox
          sx={{
            flex: 1,
            minHeight: 0,
            overflowY: "auto",
            px: { xs: 2.5, md: 3.5 },
            py: 2.5,
          }}
        >
          <AttributesHeader
            projectName={projectName}
            canEdit={canEdit}
            selectedCount={selectedIds.length}
            onImportAttributes={() => setIsImportModalOpen(true)}
            onCreateAttribute={handleOpenCreate}
            onDeleteSelected={() => {
              const selected = new Set(selectedIds);
              setDeletingAttributes(filteredAttributes.filter((row) => selected.has(row.id)));
            }}
          />
          {valueNotice ? (
            <AiaBox sx={{ mt: 1.5, color: "#B45309", fontSize: 12 }}>{valueNotice}</AiaBox>
          ) : null}
          {loadError ? (
            <AiaBox sx={{ mt: 1.5, display: "flex", alignItems: "center", gap: 1.5, color: "#DC2626", fontSize: 12 }}>
              <span>{loadError}</span>
              <AiaButton
                size="small"
                variant="outlined"
                color="error"
                onClick={() => setReloadToken((value) => value + 1)}
                sx={{ textTransform: "none", minWidth: 0 }}
              >
                Retry
              </AiaButton>
            </AiaBox>
          ) : null}

          <AiaBox sx={{ mt: 2.5 }}>
            <AttributesTable
              variant="landing"
              selectable={canEdit}
              rows={filteredAttributes}
              selectedIds={selectedIds}
              onToggleRow={canEdit ? handleToggleRow : undefined}
              onToggleAll={canEdit ? handleToggleAll : undefined}
              onEdit={canEdit ? handleOpenEdit : undefined}
              onDelete={canEdit ? (row) => setDeletingAttributes([row]) : undefined}
            />
          </AiaBox>
        </AiaBox>
      </AiaBox>

      <NewAttributeModal
        open={isFormModalOpen}
        projectName={projectName}
        mode={modalMode}
        initialValues={editingAttribute}
        existingFirmValues={firmValueIdentities}
        ignoreFirmValueId={modalMode === "edit" ? editingAttribute?.id : undefined}
        onClose={handleCloseFormModal}
        onSubmit={handleSubmitAttribute}
      />

      <ImportAttributesModal
        open={isImportModalOpen}
        currentProjectId={projectId}
        currentProjectName={projectName}
        onClose={() => setIsImportModalOpen(false)}
        onImport={handleImportAttributes}
      />

      <DeleteAttributeModal
        open={deletingAttributes.length > 0 || Boolean(deleteResult)}
        attributes={deletingAttributes}
        result={deleteResult}
        onClose={() => {
          setDeletingAttributes([]);
          setDeleteResult(null);
        }}
        onConfirm={handleConfirmDelete}
      />

      <AiaLoadingOverlay
        blocking
        open={pendingRequests.length > 0}
        label={pendingRequests[pendingRequests.length - 1] ?? "Loading firm values…"}
        zIndex={MODAL_ABOVE_AI_CHAT_Z_INDEX}
      />
    </>
  );
}

export default function AttributesPage() {
  return (
    <Suspense
      fallback={
        <AiaBox
          sx={{
            flex: 1,
            minHeight: 0,
            bgcolor: "#F7F8FA",
          }}
        />
      }
    >
      <AttributesPageContent />
    </Suspense>
  );
}
