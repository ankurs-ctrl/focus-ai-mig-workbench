-- One-release compatibility migration: legacy request values remain accepted by
-- the API, while persisted bundle records expose only the canonical runtime mode.
UPDATE __STTM_METADATA_NAMESPACE__.TBL_SEMANTIC_BUNDLES
SET SEMANTIC_LEVEL = 'FULL_REGISTRY',
    BUNDLE_ARTIFACT = IFF(
        BUNDLE_ARTIFACT IS NULL,
        NULL,
        OBJECT_INSERT(
            OBJECT_INSERT(BUNDLE_ARTIFACT, 'requested_level', 'FULL_REGISTRY', TRUE),
            'achieved_level',
            'FULL_REGISTRY',
            TRUE
        )
    ),
    UPDATED_AT = CURRENT_TIMESTAMP()
WHERE COALESCE(SEMANTIC_LEVEL, '') IN (
    'L0_RELATIONSHIP',
    'L1_CONTEXT',
    'L2_ANALYST_READY',
    'L3_MAPPING_ENRICHED'
);
