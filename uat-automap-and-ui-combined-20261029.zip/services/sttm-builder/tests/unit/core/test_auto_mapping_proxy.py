import threading
import time

import pytest

from fastapi import Request
from fastapi import testclient as fastapi_testclient

from app.auth.models import AppPersona, CurrentPrincipal, PermissionSet
from app.core.auto_mapping_proxy import AutoMappingProxyClient
from app.core.config import Settings
from app.schema.common import TableRef
from app.schema.sttm_builder import (
    AttributeMapping,
    Interface,
    LearningContext,
    MappingPrecedentContext,
    RelationGraphContext,
    RelationNode,
    RelationNodeKind,
    SemanticContextItem,
    SourceMappingResult,
    STTMBuilderContext,
    STTMBuilderEnvelopeRequest,
    STTMBuilderRequestData,
    STTMBuilderResponse,
    STTMOperation,
    STTMStatus,
    SubAgent,
    TargetAttributeItem,
    TransformationResult,
    TransformationRule,
)


def test_worker_headers_refresh_verified_session_without_forwarding_session_id(monkeypatch):
    from types import SimpleNamespace
    from app.core.auto_mapping_proxy import _DelegatedHeaders
    import app.auth.custom_oauth as oauth

    proxy = AutoMappingProxyClient(Settings(_env_file=None, AUTH_MODE="custom_oauth"))
    headers = _DelegatedHeaders({"X-Workbench-OAuth-Access-Token": "old",
        "X-Workbench-OAuth-User": "alice", "X-Workbench-OAuth-Role": "reader"}, session_id="session")
    record = SimpleNamespace(snowflake_user="ALICE", snowflake_role="READER")
    monkeypatch.setattr(oauth, "_session_select_row", lambda session_id, settings: record)
    monkeypatch.setattr(oauth, "_refresh_session_if_needed", lambda value, settings: value)
    monkeypatch.setattr(oauth, "decrypt_access_token", lambda value, settings: "fresh")
    actual = proxy._fresh_worker_headers(headers)
    assert actual["X-Workbench-OAuth-Access-Token"] == "fresh"
    assert "session" not in actual.values()
    assert headers["X-Workbench-OAuth-Access-Token"] == "old"


def test_worker_refresh_rejects_changed_identity(monkeypatch):
    import pytest
    from fastapi import HTTPException
    from types import SimpleNamespace
    from app.core.auto_mapping_proxy import _DelegatedHeaders
    import app.auth.custom_oauth as oauth

    proxy = AutoMappingProxyClient(Settings(_env_file=None, AUTH_MODE="custom_oauth"))
    headers = _DelegatedHeaders({"X-Workbench-OAuth-User": "alice",
        "X-Workbench-OAuth-Role": "reader"}, session_id="session")
    monkeypatch.setattr(oauth, "_session_select_row", lambda *args: SimpleNamespace(
        snowflake_user="bob", snowflake_role="reader"))
    with pytest.raises(HTTPException) as error:
        proxy._fresh_worker_headers(headers)
    assert error.value.status_code == 401


def test_single_batch_unresolved_result_has_truthful_terminal_review(monkeypatch):
    proxy = AutoMappingProxyClient(Settings(_env_file=None, AUTO_MAPPING_PROXY_BATCH_SIZE=16))
    request = _request(2)
    response = _response(request)
    for mapping in response.result.mappings.values():
        mapping.transformation_classification = 'unresolved'
        mapping.unmatched_reason = 'Source binding does not fit the prepared graph.'
    response.data.result = response.result
    monkeypatch.setattr(proxy, '_invoke_complete_batch', lambda *args, **kwargs: response)
    actual = proxy._invoke_with_headers(request, headers={})
    assert actual.data.status == STTMStatus.NEEDS_INPUT
    assert actual.meta['auto_mapping_review']['unresolved_count'] == 2
    assert actual.meta['auto_mapping_review']['mapped_count'] == 0
    assert actual.meta['auto_mapping_dispatch']['batch_count'] == 1


def test_no_agent_call_batch_is_partial_without_dropping_other_batch_results(monkeypatch):
    settings = Settings(_env_file=None, AUTOMAP_CONTEXT_RETRIEVAL_V1=True)
    proxy = AutoMappingProxyClient(settings)
    request = _request(8)
    def invoke(batch, *, batch_index, **kwargs):
        response = _response(batch)
        if batch_index == 1:
            response.thread_id = None
            response.meta["auto_map_retrieval"] = {
                "parallel_preparation": {"enabled": True}, "model_call_count": 0,
            }
            for mapping in response.result.mappings.values():
                mapping.source_attributes = []
                mapping.transformation_classification = "unresolved"
                mapping.unmatched_reason = "Preparation stopped before source mapping."
            response.data.result = response.result
        return response
    monkeypatch.setattr(proxy, "_invoke_complete_batch", invoke)
    result = proxy._invoke_with_headers(request, headers={})
    assert len(result.result.mappings) == 8
    assert result.meta["auto_mapping_dispatch"]["failed_batches"] == [1]
    assert result.meta["auto_mapping_dispatch"]["incomplete_worker_batches"] == [1]
    assert result.data.status == STTMStatus.NEEDS_INPUT
    assert sum(mapping.transformation_classification == "unresolved"
               for mapping in result.result.mappings.values()) == 2


def _request(attribute_count: int = 6) -> STTMBuilderEnvelopeRequest:
    source = TableRef(database="DB", schema="SRC", table="SOURCE")
    target = TableRef(database="DB", schema="TGT", table="TARGET")
    return STTMBuilderEnvelopeRequest(
        request_id="request-123",
        operation=STTMOperation.AUTO_MAP,
        context=STTMBuilderContext(source_tables=[source], target_table=target),
        data=STTMBuilderRequestData(
            intent=Interface.AUTO_MAP,
            attributes=[
                TargetAttributeItem(
                    target_table=target,
                    target_attribute=f"COL_{index}",
                )
                for index in range(attribute_count)
            ],
        ),
    )


def _response(req: STTMBuilderEnvelopeRequest) -> STTMBuilderResponse:
    mappings = {
        item.target_attribute: AttributeMapping(
            source_attributes=[f"DB.SRC.SOURCE.{item.target_attribute}"],
            confidence_score=0.9,
        )
        for item in req.data.attributes or []
    }
    return STTMBuilderResponse.from_invocation(
        req,
        thread_id="worker-thread",
        parent_message_id=None,
        agent=SubAgent.SOURCE_MAPPING_AGENT,
        result=SourceMappingResult(mappings=mappings),
        message="ok",
        status=STTMStatus.COMPLETED,
    )


def _partial_response(
    req: STTMBuilderEnvelopeRequest,
    returned_targets: set[str],
) -> STTMBuilderResponse:
    response = _response(req)
    result = SourceMappingResult(
        mappings={
            target: mapping
            for target, mapping in response.result.mappings.items()
            if target in returned_targets
        }
    )
    return response.model_copy(
        update={
            "result": result,
            "data": response.data.model_copy(update={"result": result}),
        }
    )


def test_local_v2_defaults_to_private_inprocess_worker() -> None:
    local = Settings(
        _env_file=None,
        APP_ENV="local",
        AUTO_MAP_PIPELINE_V2=True,
        AUTO_MAPPING_SERVICE_URL="",
    )
    deployed = Settings(
        _env_file=None,
        APP_ENV="production",
        AUTO_MAP_PIPELINE_V2=True,
        AUTO_MAPPING_SERVICE_URL="",
    )

    assert local.resolved_auto_mapping_service_url == "inprocess"
    assert local.auto_mapping_service_enabled is True
    assert AutoMappingProxyClient(local).enabled is True
    assert deployed.resolved_auto_mapping_service_url == ""
    assert deployed.auto_mapping_service_enabled is False
    assert AutoMappingProxyClient(deployed).enabled is False


@pytest.mark.parametrize("configured_limit", [1, 2, 4, 8])
def test_retrieval_caps_actual_dispatch_and_preserves_four_batches(monkeypatch, configured_limit):
    settings = Settings(_env_file=None, AUTOMAP_CONTEXT_RETRIEVAL_V1=True,
                        AUTOMAP_CONTEXT_BATCH_COUNT=4,
                        AUTO_MAPPING_PROXY_MAX_IN_FLIGHT=configured_limit)
    client = AutoMappingProxyClient(settings)
    req = _request(37)
    expected_limit = min(4, configured_limit)
    barrier = threading.Barrier(expected_limit)
    lock = threading.Lock()
    calls = []
    active = 0
    max_active = 0

    def invoke(batch, **kwargs):
        nonlocal active, max_active
        with lock:
            calls.append([item.target_attribute for item in batch.data.attributes])
            active += 1
            max_active = max(max_active, active)
        try:
            barrier.wait(timeout=5)
            return _response(batch)
        finally:
            with lock:
                active -= 1

    monkeypatch.setattr(client, "_invoke_batch", invoke)
    response = client._invoke_with_headers(req, headers={})
    assert len(calls) == 4
    assert sorted(map(len, calls)) == [9, 9, 9, 10]
    assert list(response.result.mappings) == [f"COL_{index}" for index in range(37)]
    assert max_active == expected_limit
    assert active == 0
    assert response.meta["auto_mapping_dispatch"]["max_in_flight"] == min(5, configured_limit)
    assert response.meta["auto_mapping_dispatch"]["failed_batches"] == []


@pytest.mark.parametrize("configured_limit", [0, 1, 2, 8])
def test_retrieval_off_keeps_existing_proxy_limit_behavior(configured_limit):
    client = AutoMappingProxyClient(Settings(_env_file=None,
        AUTOMAP_CONTEXT_RETRIEVAL_V1=False, AUTO_MAPPING_PROXY_MAX_IN_FLIGHT=configured_limit))
    assert client._max_in_flight == max(1, configured_limit)


def test_retrieval_resume_rejects_singleton_foreign_context_and_old_strategy(monkeypatch):
    settings = Settings(_env_file=None, AUTOMAP_CONTEXT_RETRIEVAL_V1=True)
    client = AutoMappingProxyClient(settings)
    req = _request(8)
    batches = client._build_batches(req)
    accepted = req.model_copy(update={"data": req.data.model_copy(update={"attributes": batches[0]})})
    identity = client._batch_identity(req, batches[0])
    partials = [{"batch_index": 0, "response": _response(accepted).model_dump(mode="json"), "batch_identity": identity}]
    for index, change in enumerate(({"context_hash": "foreign"}, {"strategy_version": "singleton"}, {"target_attributes": ["COL_1"]}), 1):
        partials.append({"batch_index": index, "response": _response(req).model_dump(mode="json"),
                         "batch_identity": {**client._batch_identity(req, batches[index]), **change}})
    calls = []
    def invoke(batch, **kwargs):
        calls.append(kwargs["batch_index"])
        return _response(batch)
    monkeypatch.setattr(client, "_invoke_batch", invoke)
    response = client._invoke_with_headers(req, headers={}, resume_partials=partials)
    assert sorted(calls) == [1, 2, 3]
    assert response.meta["auto_mapping_dispatch"]["resumed_batch_indices"] == [0]


def test_retrieval_never_splits_oversized_batch_into_hidden_worker_calls(monkeypatch):
    import pytest
    from app.core.agent_payload_budget import AgentPayloadBudgetError
    client = AutoMappingProxyClient(Settings(_env_file=None, AUTOMAP_CONTEXT_RETRIEVAL_V1=True))
    calls = []
    def invoke(req, **kwargs):
        calls.append(len(req.data.attributes))
        raise AgentPayloadBudgetError("bounded batch failed")
    monkeypatch.setattr(client, "_invoke_batch", invoke)
    with pytest.raises(AgentPayloadBudgetError):
        client._invoke_complete_batch(_request(10), headers={}, batch_index=0)
    assert calls == [10]


def test_oversized_batch_recovers_internally_without_losing_targets(monkeypatch):
    from app.core.agent_payload_budget import AgentPayloadBudgetError
    settings = Settings(_env_file=None)
    client = AutoMappingProxyClient(settings)
    request = _request(8)
    calls = []

    def invoke(req, **kwargs):
        calls.append(len(req.data.attributes))
        if len(req.data.attributes) > 2:
            raise AgentPayloadBudgetError("remote context window")
        return _response(req)

    monkeypatch.setattr(client, "_invoke_batch", invoke)
    response = client._invoke_complete_batch(request, headers={}, batch_index=0)
    assert set(response.result.mappings) == {f"COL_{index}" for index in range(8)}
    assert calls == [8, 4, 2, 2, 4, 2, 2]
    assert response.meta["automatic_context_split"] is True


def test_planner_projection_matches_worker_and_transport_is_lossless():
    import hashlib
    from app.core.sttm_builder import STTMBuilderService
    settings = Settings(_env_file=None)
    request = _request(4)
    client = AutoMappingProxyClient(settings)
    transport, _ = client._budget_batch_request(request)
    assert transport.context == request.context
    planned = STTMBuilderService.project_agent_payload(request, settings)
    service = STTMBuilderService.__new__(STTMBuilderService)
    service._settings = settings
    dispatched = service._build_agent_payload(transport)
    assert hashlib.sha256(planned.text.encode()).hexdigest() == hashlib.sha256(dispatched.encode()).hexdigest()


def test_resumed_oversized_projection_subdivides_and_keeps_every_child_audit(monkeypatch):
    from app.core.agent_payload_budget import AgentPayloadBudgetError
    from app.core.sttm_builder import STTMBuilderService
    settings = Settings(_env_file=None)
    client = AutoMappingProxyClient(settings)
    original = STTMBuilderService.project_agent_payload

    def project(req, config, **kwargs):
        if len(req.data.attributes) > 2:
            raise AgentPayloadBudgetError("local budget changed")
        return original(req, config, **kwargs)

    calls = []

    def invoke(req, **kwargs):
        targets = [item.target_attribute for item in req.data.attributes]
        calls.append(targets)
        response = _response(req)
        response.meta["agent_payload_attempts"] = [{"targets": targets}]
        return response

    monkeypatch.setattr(STTMBuilderService, "project_agent_payload", project)
    monkeypatch.setattr(client, "_invoke_batch", invoke)
    response = client._invoke_complete_batch(_request(8), headers={}, batch_index=0)
    assert len(calls) == 4
    assert len(response.result.mappings) == 8
    assert [item["targets"] for item in response.meta["agent_payload_attempts"]] == calls
    assert response.meta["planned_model_payload"]["split_reason"] == "local_context_budget"


def test_proxy_fans_out_two_batches_and_preserves_mapping_order(monkeypatch) -> None:
    settings = Settings(
        _env_file=None,
        AUTH_MODE="custom_oauth",
        AUTO_MAPPING_SERVICE_URL="http://worker.internal:8000",
        AUTO_MAPPING_PROXY_BATCH_SIZE=2,
        AUTO_MAPPING_PROXY_MAX_IN_FLIGHT=2,
    )
    proxy = AutoMappingProxyClient(settings)
    envelope = _request()
    http_request = Request({"type": "http", "method": "POST", "path": "/", "headers": []})
    http_request.state.current_principal = CurrentPrincipal(
        user_id=1,
        snowflake_user="ALICE",
        email="alice@example.com",
        display_name="Alice",
        app_persona=AppPersona.ADMIN,
        permissions=PermissionSet(can_read=True, can_edit=True),
        snowflake_user_token="oauth-secret-token",
        snowflake_role="FOCUS_ADMIN",
    )

    lock = threading.Lock()
    active = 0
    max_active = 0
    captured_headers: list[dict[str, str]] = []
    captured_payloads: list[str] = []

    def fake_invoke_batch(req, *, headers, batch_index):  # type: ignore[no-untyped-def]
        nonlocal active, max_active
        with lock:
            active += 1
            max_active = max(max_active, active)
            captured_headers.append(headers)
            captured_payloads.append(req.model_dump_json())
        time.sleep(0.03 if batch_index == 0 else 0.01)
        with lock:
            active -= 1
        return _response(req)

    monkeypatch.setattr(proxy, "_invoke_batch", fake_invoke_batch)

    result = proxy.invoke(http_request, envelope)

    assert max_active == 2
    assert list(result.result.mappings) == [f"COL_{index}" for index in range(6)]
    assert result.contract_version == "1.0"
    assert result.meta["auto_mapping_dispatch"] == {
        "attribute_count": 6,
        "batch_count": 3,
        "batch_size": 2,
        "batch_sizes": [2, 2, 2],
        "batching_mode": "adaptive_complexity_token_budget",
        "max_in_flight": 2,
        "resumed_batch_indices": [],
        "failed_batches": [],
    }
    assert result.meta["auto_mapping_review"]["headline"] == (
        "Auto-map completed: 6/6 targets mapped. No mapping issues were detected."
    )
    assert result.meta["auto_mapping_review"]["recommendations"] == []
    assert all(item["X-Workbench-OAuth-Access-Token"] == "oauth-secret-token" for item in captured_headers)
    assert all("oauth-secret-token" not in item for item in captured_payloads)


def test_proxy_does_not_duplicate_worker_transformation_after_source_batches(monkeypatch) -> None:
    settings = Settings(
        _env_file=None,
        AUTO_MAPPING_SERVICE_URL="http://worker.internal:8000",
        AUTO_MAPPING_PROXY_BATCH_SIZE=2,
        AUTO_MAPPING_PROXY_MAX_IN_FLIGHT=5,
    )
    proxy = AutoMappingProxyClient(settings)
    envelope = _request(attribute_count=5)
    transform_calls: list[STTMBuilderEnvelopeRequest] = []

    def fake_invoke_batch(req, *, headers, batch_index):  # type: ignore[no-untyped-def]
        if req.data.intent == Interface.TRANSFORM:
            transform_calls.append(req)
            rules = [
                TransformationRule(
                    target_attribute=item.target_attribute,
                    rule=f"UPPER({item.target_attribute})",
                    description="Normalize the value.",
                )
                for item in req.data.attributes or []
            ]
            return STTMBuilderResponse.from_invocation(
                req,
                thread_id="transform-thread",
                parent_message_id=None,
                agent=SubAgent.TRANSFORMATION_AGENT,
                result=TransformationResult(rules=rules),
                message="transformed",
                status=STTMStatus.COMPLETED,
            )
        response = _response(req)
        source_result = response.result
        assert isinstance(source_result, SourceMappingResult)
        complex_result = SourceMappingResult(
            mappings={
                target: mapping.model_copy(
                    update={
                        "transformation_classification": "complex",
                        "preprocessing_rule_type": "Custom",
                    }
                )
                for target, mapping in source_result.mappings.items()
            }
        )
        return response.model_copy(
            update={
                "result": complex_result,
                "data": response.data.model_copy(update={"result": complex_result}),
            }
        )

    monkeypatch.setattr(proxy, "_invoke_batch", fake_invoke_batch)

    response = proxy._invoke_with_headers(envelope, headers={})

    assert transform_calls == []
    assert "transformation_stage" not in response.meta
    assert all(
        mapping.preprocessing_rule_type == "Custom"
        for mapping in response.result.mappings.values()
    )
def test_proxy_retries_only_targets_omitted_by_agent(monkeypatch) -> None:
    settings = Settings(
        _env_file=None,
        AUTO_MAPPING_SERVICE_URL="http://worker.internal:8000",
        AUTO_MAPPING_PROXY_BATCH_SIZE=6,
        AUTO_MAPPING_SERVICE_RETRY_ATTEMPTS=2,
    )
    proxy = AutoMappingProxyClient(settings)
    envelope = _request(attribute_count=6)
    invoked_targets: list[list[str]] = []

    def fake_invoke_batch(req, *, headers, batch_index):  # type: ignore[no-untyped-def]
        targets = [item.target_attribute for item in req.data.attributes or []]
        invoked_targets.append(targets)
        if len(invoked_targets) == 1:
            return _partial_response(req, set(targets[:4]))
        return _response(req)

    monkeypatch.setattr(proxy, "_invoke_batch", fake_invoke_batch)

    response = proxy._invoke_with_headers(envelope, headers={})

    assert invoked_targets == [
        ["COL_0", "COL_1", "COL_2", "COL_3", "COL_4", "COL_5"],
        ["COL_4", "COL_5"],
    ]
    assert {
        AutoMappingProxyClient._normalized_target(target)
        for target in response.result.mappings
    } == {f"COL_{index}" for index in range(6)}


def test_proxy_never_silently_completes_with_omitted_targets(monkeypatch) -> None:
    settings = Settings(
        _env_file=None,
        AUTO_MAPPING_SERVICE_URL="http://worker.internal:8000",
        AUTO_MAPPING_PROXY_BATCH_SIZE=6,
        AUTO_MAPPING_SERVICE_RETRY_ATTEMPTS=2,
    )
    proxy = AutoMappingProxyClient(settings)
    envelope = _request(attribute_count=6)

    def fake_invoke_batch(req, *, headers, batch_index):  # type: ignore[no-untyped-def]
        targets = [item.target_attribute for item in req.data.attributes or []]
        return _partial_response(req, set(targets[:1]))

    monkeypatch.setattr(proxy, "_invoke_batch", fake_invoke_batch)

    response = proxy._invoke_with_headers(envelope, headers={})

    assert list(response.result.mappings) == [f"COL_{index}" for index in range(6)]
    assert response.data.status == STTMStatus.NEEDS_INPUT
    assert response.meta["auto_mapping_coverage"] == {
        "requested": 6,
        "returned": 2,
        "omitted_targets": ["COL_2", "COL_3", "COL_4", "COL_5"],
    }
    for target in ("COL_2", "COL_3", "COL_4", "COL_5"):
        assert response.result.mappings[target].transformation_classification == "unresolved"
    assert [warning.field for warning in response.warnings] == [
        "COL_2",
        "COL_3",
        "COL_4",
        "COL_5",
    ]


def test_inprocess_worker_adapter_uses_private_worker_contract(monkeypatch) -> None:
    settings = Settings(
        _env_file=None,
        AUTO_MAPPING_SERVICE_URL="inprocess",
    )
    proxy = AutoMappingProxyClient(settings)
    envelope = _request(attribute_count=2)
    captured: dict[str, object] = {}

    class FakeResponse:
        status_code = 200

        def json(self):
            return _response(envelope).model_dump(mode="json")

    class FakeTestClient:
        def __init__(self, app):
            captured["app"] = app

        def __enter__(self):
            return self

        def __exit__(self, *_args):
            return None

        def post(self, path, *, headers, json):
            captured.update({"path": path, "headers": headers, "json": json})
            return FakeResponse()

    monkeypatch.setattr(fastapi_testclient, "TestClient", FakeTestClient)

    response = proxy._invoke_batch(
        envelope,
        headers={"Content-Type": "application/json"},
        batch_index=0,
    )

    assert captured["path"] == "/api/v1/auto-mapping/invoke"
    assert captured["json"]["request_id"] == "request-123"
    assert response.data is not None
    assert response.data.status == STTMStatus.COMPLETED


def test_inprocess_worker_retries_transient_response(monkeypatch) -> None:
    settings = Settings(
        _env_file=None,
        AUTO_MAPPING_SERVICE_URL="inprocess",
        AUTO_MAPPING_SERVICE_RETRY_ATTEMPTS=2,
    )
    proxy = AutoMappingProxyClient(settings)
    envelope = _request(attribute_count=2)
    attempts = 0

    class FakeResponse:
        def __init__(self, status_code: int):
            self.status_code = status_code

        def json(self):
            if self.status_code == 200:
                return _response(envelope).model_dump(mode="json")
            return {
                "error": {
                    "code": "SNOWFLAKE_AGENT_ERROR",
                    "detail": "Temporary Cortex failure",
                }
            }

    class FakeTestClient:
        def __init__(self, _app):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *_args):
            return None

        def post(self, _path, *, headers, json):
            nonlocal attempts
            attempts += 1
            return FakeResponse(503 if attempts == 1 else 200)

    monkeypatch.setattr(fastapi_testclient, "TestClient", FakeTestClient)
    monkeypatch.setattr(time, "sleep", lambda _seconds: None)

    response = proxy._invoke_batch(envelope, headers={}, batch_index=0)

    assert attempts == 2
    assert response.data is not None
    assert response.data.status == STTMStatus.COMPLETED


def test_worker_response_rejects_fabricated_precedent_claim_without_losing_mapping() -> None:
    envelope = _request(attribute_count=1)
    response = _response(envelope)
    result = response.data.result
    assert isinstance(result, SourceMappingResult)
    mapping = result.mappings["COL_0"]
    mapping.precedent_decision = "accept_precedent"
    mapping.precedent_mapping_id = "fabricated-semantic-pattern"

    AutoMappingProxyClient._validate_worker_response(
        response,
        req=envelope,
        batch_index=0,
    )

    assert mapping.source_attributes == ["DB.SRC.SOURCE.COL_0"]
    assert mapping.precedent_decision == "unresolved"
    assert mapping.precedent_mapping_id is None
    assert any(
        warning.code == "AUTO_MAPPING_PRECEDENT_DECISION_NORMALIZED"
        for warning in response.warnings
    )


def test_worker_response_does_not_require_precedent_for_fresh_verified_mapping() -> None:
    envelope = _request(attribute_count=1)
    response = _response(envelope)
    mapping = response.result.mappings["COL_0"]
    mapping.precedent_decision = None
    mapping.precedent_mapping_id = None

    AutoMappingProxyClient._validate_worker_response(
        response,
        req=envelope,
        batch_index=0,
    )

    assert mapping.source_attributes == ["DB.SRC.SOURCE.COL_0"]
    assert mapping.precedent_decision is None
    assert not any(
        warning.code == "AUTO_MAPPING_PRECEDENT_DECISION_NORMALIZED"
        for warning in response.warnings
    )


def test_mapping_review_counts_valid_binding_with_unverified_precedent_as_review() -> None:
    mapping = AttributeMapping(
        source_attributes=["DB.SCHEMA.ADDRESSES.CITY"],
        confidence_score=0.95,
        precedent_decision="unresolved",
        confidence_reason="The source binding is verified but the precedent citation is not.",
    )

    message, review = AutoMappingProxyClient._build_mapping_review(
        {"DB.TARGET.HOUSEHOLD.BILLINGCITY": mapping}
    )

    assert review["mapped_count"] == 1
    assert review["action_required_count"] == 0
    assert review["mapped_with_review_count"] == 1
    assert "1/1 targets mapped" in message


def test_worker_response_accepts_only_an_actual_linked_precedent_id() -> None:
    envelope = _request(attribute_count=1)
    envelope = envelope.model_copy(
        update={
            "context": envelope.context.model_copy(
                update={
                    "learning_context": LearningContext(
                        mapping_precedents=[
                            MappingPrecedentContext(
                                precedent_sttm_id="1101",
                                precedent_project_id="903",
                                compatibility="similar",
                                confidence=0.9,
                            )
                        ]
                    )
                }
            )
        }
    )
    response = _response(envelope)
    result = response.data.result
    assert isinstance(result, SourceMappingResult)
    mapping = result.mappings["COL_0"]
    mapping.precedent_decision = "accept_precedent"
    mapping.precedent_mapping_id = "1101"

    AutoMappingProxyClient._validate_worker_response(
        response,
        req=envelope,
        batch_index=0,
    )

    assert mapping.precedent_decision == "accept_precedent"
    assert mapping.precedent_mapping_id == "1101"
    assert response.warnings == []


def test_worker_response_rejects_accept_when_value_contract_changed() -> None:
    envelope = _request(attribute_count=1)
    envelope = envelope.model_copy(
        update={
            "context": envelope.context.model_copy(
                update={
                    "learning_context": LearningContext(
                        mapping_precedents=[
                            MappingPrecedentContext(
                                precedent_sttm_id="1101",
                                mappings=[
                                    {
                                        "target_column": "COL_0",
                                        "mapping_mode": "constant",
                                        "constant_value": "$ClientStartDate",
                                        "preprocessing_rule_type": "Value",
                                    }
                                ],
                            )
                        ]
                    )
                }
            )
        }
    )
    response = _response(envelope)
    mapping = response.result.mappings["COL_0"]
    mapping.precedent_decision = "accept_precedent"
    mapping.precedent_mapping_id = "1101"
    mapping.mapping_mode = "source"

    AutoMappingProxyClient._validate_worker_response(
        response,
        req=envelope,
        batch_index=0,
    )

    assert mapping.precedent_decision == "unresolved"
    assert mapping.precedent_mapping_id is None
    assert any(
        warning.code == "AUTO_MAPPING_PRECEDENT_DECISION_NORMALIZED"
        for warning in response.warnings
    )


def test_worker_response_leaves_absent_derived_output_unresolved() -> None:
    envelope = _request(attribute_count=1)
    envelope = envelope.model_copy(
        update={
            "context": envelope.context.model_copy(
                update={
                    "relation_graph": RelationGraphContext(
                        nodes=[
                            RelationNode(
                                relation_id="derived_household",
                                kind=RelationNodeKind.DERIVED_SOURCE,
                                alias="derived_household_1",
                                output_columns=[
                                    {"name": "HOUSEHOLD_ID", "data_type": "NUMBER"}
                                ],
                            )
                        ]
                    )
                }
            )
        }
    )
    response = _response(envelope)
    mapping = response.result.mappings["COL_0"]
    mapping.source_attributes = ["derived_household.MISSING_FIELD"]
    mapping.source_dependencies = ["derived_household.MISSING_FIELD"]
    mapping.preprocessing_rule = "COALESCE(derived_household.MISSING_FIELD, '')"

    AutoMappingProxyClient._validate_worker_response(
        response,
        req=envelope,
        batch_index=0,
    )

    assert mapping.source_attributes == []
    assert mapping.source_dependencies == []
    assert mapping.preprocessing_rule is None
    assert mapping.precedent_decision == "unresolved"
    assert "not present" in str(mapping.unmatched_reason)
    assert any(
        warning.code == "AUTO_MAPPING_DERIVED_OUTPUT_NOT_FOUND"
        for warning in response.warnings
    )


def test_worker_response_keeps_verified_physical_source_when_derived_alias_is_absent() -> None:
    envelope = _request(attribute_count=1)
    envelope = envelope.model_copy(
        update={
            "context": envelope.context.model_copy(
                update={
                    "relation_graph": RelationGraphContext(
                        nodes=[
                            RelationNode(
                                relation_id="derived_household",
                                kind=RelationNodeKind.DERIVED_SOURCE,
                                alias="derived_household_1",
                                output_columns=[
                                    {"name": "HOUSEHOLD_ID", "data_type": "NUMBER"}
                                ],
                            )
                        ]
                    )
                }
            )
        }
    )
    response = _response(envelope)
    mapping = response.result.mappings["COL_0"]
    physical = "DB.SCHEMA.CONTACTS.LEGACY_HH_ID"
    mapping.source_attributes = [physical, "derived_household.MISSING_FIELD"]
    mapping.source_dependencies = [physical, "derived_household.MISSING_FIELD"]
    mapping.preprocessing_rule = "derived_household.MISSING_FIELD"
    mapping.preprocessing_rule_type = "Custom"

    AutoMappingProxyClient._validate_worker_response(
        response,
        req=envelope,
        batch_index=0,
    )

    assert mapping.source_attributes == [physical]
    assert mapping.source_dependencies == [physical]
    assert mapping.preprocessing_rule == "Direct"
    assert mapping.preprocessing_rule_type == "Direct"
    assert mapping.precedent_decision != "unresolved"
    assert mapping.unmatched_reason is None


def test_mapping_review_explains_missing_derived_outputs_and_next_action() -> None:
    mappings = {
        "LEGACY_FIRM_INFO__C": AttributeMapping(
            source_attributes=[],
            confidence_score=0.0,
            precedent_decision="unresolved",
            unmatched_reason=(
                "The proposed source derived_household.LEGACY_FIRM_INFO is not present "
                "in the selected derived source output contract."
            ),
            candidate_source_attributes=["CONTACT_UDFS.FIELD_VALUE"],
            used_learning_ids=["precedent-row-17"],
        ),
        "BILLINGCITY": AttributeMapping(
            source_attributes=["derived_household.BILLING_CITY"],
            confidence_score=0.72,
            confidence_reason="Only a semantic similarity match was available.",
            precedent_decision="override_precedent",
            override_evidence=["fir-12"],
        ),
    }

    message, review = AutoMappingProxyClient._build_mapping_review(mappings)

    assert "1/2 targets mapped" in message
    assert review["missing_derived_output_count"] == 1
    assert review["low_confidence_count"] == 1
    assert review["completed_without_review_count"] == 0
    assert review["mapped_with_review_count"] == 1
    assert review["action_required_count"] == 1
    categories = [item["category"] for item in review["recommendations"]]
    assert categories == [
        "missing_derived_output",
        "low_confidence",
        "precedent_override",
    ]
    missing = review["recommendations"][0]
    assert "Source Selection" in missing["recommended_action"]
    assert missing["candidate_sources"] == ["CONTACT_UDFS.FIELD_VALUE"]
    assert missing["evidence_ids"] == ["precedent-row-17"]


def test_exact_completed_precedent_replay_uses_zero_cortex_calls(monkeypatch) -> None:
    settings = Settings(
        _env_file=None,
        AUTO_MAPPING_SERVICE_URL="http://worker.internal:8000",
    )
    proxy = AutoMappingProxyClient(settings)
    envelope = _request(attribute_count=2)
    envelope = envelope.model_copy(
        update={
            "context": envelope.context.model_copy(
                update={
                    "replay_exact_precedent": True,
                    "learning_context": LearningContext(
                        mapping_precedents=[
                            MappingPrecedentContext(
                                precedent_sttm_id="1101",
                                precedent_project_id="903",
                                compatibility="exact",
                                confidence=1.0,
                                mappings=[
                                    {
                                        "mapping_id": "map-value",
                                        "target_column": "COL_0",
                                        "mapping_mode": "constant",
                                        "constant_value": "$ParentOfficeID",
                                        "preprocessing_rule": "Value",
                                        "preprocessing_rule_type": "Value",
                                    },
                                    {
                                        "mapping_id": "map-direct",
                                        "target_column": "COL_1",
                                        "mapping_mode": "source",
                                        "source_columns": ["SOURCE.COL_1"],
                                        "preprocessing_rule": "Direct",
                                        "preprocessing_rule_type": "Direct",
                                    },
                                ],
                                ctes=[{"name": "SOURCE"}],
                                business_rules=[{"rule_type": "filter"}],
                                raw_sql_hash="canonical-hash",
                            )
                        ]
                    )
                }
            )
        }
    )
    monkeypatch.setattr(
        proxy,
        "_invoke_batch",
        lambda *_args, **_kwargs: (_ for _ in ()).throw(AssertionError("Cortex called")),
    )

    response = proxy._invoke_with_headers(envelope, headers={})

    assert response.data is not None
    result = response.data.result
    assert isinstance(result, SourceMappingResult)
    assert result.mappings["COL_0"].mapping_mode == "constant"
    assert result.mappings["COL_0"].constant_value == "$ParentOfficeID"
    assert result.mappings["COL_1"].precedent_decision == "accept_precedent"
    assert response.meta["auto_mapping_dispatch"]["batching_mode"] == "exact_precedent_cache"
    assert response.meta["accepted_precedent"]["cte_count"] == 1


def test_exact_completed_precedent_is_evidence_and_invokes_agent_by_default(
    monkeypatch,
) -> None:
    settings = Settings(
        _env_file=None,
        AUTO_MAPPING_SERVICE_URL="http://worker.internal:8000",
    )
    proxy = AutoMappingProxyClient(settings)
    envelope = _request(attribute_count=1)
    envelope = envelope.model_copy(
        update={
            "context": envelope.context.model_copy(
                update={
                    "learning_context": LearningContext(
                        mapping_precedents=[
                            MappingPrecedentContext(
                                precedent_sttm_id="1101",
                                precedent_project_id="903",
                                compatibility="exact",
                                confidence=1.0,
                                mappings=[
                                    {
                                        "mapping_id": "map-direct",
                                        "target_column": "COL_0",
                                        "mapping_mode": "source",
                                        "source_columns": ["OLD_DB.SRC.CONTACTS.COL_0"],
                                    }
                                ],
                            )
                        ]
                    )
                }
            )
        }
    )
    invoked: list[STTMBuilderEnvelopeRequest] = []

    def fake_invoke_batch(req, *, headers, batch_index):  # type: ignore[no-untyped-def]
        invoked.append(req)
        return _response(req)

    monkeypatch.setattr(proxy, "_invoke_batch", fake_invoke_batch)

    response = proxy._invoke_with_headers(envelope, headers={})

    assert len(invoked) == 1
    assert invoked[0].context.learning_context is not None
    assert invoked[0].context.learning_context.mapping_precedents[0].precedent_sttm_id == "1101"
    assert response.meta.get("accepted_precedent") is None
    assert response.result.mappings["COL_0"].source_attributes == ["DB.SRC.SOURCE.COL_0"]


def test_terminal_partial_selection_matches_qualified_agent_target_keys() -> None:
    envelope = _request(attribute_count=2)
    response = _response(envelope)
    result = response.result
    assert isinstance(result, SourceMappingResult)
    result.mappings = {
        f"DB.TGT.TARGET.{target}": mapping
        for target, mapping in result.mappings.items()
    }

    partial = AutoMappingProxyClient._response_for_targets(response, {"COL_1"})

    assert list(partial.result.mappings) == ["DB.TGT.TARGET.COL_1"]


def test_durable_acceptance_returns_before_preparation_and_resumes_stage(monkeypatch):
    import copy
    from types import SimpleNamespace
    from app.core import auto_mapping_proxy as module
    settings = Settings(_env_file=None, AUTO_MAP_PIPELINE_V2=True,
                        AUTOMAP_CONTEXT_RETRIEVAL_V1=True, AUTO_MAPPING_SERVICE_URL="inprocess")
    proxy = AutoMappingProxyClient(settings)
    request = Request({"type": "http", "method": "POST", "path": "/", "headers": []})
    request.state.current_principal = SimpleNamespace(snowflake_user="ALICE", user_id=1)
    prepared_started, release, finished = threading.Event(), threading.Event(), threading.Event()
    persisted = []
    monkeypatch.setattr(proxy, "_load_persisted_job", lambda *args, **kwargs: copy.deepcopy(persisted[-1]) if persisted else None)
    monkeypatch.setattr(proxy, "_forward_headers", lambda request: {})
    monkeypatch.setattr(proxy, "_persist_job", lambda record, **kwargs: persisted.append(copy.deepcopy(record)))
    monkeypatch.setattr(proxy, "_open_job_client", lambda headers: SimpleNamespace(session=object(), close=finished.set))
    monkeypatch.setattr(proxy, "_claim_job_lease", lambda *args, **kwargs: True)
    def prepare(req, **kwargs):
        assert persisted[0]["preparation_pending"] is True
        prepared_started.set()
        assert release.wait(3)
        return req
    monkeypatch.setattr(proxy, "_prepare_job_request", prepare)
    monkeypatch.setattr(proxy, "_invoke_with_headers", lambda req, **kwargs: _response(req))
    accepted = proxy.start_job(request, _request(8), session=object(), prepare=True)
    try:
        assert prepared_started.wait(1)
        assert accepted["status"] in {"queued", "running"}
        assert accepted["batch_count"] == 0
        assert "request_envelope" not in accepted
    finally:
        release.set()
    assert finished.wait(3)
    terminal = persisted[-1]
    assert terminal["status"] == "completed"
    assert terminal["preparation_pending"] is False
    assert terminal["batch_count"] == 4
    assert terminal["preparation_ms"] >= 0
    assert len(terminal["partial_responses"]) == 4
    with module._AUTO_MAP_JOBS_LOCK:
        module._AUTO_MAP_JOBS.pop(accepted["job_id"], None)


def test_poll_does_not_replace_live_dispatcher_revision_or_lease(monkeypatch):
    from types import SimpleNamespace
    from app.core import auto_mapping_proxy as module
    proxy = AutoMappingProxyClient(Settings(_env_file=None, AUTO_MAP_PIPELINE_V2=True))
    request = Request({"type":"http", "method":"GET", "path":"/", "headers":[]})
    request.state.current_principal = SimpleNamespace(snowflake_user="ALICE", user_id=1)
    live = {"job_id":"poll-race", "owner":"ALICE", "status":"running", "state_version":5,
            "batch_count":4, "dispatcher_lease_owner":"fence", "preparation_pending":False}
    stale = {**live, "state_version":2, "batch_count":0, "preparation_pending":True}
    monkeypatch.setattr(proxy, "_forward_headers", lambda request:{})
    monkeypatch.setattr(proxy, "_load_persisted_job", lambda *args, **kwargs:stale)
    with module._AUTO_MAP_JOBS_LOCK:
        module._AUTO_MAP_JOBS["poll-race"] = live
        module._AUTO_MAP_ACTIVE_RUNNERS.add("poll-race")
    try:
        proxy.get_job(request, "poll-race", session=object())
        assert module._AUTO_MAP_JOBS["poll-race"] is live
        assert live["state_version"] == 5
        assert live["batch_count"] == 4
    finally:
        with module._AUTO_MAP_JOBS_LOCK:
            module._AUTO_MAP_JOBS.pop("poll-race", None)
            module._AUTO_MAP_ACTIVE_RUNNERS.discard("poll-race")


def test_start_route_has_no_agent_or_automap_session_dependency():
    import app.api
    from app.api import deps
    from typing import get_type_hints, get_args
    hints = get_type_hints(app.api.start_auto_map_job, include_extras=True)
    assert "service" not in hints
    assert get_args(hints["client"])[1].dependency is deps.get_snowflake_client


def test_mixed_failure_job_counts_only_successful_batches(monkeypatch):
    from app.core import auto_mapping_proxy as module
    from app.core.exceptions import SnowflakeAgentError
    from types import SimpleNamespace

    proxy = AutoMappingProxyClient(Settings(_env_file=None, AUTO_MAP_PIPELINE_V2=False,
        AUTO_MAPPING_SERVICE_URL="http://worker.internal:8000", AUTO_MAPPING_PROXY_BATCH_SIZE=2))
    request = Request({"type": "http", "method": "POST", "path": "/", "headers": []})
    request.state.current_principal = SimpleNamespace(snowflake_user="ALICE", user_id=1)
    monkeypatch.setattr(proxy, "_forward_headers", lambda request: {})
    def invoke(req, *, headers, batch_index):
        if batch_index == 1:
            raise SnowflakeAgentError("synthetic infrastructure failure")
        return _response(req)
    monkeypatch.setattr(proxy, "_invoke_complete_batch", invoke)
    started = proxy.start_job(request, _request(3))
    try:
        for _ in range(300):
            job = proxy.get_job(request, started["job_id"])
            if job["status"] not in {"queued", "running"}:
                break
            time.sleep(0.01)
        assert job["status"] == "partial_failure"
        assert job["completed_batch_count"] == 1
        assert job["completed_attribute_count"] == 2
        assert [item["batch_index"] for item in job["partial_responses"]] == [0]
        assert job["response"]["meta"]["auto_mapping_review"]["infrastructure_failed_count"] == 1
        assert job["response"]["data"]["status"] == "needs_input"
        assert proxy.get_job(request, started["job_id"])["status"] == "partial_failure"
    finally:
        with module._AUTO_MAP_JOBS_LOCK:
            module._AUTO_MAP_JOBS.pop(started["job_id"], None)


def test_async_job_completes_without_holding_the_ingress_request(monkeypatch) -> None:
    settings = Settings(
        _env_file=None,
        AUTH_MODE="custom_oauth",
        AUTO_MAPPING_SERVICE_URL="http://worker.internal:8000",
        AUTO_MAPPING_PROXY_BATCH_SIZE=2,
        AUTO_MAPPING_PROXY_MAX_IN_FLIGHT=2,
    )
    proxy = AutoMappingProxyClient(settings)
    envelope = _request(attribute_count=3)
    http_request = Request({"type": "http", "method": "POST", "path": "/", "headers": []})
    http_request.state.current_principal = CurrentPrincipal(
        user_id=1,
        snowflake_user="ALICE",
        email="alice@example.com",
        display_name="Alice",
        app_persona=AppPersona.ADMIN,
        permissions=PermissionSet(can_read=True, can_edit=True),
        snowflake_user_token="oauth-secret-token",
        snowflake_role="FOCUS_ADMIN",
    )
    monkeypatch.setattr(
        proxy,
        "_invoke_with_headers",
        lambda req, *, headers: _response(req),
    )

    started = proxy.start_job(http_request, envelope)
    assert started["status"] in {"queued", "running", "completed"}
    for _ in range(100):
        job = proxy.get_job(http_request, started["job_id"])
        if job["status"] == "completed":
            break
        time.sleep(0.01)

    assert job["status"] == "completed"
    assert job["response"]["contract_version"] == "1.0"
    assert job["completed_batch_count"] == job["batch_count"]
    assert [item["batch_index"] for item in job["partial_responses"]] == [0, 1]
    assert [
        list(item["response"]["result"]["mappings"])
        for item in job["partial_responses"]
    ] == [["COL_0", "COL_1"], ["COL_2"]]
    assert "owner" not in job
    assert "request_envelope" not in job


def test_polling_resumes_an_expired_durable_job_on_a_new_replica(monkeypatch) -> None:
    settings = Settings(
        _env_file=None,
        AUTH_MODE="custom_oauth",
        AUTO_MAP_PIPELINE_V2=True,
        AUTO_MAPPING_SERVICE_URL="http://worker.internal:8000",
    )
    proxy = AutoMappingProxyClient(settings)
    envelope = _request(attribute_count=2)
    http_request = Request({"type": "http", "method": "GET", "path": "/", "headers": []})
    http_request.state.current_principal = CurrentPrincipal(
        user_id=1,
        snowflake_user="ALICE",
        email="alice@example.com",
        display_name="Alice",
        app_persona=AppPersona.ADMIN,
        permissions=PermissionSet(can_read=True, can_edit=True),
        snowflake_user_token="replacement-poll-token",
        snowflake_role="FOCUS_ADMIN",
    )
    durable_record = {
        "job_id": "restart-job",
        "request_id": envelope.request_id,
        "owner": "ALICE",
        "status": "running",
        "request_envelope": envelope.model_dump(mode="json"),
        "partial_responses": [],
    }
    launched: dict[str, object] = {}
    monkeypatch.setattr(
        proxy,
        "_load_persisted_job",
        lambda *_args, **_kwargs: dict(durable_record),
    )

    def fake_launch(job_id, *, req, headers, owner, record):  # type: ignore[no-untyped-def]
        launched.update(
            {
                "job_id": job_id,
                "request_id": req.request_id,
                "headers": headers,
                "owner": owner,
                "record": record,
            }
        )
        return True

    monkeypatch.setattr(proxy, "_launch_job_runner", fake_launch)

    public = proxy.get_job(http_request, "restart-job", session=object())

    assert launched["job_id"] == "restart-job"
    assert launched["request_id"] == envelope.request_id
    assert launched["owner"] == "ALICE"
    assert launched["headers"]["X-Workbench-OAuth-Access-Token"] == "replacement-poll-token"
    assert "request_envelope" not in public


def test_durable_lease_allows_only_one_replica_to_claim_a_job() -> None:
    class LeaseRow:
        def __init__(self, owner):
            self.owner = owner

        def as_dict(self):
            return {"LEASE_OWNER": self.owner}

    class LeaseQuery:
        def __init__(self, session, sql, params):
            self.session = session
            self.sql = sql
            self.params = params

        def collect(self):
            if "UPDATE" in self.sql and self.session.lease_owner is None:
                self.session.lease_owner = self.params[0]
                return []
            if "SELECT LEASE_OWNER" in self.sql:
                return [LeaseRow(self.session.lease_owner)]
            return []

    class LeaseSession:
        def __init__(self):
            self.lease_owner = None

        def sql(self, sql, params=None):
            return LeaseQuery(self, sql, params or [])

    settings = Settings(
        _env_file=None,
        AUTO_MAP_PIPELINE_V2=True,
        AUTO_MAPPING_SERVICE_URL="http://worker.internal:8000",
    )
    session = LeaseSession()
    first = AutoMappingProxyClient(settings)
    second = AutoMappingProxyClient(settings)

    assert first._claim_job_lease(
        "job-1", owner="ALICE", headers={}, session=session
    ) is True
    assert second._claim_job_lease(
        "job-1", owner="ALICE", headers={}, session=session
    ) is False


def test_recovered_job_invokes_only_batches_missing_from_durable_partials(monkeypatch) -> None:
    settings = Settings(
        _env_file=None,
        AUTO_MAPPING_SERVICE_URL="http://worker.internal:8000",
        AUTO_MAPPING_PROXY_BATCH_SIZE=2,
        AUTO_MAPPING_PROXY_MAX_IN_FLIGHT=2,
    )
    proxy = AutoMappingProxyClient(settings)
    envelope = _request(attribute_count=6)
    first_batch_req = envelope.model_copy(
        update={
            "data": envelope.data.model_copy(
                update={"attributes": envelope.data.attributes[:2]}
            )
        }
    )
    partials = [
        {
            "batch_index": 0,
            "response": _response(first_batch_req).model_dump(mode="json"),
        }
    ]
    invoked: list[int] = []

    def fake_invoke(req, *, headers, batch_index):  # type: ignore[no-untyped-def]
        invoked.append(batch_index)
        return _response(req)

    monkeypatch.setattr(proxy, "_invoke_batch", fake_invoke)

    result = proxy._invoke_with_headers(
        envelope,
        headers={},
        resume_partials=partials,
    )

    assert sorted(invoked) == [1, 2]
    assert list(result.result.mappings) == [f"COL_{index}" for index in range(6)]
    assert result.meta["auto_mapping_dispatch"]["resumed_batch_indices"] == [0]


def test_v2_job_state_round_trips_through_durable_store() -> None:
    class DurableRow:
        def __init__(self, state):
            self.state = state

        def as_dict(self):
            return {"JOB_STATE": self.state}

    class DurableQuery:
        def __init__(self, session, sql, params=None):
            self.session = session
            self.sql = sql
            self.params = params or []

        def collect(self):
            self.session.queries.append((self.sql, self.params))
            if "SELECT JOB_STATE" in self.sql:
                return [DurableRow(self.session.state)]
            return []

    class DurableSession:
        def __init__(self):
            self.queries = []
            self.state = {
                "job_id": "job-1",
                "owner": "ALICE",
                "status": "running",
                "partial_responses": [],
            }

        def sql(self, sql, params=None):
            return DurableQuery(self, sql, params)

    settings = Settings(
        _env_file=None,
        AUTO_MAP_PIPELINE_V2=True,
        AUTO_MAPPING_SERVICE_URL="http://worker.internal:8000",
    )
    proxy = AutoMappingProxyClient(settings)
    session = DurableSession()
    record = dict(session.state)

    proxy._persist_job(record, headers={}, session=session, required=True)
    loaded = proxy._load_persisted_job(
        "job-1", owner="ALICE", headers={}, session=session
    )

    assert loaded == record
    assert any(
        "MERGE INTO" in query and "TBL_AUTO_MAP_JOBS" in query
        for query, _params in session.queries
    )
    assert any(
        "JOB_STATE:state_version" in query
        for query, _params in session.queries
        if "MERGE INTO" in query
    )
    assert any("SELECT JOB_STATE" in query for query, _params in session.queries)
    merge_params = next(params for query, params in session.queries if "MERGE INTO" in query)
    assert len(merge_params) == 9


def test_durable_partial_omits_repeated_prepared_context() -> None:
    envelope = _request(attribute_count=2)
    envelope = envelope.model_copy(
        update={
            "context": envelope.context.model_copy(
                update={
                    "semantic_context": [
                        {
                            "table": {"database": "DB", "schema": "SRC", "table": "SOURCE"},
                            "semantic_model": {"large": "semantic-yaml"},
                        }
                    ],
                    "learning_context": {"fir_recommendations": [{"id": "fir-1"}]},
                    "datahub_context": {"legacy": True},
                }
            )
        }
    )
    response = _response(envelope)

    compact = AutoMappingProxyClient._compact_partial_response(response)

    assert compact.result == response.result
    assert compact.context.semantic_context is None
    assert compact.context.learning_context is None
    assert compact.context.datahub_context is None


def test_host_worker_transport_preserves_prepared_context_above_model_limit() -> None:
    settings = Settings(
        _env_file=None,
        AGENT_OUTBOUND_MESSAGE_MAX_CHARS=60_000,
        AGENT_OUTBOUND_MESSAGE_MAX_BYTES=65_536,
        AGENT_CALLER_INLINE_FALLBACK_LIMIT_BYTES=1_048_576,
        AUTO_MAPPING_SERVICE_URL="http://worker.internal:8000",
    )
    proxy = AutoMappingProxyClient(settings)
    envelope = _request(attribute_count=2)
    envelope = envelope.model_copy(
        update={
            "context": envelope.context.model_copy(
                update={
                    "semantic_bundle_id": "sem_prepared",
                    "prepared_context_hash": "prepared-hash",
                    "semantic_context": [
                        SemanticContextItem(
                            table=TableRef(database="DB", schema="SRC", table="SOURCE"),
                            semantic_model={"yaml": "x" * 80_000},
                        )
                    ],
                    "learning_context": LearningContext(
                        fir_recommendations=[{"id": "fir-1"}]
                    ),
                }
            )
        }
    )

    budgeted, diagnostics = proxy._budget_batch_request(envelope)

    assert budgeted.context.prepared_context_hash == "prepared-hash"
    assert budgeted.context.semantic_context
    assert budgeted.context.learning_context is not None
    assert diagnostics["budget_scope"] == "host_to_worker_transport"
    assert diagnostics["model_prompt_budget_applied_by_worker"] is True


def test_planner_splits_batches_instead_of_dropping_pattern_context() -> None:
    from app.core.agent_payload_budget import budget_agent_payload
    from app.core.target_mapping_patterns import compact_candidate_for_agent
    from tests.unit.core.test_agent_payload_budget import _bulky_pattern

    # With the default 60K budget these 16 compacted patterns fit in one batch; a
    # tighter budget forces the case where one batch would need emergency compaction.
    settings = Settings(
        _env_file=None,
        AUTH_MODE="custom_oauth",
        AUTO_MAPPING_SERVICE_URL="http://worker.internal:8000",
        AUTO_MAPPING_PROXY_BATCH_SIZE=16,
        AGENT_OUTBOUND_MESSAGE_MAX_CHARS=36_000,
        AGENT_OUTBOUND_MESSAGE_MAX_BYTES=40_000,
    )
    proxy = AutoMappingProxyClient(settings)
    envelope = _request(16)
    envelope = envelope.model_copy(
        update={
            "context": envelope.context.model_copy(
                update={
                    "learning_context": LearningContext(
                        target_mapping_patterns=[
                            compact_candidate_for_agent(_bulky_pattern(f"COL_{index}", rank))
                            for index in range(16)
                            for rank in range(4)
                        ]
                    )
                }
            )
        }
    )

    batches = proxy._build_batches(envelope)

    assert len(batches) > 1
    assert sorted(item.target_attribute for batch in batches for item in batch) == sorted(
        f"COL_{index}" for index in range(16)
    )
    for batch in batches:
        batch_req = envelope.model_copy(
            update={"data": envelope.data.model_copy(update={"attributes": batch})}
        )
        result = budget_agent_payload(
            batch_req.model_dump(mode="json", exclude_none=True),
            max_chars=settings.agent_outbound_message_max_chars,
            max_bytes=settings.agent_outbound_message_max_bytes,
        )
        # Either the batch kept full pattern context, or it is already at the floor.
        assert not result.diagnostics["emergency_compaction"] or len(batch) <= 4
        kept = {
            item["pattern"]["target_contract"]["target_column"]
            for item in result.payload["context"]["learning_context"]["target_mapping_patterns"]
        }
        assert kept == {item.target_attribute for item in batch}


def _firm_value_envelope() -> STTMBuilderEnvelopeRequest:
    """One target, a graph whose only project firm value is TransactionFirmID."""
    from app.schema.sttm_builder import ValueBinding

    envelope = _request(attribute_count=1)
    return envelope.model_copy(
        update={
            "context": envelope.context.model_copy(
                update={
                    "relation_graph": RelationGraphContext(
                        value_bindings=[
                            ValueBinding(
                                binding_id="project-TransactionFirmID",
                                value="$TransactionFirmID",
                                resolved_value="001Qi00001Rb8gCIAR",
                                attribute_name="TransactionFirmID",
                                is_placeholder=True,
                                resolution_status="project_attribute",
                            ),
                            # A linked precedent from another project uses this name.
                            ValueBinding(
                                binding_id="precedent:2901:ClientStartDate",
                                value="$ClientStartDate",
                                is_placeholder=True,
                                resolution_status="placeholder_contract",
                            ),
                        ]
                    )
                }
            )
        }
    )


def test_worker_response_leaves_firm_value_from_another_project_unresolved() -> None:
    envelope = _firm_value_envelope()
    response = _response(envelope)
    mapping = response.result.mappings["COL_0"]
    mapping.source_attributes = []
    mapping.mapping_mode = "constant"
    mapping.constant_value = "$ClientStartDate"
    mapping.transformation_classification = "value"
    mapping.precedent_decision = "accept_precedent"
    mapping.precedent_mapping_id = "2901"

    AutoMappingProxyClient._validate_worker_response(response, req=envelope, batch_index=0)

    assert mapping.transformation_classification == "unresolved"
    assert mapping.constant_value is None
    assert mapping.mapping_mode == "source"
    assert mapping.confidence_score == 0.0
    assert "$ClientStartDate is not defined for this project" in str(mapping.unmatched_reason)
    assert any(
        warning.code == "AUTO_MAPPING_FIRM_VALUE_NOT_DEFINED" for warning in response.warnings
    )


def test_worker_response_keeps_the_projects_own_firm_values() -> None:
    envelope = _firm_value_envelope()
    response = _response(envelope)
    constant = response.result.mappings["COL_0"]
    constant.source_attributes = []
    constant.mapping_mode = "constant"
    constant.constant_value = "$TRANSACTIONFIRMID"  # agent casing
    constant.transformation_classification = "value"

    AutoMappingProxyClient._validate_worker_response(response, req=envelope, batch_index=0)

    assert constant.constant_value == "$TRANSACTIONFIRMID"
    assert constant.transformation_classification == "value"
    assert not any(
        warning.code == "AUTO_MAPPING_FIRM_VALUE_NOT_DEFINED" for warning in response.warnings
    )


def test_worker_response_checks_firm_values_inside_custom_transformations() -> None:
    envelope = _firm_value_envelope()
    response = _response(envelope)
    mapping = response.result.mappings["COL_0"]
    mapping.preprocessing_rule = "COALESCE(DB.SRC.SOURCE.START_DATE, $ClientStartDate)"
    mapping.preprocessing_rule_type = "Custom"

    AutoMappingProxyClient._validate_worker_response(response, req=envelope, batch_index=0)

    assert mapping.transformation_classification == "unresolved"
    assert mapping.source_attributes == []
    assert mapping.preprocessing_rule is None
    assert mapping.candidate_source_attributes == ["DB.SRC.SOURCE.COL_0"]

def test_parallel_preflight_does_not_multiply_batches_for_persistent_oversized_table(monkeypatch):
    from types import SimpleNamespace
    from app.core.sttm_builder import STTMBuilderService
    settings = Settings(_env_file=None, AUTOMAP_CONTEXT_RETRIEVAL_V1=True)
    proxy = AutoMappingProxyClient(settings)
    req = _request(8)
    monkeypatch.setattr(proxy, "_balanced_retrieval_batches", lambda request: [list(request.data.attributes)])
    def preflight(batch_req, settings):
        count = len(batch_req.data.attributes)
        return SimpleNamespace(diagnostics={"parallel_preflight": {
            "excluded_group_count": 1 if count > 2 else 0,
            "max_scan_message_bytes": 100_000,
        }})
    monkeypatch.setattr(STTMBuilderService, "project_agent_payload", preflight)
    diagnostics = []
    batches = proxy._build_batches(req, diagnostics=diagnostics)
    assert [len(batch) for batch in batches] == [8]
    assert sorted(item.target_attribute for batch in batches for item in batch) == [
        f"COL_{index}" for index in range(8)]
    assert len(diagnostics) == 1
    assert diagnostics[0]["excluded_group_count"] == 1


def test_preflight_reuses_compiled_workspace_without_repeating_generated_output():
    from app.schema.workspace_context import WorkbenchContextSnapshotV1
    settings = Settings(_env_file=None, AUTOMAP_CONTEXT_RETRIEVAL_V1=True,
        AUTOMAP_PARALLEL_CONTEXT_V1=True, AUTOMAP_PARALLEL_TEST_AGENT="D.S.SCAN_AGENT",
        AUTOMAP_PARALLEL_PERMIT_TABLE_FQN="D.S.PERMITS",
        AUTOMAP_PARALLEL_ARCHIVE_TABLE_FQN="D.S.ARCHIVE",
        AUTOMAP_PARALLEL_ACCOUNT_NAMESPACE="ORG.ACCOUNT",
        AUTOMAP_PARALLEL_POOL_EPOCH="11111111-1111-1111-1111-111111111111",
        AUTOMAP_PARALLEL_POOL_CAPACITY=2)
    request = _request(37)
    workspace = WorkbenchContextSnapshotV1(
        mapping_sql="SELECT approved_source FROM DB.SRC.SOURCE",
        compiled_mapping_context_hash='{"compilerContractVersion":"v2","input":"' + "x" * 74_000 + '"}',
        auto_map_outcome={"previous": "p" * 8_500},
        compiled_mapping_semantic_context=[{"table": {"database": "DB", "schema": "SRC",
                                                      "table": "SOURCE"}, "semantic_model": {"grain": "one"}}],
        compiled_mapping_sql="c" * 6_900, compiled_mapping_preview_sql="v" * 6_000)
    request = request.model_copy(update={
        "context": request.context.model_copy(update={"workspace_context": workspace})})
    batches = AutoMappingProxyClient(settings)._build_batches(request)
    assert len(batches) == 4
    assert sorted(len(batch) for batch in batches) == [9, 9, 9, 10]
    assert {item.target_attribute for batch in batches for item in batch} == {
        f"COL_{index}" for index in range(37)}
    assert request.context.workspace_context.compiled_mapping_context_hash == workspace.compiled_mapping_context_hash
    assert WorkbenchContextSnapshotV1.model_validate(workspace.model_dump()).compiled_mapping_semantic_context == (
        workspace.compiled_mapping_semantic_context)
    from app.core.agent_payload_budget import AgentPayloadBudgetError
    oversized = workspace.model_copy(update={"mapping_sql": "SELECT " + "x" * 130_000})
    bad_request = request.model_copy(update={
        "context": request.context.model_copy(update={"workspace_context": oversized})})
    with pytest.raises(AgentPayloadBudgetError) as caught:
        AutoMappingProxyClient(settings)._build_batches(bad_request)
    assert "workspace_context.mapping_sql" in str(caught.value)
    assert "x" * 100 not in str(caught.value)


def test_37_targets_and_603_record_exclusion_stay_in_four_batches(monkeypatch):
    from types import SimpleNamespace
    from app.core.sttm_builder import STTMBuilderService
    proxy = AutoMappingProxyClient(Settings(_env_file=None, AUTOMAP_CONTEXT_RETRIEVAL_V1=True))
    req = _request(37)
    monkeypatch.setattr(STTMBuilderService, "project_agent_payload", lambda batch_req, settings:
        SimpleNamespace(diagnostics={"parallel_preflight": {
            "excluded_group_count": 1, "excluded_record_count": 603,
            "max_scan_message_bytes": 109_000,
        }}))
    batches = proxy._build_batches(req)
    assert len(batches) == 4
    assert sorted(len(batch) for batch in batches) == [9, 9, 9, 10]
    assert len({item.target_attribute for batch in batches for item in batch}) == 37


def test_parallel_preflight_adds_one_batch_when_coverage_improves(monkeypatch):
    from types import SimpleNamespace
    from app.core.sttm_builder import STTMBuilderService
    settings = Settings(_env_file=None, AUTOMAP_CONTEXT_RETRIEVAL_V1=True)
    proxy = AutoMappingProxyClient(settings)
    req = _request(8)
    monkeypatch.setattr(proxy, "_balanced_retrieval_batches", lambda request: [list(request.data.attributes)])
    def preflight(batch_req, settings):
        names = {item.target_attribute for item in batch_req.data.attributes}
        excluded = int(any(name in names for name in {"COL_4", "COL_5", "COL_6", "COL_7"}))
        return SimpleNamespace(diagnostics={"parallel_preflight": {
            "excluded_group_count": excluded, "excluded_record_count": 603 * excluded,
        }})
    monkeypatch.setattr(STTMBuilderService, "project_agent_payload", preflight)
    batches = proxy._build_batches(req)
    assert [len(batch) for batch in batches] == [4, 4]
    assert [item.target_attribute for batch in batches for item in batch] == [f"COL_{index}" for index in range(8)]


def test_fifth_coverage_batch_dispatches_with_other_four(monkeypatch):
    from types import SimpleNamespace
    from app.core.sttm_builder import STTMBuilderService
    settings = Settings(_env_file=None, AUTOMAP_CONTEXT_RETRIEVAL_V1=True,
                        AUTO_MAPPING_PROXY_MAX_IN_FLIGHT=5)
    proxy = AutoMappingProxyClient(settings)
    req = _request(16)
    monkeypatch.setattr(proxy, "_balanced_retrieval_batches",
        lambda request: [list(request.data.attributes[index:index + 4])
                         for index in range(0, 16, 4)])
    def preflight(batch_req, settings):
        names = {item.target_attribute for item in batch_req.data.attributes}
        excluded = int("COL_0" in names)
        return SimpleNamespace(diagnostics={"parallel_preflight": {
            "excluded_group_count": excluded, "excluded_record_count": 603 * excluded,
        }})
    monkeypatch.setattr(STTMBuilderService, "project_agent_payload", preflight)
    barrier = threading.Barrier(5)
    lock = threading.Lock()
    active = 0
    peak = 0
    def invoke(batch, **kwargs):
        nonlocal active, peak
        with lock:
            active += 1
            peak = max(peak, active)
        try:
            barrier.wait(timeout=5)
            return _response(batch)
        finally:
            with lock:
                active -= 1
    monkeypatch.setattr(proxy, "_invoke_complete_batch", invoke)
    result = proxy._invoke_with_headers(req, headers={})
    assert result.meta["auto_mapping_dispatch"]["batch_count"] == 5
    assert result.meta["auto_mapping_dispatch"]["max_in_flight"] == 5
    assert peak == 5
    assert len(result.result.mappings) == 16


def test_preparation_budget_failure_persists_enriched_request_and_safe_sizes(monkeypatch):
    from copy import deepcopy
    from types import SimpleNamespace
    from app.core import auto_mapping_proxy as module
    from app.core.agent_payload_budget import AgentPayloadBudgetError
    from app.core.automap_shards import BoundedMessage, MessageBudget, MessageBudgetError
    settings = Settings(_env_file=None, AUTO_MAP_PIPELINE_V2=True,
                        AUTOMAP_CONTEXT_RETRIEVAL_V1=True, AUTO_MAPPING_SERVICE_URL="inprocess")
    proxy = AutoMappingProxyClient(settings)
    request = Request({"type": "http", "method": "POST", "path": "/", "headers": []})
    request.state.current_principal = SimpleNamespace(snowflake_user="ALICE", user_id=1)
    finished = threading.Event()
    persisted = []
    monkeypatch.setattr(proxy, "_load_persisted_job", lambda *args, **kwargs: deepcopy(persisted[-1]) if persisted else None)
    monkeypatch.setattr(proxy, "_forward_headers", lambda request: {})
    monkeypatch.setattr(proxy, "_persist_job", lambda record, **kwargs: persisted.append(deepcopy(record)))
    monkeypatch.setattr(proxy, "_open_job_client", lambda headers: SimpleNamespace(session=object(), close=finished.set))
    monkeypatch.setattr(proxy, "_claim_job_lease", lambda *args, **kwargs: True)
    monkeypatch.setattr(proxy, "_prepare_job_request", lambda req, **kwargs: req)
    def reject(req, **kwargs):
        try:
            raise MessageBudgetError(BoundedMessage("x" * 120_001, "{}"), MessageBudget(120_000, 120_000))
        except MessageBudgetError as exc:
            raise AgentPayloadBudgetError("preflight failed") from exc
    monkeypatch.setattr(proxy, "_build_batches", reject)
    accepted = proxy.start_job(request, _request(2), session=object(), prepare=True)
    assert finished.wait(3)
    terminal = persisted[-1]
    assert terminal["status"] == "failed"
    assert terminal["request_envelope"] is not None
    assert terminal["preparation_pending"] is False
    assert terminal["error"]["code"] == "AUTO_MAP_PREPARATION_BUDGET_EXCEEDED"
    assert terminal["error"]["measured_bytes"] == 120_001
    assert terminal["error"]["limit_bytes"] == 120_000
    assert terminal["preparation_diagnostics"]["stage"] == "target_batch_preflight"
    with module._AUTO_MAP_JOBS_LOCK:
        module._AUTO_MAP_JOBS.pop(accepted["job_id"], None)
