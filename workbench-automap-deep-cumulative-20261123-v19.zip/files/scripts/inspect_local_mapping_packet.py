"""Read-only diagnostics of a saved mapping and its prepared learning handle."""
import json
import os
import sys
from pathlib import Path

import httpx
import yaml

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "services" / "sttm-builder"))

from app.core.config import Settings
from app.core.learning_retrieval import LearningRetrievalService
from app.core.mapping_context import project_mapping_context
from app.core.snowflake import SnowflakeClient
from app.core.semantic_context import SemanticContextService
from app.core.semantic_model import SemanticModelService
from app.schema.common import TableRef
from app.schema.semantic_context import SemanticLevel
from app.schema.sttm_builder import STTMBuilderEnvelopeRequest, STTMAgentRequestEnvelope


def main():
    settings = Settings(_env_file=os.environ["WORKBENCH_TEST_ENV_FILE"])
    client = SnowflakeClient(settings)
    try:
        response = httpx.get("http://127.0.0.1:8001/api/v1/sttms/9101", timeout=60).json()["data"]
        snapshot = response["latest_snapshot"]
        table = settings.qualify_metadata_object_name("TBL_PREPARED_LEARNING_CONTEXTS")
        rows = client.session.sql(
            f"SELECT CONTEXT_PAYLOAD FROM {table} WHERE LEARNING_CONTEXT_ID = ? LIMIT 1",
            params=[sys.argv[1]],
        ).collect()
        learning = rows[0].as_dict()["CONTEXT_PAYLOAD"]
        if isinstance(learning, str):
            learning = json.loads(learning)
        # Use the saved semantic bundle when present; this diagnostic never
        # refreshes registry content or writes a workspace.
        context = {key: snapshot[key] for key in ("source_tables", "target_table", "driving_table", "relationships", "relation_graph") if key in snapshot}
        context.update(project_id="1701", sttm_id="9101", learning_context=learning)
        semantic = snapshot.get("semantic_bundle") or {}
        context["semantic_context"] = semantic.get("semantic_context") or []
        projector = SemanticContextService.__new__(SemanticContextService)
        projector._settings = settings
        refs = [TableRef.model_validate(table) for table in [*snapshot["source_tables"], snapshot["target_table"]]]
        records = SemanticModelService(settings).get_table_records(client.session, refs)
        for record in records:
            reference = TableRef(database=record["database"], schema=record["schema_name"], table=record["table_name"])
            model = projector._compact_table_semantic_projection(table=reference, table_record=record,
                relationships=snapshot["relationships"], requested_level=SemanticLevel.FULL_REGISTRY)
            if model.get('pk_detection'):
                print(json.dumps({'key_contract': reference.table, 'keys': model['pk_detection']}))
            context["semantic_context"].append({"table": reference.model_dump(), "scope": "TABLE", "semantic_model": model})
        for derived in snapshot.get("derived_sources") or []:
            stored = client.session.sql(f"SELECT SEMANTIC_PROJECTION FROM {settings.qualify_metadata_object_name('TBL_DERIVED_SOURCES')} WHERE DERIVED_SOURCE_ID = ? LIMIT 1", params=[derived['id']]).collect()
            model = stored[0].as_dict()['SEMANTIC_PROJECTION'] if stored else {}
            model = json.loads(model) if isinstance(model, str) else model
            context["semantic_context"].append({"table": {"database": "DERIVED", "schema": "WORKSPACE", "table": derived.get("name") or derived.get("id")},
                                                "scope": "DERIVED_SOURCE", "semantic_model": model})
        # The UI currently omits native DDL/YAML; measure the same wire shape.
        for item in context["semantic_context"]:
            item['semantic_model'].pop('semantic_view', None)
        prepared_table = settings.qualify_metadata_object_name("TBL_PREPARED_WORKSPACE_CONTEXTS")
        prepared_rows = client.session.sql(
            f"SELECT CONTEXT_PAYLOAD FROM {prepared_table} WHERE CONTEXT_PAYLOAD:_workspace_snapshot:sttm_id::STRING = ? ORDER BY UPDATED_AT DESC LIMIT 1",
            params=["9101"],
        ).collect()
        if prepared_rows:
            prepared = prepared_rows[0].as_dict()["CONTEXT_PAYLOAD"]
            prepared = json.loads(prepared) if isinstance(prepared, str) else prepared
            saved = prepared.get("_workspace_snapshot") or {}
            print(json.dumps({"prepared_snapshot_keys": list(saved)}))
            context["semantic_context"] = saved.get("semantic_context") or context["semantic_context"]
        request = STTMBuilderEnvelopeRequest.model_validate({"operation": "sttm.auto_map", "context": context,
            "data": {"intent": "AUTO_MAP", "attributes": [{"target_table": snapshot["target_table"], "target_attribute": sys.argv[2]}]}})
        raw = STTMAgentRequestEnvelope.from_builder_request(request).model_dump(mode="json", exclude_none=True)
        projected = project_mapping_context(raw)
        sizes = lambda values: {key: len(json.dumps(value, default=str, separators=(",", ":"))) for key, value in values.items()}
        print(json.dumps({"sections": sizes(projected["context"]), "learning": sizes(projected["context"].get("learning_context") or {}),
                          "semantic_fields": {key: sum(len(json.dumps((item.get('semantic_model') or {}).get(key), default=str)) for item in projected['context'].get('semantic_context') or []) for key in {key for item in projected['context'].get('semantic_context') or [] for key in item['semantic_model']}},
                          "native_shape": [{key: type(value).__name__ for key, value in (item.get('semantic_model', {}).get('semantic_view') or {}).items()} for item in projected['context'].get('semantic_context') or []][:1],
                          "native_fields": [sizes((item.get('semantic_model', {}).get('semantic_view') or {}).get('definition') or {}) for item in projected['context'].get('semantic_context') or []][:2],
                          "assets": [{"table": item['table']['table'], "chars": len(json.dumps(item)), "columns": [value.get('name') for value in item['semantic_model'].get('attributes', [])]} for item in projected['context'].get('semantic_context') or []],
                          "relationship_shape": [str((item.get('semantic_model') or {}).get('relationships'))[:1400] for item in projected['context'].get('semantic_context') or []][:2],
                          "unresolved": projected["context"]["context_selection"].get("unresolved_dependencies", []),
                          "broadening": projected["context"]["context_selection"]["broadening_applied"]}, indent=2))
    finally:
        client.close()


if __name__ == "__main__":
    main()