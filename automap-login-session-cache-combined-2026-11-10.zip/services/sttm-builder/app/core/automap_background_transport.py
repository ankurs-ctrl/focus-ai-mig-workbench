"""Single-submission Cortex background runs with bounded status/cancel recovery."""
from dataclasses import replace
import json
import hashlib
import re
from threading import Event
import time

import httpx

from app.core.automap_admission import ThreadReference, request_digest, RemoteCallNotDispatched
from app.core.automap_scan_transport import (
    SnowflakeScanTransport, ScanTransportError, TerminalCallFailure, DiagnosticPhase,
    DiagnosticOperation, _request_body, _thread_terminal, _load_json, _http_error_reason,
)


class BackgroundRunTransport(SnowflakeScanTransport):
    def _thread_recovery_cap(self):
        # A persisted thread includes JSON-escaped original 180K input plus the
        # output. Its read allowance must be separate from the 120K model output.
        return 1_000_000

    def _json_exchange(self, method, url, request, *, body=b'', model_post=False, emit=None):
        """No HTTP retries or redirect/auth fallback; GET/cancel are explicit operations."""
        request.check_active()
        timeouts = httpx.Timeout(min(10, request.remaining_seconds())).as_dict()
        outgoing = httpx.Request(method, url, headers=self._headers(), content=body,
            extensions={'timeout':timeouts})
        if model_post and request.runtime_trace is not None:
            request.runtime_trace.model_post_attempts += 1
        try:
            response = self._http_client.send(outgoing, stream=True, auth=None, follow_redirects=False)
            try:
                if emit is not None: emit(DiagnosticPhase.BEFORE_PARSE,response=response,operation=DiagnosticOperation.MODEL_RUN)
                bounded=replace(request,deadline=min(request.effective_deadline,time.monotonic()+10),runtime_trace=None)
                raw = self._read_raw(response, bounded, timeouts, max_bytes=self._thread_recovery_cap() if method=="GET" else None)
            finally:
                response.close()
            if response.status_code in (401,403):
                raise PermissionError('Original caller authentication unavailable')
            if response.status_code not in (200,201,202,409):
                if model_post and response.status_code == 429:
                    raise TerminalCallFailure('Provider rejected model submission with HTTP 429')
                raise ScanTransportError('Background run control unavailable')
            data=_load_json(raw.decode('utf-8')) if raw else {}
            if emit is not None:
                diagnostic_data=data
                if model_post and type(data) is dict and data.get('status')=='in_progress':
                    metadata=data.get('metadata')
                    candidate=metadata.get('run_id') if type(metadata) is dict else None
                    thread_id=json.loads(body).get('thread_id')
                    if type(thread_id) is int and type(candidate) is str and re.fullmatch(str(thread_id)+'-[1-9][0-9]{0,18}',candidate):
                        # Recognize native background metadata only at the model
                        # ACK boundary and only for the dedicated original thread.
                        diagnostic_data={'status':'in_progress','run_id':candidate}
                emit(DiagnosticPhase.PARSED,data=diagnostic_data,operation=DiagnosticOperation.MODEL_RUN)
            return response.status_code, data
        except httpx.HTTPError as exc:
            raise ScanTransportError('Background run connection unavailable; outcome requires reconciliation',reason=_http_error_reason(exc)) from None

    def _thread_exchange(self,request,*,thread_id=None,emit=None):
        if thread_id is None:
            return super()._thread_exchange(request,thread_id=None,emit=emit)
        status,data=self._json_exchange('GET',f'{self._threads_url}/{thread_id}?page_size=100',request)
        if status!=200:raise ScanTransportError('Thread inspection unavailable')
        return data

    def _observe(self, request, reference):
        data = self._thread_exchange(request, thread_id=reference.thread_id)
        if (type(data) is not dict or data.get('metadata',{}).get('thread_id') != reference.thread_id
                or type(data.get('messages')) is not list or len(data['messages']) > 100):
            raise ScanTransportError('Invalid provider thread identity')
        messages = data['messages']
        terminal = _thread_terminal(messages, request, reference, max_payload_bytes=self._thread_recovery_cap())
        # Derive a lost-ACK run identity only from one exact original user root.
        users = [m for m in messages if type(m) is dict and m.get('role')=='user']
        run_id = None
        if len(users)==1:
            user = users[0]
            payload = _load_json(user.get('message_payload',''))
            expected = _load_json(request.message)[0]
            expected.setdefault('status','completed')
            if (type(payload) is dict and user.get('parent_id')==0
                    and payload.get('schema_version') in (None,'v2')
                    and not set(payload)-{'role','content','status','schema_version','tags'}):
                observed = {k:v for k,v in payload.items() if k not in {'schema_version','tags'}}
                observed.setdefault('status','completed')
                message_id = user.get('message_id')
                if observed==expected and type(message_id) is int and 0<message_id<2**63:
                    run_id = f'{reference.thread_id}-{message_id}'
        return terminal, run_id, messages

    def inspect_run(self, request, reference, expected_run_id=None):
        terminal, run_id, messages = self._observe(request,reference)
        if expected_run_id is not None and run_id != expected_run_id:
            raise ScanTransportError('Provider run does not match original message')
        return terminal, run_id, messages

    def cancel_run(self, request, run_id):
        if type(run_id) is not str or not re.fullmatch('[1-9][0-9]{0,18}-[1-9][0-9]{0,18}',run_id):
            raise ValueError('Verified provider run ID required')
        url = self._agent_client._base_url + '/api/v2/cortex/agent/runs/' + run_id + '/cancel'
        # 200 is acceptance; 409 is already ended. Neither replaces terminal GET.
        self._json_exchange('POST',url,request)

    def find_result(self, request):
        archive = self.result_archive.with_deadline(request.effective_deadline)
        with archive._session() as session:
            rows = session.sql(f"SELECT DISTINCT CONTENT_HASH FROM {archive._table} "
                "WHERE OWNER_ID=? AND ACCESS_SCOPE=? AND SNAPSHOT_ID=? "
                "AND TRY_PARSE_JSON(BODY):value:protocol::VARCHAR='automap_background_result_v2' "
                "AND TRY_PARSE_JSON(BODY):value:request_digest::VARCHAR=? LIMIT 2",
                params=[archive._scope.owner_id, archive._caller.access_scope, archive._scope.snapshot_id,
                        request_digest(request)]).collect(statement_params={'STATEMENT_TIMEOUT_IN_SECONDS':'5','LOCK_TIMEOUT':'1'})
        if len(rows)>1: raise ScanTransportError('Conflicting durable model results')
        if not rows: return None
        row=rows[0].as_dict() if hasattr(rows[0],'as_dict') else dict(rows[0])
        value=json.loads(archive.get(row['CONTENT_HASH']))['value']
        if value.get('request_digest')!=request_digest(request) or value.get('status')!='completed':
            raise ScanTransportError('Invalid durable model result')
        text=value['text']
        if type(text) is not str or len(text)>request.output_budget.max_chars or len(text.encode())>request.output_budget.max_bytes:
            raise ScanTransportError('Invalid durable model output budget')
        return text

    def save_result(self, request, text):
        body=json.dumps({'scope':{'owner_id':request.scope.owner_id,'snapshot_id':request.scope.snapshot_id},
            'generation':request.generation,'value':{'protocol':'automap_background_result_v2',
                'request_digest':request_digest(request),'status':'completed','text':text}},
            sort_keys=True,separators=(',',':'),ensure_ascii=False)
        ref=hashlib.sha256(body.encode()).hexdigest()
        archive=self.result_archive.with_deadline(request.effective_deadline)
        archive.put(ref,body)
        if archive.get(ref)!=body: raise ScanTransportError('Model result receipt not acknowledged')
        return text

    def _result(self, terminal, messages, request, emit):
        if terminal.status.value != 'completed':
            raise TerminalCallFailure('Original background model run terminated without success')
        assistant = next(m for m in messages if m.get('message_id')==terminal.assistant_message_id)
        payload = _load_json(assistant['message_payload'])
        return self.save_result(request,self._extract(json.dumps({'status':'completed','message':payload}).encode(),request,emit))

    def _exchange(self, request, emit, lifecycle=None):
        if lifecycle is None:
            raise ValueError('Background runs require durable paired admission')
        pool = self._admission.store
        permit = lifecycle._state.permit
        from app.core.automap_scan import RuntimePhase
        try:
            if request.runtime_trace is not None: request.runtime_trace.enter(RuntimePhase.THREAD_CREATE)
            data = self._thread_exchange(request,emit=lambda phase,**v:emit(phase,
                operation=DiagnosticOperation.THREAD_CREATE,**v))
            reference = ThreadReference(data['thread_id'],self._config.agent,request_digest(request))
            if request.runtime_trace is not None: request.runtime_trace.enter(RuntimePhase.THREAD_PERSIST)
            lifecycle.record_reconciliation(reference)
            # Persist exact recovery context and single-use intent BEFORE model POST.
            pool.record_request(permit,request.request_archive_ref,self.run_seconds)
            body = _request_body(request,new_thread=True)
            body = body[:-1] + (f',"thread_id":{reference.thread_id},"parent_message_id":0,"background":true}}').encode()
        except Exception:
            raise RemoteCallNotDispatched('Auto-map preparation failed before model submission') from None
        run_id = None
        try:
            lifecycle.check_dispatch()
            if request.runtime_trace is not None: request.runtime_trace.enter(RuntimePhase.MODEL_RUN)
            emit(None,operation=DiagnosticOperation.MODEL_RUN)
            _, result = self._json_exchange('POST',self._url,request,body=body,model_post=True,emit=emit)
            if type(result) is not dict:
                raise ScanTransportError('Invalid model submission acknowledgement')
            metadata=result.get('metadata') if type(result.get('metadata')) is dict else {}
            run_id = result.get('run_id') or metadata.get('run_id')
            if run_id is not None:
                if not re.fullmatch(str(reference.thread_id) + '-[1-9][0-9]{0,18}',str(run_id)):
                    raise ScanTransportError('Invalid provider run identity')
                pool.record_run(permit,run_id)
            elif result.get('status')=='completed':
                return self.save_result(request,self._extract(json.dumps(result).encode(),request,emit))
            else:
                raise ScanTransportError('Missing model run acknowledgement')
            run_deadline=time.monotonic()+self.run_seconds
            while True:
                request.check_active()
                if time.monotonic()>=run_deadline:
                    raise ScanTransportError('Background run execution budget expired')
                inspection=replace(request,deadline=min(request.effective_deadline,run_deadline),runtime_trace=None)
                terminal, observed_run, messages = self.inspect_run(inspection,reference,run_id)
                if terminal is not None:
                    return self._result(terminal,messages,request,emit)
                if request._cancel.wait(min(.5,request.remaining_seconds())):
                    request.check_active()
        except Exception as original_error:
            # Fresh control budget ONLY: never extend inference or resubmit. The
            # original dispatcher is unwinding synchronously and sends no more POSTs.
            control = replace(request,deadline=time.monotonic()+10,_cancel=Event(),_stop=Event(),runtime_trace=None)
            try:
                terminal, discovered, messages = self.inspect_run(control,reference,run_id)
                if terminal is not None:
                    if terminal.status.value=='completed':
                        return self._result(terminal,messages,control,emit)
                    raise TerminalCallFailure('Original run is terminal')
                run_id = run_id or discovered
                if run_id is not None:
                    self.cancel_run(control,run_id)
                    terminal,_,messages = self.inspect_run(control,reference,run_id)
                    if terminal is not None:
                        if terminal.status.value=='completed':
                            return self._result(terminal,messages,control,emit)
                        raise TerminalCallFailure('Original run cancellation confirmed')
            except TerminalCallFailure:
                raise
            except Exception:
                pass  # unknown outcome is transferred to bounded durable recovery
            if request.runtime_trace is not None and request.runtime_trace.model_post_attempts==0:
                raise RemoteCallNotDispatched('No model submission was attempted') from None
            raise original_error
