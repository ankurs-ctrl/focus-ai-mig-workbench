from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Request

from app.api.deps import (
    get_auto_mapping_proxy_client,
    get_prepared_workspace_context_service,
    get_automap_snowflake_client,
    get_snowflake_client,
    get_sttm_builder_service,
)
from app.auth.dependencies import get_current_principal
from app.core.auto_mapping_proxy import AutoMappingProxyClient
from app.core.prepared_context import PreparedWorkspaceContextService
from app.core.sttm_builder import STTMBuilderService
from app.core.snowflake import SnowflakeClient
from app.schema.contracts import ApiResponseEnvelope, build_response_envelope
from app.schema.sttm_builder import Interface, STTMBuilderEnvelopeRequest, STTMBuilderRequest, normalize_sttm_builder_invoke_body

from app.routers import (
    agents,
    agent_gateway,
    agent_runs,
    migration_knowledge,
    assistant_conversations,
    artifacts,
    bundle_curation,
    conversation,
    coco,
    dbt_conversion,
    derived_source,
    diagnostics,
    export_workbook,
    fir_admin,
    fir_learning,
    mapping_sql,
    prepared_context,
    projects,
    recommendation_actions,
    semantic_context,
    semantic_model,
    sttm_builder,
    table_selection,
    test_case_generation,
    user,
)

router = APIRouter(prefix="/api/v1")
router.include_router(table_selection.router)
router.include_router(derived_source.router)
router.include_router(diagnostics.router)
router.include_router(sttm_builder.router)
router.include_router(agent_gateway.router)
router.include_router(agent_runs.router)
router.include_router(migration_knowledge.router)
router.include_router(assistant_conversations.router)
router.include_router(artifacts.router)
router.include_router(conversation.router)
router.include_router(coco.router)
router.include_router(mapping_sql.router)
router.include_router(prepared_context.router)
router.include_router(projects.router)
router.include_router(dbt_conversion.router)
router.include_router(test_case_generation.router)
router.include_router(export_workbook.router)
router.include_router(agents.router)
router.include_router(user.router)
router.include_router(semantic_model.router)
router.include_router(semantic_context.router)
router.include_router(fir_admin.router)
router.include_router(fir_learning.router)
router.include_router(recommendation_actions.router)
router.include_router(bundle_curation.router)


@router.get("/workbench/auto-map-capabilities")
def auto_map_capabilities(request: Request, project_id: str,
    proxy: Annotated[AutoMappingProxyClient, Depends(get_auto_mapping_proxy_client)]) -> ApiResponseEnvelope[dict]:
    get_current_principal(request)
    from app.core.automap_batch import fast_project_enabled
    enabled = fast_project_enabled(proxy._settings, project_id)
    return build_response_envelope(operation="sttm.auto_map.capabilities", request=request,
        data={"selected_scope": enabled, "reevaluation": enabled,
              "modes": ["preserve_and_complete", "reeval_selected", "reeval_all"] if enabled else ["preserve_and_complete"]})


@router.post("/workbench/auto-map-jobs", status_code=202)
def start_auto_map_job(
    request: Request,
    body: STTMBuilderEnvelopeRequest | STTMBuilderRequest,
    proxy: Annotated[AutoMappingProxyClient, Depends(get_auto_mapping_proxy_client)],
    client: Annotated[SnowflakeClient, Depends(get_snowflake_client)],
    prepared_service: Annotated[PreparedWorkspaceContextService, Depends(get_prepared_workspace_context_service)] = None,
) -> ApiResponseEnvelope[dict]:
    normalized_body = normalize_sttm_builder_invoke_body(body)
    if prepared_service is not None:
        normalized_body = sttm_builder._hydrate_prepared_workspace(normalized_body, prepared_service)
    normalized, _decision = sttm_builder._apply_sttm_preflight(request, normalized_body)
    if normalized.data.intent != Interface.AUTO_MAP:
        raise HTTPException(status_code=400, detail="The request is not an Auto-map operation")
    if not proxy.enabled:
        raise HTTPException(
            status_code=503,
            detail="The Auto-map worker service is not configured for this environment",
        )
    job = proxy.start_job(request, normalized, session=client.session, prepare=True)
    return build_response_envelope(
        operation="sttm.auto_map.job.start",
        request=request,
        request_id=normalized.request_id,
        data=job,
    )


@router.get("/workbench/auto-map-jobs/by-request/{request_id}")
def find_auto_map_job(
    request: Request,
    request_id: str,
    proxy: Annotated[AutoMappingProxyClient, Depends(get_auto_mapping_proxy_client)],
    client: Annotated[SnowflakeClient, Depends(get_snowflake_client)],
) -> ApiResponseEnvelope[dict]:
    get_current_principal(request)
    job = proxy.find_job(request, request_id, session=client.session)
    return build_response_envelope(operation="sttm.auto_map.job.get", request=request,
                                   request_id=request_id, data=job)


@router.get("/workbench/auto-map-jobs/{job_id}")
def get_auto_map_job(
    request: Request,
    job_id: str,
    proxy: Annotated[AutoMappingProxyClient, Depends(get_auto_mapping_proxy_client)],
    client: Annotated[SnowflakeClient, Depends(get_snowflake_client)],
) -> ApiResponseEnvelope[dict]:
    get_current_principal(request)
    job = proxy.get_job(request, job_id, session=client.session)
    return build_response_envelope(
        operation="sttm.auto_map.job.get",
        request=request,
        request_id=str(job.get("request_id") or ""),
        data=job,
    )
