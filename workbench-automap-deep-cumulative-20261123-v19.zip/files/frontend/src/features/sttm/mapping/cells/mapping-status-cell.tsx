import { mappingDisplayStatus } from '../mapping-review-model';
import { AiaTooltip, AiaTableCellPrimitive, AiaChip } from '@/components/ui';
import { aiaTableCellSx } from '@/components/ui/aia-table';
import type { SxProps, Theme } from '@mui/material/styles';
import type { MappingStatus } from '@/features/sttm/types/sttm.types';

type MappingStatusCellProps = {
  status: MappingStatus;
  displayStatus?: ReturnType<typeof mappingDisplayStatus>;
  align?: 'left' | 'center' | 'right';
  width?: number | string;
  minWidth?: number | string;
  sx?: SxProps<Theme>;
};

export const MappingStatusCell = ({
  status,
  displayStatus = status === 'MAPPED' ? 'MAPPED' : 'UNMAPPED',
  align = 'left',
  width = 110,
  minWidth,
  sx,
}: MappingStatusCellProps) => (
  <AiaTableCellPrimitive align={align} sx={aiaTableCellSx({width,minWidth,sx})}>
    <AiaTooltip title={displayStatus === 'MAPPED' ? 'Mapping definition present' : 'No mapping definition'} arrow><span>
      <AiaChip label={displayStatus === 'MAPPED' ? 'Mapped' : 'Unmapped'} color={displayStatus === 'MAPPED' ? 'success' : 'default'} size="small" rounded />
    </span></AiaTooltip>
  </AiaTableCellPrimitive>
);
