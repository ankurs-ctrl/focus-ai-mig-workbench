import copy
import json
from types import SimpleNamespace
from unittest.mock import Mock

import pytest

from app.core.exceptions import SnowflakeQueryError
from app.core.project_service import ProjectService
from app.schema.project import STTMPublishRequest


class Row(dict):
    def as_dict(self):
        return dict(self)


def service_fixture():
    service = ProjectService.__new__(ProjectService)
    statements = []

    def execute(sql, params=None):
        statements.append((sql, params))
        if "SELECT VERSION_ID" in sql:
            rows = [Row(VERSION_ID=7)]
        elif "SET CURRENT_VERSION = ?" in sql:
            rows = [Row(number_of_rows_updated=1)]
        else:
            rows = []
        return SimpleNamespace(collect=lambda: rows)

    service._session = SimpleNamespace(sql=execute)
    service._qualified_name = lambda name: f"DB.S.{name}"
    service._settings = SimpleNamespace(
        autosave_postsave_async_v1=True,
        snowflake_sttm_table="STTMS", snowflake_sttm_versions_table="VERSIONS",
    )
    # These legacy fixtures isolate capture/outbox semantics. Gate tests below
    # restore the real validator and compiler with a mocked SQL session.
    service.list_project_attributes = Mock(return_value=[])
    service._validate_publication = Mock()
    service.ensure_storage_exists = Mock()
    service._table_columns = Mock(return_value={})
    service._actor_column_values = Mock(return_value={})
    service._list_artifacts = Mock(return_value=[])
    service.get_sttm_record = Mock(return_value=SimpleNamespace(
        sttm_id="42", project_id="p", current_version=1, last_snapshot_id="old",
        semantic_bundle_id=None, semantic_bundle_hash=None,
    ))
    service.autosave_sttm = Mock(return_value=SimpleNamespace(snapshot_id="snap"))
    service._async_jobs = Mock()
    service._async_jobs.enqueue.return_value = ("job", "queued")
    service._run_publish_projections = Mock()
    return service, statements


def request():
    return STTMPublishRequest(request_id="publish-1", workspace_snapshot={
        "raw_mapping_sql": "SELECT 'a  b' AS value", "mapping_rows": [],
    })


def test_version_header_and_learning_intent_share_transaction():
    service, statements = service_fixture()
    service._async_jobs.enqueue.side_effect = lambda **kwargs: (
        statements.append(("OUTBOX", copy.deepcopy(kwargs))) or ("job", "queued")
    )
    result = service.publish_sttm("42", request(), user_id="u")
    sql = [item[0] for item in statements]
    begin, commit = sql.index("BEGIN TRANSACTION"), sql.index("COMMIT")
    assert begin < next(index for index, text in enumerate(sql) if text.startswith("INSERT INTO")) < commit
    assert begin < sql.index("OUTBOX") < commit
    capture = statements[sql.index("OUTBOX")][1]
    assert capture["payload"]["snapshot"]["raw_mapping_sql"] == "SELECT 'a  b' AS value"
    assert capture["payload"]["version_id"] == "7"
    assert result.status == "COMPLETE"
    assert result.learning_status == "queued"
    assert result.learning_job_id == "job"
    service._run_publish_projections.assert_not_called()


def test_publication_captures_all_rows_and_exact_authored_and_compiled_sql():
    service, _ = service_fixture()
    service._insert_existing_columns_bound = Mock()
    authored = "SELECT 'a  b' AS NAME -- retain original spacing\nFROM D.S.A"
    compiled = "INSERT INTO D.S.T SELECT TRIM(a.NAME) FROM D.S.A a"
    snapshot = {
        "raw_mapping_sql": authored,
        "compiled_mapping_sql": compiled,
        "compiled_mapping_script_sql": "SET FirmID = 'historical';\n" + compiled,
        "mapping_rows": [{"id": str(index), "target_column": f"COL_{index}", "status": "MAPPED"}
                         for index in range(137)],
    }
    service.publish_sttm("42", STTMPublishRequest(request_id="all-rows", workspace_snapshot=snapshot), user_id="u")
    fields = service._insert_existing_columns_bound.call_args.args[1]
    capture = json.loads(fields["VERSION_PAYLOAD"][1][0])
    assert fields["RAW_MAPPING_SQL"][1] == [authored]
    assert capture["raw_mapping_sql"] == authored
    assert capture["compiled_mapping_sql"] == compiled
    assert capture["compiled_mapping_script_sql"] == snapshot["compiled_mapping_script_sql"]
    assert len(capture["mapping_rows"]) == 137
    assert service._async_jobs.enqueue.call_args.kwargs["payload"]["snapshot"] == capture


def test_captured_publication_recovers_and_hydrates_exact_mapping_scoped_learning(monkeypatch):
    from app.core.mapping_knowledge_projector import MappingKnowledgeProjector
    from app.core.mapping_search import MappingSearchService
    from app.core import mapping_search

    service, _ = service_fixture()
    snapshot = {"raw_mapping_sql": "SELECT 'a  b' AS NAME", "snapshot_id": "snap",
                "target_table": {"database": "D", "schema": "T", "table": "HOUSEHOLD"},
                "mapping_rows": [{"target_column": "NAME", "constant_value": "a  b", "status": "MAPPED"}]}
    before = copy.deepcopy(snapshot)
    receipt = service.publish_sttm("42", STTMPublishRequest(request_id="recover", workspace_snapshot=snapshot), user_id="u")
    captured = copy.deepcopy(service._async_jobs.enqueue.call_args.kwargs["payload"])
    assert receipt.learning_status == "queued"
    service._run_publish_projections.assert_not_called()

    # The callback is lost. A fresh service receives only the durable payload.
    recovered = ProjectService.__new__(ProjectService)
    recovered._async_jobs = Mock()
    recovered._async_jobs.claim_next.side_effect = [
        {"JOB_ID": receipt.learning_job_id, "LEASE_OWNER": "restart:1", "JOB_TYPE": "sttm_publish_projection",
         "PROJECT_ID": "p", "STTM_ID": "42", "PAYLOAD": captured}, None, None,
    ]
    recorder = Mock()
    canonical = {}
    def record(**kwargs):
        identity = "canonical-published-name"
        canonical[identity] = {"LEARNING_ID": identity, "PROJECT_ID": "p", "STTM_ID": "42", "TRUST_STAGE": "published",
                               "ENTITY_IDS": {"project_id": "p", "sttm_id": "42"},
                               "AGENT_PAYLOAD": kwargs["attributes"], "ATTRIBUTES": kwargs["attributes"]}
        return identity
    recorder.record_learning.side_effect = record
    recovered._knowledge_projector = MappingKnowledgeProjector(recorder)
    recovered._record_fir = Mock()
    recovered._record_agent_learnings = Mock(return_value=0)
    recovered._record_target_mapping_patterns = Mock()
    recovered._record_learned_relationships = Mock()
    recovered._memory = Mock()
    assert recovered.process_postsave_jobs(worker_id="restart", project_id="p", job_types=("sttm_publish_projection",)) == 1
    assert recovered.process_postsave_jobs(worker_id="restart", project_id="p", job_types=("sttm_publish_projection",)) == 0
    evidence = canonical["canonical-published-name"]["AGENT_PAYLOAD"]["learning_evidence"]
    assert evidence["version_id"] == receipt.version_id
    assert evidence["snapshot_id"] == receipt.snapshot_id
    recovered._async_jobs.mark_complete.assert_called_once_with(receipt.learning_job_id, worker_id="restart:1")

    # External Search is simulated, but canonical hydration and eligibility use
    # the actual reader. This does not assert real indexing/enrichment occurred.
    monkeypatch.setattr(mapping_search, "search_service", lambda session, service, **kwargs:
        [{"KNOWLEDGE_ID": "canonical-published-name", "KNOWLEDGE_TYPE": "agent_learning"}]
        if service.endswith("CSS_FIR_KNOWLEDGE") else [])
    session = Mock()
    persisted_receipt = Row(EVENT_ID=evidence["event_id"], EVENT_TYPE="sttm.published", EVENT_PAYLOAD={},
                            SNAPSHOT_ID=receipt.snapshot_id, PROJECT_ID="p", STTM_ID="42",
                            SNAPSHOT_PAYLOAD=captured["snapshot"], VERSION_ID=receipt.version_id)
    session.sql.side_effect = lambda sql, params=None: SimpleNamespace(collect=lambda:
        [persisted_receipt] if "SELECT e.EVENT_ID" in sql else [Row(canonical["canonical-published-name"])])
    settings = SimpleNamespace(automap_recipe_search_service="", automap_column_search_service="",
                               qualify_metadata_object_name=lambda name: f"DB.S.{name}")
    result = MappingSearchService(session, settings).discover(project_id="p", sttm_id="42",
        target_table="D.T.HOUSEHOLD", target_columns=["NAME"], source_tables=[])
    assert result["diagnostics"]["hydrated_ids"] == ["canonical-published-name"]
    assert result["evidence"]
    second = MappingSearchService(session, settings).discover(project_id="p", sttm_id="second",
        target_table="D.T.HOUSEHOLD", target_columns=["NAME"], source_tables=[])
    assert second["evidence"] == []  # Mapping-scoped learnings are not shared recipes.
    assert snapshot == before


def test_publish_callback_loss_recovers_shared_recipe_for_second_mapping(monkeypatch):
    from app.core.config import Settings
    from app.core.target_mapping_patterns import TargetMappingPatternService
    from app.core.mapping_search import MappingSearchService
    from app.core import mapping_search

    service, _ = service_fixture()
    snapshot = {"snapshot_id": "snap", "raw_mapping_sql": "SELECT TRIM(a.NAME) FROM D.S.A a",
        "target_table": {"database": "D", "schema": "S", "table": "T"},
        "source_tables": [{"database": "D", "schema": "S", "table": "A"}],
        "relation_graph": {"nodes": [{"alias": "a", "table": {"database": "D", "schema": "S", "table": "A"},
            "grain": "One customer", "output_columns": [{"name": "NAME", "data_type": "TEXT"}]}]},
        "mapping_rows": [{"target_column": "NAME", "status": "MAPPED", "source_columns": ["D.S.A.NAME"],
                          "target_type": "VARCHAR", "expression": "TRIM(a.NAME)"}]}
    before = copy.deepcopy(snapshot)
    receipt = service.publish_sttm("42", STTMPublishRequest(request_id="share-recipe", workspace_snapshot=snapshot), user_id="u")
    payload = copy.deepcopy(service._async_jobs.enqueue.call_args.kwargs["payload"])
    patterns = []
    monkeypatch.setattr(TargetMappingPatternService, "upsert_patterns", lambda _, items: patterns.extend(items) or len(items))
    jobs = []
    monkeypatch.setattr(TargetMappingPatternService, "create_learning_job", lambda _, **kwargs: jobs.append(kwargs))
    recovered = ProjectService.__new__(ProjectService)
    recovered._settings = Settings(FIR_TARGET_MAPPING_PATTERNS_V2=True, FIR_DURABLE_JOBS_V2=True)
    recovered._session = Mock()
    recovered._async_jobs = Mock()
    recovered._async_jobs.claim_next.side_effect = [{"JOB_ID": receipt.learning_job_id, "LEASE_OWNER": "restart:1",
        "JOB_TYPE": "sttm_publish_projection", "PROJECT_ID": "p", "STTM_ID": "42", "PAYLOAD": payload}, None]
    recovered._record_fir = Mock()
    recovered._record_agent_learnings = Mock(return_value=0)
    recovered._knowledge_projector = Mock()
    recovered._knowledge_projector.project.return_value = 0
    recovered._record_learned_relationships = Mock()
    recovered._memory = Mock()
    assert recovered.process_postsave_jobs(worker_id="restart") == 1
    assert len(patterns) == len(jobs) == 1
    pattern = patterns[0]
    assert pattern.provenance["publication_version_id"] == receipt.version_id
    assert jobs[0]["patterns"][0].pattern_id == pattern.pattern_id
    # Exercise real embedded enrichment stages; external SQL is a deterministic
    # fake that supplies inventory and DML results, never a live connection.
    from pathlib import Path
    queue_path = Path(__file__).resolve().parents[5] / "infra/snowflake/fir_system/procedures/sp-fir-process-learning-queue.sql"
    handler = {}
    exec(compile(queue_path.read_text(encoding="utf-8").split("$$", 2)[1], str(queue_path), "exec"), handler)
    stages = []
    class QueueSession:
        def sql(self, sql, params=None):
            stages.append(sql)
            if "SELECT WORK_ITEM_ID, ATTEMPT_COUNT" in sql:
                rows = [{"WORK_ITEM_ID": "agent", "ATTEMPT_COUNT": 0}]
            elif "AS ESCALATION_COUNT" in sql:
                rows = [{"PATTERN_COUNT": 1, "ESCALATION_COUNT": 0}]
            elif "SELECT DISCOVERED_PATTERN_COUNT" in sql:
                rows = [{"DISCOVERED_PATTERN_COUNT": 1}]
            elif "AS TOTAL_ITEMS" in sql:
                rows = [{"DISCOVERED": 1, "COMPLETED": 1, "FAILED": 0, "REMAINING": 0, "DEAD_LETTER": 0, "TOTAL_ITEMS": 6}]
            elif "SELECT COUNT(*) AS CNT" in sql:
                rows = [{"CNT": 1}]
            else:
                rows = [{"number_of_rows_updated": 1}]
            return SimpleNamespace(collect=lambda: rows)
    queue_session = QueueSession()
    handler["_complete_deterministic_enrichment"](queue_session, "job", 10)
    handler["_complete_conflict_stage"](queue_session, "job")
    assert handler["_run_agent"](queue_session, "job", jobs[0]["asset_id"]) == "routine_enrichment_complete"
    handler["_complete_post_agent_stages"](queue_session, "job")
    assert handler["_refresh_job"](queue_session, "job", 1)["status"] == "completed"
    assert any("search_visibility_verified" in sql for sql in stages)
    canonical = Row(PATTERN_ID=pattern.pattern_id, TARGET_COLUMN="NAME", TARGET_TABLE="D.S.T", SCOPE=pattern.scope,
        PROJECT_ID="p", STTM_ID="42", VALIDATION_STATUS="published", CONFIDENCE=.97,
        PATTERN_PAYLOAD=pattern.model_dump(mode="json"))
    session = Mock()
    session.sql.return_value.collect.return_value = [canonical]
    monkeypatch.setattr(mapping_search, "search_service", lambda session, service, **kwargs:
        [{"PATTERN_ID": pattern.pattern_id}] if service.endswith("RECIPES") else [])
    settings = Settings(AUTOMAP_RECIPE_SEARCH_SERVICE="RECIPES")
    discovery = MappingSearchService(session, settings).discover(project_id="other-project", sttm_id="second",
        target_table="D.S.T", target_columns=["NAME"], source_tables=["D.S.A"])
    assert discovery["diagnostics"]["hydrated_ids"] == [pattern.pattern_id]
    candidate = TargetMappingPatternService(session, settings).retrieve_candidates(
        target_table="D.S.T", target_columns=["NAME"], source_tables=["D.S.A"], source_columns=["D.S.A.NAME"],
        source_column_profiles=[{"physical_name": "D.S.A.NAME", "type": "TEXT", "grain": "One customer"}],
        project_id="other-project", workspace_context_id="second", discovered_only=True,
        additional_pattern_ids=[pattern.pattern_id])[0]
    assert candidate.decision == "accept_exact_precedent"
    assert candidate.pattern.provenance["publication_version_id"] == receipt.version_id
    assert snapshot == before


def test_outbox_failure_rolls_back_publication():
    service, statements = service_fixture()
    service._async_jobs.enqueue.side_effect = RuntimeError("queue unavailable")
    with pytest.raises(RuntimeError, match="queue unavailable"):
        service.publish_sttm("42", request(), user_id="u")
    assert statements[-1][0] == "ROLLBACK"
    assert "COMMIT" not in [sql for sql, _ in statements]


def test_concurrent_draft_or_version_change_does_not_insert_version():
    service, statements = service_fixture()
    original = service._session.sql

    def execute(sql, params=None):
        if "SET CURRENT_VERSION = ?" in sql:
            return SimpleNamespace(collect=lambda: [Row(number_of_rows_updated=0)])
        return original(sql, params)

    service._session.sql = execute
    from app.core.exceptions import ConflictError
    with pytest.raises(ConflictError, match="changed during publication") as error:
        service.publish_sttm("42", request(), user_id="u")
    assert error.value.status_code == 409
    assert not any(sql.startswith("INSERT INTO") for sql, _ in statements)
    service._async_jobs.enqueue.assert_not_called()
    assert statements[-1][0] == "ROLLBACK"


def test_retry_returns_durable_version_without_autosave_or_projection():
    service, _ = service_fixture()
    published = service.publish_sttm("42", request(), user_id="u")
    version = service._async_jobs.enqueue.call_args.kwargs["payload"]["snapshot"]
    service.autosave_sttm.reset_mock()
    service._session.sql = lambda *args, **kwargs: SimpleNamespace(collect=lambda: [Row(
        VERSION_ID=7, VERSION_NUMBER=2, SNAPSHOT_ID="snap", VERSION_PAYLOAD=json.dumps(version),
    )])
    service._async_jobs.for_snapshot.return_value = {"JOB_ID": "job", "STATUS": "completed"}
    retried = service.publish_sttm("42", request(), user_id="u")
    assert retried.version_id == published.version_id
    assert retried.learning_status == "completed"
    service.autosave_sttm.assert_not_called()


def test_publish_projection_uses_immutable_capture_not_later_draft():
    service = ProjectService.__new__(ProjectService)
    service._record_fir = Mock()
    service._record_agent_learnings = Mock(return_value=1)
    service._knowledge_projector = Mock()
    service._knowledge_projector.project.return_value = 2
    service._record_target_mapping_patterns = Mock()
    service._record_learned_relationships = Mock()
    service._memory = Mock()
    service._latest_snapshot = Mock(side_effect=AssertionError("must not read draft"))
    service._list_artifacts = Mock(side_effect=AssertionError("must not read mutable artifacts"))
    snapshot = {"snapshot_id": "immutable", "mapping_rows": [{"used_recommendation_ids": ["rec"]}]}
    assert service._run_publish_projections(project_id="p", sttm_id="42", projection_payload={
        "snapshot": snapshot, "version_id": "7", "version_number": 2, "user_id": "u",
    }) == (3, 1)
    assert service._record_agent_learnings.call_args.kwargs["snapshot"] == snapshot
    assert service._record_agent_learnings.call_args.kwargs["strict"] is True
    assert service._memory.record_fir_recommendation_outcome.call_args.kwargs["request_id"] == "publish:42:7"


def test_publication_provenance_pages_only_captured_artifacts_without_global_cap():
    service, _ = service_fixture()
    service._settings.snowflake_agent_artifacts_table = "ARTIFACTS"
    calls = []
    def execute(sql, params=None):
        calls.append((sql, params))
        return SimpleNamespace(collect=lambda: [Row(ARTIFACT_ID=value, PAYLOAD={},
            USED_RECOMMENDATION_IDS=json.dumps([f"rec-{value}"])) for value in params[:-2]])
    service._session.sql = execute
    snapshot = {"mapping_rows": [{"agent_artifact_id": f"a-{index}"} for index in range(205)]}
    artifacts, recommendations = service._publication_provenance("42", snapshot)
    assert len(artifacts) == len(recommendations) == 205
    assert [len(params) - 2 for _, params in calls] == [100, 100, 5]
    assert all(params[-2:] == ["42", "42"] for _, params in calls)
    service._list_artifacts.assert_not_called()


def publication_fixture():
    service, statements = service_fixture()
    del service._validate_publication
    snapshot = {
        "project_id": "p", "target_table": {"database": "D", "schema": "S", "table": "T"},
        "source_tables": [{"database": "D", "schema": "S", "table": "A"}],
        "relation_graph": {"nodes": [{"relation_id": "D.S.A", "alias": "a", "kind": "PHYSICAL_TABLE",
            "table": {"database": "D", "schema": "S", "table": "A"},
            "output_columns": [{"name": "NAME", "data_type": "VARCHAR"}]}]},
        "mapping_rows": [{"id": "name", "target_column": "NAME", "target_type": "VARCHAR",
                          "source_columns": ["a.NAME"], "rule": "Direct", "status": "NEEDS_VALIDATION"}],
        "mapping_sql": "INSERT INTO D.S.T (NAME) SELECT a.NAME AS NAME FROM D.S.A a",
        "mapping_preview_sql": "SELECT a.NAME AS NAME FROM D.S.A a",
    }
    return service, statements, snapshot


def test_actual_publication_compiles_only_select_before_metadata_capture_and_allows_partial_without_citations():
    service, statements, snapshot = publication_fixture()
    snapshot["mapping_rows"].append({"id": "unused", "target_column": "UNUSED", "status": "UNMAPPED", "rule": "Select..."})
    snapshot["mapping_rows"][0]["draft_issues"] = [{"category": "evidence", "message": "Missing citation"}]
    result = service.publish_sttm("42", STTMPublishRequest(workspace_snapshot=snapshot), user_id="u")
    assert result.version_number == 2
    explained = [sql for sql, _ in statements if sql.startswith("EXPLAIN")]
    assert explained and all("INSERT INTO" not in sql for sql in explained)
    assert service._async_jobs.enqueue.call_args.kwargs["payload"]["snapshot"]["_publication_validation"]["execution_permissions_validated"] is False
    assert "SELECT a.NAME" in explained[0] or "SELECT A.NAME" in explained[0]
    assert next(index for index, (sql, _) in enumerate(statements) if sql.startswith("EXPLAIN")) < next(
        index for index, (sql, _) in enumerate(statements) if sql == "BEGIN TRANSACTION")
    assert len(service._async_jobs.enqueue.call_args.kwargs["payload"]["snapshot"]["mapping_rows"]) == 2


@pytest.mark.parametrize("case", ["sql", "omitted-draft", "source", "rule", "missing-value", "value-mismatch",
    "population", "preview", "target", "multi-statement", "query-modifier", "no-rows", "duplicate", "quoted-source"])
def test_actual_publish_rejects_invalid_api_artifact_before_autosave_version_or_learning(case):
    from app.core.exceptions import AppValidationError
    service, statements, snapshot = publication_fixture()
    row = snapshot["mapping_rows"][0]
    if case == "sql": snapshot["mapping_sql"] = snapshot["mapping_sql"].replace("a.NAME AS", "TRIM(a.NAME) AS")
    if case == "omitted-draft": snapshot["mapping_rows"].append({**row, "id": "bad", "target_column": "BAD", "rule": "Custom"})
    if case == "source": row["source_columns"] = ["foreign.NAME"]
    if case == "quoted-source": row["source_columns"] = ['a."name"']
    if case == "rule": row["rule"] = "Custom"
    if case == "missing-value": row.update(mapping_mode="attribute", attribute_name="Missing", constant_value="$Missing")
    if case == "value-mismatch": row.update(mapping_mode="attribute", attribute_name="Firm", constant_value="fake")
    if case == "population": snapshot["filters"] = {"filter_sql": "a.NAME IS NOT NULL"}
    if case == "preview": snapshot["mapping_preview_sql"] = "SELECT 1 AS NAME"
    if case == "target": snapshot["mapping_sql"] = snapshot["mapping_sql"].replace("D.S.T", "D.S.OTHER")
    if case == "multi-statement": snapshot["mapping_sql"] += "; SELECT 1"
    if case == "query-modifier": snapshot["filters"] = {"query_modifiers": {"limit": "LIMIT 1"}}
    if case == "no-rows": snapshot["mapping_rows"] = []
    if case == "duplicate": snapshot["mapping_rows"].append(dict(row))
    snapshot["compiled_mapping_ready"] = True
    snapshot["validation_history"] = [{"valid": True, "signature": "forged", "kind": "mapping_sql_validation"}]
    with pytest.raises(AppValidationError):
        service.publish_sttm("42", STTMPublishRequest(workspace_snapshot=snapshot), user_id="u")
    service.autosave_sttm.assert_not_called()
    service._async_jobs.enqueue.assert_not_called()
    assert not any(sql == "BEGIN TRANSACTION" or sql.startswith("INSERT INTO") for sql, _ in statements)


@pytest.mark.parametrize("failure", ["SELECT"])
def test_actual_publish_explain_failure_no_capture_and_recovery_validates_again(failure):
    service, statements, snapshot = publication_fixture()
    original = service._session.sql
    def execute(sql, params=None):
        if sql.startswith("EXPLAIN USING TEXT " + failure):
            raise RuntimeError("type or SQL compilation failed")
        return original(sql, params)
    service._session.sql = execute
    with pytest.raises(RuntimeError, match="compilation failed"):
        service.publish_sttm("42", STTMPublishRequest(workspace_snapshot=snapshot), user_id="u")
    service.autosave_sttm.assert_not_called()
    service._async_jobs.enqueue.assert_not_called()
    service._session.sql = original
    service.publish_sttm("42", STTMPublishRequest(workspace_snapshot=snapshot), user_id="u")
    service._async_jobs.enqueue.assert_called_once()


@pytest.mark.parametrize("value, kind", [("", "VARCHAR"), ("0", "NUMBER"), ("false", "BOOLEAN")])
def test_actual_publish_preserves_empty_zero_false_constants(value, kind):
    from app.core.mapping_sql import MappingSqlService
    service, _, snapshot = publication_fixture()
    snapshot["mapping_rows"][0].update(mapping_mode="constant", constant_value=value, target_type=kind, source_columns=[])
    snapshot["relation_graph"]["value_bindings"] = [{"binding_id": "value:name", "value": value, "data_type": kind}]
    literal = MappingSqlService._compile_constant(value, kind)
    snapshot["mapping_preview_sql"] = f"SELECT {literal} AS NAME FROM D.S.A a"
    snapshot["mapping_sql"] = "INSERT INTO D.S.T (NAME) " + snapshot["mapping_preview_sql"]
    service.publish_sttm("42", STTMPublishRequest(workspace_snapshot=snapshot), user_id="u")
    captured = service._async_jobs.enqueue.call_args.kwargs["payload"]["snapshot"]
    assert captured["mapping_rows"][0]["constant_value"] == value
    assert captured["_publication_validation"]["sql"] == snapshot["mapping_sql"]


def test_actual_publish_all_45_drafts_included_and_cte_population_checked():
    service, _, snapshot = publication_fixture()
    snapshot["relation_graph"]["nodes"] = [{"relation_id": "cte", "kind": "CTE", "alias": "c",
        "sql_text": "SELECT NAME FROM D.S.A WHERE NAME IS NOT NULL", "output_columns": [{"name": "NAME"}]}]
    snapshot["mapping_rows"] = [{"id": str(index), "target_column": f"NAME_{index}", "source_columns": ["c.NAME"],
        "target_type": "VARCHAR", "rule": "Direct", "status": "VALIDATION_FAILED"} for index in range(45)]
    from app.core.mapping_sql import MappingSqlService
    from app.schema.mapping_sql import MappingSqlCompileRequest
    compiled = MappingSqlService(session=None, analyst_client=None).compile(MappingSqlCompileRequest(
        relation_graph=snapshot["relation_graph"], target_table=snapshot["target_table"], validate_with_explain=False,
        mappings=[{**row, "status": "MAPPED"} for row in snapshot["mapping_rows"]]))
    snapshot.update(mapping_sql=compiled.generated_sql, mapping_preview_sql=compiled.preview_sql)
    service.publish_sttm("42", STTMPublishRequest(workspace_snapshot=snapshot), user_id="u")
    assert len(service._async_jobs.enqueue.call_args.kwargs["payload"]["snapshot"]["mapping_rows"]) == 45
    service.autosave_sttm.reset_mock()
    snapshot["relation_graph"]["nodes"][0]["sql_text"] = "SELECT NAME FROM D.S.A"
    from app.core.exceptions import AppValidationError
    with pytest.raises(AppValidationError, match="does not match"):
        service.publish_sttm("42", STTMPublishRequest(workspace_snapshot=snapshot), user_id="u")
    service.autosave_sttm.assert_not_called()


def test_publish_route_permission_and_invalid_artifact_cannot_be_bypassed(monkeypatch):
    import app.api
    from app.routers import projects
    from app.core.exceptions import AppValidationError
    from fastapi import BackgroundTasks, HTTPException
    service, _, snapshot = publication_fixture()
    snapshot["mapping_sql"] = "SELECT 1 AS NAME"
    permissions = SimpleNamespace(can_publish=False)
    monkeypatch.setattr(projects, "get_current_principal", lambda _: SimpleNamespace(
        snowflake_user="u", user_id="u", permissions=permissions))
    tasks = BackgroundTasks()
    payload = STTMPublishRequest(workspace_snapshot=snapshot)
    with pytest.raises(HTTPException) as error:
        projects.publish_sttm(None, tasks, "42", payload, service, Mock())
    assert error.value.status_code == 403
    permissions.can_publish = True
    with pytest.raises(AppValidationError):
        projects.publish_sttm(None, tasks, "42", payload, service, Mock())
    service.autosave_sttm.assert_not_called()
    service._async_jobs.enqueue.assert_not_called()
    assert not tasks.tasks


def test_actual_successful_publish_retry_does_not_revalidate_or_duplicate_side_effects():
    service, statements, snapshot = publication_fixture()
    payload = STTMPublishRequest(request_id="same", workspace_snapshot=snapshot)
    first = service.publish_sttm("42", payload, user_id="u")
    version = copy.deepcopy(service._async_jobs.enqueue.call_args.kwargs["payload"]["snapshot"])
    service.autosave_sttm.reset_mock()
    service.list_project_attributes.side_effect = AssertionError("retry must return captured version")
    service._session.sql = lambda *args, **kwargs: SimpleNamespace(collect=lambda: [Row(
        VERSION_ID=7, VERSION_NUMBER=2, SNAPSHOT_ID="snap", VERSION_PAYLOAD=version)])
    service._async_jobs.for_snapshot.return_value = {"JOB_ID": "job", "STATUS": "completed"}
    assert service.publish_sttm("42", payload, user_id="u").version_id == first.version_id
    service.autosave_sttm.assert_not_called()
    service._async_jobs.enqueue.assert_called_once()


def test_actual_publication_reloads_values_and_rejects_stale_inlined_sql():
    from app.core.exceptions import AppValidationError
    service, statements, snapshot = publication_fixture()
    service.list_project_attributes.return_value = [SimpleNamespace(attribute_name="Firm", attribute_value="new", attribute_type="VARCHAR")]
    row = snapshot["mapping_rows"][0]
    row.update(mapping_mode="attribute", attribute_name="Firm", constant_value="$Firm", source_columns=[])
    snapshot["relation_graph"]["value_bindings"] = [{"binding_id": "value:name", "value": "$Firm", "resolved_value": "old", "resolution_status": "resolved"}]
    snapshot["mapping_sql"] = "INSERT INTO D.S.T (NAME) SELECT 'old' AS NAME FROM D.S.A a"
    snapshot["mapping_preview_sql"] = "SELECT 'old' AS NAME FROM D.S.A a"
    with pytest.raises(AppValidationError, match="does not match"):
        service.publish_sttm("42", STTMPublishRequest(workspace_snapshot=snapshot), user_id="u")
    service.autosave_sttm.assert_not_called()
    snapshot["mapping_sql"] = snapshot["mapping_sql"].replace("'old'", "$Firm")
    snapshot["mapping_preview_sql"] = snapshot["mapping_preview_sql"].replace("'old'", "$Firm")
    service.publish_sttm("42", STTMPublishRequest(workspace_snapshot=snapshot), user_id="u")
    assert any(sql.startswith("EXPLAIN USING TEXT SELECT") and "'new'" in sql for sql, _ in statements)
    assert not any(sql.startswith("EXPLAIN USING TEXT INSERT") for sql, _ in statements)


def compile_publication_snapshot(snapshot):
    from app.core.mapping_sql import MappingSqlService
    from app.schema.mapping_sql import MappingSqlCompileRequest
    compiled = MappingSqlService(session=None, analyst_client=None).compile(MappingSqlCompileRequest(
        relation_graph=snapshot["relation_graph"], target_table=snapshot["target_table"],
        driving_relation_id=snapshot.get("driving_relation_id"), validate_with_explain=False,
        mappings=[{**row, "status": "MAPPED"} for row in snapshot["mapping_rows"]]))
    snapshot.update(mapping_sql=compiled.generated_sql, mapping_preview_sql=compiled.preview_sql)


@pytest.mark.parametrize("quoted", [False, True])
@pytest.mark.parametrize("change", ["rename", "uncorrelate", "self-join-owner"])
def test_actual_publication_preserves_correlated_cte_binding_ownership(quoted, change):
    from app.core.exceptions import AppValidationError
    service, statements, snapshot = publication_fixture()
    outer, inner = ('"Outer"', '"Inner"') if quoted else ('a', 'b')
    sql = f'SELECT {outer}.NAME FROM D.S.A {outer} WHERE EXISTS (SELECT 1 FROM D.S.B {inner} WHERE {inner}.ID = {outer}.ID)'
    snapshot["source_tables"].append({"database": "D", "schema": "S", "table": "B"})
    if change == "self-join-owner":
        sql = f'SELECT {outer}.NAME FROM D.S.A {outer} JOIN D.S.A {inner} ON {outer}.ID = {inner}.ID'
    snapshot["relation_graph"]["nodes"] = [{"relation_id": "cte", "kind": "CTE", "alias": "c",
        "sql_text": sql, "output_columns": [{"name": "NAME"}]}]
    snapshot["mapping_rows"][0]["source_columns"] = ["c.NAME"]
    compile_publication_snapshot(snapshot)
    for field in ("mapping_sql", "mapping_preview_sql"):
        if change == "rename":
            snapshot[field] = snapshot[field].replace(outer, '"RenamedOuter"').replace(inner, '"RenamedInner"')
        elif change == "uncorrelate":
            snapshot[field] = snapshot[field].replace(f"{inner}.ID = {outer}.ID", f"{inner}.ID = {inner}.ID")
        else:
            snapshot[field] = snapshot[field].replace(f"{outer}.NAME", f"{inner}.NAME")
    if change == "rename":
        service.publish_sttm("42", STTMPublishRequest(workspace_snapshot=snapshot), user_id="u")
        assert any(sql.startswith("EXPLAIN") for sql, _ in statements)
    else:
        with pytest.raises(AppValidationError, match="does not match"):
            service.publish_sttm("42", STTMPublishRequest(workspace_snapshot=snapshot), user_id="u")
        service.autosave_sttm.assert_not_called()
        service._async_jobs.enqueue.assert_not_called()
        assert not any(sql.startswith("EXPLAIN") or sql == "BEGIN TRANSACTION" for sql, _ in statements)
        # The fake session would accept EXPLAIN: it is not a semantic proof.


@pytest.mark.parametrize("case", ["hidden", "nested", "unused", "qualified-shadow", "quoted-case",
                                  "selected", "internal-lineage", "wrong-branch", "stale-definition"])
def test_actual_publication_checks_full_physical_dependencies_and_branch_lineage(case):
    from app.core.exceptions import AppValidationError
    service, statements, snapshot = publication_fixture()
    sql = "SELECT NAME FROM SECRET.S.UNSELECTED"
    if case == "nested": sql = "WITH local AS (SELECT NAME FROM SECRET.S.UNSELECTED) SELECT NAME FROM local"
    if case == "unused": sql = "WITH unused AS (SELECT NAME FROM SECRET.S.UNSELECTED) SELECT NAME FROM D.S.A"
    if case == "qualified-shadow": sql = "WITH UNSELECTED AS (SELECT NAME FROM D.S.A) SELECT NAME FROM SECRET.S.UNSELECTED"
    if case == "quoted-case": sql = 'SELECT NAME FROM D.S."a"'
    node = {"relation_id": "cte", "kind": "CTE", "alias": "c", "sql_text": sql, "output_columns": [{"name": "NAME"}]}
    snapshot["relation_graph"]["nodes"] = [node]
    snapshot["mapping_rows"][0]["source_columns"] = ["c.NAME"]
    lineage = {"database": "SECRET", "schema": "S", "table": "UNSELECTED"}
    if case == "selected": snapshot["source_tables"].append(lineage)
    if case in {"internal-lineage", "wrong-branch", "stale-definition"}:
        snapshot["derived_sources"] = [{"id": "cte", "is_selected": True, "sql_text": sql,
                                        "base_source_tables": [lineage]}]
        if case == "wrong-branch": snapshot["derived_sources"][0]["id"] = "different-cte"
        if case == "stale-definition": snapshot["derived_sources"][0]["sql_text"] = "SELECT NAME FROM D.S.A"
    compile_publication_snapshot(snapshot)
    if case in {"selected", "internal-lineage"}:
        service.publish_sttm("42", STTMPublishRequest(workspace_snapshot=snapshot), user_id="u")
        assert any(sql.startswith("EXPLAIN") for sql, _ in statements)
    else:
        with pytest.raises(AppValidationError, match="outside|disagrees"):
            service.publish_sttm("42", STTMPublishRequest(workspace_snapshot=snapshot), user_id="u")
        service.autosave_sttm.assert_not_called()
        service._async_jobs.enqueue.assert_not_called()
        assert not any(sql.startswith("EXPLAIN") or sql == "BEGIN TRANSACTION" for sql, _ in statements)


@pytest.mark.parametrize("before, after, equal", [
    ('WITH c AS (SELECT a.NAME FROM D.S.A a) SELECT l.NAME FROM c l JOIN c r ON l.NAME=r.NAME',
     'WITH renamed AS (SELECT x.NAME FROM D.S.A x) SELECT lhs.NAME FROM renamed lhs JOIN renamed rhs ON lhs.NAME=rhs.NAME', True),
    ('WITH c AS (SELECT a.NAME FROM D.S.A a) SELECT l.NAME FROM c l JOIN c r ON l.NAME=r.NAME',
     'WITH c AS (SELECT a.NAME FROM D.S.A a) SELECT r.NAME FROM c l JOIN c r ON l.NAME=r.NAME', False),
    ('SELECT x.NAME FROM (SELECT a.NAME FROM D.S.A a) x',
     'SELECT y.NAME FROM (SELECT b.NAME FROM D.S.A b) y', True),
    ('SELECT x.NAME FROM D.S.A x(NAME, ID)', 'SELECT x.NAME FROM D.S.A x(ID, NAME)', False),
    ('WITH c(NAME, ID) AS (SELECT a.NAME, a.ID FROM D.S.A a) SELECT c.NAME FROM c',
     'WITH c(ID, NAME) AS (SELECT a.NAME, a.ID FROM D.S.A a) SELECT c.NAME FROM c', False),
    ('SELECT a."Name" FROM D.S.A a', 'SELECT a."NAME" FROM D.S.A a', False),
    ('SELECT a.NAME FROM D.S.A a WHERE EXISTS (SELECT 1 FROM D.S.B b WHERE b.ID=ID)',
     'SELECT a.NAME FROM D.S.A a WHERE EXISTS (SELECT 1 FROM D.S.B b WHERE b.ID=a.ID)', False),
])
def test_publication_alias_matching_preserves_cte_self_join_and_column_alias_ownership(before, after, equal):
    from app.core.mapping_sql import MappingSqlService
    assert (MappingSqlService._artifact_tree(before) == MappingSqlService._artifact_tree(after)) is equal


@pytest.mark.parametrize("change_owner", [False, True])
def test_actual_publication_cte_self_join_accepts_renames_not_changed_output_owner(change_owner):
    from app.core.exceptions import AppValidationError
    service, _, snapshot = publication_fixture()
    snapshot["relation_graph"]["nodes"] = [{"relation_id": "cte", "kind": "CTE", "alias": "c",
        "sql_text": "WITH base AS (SELECT a.NAME FROM D.S.A a) SELECT lhs.NAME FROM base lhs JOIN base rhs ON lhs.NAME=rhs.NAME",
        "output_columns": [{"name": "NAME"}]}]
    snapshot["mapping_rows"][0]["source_columns"] = ["c.NAME"]
    compile_publication_snapshot(snapshot)
    for field in ("mapping_sql", "mapping_preview_sql"):
        snapshot[field] = snapshot[field].replace("base", "renamed_base").replace("lhs", "renamed_left").replace("rhs", "renamed_right")
        if change_owner:
            snapshot[field] = snapshot[field].replace("SELECT renamed_left.NAME", "SELECT renamed_right.NAME")
    if change_owner:
        with pytest.raises(AppValidationError, match="does not match"):
            service.publish_sttm("42", STTMPublishRequest(workspace_snapshot=snapshot), user_id="u")
        service.autosave_sttm.assert_not_called()
    else:
        service.publish_sttm("42", STTMPublishRequest(workspace_snapshot=snapshot), user_id="u")


def test_actual_publication_selected_cte_parent_lineage_is_not_an_outer_table_selection():
    service, _, snapshot = publication_fixture()
    parent = {"relation_id": "parent", "kind": "CTE", "alias": "p",
              "sql_text": "SELECT NAME FROM INTERNAL.S.BASE", "output_columns": [{"name": "NAME"}]}
    child = {"relation_id": "child", "kind": "CTE", "alias": "c", "parent_relation_ids": ["parent"],
             "sql_text": "SELECT NAME FROM p", "output_columns": [{"name": "NAME"}]}
    snapshot["relation_graph"]["nodes"] = [parent, child]
    snapshot["driving_relation_id"] = "child"
    snapshot["mapping_rows"][0]["source_columns"] = ["c.NAME"]
    snapshot["derived_sources"] = [
        {"id": "parent", "is_selected": False, "sql_text": parent["sql_text"],
         "base_source_tables": [{"database": "INTERNAL", "schema": "S", "table": "BASE"}]},
        {"id": "child", "is_selected": True, "sql_text": child["sql_text"], "parent_derived_source_ids": ["parent"]},
    ]
    compile_publication_snapshot(snapshot)
    service.publish_sttm("42", STTMPublishRequest(workspace_snapshot=snapshot), user_id="u")


def test_actual_publication_optimization_requires_synchronized_row_definitions():
    from app.core.exceptions import AppValidationError
    service, _, snapshot = publication_fixture()
    snapshot["mapping_rows"][0].update(expression="COALESCE(a.NAME, a.NAME)", rule="Custom")
    # EXPLAIN success/client flags cannot stand in for the missing synchronization.
    snapshot["compiled_mapping_ready"] = True
    with pytest.raises(AppValidationError, match="synchronize"):
        service.publish_sttm("42", STTMPublishRequest(workspace_snapshot=snapshot), user_id="u")
    service.autosave_sttm.assert_not_called()
    from app.core.mapping_sql import MappingSqlService
    from app.schema.mapping_sql import MappingSqlParseRequest
    parsed = MappingSqlService(session=service._session, analyst_client=None).parse(MappingSqlParseRequest(
        sql=snapshot["mapping_preview_sql"], known_tables=snapshot["source_tables"],
        current_workspace={"target_table": "D.S.T"}))
    assert parsed.valid
    snapshot["mapping_rows"] = [{**parsed.parsed_workspace["mapping_rows"][0], "id": "name", "target_type": "VARCHAR"}]
    compile_publication_snapshot(snapshot)
    service.publish_sttm("42", STTMPublishRequest(workspace_snapshot=snapshot), user_id="u")


def test_publication_cannot_silently_lose_missing_referenced_evidence():
    service, _ = service_fixture()
    service._settings.snowflake_agent_artifacts_table = "ARTIFACTS"
    with pytest.raises(SnowflakeQueryError, match="evidence is not yet available"):
        service._publication_provenance("42", {"mapping_rows": [{"agent_artifact_id": "missing"}]})

@pytest.mark.parametrize('artifact', ['insert','select'])
def test_metadata_only_publication_succeeds_when_target_dml_is_forbidden(artifact):
    service,statements,snapshot=publication_fixture()
    if artifact=='select':snapshot['mapping_sql']=snapshot['mapping_preview_sql']
    execute=service._session.sql
    def read_only_data_tables(sql,params=None):
        if 'INSERT INTO D.S.T' in sql or 'UPDATE D.S.T' in sql or 'DELETE FROM D.S.T' in sql:
            raise PermissionError('No target DML permission')
        return execute(sql,params)
    service._session.sql=read_only_data_tables
    result=service.publish_sttm('42',STTMPublishRequest(workspace_snapshot=snapshot),user_id='u')
    assert result.status=='COMPLETE'
    assert service._async_jobs.enqueue.call_args.kwargs['payload']['snapshot']['_publication_validation']['validation_kind']=='read_only_definition'
    assert any(sql=='COMMIT' for sql,_ in statements)
    assert not any('EXPLAIN USING TEXT INSERT' in sql for sql,_ in statements)


def test_source_permission_error_is_specific_and_excludes_native_sql_text():
    from snowflake.connector.errors import ProgrammingError
    from app.core.exceptions import AuthorizationError
    service,statements,snapshot=publication_fixture()
    original=service._session.sql
    def execute(sql,params=None):
        if sql.startswith('EXPLAIN'):
            raise ProgrammingError(msg='private SQL/bindings must not reach UI',errno=3001,sqlstate='42501',sfqid='safe-query-id')
        return original(sql,params)
    service._session.sql=execute
    with pytest.raises(AuthorizationError) as error:
        service.publish_sttm('42',STTMPublishRequest(workspace_snapshot=snapshot),user_id='u')
    assert 'cannot read' in str(error.value) and 'safe-query-id' in str(error.value)
    assert 'private SQL' not in str(error.value)
    service.autosave_sttm.assert_not_called()
