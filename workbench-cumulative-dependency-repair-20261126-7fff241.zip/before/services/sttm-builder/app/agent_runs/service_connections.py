"""Recover only worker-owned Snowflake sessions, never delegated credentials.

The facade deliberately supports the SQL/collect and stage-stream operations
used by the worker stores. No arbitrary method forwarding or mutation retry is
allowed. Repositories retain this facade, not a discarded raw Snowpark session.
"""
from __future__ import annotations

import logging
import re
import threading
import time
from types import SimpleNamespace
from typing import Any, Callable

logger = logging.getLogger(__name__)


def exception_chain(error: BaseException):
    pending, seen = [error], set()
    while pending:
        current = pending.pop(0)
        if id(current) in seen:
            continue
        seen.add(id(current))
        yield current
        pending.extend(item for item in (current.__cause__, current.__context__) if item is not None)


def sql_diagnostics(error: BaseException) -> dict[str, str]:
    result: dict[str, str] = {}
    for item in exception_chain(error):
        for field, names in (
            ('native_code', ('sql_error_code', 'errno')),
            ('wrapper_code', ('error_code',)),
            ('sql_state', ('sqlstate', 'sql_state')),
            ('query_id', ('sfqid', 'query_id')),
        ):
            for name in names:
                value = str(getattr(item, name, '') or '')
                if value and re.fullmatch(r'[a-zA-Z0-9_-]{1,80}', value):
                    # Prefer native expiry over an intermediate wrapper's code.
                    if field not in result or (field == 'native_code' and value == '390114'):
                        result[field] = value
                    break
    if session_expired(error):
        result['native_code'] = '390114'
    return result


def session_expired(error: BaseException) -> bool:
    return any(
        str(getattr(item, 'sql_error_code', '') or getattr(item, 'errno', '')) == '390114'
        or bool(re.search(r'\b390114\b', str(item)))
        or 'authentication token has expired' in str(item).casefold()
        for item in exception_chain(error)
    )


class ServiceConnectionError(RuntimeError):
    error_code = 'service_connection_unavailable'

    def __init__(self, purpose: str, operation: str, *, uncertain: bool = False,
                 diagnostics: dict[str, str] | None = None):
        self.purpose, self.operation, self.uncertain = purpose, operation, uncertain
        self.diagnostics = dict(diagnostics or {})
        if uncertain:
            self.error_code = 'service_connection_uncertain'
        super().__init__('Deep lost its internal Snowflake connection. Saved drafts and checkpoints are retained.'
                         + (' The interrupted operation needs reconciliation before continuation.' if uncertain else ''))


class _Statement:
    def __init__(self, owner, query, params, kwargs):
        self.owner, self.query, self.params, self.kwargs = owner, query, params, kwargs

    def collect(self, **kwargs):
        # These are host-authored store queries, never user-supplied SQL.
        read = bool(re.match(r'^\s*SELECT\b', self.query, re.I)) and not re.search(r'\bFOR\s+UPDATE\b', self.query, re.I)
        return self.owner.execute(
            lambda session: session.sql(self.query, self.params, **self.kwargs).collect(**kwargs),
            operation='read' if read else 'write', read_only=read,
            transaction_command=self.query.strip().upper(),
        )


class ServiceConnection:
    def __init__(self, factory: Callable[[], Any], purpose: str, *,
                 timeout_seconds: float = 30, sleep: Callable[[float], None] = time.sleep):
        self._factory, self.purpose, self._sleep = factory, purpose, sleep
        self._timeout = max(1.0, float(timeout_seconds))
        self._lock = threading.RLock()
        self._client = None
        self._closed = False
        self._transaction = False
        self._failed: ServiceConnectionError | None = None
        self._lease_check: Callable[[], None] | None = None
        self.run_id: str | None = None
        self.file = SimpleNamespace(get_stream=self._get_stream, put_stream=self._put_stream)

    @property
    def session(self):
        return self

    def sql(self, query, params=None, **kwargs):
        return _Statement(self, query, params, kwargs)

    def set_lease_check(self, check: Callable[[], None] | None, run_id: str | None = None):
        with self._lock:
            self._lease_check, self.run_id = check, run_id

    def _discard(self):
        client, self._client = self._client, None
        if client is not None:
            try:
                client.close()
            except Exception:
                logger.warning('Deep service connection close failed purpose=%s run_id=%s', self.purpose, self.run_id)

    def _connect(self):
        deadline = time.monotonic() + self._timeout
        for attempt, delay in enumerate((1, 2, 4), 1):
            try:
                self._client = self._factory()
                self._transaction = False
                logger.info('Deep service connection ready purpose=%s run_id=%s attempt=%s', self.purpose, self.run_id, attempt)
                return
            except Exception as error:
                # Permissions/configuration errors are not reconnect loops.
                if not session_expired(error) and not isinstance(error, (TimeoutError, ConnectionError)):
                    raise
                logger.warning('Deep service connection recovery failed purpose=%s run_id=%s attempt=%s diagnostics=%s',
                               self.purpose, self.run_id, attempt, sql_diagnostics(error))
                if attempt == 3 or time.monotonic() + delay >= deadline:
                    raise ServiceConnectionError(self.purpose, 'connect', diagnostics=sql_diagnostics(error)) from error
                self._sleep(delay)

    def recover(self):
        """Called only at a quiescent boundary; never replays an operation."""
        with self._lock:
            if self._closed:
                raise ServiceConnectionError(self.purpose, 'connect')
            self._discard()
            self._connect()
            self._failed = None

    def execute(self, operation_fn, *, operation: str, read_only: bool = False, transaction_command: str = ''):
        with self._lock:
            if self._closed:
                raise ServiceConnectionError(self.purpose, operation)
            if self._failed is not None:
                raise self._failed
            if self._client is None:
                self._connect()
            for attempt in range(2):
                try:
                    result = operation_fn(self._client.session)
                    if transaction_command == 'BEGIN':
                        self._transaction = True
                    elif transaction_command in {'COMMIT', 'ROLLBACK'}:
                        self._transaction = False
                    return result
                except Exception as error:
                    if not session_expired(error):
                        raise
                    diagnostic = sql_diagnostics(error)
                    uncertain = not read_only or self._transaction
                    self._failed = ServiceConnectionError(self.purpose, operation, uncertain=uncertain, diagnostics=diagnostic)
                    logger.warning('Deep service connection expired purpose=%s run_id=%s operation=%s diagnostics=%s',
                                   self.purpose, self.run_id, operation, diagnostic)
                    if uncertain or attempt:
                        raise self._failed from error
                    self.recover()
                    if self._lease_check is not None:
                        self._lease_check()
                    logger.info('Deep service read recovery purpose=%s run_id=%s lease_validated=%s',
                                self.purpose, self.run_id, self._lease_check is not None)

    def _get_stream(self, *args, **kwargs):
        return self.execute(lambda session: session.file.get_stream(*args, **kwargs), operation='stage_read', read_only=True)

    def _put_stream(self, *args, **kwargs):
        return self.execute(lambda session: session.file.put_stream(*args, **kwargs), operation='stage_write')

    def close(self):
        # Wait for the current operation. Never close a session in use.
        with self._lock:
            self._closed = True
            self._discard()
