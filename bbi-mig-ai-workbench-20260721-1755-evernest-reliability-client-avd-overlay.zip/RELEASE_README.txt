EverNest Mapping Intelligence and Reliability client AVD overlay
Release: 20260721-1755

Baseline
--------
This overlay was content-compared against:
1. bbi-mig-ai-workbench-20260717-1730-complete-source.zip
2. bbi-mig-ai-workbench-20260717-1959-final-client-hotfix.zip

Apply
-----
1. Extract this ZIP over the client source tree that already contains the baseline above.
2. Keep the client's existing Dockerfiles and environment files. This package intentionally
   contains no Dockerfile, .dockerignore, docker-compose file, .env file, or env directory.
3. Verify agent specifications before deployment:
     python scripts/verify_mapping_agent_specs.py
4. Apply the changed Snowflake DDL through the client's normal reviewed deployment process.
5. Rebuild and redeploy the web application and STTM Builder/Auto-map services.

Snowflake and agent assets included
-----------------------------------
- AGT_SOURCE_MAPPING specification and manifest hash.
- AGT_TRANSFORMATION_RULE specification and manifest hash.
- AGT_STTM_BUILDER specification and manifest hash.
- TBL_AUTO_MAP_JOBS durable-job migration and cumulative table DDL.
- FIR agent-recommendation table DDL.
- SP_FIR_GET_AGENT_RECOMMENDATIONS procedure DDL.
- SP_FIR_MATERIALIZE_DERIVED_SOURCE procedure DDL.
- EverNest import/reliability DDL.
- Updated FIR deployment/bootstrap scripts, including protection against
  Snowflake "Empty SQL statement" failures from trailing comment-only SQL.

AGT_SEMANTIC_MODEL_V2 was not changed, regenerated, or included.

Packaging exclusions
--------------------
- Docker and environment files.
- Build output, caches, virtual environments, node_modules, logs, and bytecode.
- Release history and documentation not required at runtime.
- Developer-only STTM debug pages.

Integrity
---------
MANIFEST.sha256 contains the SHA-256 checksum for every packaged payload file except itself.
Extracting this archive does not delete existing client files; it only adds or replaces the
listed overlay files.
