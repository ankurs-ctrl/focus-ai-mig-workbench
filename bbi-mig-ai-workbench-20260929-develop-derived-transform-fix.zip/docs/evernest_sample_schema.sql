-- Sample source/master/target objects for the EverNest-style migration test.
-- Safe to rerun: schemas and tables are created only when absent.

SET CORE_DB = 'FFP_HDP_CRM_MIG_DB_DEV';
SET DATA_SCHEMA = 'SCH_REDTAIL_EVERNEST_06_23_2026';
SET MASTER_SCHEMA = 'SCH_REDTAIL_EVERNEST_MASTER';
SET TARGET_SCHEMA = 'SCH_REDTAIL_EVERNEST_TARGET';

USE DATABASE IDENTIFIER($CORE_DB);
CREATE SCHEMA IF NOT EXISTS IDENTIFIER($DATA_SCHEMA);
CREATE SCHEMA IF NOT EXISTS IDENTIFIER($MASTER_SCHEMA);
CREATE SCHEMA IF NOT EXISTS IDENTIFIER($TARGET_SCHEMA);

USE SCHEMA IDENTIFIER($DATA_SCHEMA);

CREATE TABLE IF NOT EXISTS CONTACTS (
  id NUMBER, type VARCHAR, first_name VARCHAR, last_name VARCHAR, company_name VARCHAR,
  status_id NUMBER, servicing_advisor_id NUMBER, writing_advisor_id NUMBER,
  category_id NUMBER, next_review_at TIMESTAMP_NTZ, last_review_at TIMESTAMP_NTZ,
  created_at TIMESTAMP_NTZ, deleted NUMBER DEFAULT 0
);
ALTER TABLE CONTACTS ADD COLUMN IF NOT EXISTS SALESFORCE_ID VARCHAR;
ALTER TABLE CONTACTS ADD COLUMN IF NOT EXISTS SOURCE_OF_BUSINESS VARCHAR;
ALTER TABLE CONTACTS ADD COLUMN IF NOT EXISTS LEGACY_HH_ID VARCHAR;
ALTER TABLE CONTACTS ADD COLUMN IF NOT EXISTS REFERRED_BY VARCHAR;
ALTER TABLE CONTACTS ADD COLUMN IF NOT EXISTS CLIENT_SINCE DATE;
ALTER TABLE CONTACTS ADD COLUMN IF NOT EXISTS DOB DATE;
CREATE TABLE IF NOT EXISTS ADDRESSES (
  addressable_id NUMBER, street_address VARCHAR, secondary_address VARCHAR, city VARCHAR,
  state VARCHAR, zip VARCHAR, country VARCHAR, is_primary NUMBER DEFAULT 0, deleted NUMBER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS CONTACT_STATUSES (
  id NUMBER, name VARCHAR
);
CREATE TABLE IF NOT EXISTS CONTACT_FAMILY_MEMBERS (
  id NUMBER, contact_id NUMBER, family_id NUMBER, relationship NUMBER, deleted NUMBER DEFAULT 0
);
ALTER TABLE CONTACT_FAMILY_MEMBERS ADD COLUMN IF NOT EXISTS ID NUMBER;
ALTER TABLE CONTACT_FAMILY_MEMBERS ADD COLUMN IF NOT EXISTS HOH NUMBER DEFAULT 0;
CREATE TABLE IF NOT EXISTS CONTACT_FAMILIES (
  id NUMBER, name VARCHAR, hoh NUMBER DEFAULT 0, deleted NUMBER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS CONTACT_UDFS (
  contact_id NUMBER, contact_udf_field_id NUMBER, field_value VARCHAR, created_at TIMESTAMP_NTZ,
  deleted NUMBER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS CONTACT_UDF_FIELDS (
  id NUMBER, name VARCHAR
);
CREATE TABLE IF NOT EXISTS SERVICING_ADVISORS (
  id NUMBER, name VARCHAR
);
CREATE TABLE IF NOT EXISTS WRITING_ADVISORS (
  id NUMBER, name VARCHAR
);
CREATE TABLE IF NOT EXISTS CONTACT_CATEGORIES (
  id NUMBER, name VARCHAR
);
CREATE TABLE IF NOT EXISTS COUNTRY_CODES (
  country_alias VARCHAR, country_code VARCHAR
);
CREATE TABLE IF NOT EXISTS STATE_CODES (
  state_alias VARCHAR, state_code VARCHAR
);

USE SCHEMA IDENTIFIER($MASTER_SCHEMA);
CREATE TABLE IF NOT EXISTS MAPPER_USER (
  user_id NUMBER, writing_advisor_id NUMBER, name VARCHAR
);
ALTER TABLE MAPPER_USER ADD COLUMN IF NOT EXISTS ID NUMBER;
ALTER TABLE MAPPER_USER ADD COLUMN IF NOT EXISTS FIRST_NAME VARCHAR;
ALTER TABLE MAPPER_USER ADD COLUMN IF NOT EXISTS LAST_NAME VARCHAR;
CREATE TABLE IF NOT EXISTS MAPPER_CONTACT_MASTER (
  contact_id NUMBER, target_crm_id VARCHAR, legacy_crm_id VARCHAR
);
CREATE TABLE IF NOT EXISTS MAPPER_HH_MASTER (
  legacy_hh_id VARCHAR, target_crm_legacy_id VARCHAR, target_crm_legacy_portfolio_account_id VARCHAR
);
ALTER TABLE MAPPER_HH_MASTER ADD COLUMN IF NOT EXISTS TARGETCRMID VARCHAR;
CREATE TABLE IF NOT EXISTS MAPPER_OPPORTUNITY_MASTER (
  legacy_opportunity_id VARCHAR, target_crm_id VARCHAR
);
CREATE TABLE IF NOT EXISTS MAPPER_ACR_MASTER (
  legacy_acr_id VARCHAR, target_crm_id VARCHAR
);
CREATE TABLE IF NOT EXISTS MAPPER_BIZ_ACCOUNT (
  legacy_account_id VARCHAR, target_crm_id VARCHAR
);
CREATE TABLE IF NOT EXISTS MAPPER_LEAD_MASTER (
  legacy_lead_id VARCHAR, target_crm_id VARCHAR
);
CREATE TABLE IF NOT EXISTS MAPPER_REFERRAL_MASTER (
  source_of_business VARCHAR, referral_source_id VARCHAR,
  referral_source__c VARCHAR, legacy_id__c VARCHAR
);
ALTER TABLE MAPPER_REFERRAL_MASTER ADD COLUMN IF NOT EXISTS REFERRAL_SOURCE__C VARCHAR;
ALTER TABLE MAPPER_REFERRAL_MASTER ADD COLUMN IF NOT EXISTS LEGACY_ID__C VARCHAR;

USE SCHEMA IDENTIFIER($TARGET_SCHEMA);
CREATE TABLE IF NOT EXISTS EVERNEST_HH (
  TRANSACTION_FIRM__C VARCHAR, PARENTID VARCHAR, LEGACY_ID__C VARCHAR,
  BFFS_CLIENTSTARTDATE__C DATE, OWNERID VARCHAR, XXXOWNERNAME VARCHAR,
  RECORDTYPEID VARCHAR, HOUSEHOLD_TYPE__C VARCHAR, FINSERV_STATUS__C VARCHAR,
  MASTER_PAYOUT_DATE__C DATE, SOURCEOFBUSINESS__C VARCHAR,
  BILLINGSTREET VARCHAR, BILLINGCITY VARCHAR, BILLINGSTATE VARCHAR,
  BILLINGPOSTALCODE VARCHAR, BILLINGCOUNTRY VARCHAR, REFERRAL__C VARCHAR,
  LEGACY_FIRM_INFO__C VARCHAR, MAIL_MERGE_FIRST_AND_LAST__C VARCHAR,
  MAIL_MERGE_LAST_ONLY__C VARCHAR, IS_RPC_CLIENT__C VARCHAR,
  FINSERV_REVIEW_FREQUENCY__C VARCHAR, BFFS_LEGACYSTARTDATE__C DATE,
  LEGACYPORTFOLIOSYSTEMHHID__C VARCHAR, SOURCE_HOUSEHOLD_ID VARCHAR,
  INCLUDED_IN_HOUSEHOLD VARCHAR
);

-- Minimal deterministic fixture. MERGE keeps reruns idempotent.
USE SCHEMA IDENTIFIER($DATA_SCHEMA);
MERGE INTO CONTACT_STATUSES t
USING (SELECT column1 AS id, column2 AS name FROM VALUES
  (1, 'Client'), (2, 'Deceased'), (3, 'Inactive - Former Client')) s ON t.id = s.id
WHEN NOT MATCHED THEN INSERT (id, name) VALUES (s.id, s.name);
MERGE INTO CONTACT_UDF_FIELDS t
USING (SELECT column1 AS id, column2 AS name FROM VALUES
  (8, 'Drinks'), (10, 'Pet Name'), (12, 'Preferred Contact Method'),
  (13, 'Contact Made Aware of Focus'),
  (14, 'All Tax IDs Have Client Contact Record'), (15, 'SIGNED Advisory Agreement'),
  (16, 'Focus Language Investment Agreement')) s ON t.id = s.id
WHEN NOT MATCHED THEN INSERT (id, name) VALUES (s.id, s.name);
MERGE INTO CONTACT_FAMILIES t
USING (SELECT column1 AS id, column2 AS name, column3 AS hoh, column4 AS deleted FROM VALUES
  (100, 'Doe Household', 1, 0), (200, 'Northwind Business Household', 1, 0)) s ON t.id = s.id
WHEN NOT MATCHED THEN INSERT (id, name, hoh, deleted) VALUES (s.id, s.name, s.hoh, s.deleted);
MERGE INTO CONTACTS t
USING (
  SELECT column1 AS id, column2 AS type, column3 AS first_name, column4 AS last_name,
         column5 AS company_name, column6 AS status_id, column7 AS servicing_advisor_id,
         column8 AS writing_advisor_id, column9 AS category_id, column10 AS salesforce_id,
         column11 AS source_of_business, column12 AS legacy_hh_id, column13 AS referred_by,
         TO_DATE(column14) AS client_since, TO_DATE(column15) AS dob, column16 AS deleted
  FROM VALUES
    (1001, 'Crm::Contact::Individual', 'Jane', 'Doe', NULL, 1, 10, 20, 101,
     '003SAMPLEJANE', 'Client Referral', 'LEGACY-HH-100', 'Existing Client', '2019-04-15', '1978-02-10', 0),
    (1002, 'Crm::Contact::Individual', 'John', 'Doe', NULL, 1, 10, 20, 102,
     '003SAMPLEJOHN', 'Client Referral', 'LEGACY-HH-100', 'Jane Doe', '2019-04-15', '1977-11-20', 0),
    (2001, 'Crm::Contact::Business', NULL, NULL, 'Northwind Advisory LLC', 1, 11, 21, 103,
     '001SAMPLENORTH', 'Networking', 'LEGACY-HH-200', 'Industry Event', '2021-01-08', '1990-01-01', 0),
    (3001, 'Crm::Contact::Individual', 'Former', 'Client', NULL, 3, 10, 20, 104,
     '003SAMPLEOLD', 'COI Referral', 'LEGACY-HH-300', 'CPA Partner', '2015-06-01', '1965-05-21', 0)
) s ON t.id = s.id
WHEN MATCHED THEN UPDATE SET
  type=s.type, first_name=s.first_name, last_name=s.last_name, company_name=s.company_name,
  status_id=s.status_id, servicing_advisor_id=s.servicing_advisor_id,
  writing_advisor_id=s.writing_advisor_id, category_id=s.category_id,
  salesforce_id=s.salesforce_id, source_of_business=s.source_of_business,
  legacy_hh_id=s.legacy_hh_id, referred_by=s.referred_by, client_since=s.client_since,
  dob=s.dob, deleted=s.deleted
WHEN NOT MATCHED THEN INSERT (
  id, type, first_name, last_name, company_name, status_id, servicing_advisor_id,
  writing_advisor_id, category_id, next_review_at, last_review_at, created_at, deleted,
  salesforce_id, source_of_business, legacy_hh_id, referred_by, client_since, dob
) VALUES (
  s.id, s.type, s.first_name, s.last_name, s.company_name, s.status_id,
  s.servicing_advisor_id, s.writing_advisor_id, s.category_id,
  DATEADD(month, 3, CURRENT_TIMESTAMP()), CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP(), s.deleted,
  s.salesforce_id, s.source_of_business, s.legacy_hh_id, s.referred_by, s.client_since, s.dob
);

MERGE INTO CONTACT_FAMILY_MEMBERS t
USING (SELECT column1 AS id, column2 AS contact_id, column3 AS family_id,
              column4 AS relationship, column5 AS hoh, column6 AS deleted FROM VALUES
  (1, 1001, 100, 0, 1, 0), (2, 1002, 100, 1, 0, 0), (3, 2001, 200, 0, 1, 0)) s
ON t.id = s.id
WHEN MATCHED THEN UPDATE SET contact_id=s.contact_id, family_id=s.family_id,
  relationship=s.relationship, hoh=s.hoh, deleted=s.deleted
WHEN NOT MATCHED THEN INSERT (id, contact_id, family_id, relationship, hoh, deleted)
VALUES (s.id, s.contact_id, s.family_id, s.relationship, s.hoh, s.deleted);

MERGE INTO ADDRESSES t
USING (SELECT column1 AS addressable_id, column2 AS street_address,
  column3 AS secondary_address, column4 AS city, column5 AS state, column6 AS zip,
  column7 AS country, column8 AS is_primary, column9 AS deleted FROM VALUES
  (1001, '100 Main Street', 'Suite 200', 'Denver', 'CO', '80202', 'US', 1, 0),
  (1002, '100 Main Street', 'Suite 200', 'Denver', 'Colorado', '80202', 'United States', 1, 0),
  (2001, '500 Market Avenue', NULL, 'Chicago', 'IL', '60601', 'USA', 1, 0)) s
ON t.addressable_id=s.addressable_id AND t.is_primary=1
WHEN MATCHED THEN UPDATE SET street_address=s.street_address,
  secondary_address=s.secondary_address, city=s.city, state=s.state, zip=s.zip,
  country=s.country, deleted=s.deleted
WHEN NOT MATCHED THEN INSERT (addressable_id, street_address, secondary_address, city,
  state, zip, country, is_primary, deleted)
VALUES (s.addressable_id, s.street_address, s.secondary_address, s.city, s.state,
  s.zip, s.country, s.is_primary, s.deleted);

MERGE INTO SERVICING_ADVISORS t
USING (SELECT column1 AS id, column2 AS name FROM VALUES
  (10, 'Alex Morgan'), (11, 'Priya Shah')) s ON t.id=s.id
WHEN NOT MATCHED THEN INSERT (id, name) VALUES (s.id, s.name);
MERGE INTO WRITING_ADVISORS t
USING (SELECT column1 AS id, column2 AS name FROM VALUES
  (20, 'Niki Woodworth'), (21, 'Frank Esposito')) s ON t.id=s.id
WHEN NOT MATCHED THEN INSERT (id, name) VALUES (s.id, s.name);
MERGE INTO CONTACT_CATEGORIES t
USING (SELECT column1 AS id, column2 AS name FROM VALUES
  (101, 'Client - 1 Meetings'), (102, 'Client - 2 Meetings'),
  (103, 'Client - 4 Meetings'), (104, 'Inactive - Former Client')) s ON t.id=s.id
WHEN NOT MATCHED THEN INSERT (id, name) VALUES (s.id, s.name);
MERGE INTO COUNTRY_CODES t
USING (SELECT column1 AS country_alias, column2 AS country_code FROM VALUES
  ('United States', 'US'), ('USA', 'US')) s ON UPPER(t.country_alias)=UPPER(s.country_alias)
WHEN NOT MATCHED THEN INSERT (country_alias, country_code) VALUES (s.country_alias, s.country_code);
MERGE INTO STATE_CODES t
USING (SELECT column1 AS state_alias, column2 AS state_code FROM VALUES
  ('Colorado', 'CO'), ('Illinois', 'IL')) s ON UPPER(t.state_alias)=UPPER(s.state_alias)
WHEN NOT MATCHED THEN INSERT (state_alias, state_code) VALUES (s.state_alias, s.state_code);

MERGE INTO CONTACT_UDFS t
USING (
  SELECT column1 AS contact_id, column2 AS contact_udf_field_id, column3 AS field_value,
         TO_TIMESTAMP_NTZ(column4) AS created_at, column5 AS deleted
  FROM VALUES
    (1001, 12, 'Email', '2026-01-01 09:00:00', 0),
    (1001, 8, 'Coffee', '2026-01-01 09:01:00', 0),
    (1001, 10, 'Milo', '2026-01-01 09:02:00', 0),
    (1001, 13, 'Yes', '2026-01-01 09:03:00', 0),
    (1001, 14, 'Yes', '2026-01-01 09:04:00', 0),
    (1001, 15, 'Signed', '2026-01-01 09:05:00', 0),
    (1001, 16, 'Accepted', '2026-01-01 09:06:00', 0),
    (2001, 12, 'Phone', '2026-01-02 09:00:00', 0)
) s ON t.contact_id=s.contact_id
     AND t.contact_udf_field_id=s.contact_udf_field_id
     AND t.created_at=s.created_at
WHEN NOT MATCHED THEN INSERT (contact_id, contact_udf_field_id, field_value, created_at, deleted)
VALUES (s.contact_id, s.contact_udf_field_id, s.field_value, s.created_at, s.deleted);
USE SCHEMA IDENTIFIER($MASTER_SCHEMA);
MERGE INTO MAPPER_USER t
USING (SELECT column1 AS id, column2 AS user_id, column3 AS writing_advisor_id,
  column4 AS first_name, column5 AS last_name, column6 AS name FROM VALUES
  (20, 20, 20, 'Niki', 'Woodworth', 'Niki Woodworth'),
  (21, 21, 21, 'Frank', 'Esposito', 'Frank Esposito')) s ON t.id=s.id
WHEN MATCHED THEN UPDATE SET user_id=s.user_id, writing_advisor_id=s.writing_advisor_id,
  first_name=s.first_name, last_name=s.last_name, name=s.name
WHEN NOT MATCHED THEN INSERT (id, user_id, writing_advisor_id, first_name, last_name, name)
VALUES (s.id, s.user_id, s.writing_advisor_id, s.first_name, s.last_name, s.name);
MERGE INTO MAPPER_HH_MASTER t
USING (SELECT 'EVR_RT_HH_100' AS legacy_hh_id, 'HH-100' AS target_crm_legacy_id,
              'PORT-100' AS target_crm_legacy_portfolio_account_id,
              'EVR_RT_HH-1001' AS targetcrmid) s
ON t.legacy_hh_id = s.legacy_hh_id
WHEN MATCHED THEN UPDATE SET target_crm_legacy_id=s.target_crm_legacy_id,
  target_crm_legacy_portfolio_account_id=s.target_crm_legacy_portfolio_account_id,
  targetcrmid=s.targetcrmid
WHEN NOT MATCHED THEN INSERT (legacy_hh_id, target_crm_legacy_id,
  target_crm_legacy_portfolio_account_id, targetcrmid)
VALUES (s.legacy_hh_id, s.target_crm_legacy_id,
  s.target_crm_legacy_portfolio_account_id, s.targetcrmid);
MERGE INTO MAPPER_REFERRAL_MASTER t
USING (SELECT column1 AS source_of_business, column2 AS referral_source_id,
  column3 AS referral_source__c, column4 AS legacy_id__c FROM VALUES
  ('Client Referral', 'REF-CLIENT', 'Client Referral', 'LEGACY-REF-CLIENT'),
  ('Networking', 'REF-NETWORK', 'Networking', 'LEGACY-REF-NETWORK')) s
ON UPPER(t.source_of_business)=UPPER(s.source_of_business)
WHEN MATCHED THEN UPDATE SET referral_source_id=s.referral_source_id,
  referral_source__c=s.referral_source__c, legacy_id__c=s.legacy_id__c
WHEN NOT MATCHED THEN INSERT (source_of_business, referral_source_id,
  referral_source__c, legacy_id__c)
VALUES (s.source_of_business, s.referral_source_id, s.referral_source__c, s.legacy_id__c);
