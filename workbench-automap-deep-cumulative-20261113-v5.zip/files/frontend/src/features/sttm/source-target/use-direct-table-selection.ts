"use client";

import { useCallback, useMemo } from "react";
import { useAppDispatch } from "@/store/hooks";
import { useSttmBuilderContext } from "@/features/sttm/context/sttm-builder-context";
import { fetchTables } from "@/features/sttm/store/sttm-builder-slice";
import { sqlIdentifierKey } from "@/features/sttm/shared/sql-identifiers";
import {
  resolveSelectedSourceTables,
  resolveSelectedTargetTable,
} from "@/features/sttm/shared/sttm-selection-utils";
import type { SchemaNode, SelectionSide, TableNode } from "@/features/sttm/types/sttm.types";

export type SchemaCheckState = "none" | "some" | "all";

/**
 * Adds and removes workspace tables without drag and drop. Dropping on the
 * Source/Target panels and the explorer checkboxes both go through here, so the
 * two ways of selecting behave the same.
 */
export function useDirectTableSelection() {
  const dispatch = useAppDispatch();
  const { fullData, sources, targets, toggleSource, selectTarget, clearTargets } =
    useSttmBuilderContext();

  const selectedSourceKeys = useMemo(() => {
    const keys = new Set<string>();
    for (const table of resolveSelectedSourceTables({
      sourceDatabases: fullData?.sources ?? [],
      sources,
    })) {
      keys.add(table.tableId);
      keys.add(sqlIdentifierKey(table.qualifiedName));
    }
    return keys;
  }, [fullData, sources]);

  const selectedTarget = useMemo(
    () => resolveSelectedTargetTable({ targetDatabases: fullData?.targets ?? [], targets }),
    [fullData, targets],
  );

  const isSelected = useCallback(
    (side: SelectionSide, table: Pick<TableNode, "tableId" | "qualifiedName">) => {
      if (side === "source") {
        return selectedSourceKeys.has(table.tableId)
          || selectedSourceKeys.has(sqlIdentifierKey(table.qualifiedName));
      }
      return Boolean(selectedTarget)
        && (selectedTarget?.tableId === table.tableId
          || sqlIdentifierKey(selectedTarget?.qualifiedName ?? "") === sqlIdentifierKey(table.qualifiedName));
    },
    [selectedSourceKeys, selectedTarget],
  );

  /** Adds source tables that are not already in the workspace. */
  const addSources = useCallback(
    (tableIds: string[]) => {
      for (const tableId of new Set(tableIds)) {
        if (!selectedSourceKeys.has(tableId) && !selectedSourceKeys.has(sqlIdentifierKey(tableId))) {
          toggleSource(tableId);
        }
      }
    },
    [selectedSourceKeys, toggleSource],
  );

  const removeSources = useCallback(
    (tableIds: string[]) => {
      for (const tableId of new Set(tableIds)) {
        if (selectedSourceKeys.has(tableId) || selectedSourceKeys.has(sqlIdentifierKey(tableId))) {
          toggleSource(tableId);
        }
      }
    },
    [selectedSourceKeys, toggleSource],
  );

  /** Checkbox on a table row: sources add/remove; the target holds one table, so it replaces or clears. */
  const toggleTable = useCallback(
    (side: SelectionSide, table: Pick<TableNode, "tableId" | "qualifiedName">) => {
      const selected = isSelected(side, table);
      if (side === "source") {
        if (selected) removeSources([table.tableId]);
        else addSources([table.tableId]);
        return;
      }
      if (selected) clearTargets();
      else selectTarget(table.tableId);
    },
    [addSources, clearTargets, isSelected, removeSources, selectTarget],
  );

  const schemaCheckState = useCallback(
    (side: SelectionSide, schema: SchemaNode): SchemaCheckState => {
      if (!schema.tables.length) return "none";
      const count = schema.tables.filter((table) => isSelected(side, table)).length;
      if (count === 0) return "none";
      return count === schema.tables.length ? "all" : "some";
    },
    [isSelected],
  );

  /** Checkbox on a source schema row: loads its tables if needed, then adds all (or removes all when all are in). */
  const toggleSchema = useCallback(
    async (dbId: string, schema: SchemaNode) => {
      if (schemaCheckState("source", schema) === "all") {
        removeSources(schema.tables.map((table) => table.tableId));
        return;
      }
      let tableIds = schema.tables.map((table) => table.tableId);
      if (!schema.tablesLoaded) {
        const result = await dispatch(fetchTables({ type: "source", dbId, schemaId: schema.schemaId }));
        if (fetchTables.rejected.match(result)) return;
        const [databaseName, schemaName] = schema.schemaId.split(":", 2);
        const loaded = (result.payload?.tables ?? []) as Array<{ table_name: string }>;
        if (loaded.length) {
          tableIds = loaded.map((table) => `${databaseName}.${schemaName}.${table.table_name}`);
        }
      }
      addSources(tableIds);
    },
    [addSources, dispatch, removeSources, schemaCheckState],
  );

  return { isSelected, addSources, toggleTable, schemaCheckState, toggleSchema };
}
