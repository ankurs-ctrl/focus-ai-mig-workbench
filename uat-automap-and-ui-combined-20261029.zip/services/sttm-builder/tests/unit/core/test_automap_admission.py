"""Offline SQL-contract simulation, NOT proof of Snowflake's live locking behavior."""
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from copy import deepcopy
from dataclasses import replace
import json
from threading import Barrier, Event, Lock, get_ident
import time

import pytest

from app.core import automap_admission as admission
from app.core.automap_scan import ScanRequest, ScanStatus, scan_registry
from app.core.automap_shards import ContextRecord, MessageBudget, ShardRegistry, SnapshotScope


ACCOUNT = "TEST_ORG.TEST_ACCOUNT"
EPOCH = "d74c3ae7-8233-4a97-87a7-fc69ab3e977d"
TABLE = "TEST_DB.CONTROL.TBL_AUTOMAP_CALL_ADMISSION"
SCOPE = SnapshotScope("caller", "snapshot")
IDENTITY = admission.CallIdentity("job", "caller", "generation", "shard")


class Database:
    """Simulates committed reads, atomic predicate recheck, locks and rollback.

    A barrier can force competing SELECTs to see the same FREE row. UPDATE takes
    a database lock and rechecks the bound predicate, retaining the lock until
    COMMIT/ROLLBACK. These are explicit simulation assumptions, not live evidence.
    """

    def __init__(self, capacity=2):
        self.rows = [dict(ACCOUNT_NAMESPACE=ACCOUNT, POOL_EPOCH=EPOCH, SLOT_ID=index,
                          STATE="FREE", OWNER_TOKEN=None, FENCE=0, JOB_ID=None,
                          CALLER_ID=None, GENERATION=None, SHARD_ID=None,
                          LEASE_EXPIRES_AT=None, COMPLETION=None, RECONCILIATION_REF=None)
                     for index in range(1, capacity + 1)]
        self.lock = Lock()
        self.sessions = []
        self.clock = 100
        self.barrier = None
        self.result_override = None
        self.fail_update = False
        self.commit_failure = None
        self.fail_rollback = False
        self.context_account = ACCOUNT
        self.dirty_session = False
        self.factory_failure = False

    @contextmanager
    def factory(self):
        if self.factory_failure:
            raise RuntimeError("credential text must not escape")
        session = Session(self)
        with self.lock:
            self.sessions.append(session)
        try:
            yield session
        finally:
            session.cleanup()


class Session:
    def __init__(self, database):
        self.database = database
        self.thread = get_ident()
        self.commands = []
        self.transaction = False
        self.locked = False
        self.before = None
        self.closed = False

    def sql(self, query, params=None):
        assert get_ident() == self.thread, "Snowpark session shared between threads"
        assert not self.closed
        sql = " ".join(query.split())
        params = params or []
        assert sql.count("?") == len(params)
        assert not sql.startswith(("INSERT", "DELETE", "CREATE", "MERGE", "ALTER"))
        self.commands.append((sql, params))
        session = self

        class Query:
            def collect(self, *, statement_params):
                assert int(statement_params["STATEMENT_TIMEOUT_IN_SECONDS"]) > 0
                assert int(statement_params["LOCK_TIMEOUT"]) == 1
                return session.execute(sql, params)

        return Query()

    def execute(self, sql, params):
        database = self.database
        if sql.startswith("SELECT CURRENT_ORGANIZATION_NAME()"):
            return [dict(ACCOUNT_NAMESPACE=database.context_account,
                         TRANSACTION_ID=1 if database.dirty_session else None)]
        if sql == "BEGIN TRANSACTION":
            assert not self.transaction
            self.transaction = True
            return []
        if sql == "COMMIT":
            assert self.transaction
            if database.commit_failure == "before":
                raise OSError("commit not delivered")
            self.transaction = False
            if self.locked:
                self.locked = False
                self.before = None
                database.lock.release()
            if database.commit_failure == "after":
                raise OSError("commit acknowledgement lost")
            return []
        if sql == "ROLLBACK":
            if database.fail_rollback:
                raise OSError("rollback unavailable")
            self.rollback()
            return []
        if sql.startswith("SELECT RECONCILIATION_REF"):
            keys = ("ACCOUNT_NAMESPACE", "POOL_EPOCH", "SLOT_ID", "OWNER_TOKEN", "FENCE",
                    "JOB_ID", "CALLER_ID", "GENERATION", "SHARD_ID")
            with database.lock:
                return [deepcopy(row) for row in database.rows
                        if all(row[key] == value for key, value in zip(keys, params))
                        and row["STATE"] in {"HELD", "QUARANTINED"}
                        and row["ACCOUNT_NAMESPACE"] == database.context_account][:2]
        assert self.transaction
        if sql.startswith("SELECT SLOT_ID,"):
            assert "WHERE ACCOUNT_NAMESPACE = ? ORDER BY SLOT_ID" in sql
            with database.lock:
                rows = deepcopy([row for row in database.rows if row["ACCOUNT_NAMESPACE"] == params[0]])
            if database.barrier is not None:
                database.barrier.wait(timeout=3)
            return sorted(rows, key=lambda row: row["SLOT_ID"])
        assert sql.startswith(f"UPDATE {TABLE} SET ")
        if database.fail_update:
            raise OSError("update unavailable")
        database.lock.acquire()
        self.locked = True
        self.before = deepcopy(database.rows)
        if "SET STATE = 'HELD'" in sql:
            assert "AND STATE = 'FREE' AND OWNER_TOKEN IS NULL AND FENCE = ?" in sql
            owner, job, caller, generation, shard, lease, account, epoch, slot, fence = params
            matched = [row for row in database.rows if row["ACCOUNT_NAMESPACE"] == account
                       and row["POOL_EPOCH"] == epoch and row["SLOT_ID"] == slot
                       and row["STATE"] == "FREE" and row["OWNER_TOKEN"] is None and row["FENCE"] == fence]
            for row in matched:
                row.update(STATE="HELD", OWNER_TOKEN=owner, FENCE=fence + 1, JOB_ID=job,
                           CALLER_ID=caller, GENERATION=generation, SHARD_ID=shard,
                           LEASE_EXPIRES_AT=database.clock + lease, RECONCILIATION_REF=None)
        else:
            predicate = ("WHERE ACCOUNT_NAMESPACE = ? AND POOL_EPOCH = ? AND SLOT_ID = ? "
                         "AND OWNER_TOKEN = ? AND FENCE = ? AND JOB_ID = ? AND CALLER_ID = ? "
                         "AND GENERATION = ? AND SHARD_ID = ? AND ")
            assert predicate in sql
            keys = ("ACCOUNT_NAMESPACE", "POOL_EPOCH", "SLOT_ID", "OWNER_TOKEN", "FENCE",
                    "JOB_ID", "CALLER_ID", "GENERATION", "SHARD_ID")
            matched = [row for row in database.rows
                       if all(row[key] == value for key, value in zip(keys, params[-9:]))]
            if "SET RECONCILIATION_REF" in sql:
                assert "STATE = 'HELD' AND LEASE_EXPIRES_AT > CURRENT_TIMESTAMP() AND RECONCILIATION_REF IS NULL" in sql
                matched = [row for row in matched if row["STATE"] == "HELD"
                           and row["LEASE_EXPIRES_AT"] > database.clock and row["RECONCILIATION_REF"] is None]
                for row in matched:
                    row["RECONCILIATION_REF"] = params[0]
            elif "SET LEASE_EXPIRES_AT" in sql:
                assert "STATE = 'HELD' AND LEASE_EXPIRES_AT > CURRENT_TIMESTAMP()" in sql
                matched = [row for row in matched if row["STATE"] == "HELD"
                           and row["LEASE_EXPIRES_AT"] > database.clock]
                for row in matched:
                    row["LEASE_EXPIRES_AT"] = database.clock + params[0]
            else:
                assert "STATE IN ('HELD', 'QUARANTINED')" in sql
                matched = [row for row in matched if row["STATE"] in {"HELD", "QUARANTINED"}]
                if "SET STATE = 'QUARANTINED'" in sql:
                    for row in matched:
                        row["STATE"] = "QUARANTINED"
                else:
                    assert "SET STATE = 'FREE', OWNER_TOKEN = NULL, FENCE = FENCE + 1" in sql
                    for row in matched:
                        row.update(STATE="FREE", OWNER_TOKEN=None, FENCE=row["FENCE"] + 1,
                                   LEASE_EXPIRES_AT=None, COMPLETION=params[0], RECONCILIATION_REF=params[1])
        return (database.result_override if database.result_override is not None
                else [{"number of rows updated": len(matched)}])

    def rollback(self):
        if self.locked:
            self.database.rows = self.before
            self.locked = False
            self.database.lock.release()
        self.transaction = False

    def cleanup(self):
        self.rollback()
        self.closed = True


def store(database, **kwargs):
    options = dict(session_factory=database.factory, table=TABLE, account_namespace=ACCOUNT,
                   pool_epoch=EPOCH, capacity=2, lease_seconds=30)
    options.update(kwargs)
    return admission.SnowflakeCallAdmission(**options)


def request(seconds=3, **kwargs):
    options = dict(scope=SCOPE, generation="generation", shard_id="shard", target_ids=("target",),
                   record_ids=("record",), message="unchanged", output_budget=MessageBudget(2000, 2000),
                   deadline=time.monotonic() + seconds, _cancel=Event(), _stop=Event())
    options.update(kwargs)
    return ScanRequest(**options)


def adapter(database, **kwargs):
    return admission.ScanCallAdmission(store(database), job_id="job", caller_id="caller", **kwargs)


def test_claim_release_and_new_generation_use_strictly_new_fence_and_owner():
    database = Database()
    pool = store(database)
    first = pool.try_claim(IDENTITY)
    assert first.fence == 1
    assert database.rows[0]["STATE"] == "HELD"
    pool.complete(first, admission.Completion.SUCCEEDED)
    second = pool.try_claim(replace(IDENTITY, generation="next-generation"))
    assert second.slot_id == first.slot_id and second.fence == 3 and second.owner != first.owner
    for operation in (pool.renew, pool.quarantine,
                      lambda permit: pool.complete(permit, admission.Completion.FAILED)):
        with pytest.raises(admission.StalePermit):
            operation(first)
    assert database.rows[0]["OWNER_TOKEN"] == second.owner


def test_barrier_forces_stale_free_read_only_one_replica_claims():
    database = Database(capacity=1)
    database.barrier = Barrier(2)
    pools = [store(database, capacity=1), store(database, capacity=1)]
    with ThreadPoolExecutor(2) as executor:
        futures = [executor.submit(pool.try_claim, IDENTITY) for pool in pools]
        results = [future.result(timeout=4) for future in futures]
    assert sum(result is not None for result in results) == 1
    assert len(database.sessions) == 2
    assert all(session.closed for session in database.sessions)
    assert all(session.commands[-1][0] == "COMMIT" for session in database.sessions)


def test_cap_across_independent_adapters_without_process_semaphore():
    database = Database()
    start = Barrier(12)

    def claim(index):
        start.wait(timeout=3)
        pool = store(database)
        return pool.try_claim(replace(IDENTITY, job_id=f"job-{index}", caller_id=f"caller-{index}"))

    with ThreadPoolExecutor(12) as executor:
        results = list(executor.map(claim, range(12)))
    assert 1 <= sum(result is not None for result in results) <= 2
    # Retry only known failed admissions to fill any free slot; no remote retries.
    pool = store(database)
    while pool.try_claim(IDENTITY) is not None:
        pass
    assert sum(row["STATE"] == "HELD" for row in database.rows) == 2
    assert pool.try_claim(IDENTITY) is None
    assert not pool.capabilities.per_job_limit and not pool.capabilities.per_caller_limit
    assert not pool.capabilities.fairness and not pool.capabilities.automatic_expiry_reclaim


@pytest.mark.parametrize("result", [[], [{}], [{"status": 1}], [{"number of rows updated": True}],
                                    [{"number of rows updated": 1.0}], [{"number of rows updated": -1}],
                                    [{"number of rows updated": 2}],
                                    [{"number of rows updated": 1}, {"number of rows updated": 1}]])
def test_invalid_affected_count_rolls_back_before_any_permit(result):
    database = Database()
    database.result_override = result
    with pytest.raises(admission.AdmissionInvariantError):
        store(database).try_claim(IDENTITY)
    assert database.rows[0]["STATE"] == "FREE" and database.rows[0]["FENCE"] == 0
    assert database.sessions[-1].commands[-1][0] == "ROLLBACK"


@pytest.mark.parametrize("corruption", ["duplicate", "missing", "extra", "epoch", "state", "owner", "fence"])
def test_inventory_corruption_fails_closed(corruption):
    database = Database()
    if corruption == "duplicate":
        database.rows[1]["SLOT_ID"] = 1
    elif corruption == "missing":
        database.rows.pop()
    elif corruption == "extra":
        database.rows.append(deepcopy(database.rows[0]))
    else:
        key, value = {"epoch": ("POOL_EPOCH", "wrong"), "state": ("STATE", "INVALID"),
                      "owner": ("OWNER_TOKEN", "orphan"), "fence": ("FENCE", -1)}[corruption]
        database.rows[0][key] = value
    with pytest.raises(admission.AdmissionInvariantError):
        store(database).try_claim(IDENTITY)
    assert not any(sql.startswith("UPDATE") for sql, _ in database.sessions[-1].commands)


@pytest.mark.parametrize("stage", ["factory", "update", "commit-before", "commit-after"])
def test_store_failure_never_dispatches_even_if_commit_succeeded(stage):
    database = Database()
    database.factory_failure = stage == "factory"
    database.fail_update = stage == "update"
    database.commit_failure = stage.removeprefix("commit-") if stage.startswith("commit-") else None
    gate = adapter(database)
    called = []
    with pytest.raises(admission.AdmissionUnavailable) as raised:
        req = request()
        with gate(req):
            gate.wrap_backend(lambda _: called.append(True))(req)
    assert called == [] and "credential" not in str(raised.value)
    assert database.rows[0]["STATE"] == ("HELD" if stage == "commit-after" else "FREE")


def test_failed_rollback_is_not_admission_and_factory_discards_session():
    database = Database()
    database.result_override = [{"number of rows updated": 2}]
    database.fail_rollback = True
    with pytest.raises(admission.AdmissionClaimUncertain):
        store(database).try_claim(IDENTITY)
    assert database.sessions[-1].closed


def test_expired_lease_cannot_be_renewed_or_recycled_until_terminal_reconciliation():
    database = Database(1)
    pool = store(database, capacity=1)
    permit = pool.try_claim(IDENTITY)
    database.clock += 31
    with pytest.raises(admission.StalePermit):
        pool.renew(permit)
    assert pool.try_claim(IDENTITY) is None
    pool.quarantine(permit)
    database.clock += 100000
    assert pool.try_claim(IDENTITY) is None
    pool.reconcile_terminal(permit, admission.Completion.FAILED, evidence_ref="audit-terminal-1", retired_dispatcher=True)
    assert database.rows[0]["RECONCILIATION_REF"] == "audit-terminal-1"
    assert pool.try_claim(IDENTITY) is not None


def test_renew_preserves_owner_fence_and_uses_new_session():
    database = Database()
    pool = store(database)
    permit = pool.try_claim(IDENTITY)
    database.clock += 10
    pool.renew(permit)
    assert database.rows[0]["LEASE_EXPIRES_AT"] == 140
    assert database.rows[0]["OWNER_TOKEN"] == permit.owner
    assert database.rows[0]["FENCE"] == permit.fence
    assert len(database.sessions) == 2 and all(session.closed for session in database.sessions)
    pool.quarantine(permit)
    with pytest.raises(admission.StalePermit):
        pool.renew(permit)


@pytest.mark.parametrize("field,value", [("account_namespace", "https://example.com"),
                                         ("account_namespace", "org-account"),
                                         ("account_namespace", "org.account;DROP"),
                                         ("table", "TABLE"), ("table", 'DB.SCHEMA."TABLE"'),
                                         ("table", "DB.SCHEMA.TABLE;DROP TABLE t"),
                                         ("pool_epoch", "not-uuid"), ("capacity", True),
                                         ("capacity", 0), ("lease_seconds", -1)])
def test_invalid_configuration_without_io(field, value):
    database = Database()
    with pytest.raises(ValueError):
        store(database, **{field: value})
    assert database.sessions == []


@pytest.mark.parametrize("dirty", [True, False])
def test_foreign_account_or_existing_transaction_rejected_without_begin(dirty):
    database = Database()
    database.dirty_session = dirty
    database.context_account = ACCOUNT if dirty else "OTHER.ACCOUNT"
    with pytest.raises(admission.AdmissionInvariantError):
        store(database).try_claim(IDENTITY)
    assert len(database.sessions[-1].commands) == 1


def test_bound_job_values_are_not_sql_or_credentials():
    database = Database()
    identity = replace(IDENTITY, job_id="job'; DROP TABLE x;--")
    permit = store(database).try_claim(identity)
    assert permit.identity == identity
    assert all(identity.job_id not in sql for session in database.sessions for sql, _ in session.commands)
    with pytest.raises(ValueError):
        replace(IDENTITY, caller_id="caller\nforged")


def test_suppressing_factory_cannot_return_permit_after_commit_failure():
    database = Database()
    database.commit_failure = "after"

    @contextmanager
    def suppressing_factory():
        try:
            with database.factory() as session:
                yield session
        except OSError:
            pass

    pool = store(database, session_factory=suppressing_factory)
    with pytest.raises(admission.AdmissionUnavailable):
        pool.try_claim(IDENTITY)
    assert database.rows[0]["STATE"] == "HELD"


def test_scan_context_requires_paired_backend_and_quarantines_unreported_outcome():
    database = Database()
    gate = adapter(database)
    with pytest.raises(admission.UnreportedCompletion):
        with gate(request()) as granted:
            assert granted is True
    assert database.rows[0]["STATE"] == "QUARANTINED"


def test_backend_without_admission_wrong_request_or_second_invocation_denied():
    database = Database()
    gate = adapter(database)
    calls = []
    backend = gate.wrap_backend(lambda req: calls.append(req.message) or "done")
    req = request()
    with pytest.raises(admission.AdmissionError):
        backend(req)
    with gate(req):
        with pytest.raises(admission.AdmissionError):
            backend(request())
        assert backend(req) == "done"
        with pytest.raises(admission.AdmissionError):
            backend(req)
    assert calls == ["unchanged"] and database.rows[0]["STATE"] == "FREE"


@pytest.mark.parametrize("failure,expected", [(TimeoutError, "QUARANTINED"),
                                             (ConnectionError, "QUARANTINED"),
                                             (KeyboardInterrupt, "QUARANTINED"),
                                             (admission.RemoteCallCompleted, "FREE")])
def test_unknown_remote_outcomes_are_not_released_even_when_scan_swallows_error(failure, expected):
    database = Database()
    gate = adapter(database)
    req = request()

    def transport(_):
        raise failure("remote outcome")

    with gate(req):
        with pytest.raises(failure):
            gate.wrap_backend(transport)(req)
    assert database.rows[0]["STATE"] == expected
    if expected == "FREE":
        assert database.rows[0]["COMPLETION"] == "FAILED"


def test_cancellation_after_remote_terminal_success_releases_even_after_lease_expiry():
    database = Database()
    gate = adapter(database)
    req = request()

    def transport(_):
        database.clock += 100
        req._cancel.set()
        return "terminal response"

    with gate(req):
        assert gate.wrap_backend(transport)(req) == "terminal response"
    assert database.rows[0]["STATE"] == "FREE"


def test_no_claim_for_canceled_or_foreign_caller():
    database = Database()
    gate = adapter(database)
    req = request()
    req._cancel.set()
    with pytest.raises(Exception):
        with gate(req):
            pytest.fail("entered canceled request")
    with pytest.raises(admission.AdmissionError):
        with gate(request(scope=SnapshotScope("other", "snapshot"))):
            pytest.fail("entered foreign scope")
    assert database.sessions == []


def test_waiting_for_capacity_observes_cancellation_without_dispatch():
    database = Database()
    pool = store(database)
    pool.try_claim(IDENTITY)
    pool.try_claim(IDENTITY)
    gate = adapter(database, poll_seconds=0.005)
    req = request(seconds=0.03)
    with pytest.raises(Exception):
        with gate(req):
            pytest.fail("pool was exhausted")
    assert all(row["STATE"] == "HELD" for row in database.rows)


def test_retryable_lock_contention_waits_without_terminal_failure(monkeypatch):
    database = Database()
    gate = adapter(database, poll_seconds=0.001)
    original = gate.store.try_claim
    attempts = 0
    def claim(identity):
        nonlocal attempts
        attempts += 1
        if attempts < 3:
            raise admission.AdmissionContended("lock timeout")
        return original(identity)
    monkeypatch.setattr(gate.store, "try_claim", claim)
    req = request(seconds=2)
    with gate(req):
        gate.wrap_backend(lambda active: "completed")(req)
    assert attempts == 3
    assert all(row["STATE"] == "FREE" for row in database.rows)


def test_cancellation_after_claim_before_yield_releases_not_dispatched(monkeypatch):
    database = Database()
    gate = adapter(database)
    req = request()
    original = gate.store.try_claim

    def claim(identity):
        permit = original(identity)
        req._cancel.set()
        return permit

    monkeypatch.setattr(gate.store, "try_claim", claim)
    with pytest.raises(Exception):
        with gate(req):
            pytest.fail("must not enter")
    assert database.rows[0]["STATE"] == "FREE"
    assert database.rows[0]["COMPLETION"] == "NOT_DISPATCHED"


def test_predispatch_renewal_failure_never_calls_transport():
    database = Database()
    gate = adapter(database)
    req = request()
    calls = []
    with gate(req):
        database.clock += 40
        with pytest.raises(admission.StalePermit):
            gate.wrap_backend(lambda _: calls.append(True))(req)
    assert calls == [] and database.rows[0]["COMPLETION"] == "NOT_DISPATCHED"


def test_heartbeat_uses_independent_session_until_remote_returns(monkeypatch):
    database = Database()
    gate = adapter(database, heartbeat_seconds=0.01)
    renewed = Event()
    original = gate.store.renew

    def renew(permit):
        original(permit)
        if get_ident() != main_thread:
            renewed.set()

    monkeypatch.setattr(gate.store, "renew", renew)
    main_thread = get_ident()
    req = request()

    def backend(_):
        assert renewed.wait(2)
        assert database.rows[0]["STATE"] == "HELD"
        return "done"

    with gate(req):
        gate.wrap_backend(backend)(req)
    assert database.rows[0]["STATE"] == "FREE"
    assert len({session.thread for session in database.sessions}) >= 2
    assert all(session.closed for session in database.sessions)


def test_heartbeat_failure_does_not_recycle_live_remote_call(monkeypatch):
    database = Database()
    gate = adapter(database, heartbeat_seconds=0.01)
    quarantined = Event()
    original = gate.store.quarantine
    main_thread = get_ident()
    renew = gate.store.renew

    def fail_heartbeat(permit):
        if get_ident() != main_thread:
            raise admission.AdmissionUnavailable("heartbeat failed")
        renew(permit)

    def quarantine(permit):
        original(permit)
        quarantined.set()

    monkeypatch.setattr(gate.store, "renew", fail_heartbeat)
    monkeypatch.setattr(gate.store, "quarantine", quarantine)
    req = request()

    def backend(_):
        assert quarantined.wait(2)
        assert database.rows[0]["STATE"] == "QUARANTINED"
        raise TimeoutError("remote may still be running")

    with gate(req):
        with pytest.raises(TimeoutError):
            gate.wrap_backend(backend)(req)
    assert database.rows[0]["STATE"] == "QUARANTINED"


def test_quarantine_store_outage_retains_held_permit_fail_closed():
    database = Database()
    gate = adapter(database)
    req = request()
    with pytest.raises(admission.AdmissionUnavailable):
        with gate(req):
            def backend(_):
                database.fail_update = True
                raise TimeoutError("uncertain remote")
            with pytest.raises(TimeoutError):
                gate.wrap_backend(backend)(req)
    assert database.rows[0]["STATE"] == "HELD"


def test_actual_scan_interface_success_and_swallowed_timeout():
    database = Database()
    gate = adapter(database)
    registry = ShardRegistry(scope=SCOPE,
        records=[ContextRecord(scope=SCOPE, record_id="record", kind="column", body={})],
        budget=MessageBudget(2000, 2000), message_builder=json.dumps)

    def transport(req):
        return json.dumps(dict(generation=req.generation, shard_id=req.shard_id,
                               targets=[dict(target_id="target", candidates=[])]))

    kwargs = dict(registry=registry, scope=SCOPE, target_ids=["target"], admission=gate,
                  max_workers=2, max_calls=2, total_seconds=3, output_budget=MessageBudget(2000, 2000))
    result = scan_registry(backend=gate.wrap_backend(transport), **kwargs)
    assert result.complete and database.rows[0]["STATE"] == "FREE"

    def uncertain(req):
        raise TimeoutError("still running remotely")

    result = scan_registry(backend=gate.wrap_backend(uncertain), **kwargs)
    assert result.shards[0].status == ScanStatus.BACKEND_FAILED
    assert database.rows[0]["STATE"] == "QUARANTINED"


def test_coordinator_timeout_does_not_release_running_backend():
    database = Database()
    gate = adapter(database, heartbeat_seconds=0.02)
    entered = Event()
    unblock = Event()
    finished = Event()
    registry = ShardRegistry(scope=SCOPE,
        records=[ContextRecord(scope=SCOPE, record_id="record", kind="column", body={})],
        budget=MessageBudget(2000, 2000), message_builder=json.dumps)

    def transport(req):
        entered.set()
        assert unblock.wait(3)
        return "terminal-but-not-json"

    @contextmanager
    def observed(req):
        try:
            with gate(req) as granted:
                yield granted
        finally:
            finished.set()

    try:
        result = scan_registry(registry=registry, scope=SCOPE, target_ids=["target"],
            admission=observed, backend=gate.wrap_backend(transport), max_workers=1, max_calls=1,
            total_seconds=0.15, output_budget=MessageBudget(2000, 2000))
        assert entered.is_set() and not finished.is_set()
        assert result.shards[0].status == ScanStatus.TIMED_OUT
        assert database.rows[0]["STATE"] == "HELD"
    finally:
        unblock.set()
    assert finished.wait(3)
    assert database.rows[0]["STATE"] == "FREE"


def test_twenty_waiters_complete_on_four_slots_without_terminal_refusals():
    database = Database(capacity=4)
    gates = [admission.ScanCallAdmission(store(database, capacity=4), job_id=f"job-{i}",
             caller_id="caller", poll_seconds=0.002, heartbeat_seconds=10)
             for i in range(20)]
    lock = Lock()
    active = 0
    peak = 0
    def run(gate):
        nonlocal active, peak
        req = request(seconds=5)
        with gate(req):
            def remote(active_request):
                nonlocal active, peak
                with lock:
                    active += 1
                    peak = max(peak, active)
                try:
                    time.sleep(0.01)
                    return "completed"
                finally:
                    with lock:
                        active -= 1
            return gate.wrap_backend(remote)(req)
    with ThreadPoolExecutor(20) as executor:
        assert list(executor.map(run, gates)) == ["completed"] * 20
    assert 1 < peak <= 4
    assert all(row["STATE"] == "FREE" for row in database.rows)


def test_independent_adapters_limit_actual_overlapping_simulated_remote_calls():
    database = Database()
    gates = [adapter(database, poll_seconds=0.002) for _ in range(8)]
    lock = Lock()
    two_entered = Event()
    release = Event()
    active = 0
    peak = 0
    calls = 0

    def backend(req):
        nonlocal active, peak, calls
        with lock:
            active += 1
            calls += 1
            peak = max(active, peak)
            if active == 2:
                two_entered.set()
        try:
            assert release.wait(3)
            return "completed"
        finally:
            with lock:
                active -= 1

    def run(gate):
        req = request()
        with gate(req):
            return gate.wrap_backend(backend)(req)

    with ThreadPoolExecutor(8) as executor:
        futures = [executor.submit(run, gate) for gate in gates]
        try:
            assert two_entered.wait(2)
            with lock:
                assert active == peak == calls == 2
        finally:
            release.set()
        assert [future.result(timeout=3) for future in futures] == ["completed"] * 8
    assert peak == 2 and active == 0 and calls == 8
    assert all(row["STATE"] == "FREE" for row in database.rows)


@pytest.mark.parametrize("operation", ["renew", "quarantine", "complete"])
def test_multiple_affected_rows_in_lifecycle_roll_back(operation):
    database = Database()
    pool = store(database)
    permit = pool.try_claim(IDENTITY)
    before = deepcopy(database.rows)
    database.result_override = [{"number of rows updated": 2}]
    with pytest.raises(admission.AdmissionInvariantError):
        if operation == "complete":
            pool.complete(permit, admission.Completion.SUCCEEDED)
        else:
            getattr(pool, operation)(permit)
    assert database.rows == before
    assert database.sessions[-1].commands[-1][0] == "ROLLBACK"


@pytest.mark.parametrize("field,value", [("owner", "other-owner"), ("fence", 99),
                                         ("identity", replace(IDENTITY, generation="stale")),
                                         ("identity", replace(IDENTITY, job_id="other-job")),
                                         ("identity", replace(IDENTITY, caller_id="other-caller")),
                                         ("pool_epoch", "d74c3ae7-8233-4a97-87a7-fc69ab3e977e"),
                                         ("account_namespace", "OTHER.ACCOUNT")])
def test_forged_or_stale_handle_cannot_release_current_owner(field, value):
    database = Database()
    pool = store(database)
    permit = pool.try_claim(IDENTITY)
    with pytest.raises(admission.StalePermit):
        pool.complete(replace(permit, **{field: value}), admission.Completion.SUCCEEDED)
    assert database.rows[0]["OWNER_TOKEN"] == permit.owner


def test_empty_reconciliation_evidence_and_implicit_completion_rejected():
    database = Database()
    pool = store(database)
    permit = pool.try_claim(IDENTITY)
    with pytest.raises(ValueError):
        pool.reconcile_terminal(permit, admission.Completion.FAILED, evidence_ref="", retired_dispatcher=True)
    with pytest.raises(ValueError):
        pool.complete(permit, "SUCCEEDED")
    assert database.rows[0]["STATE"] == "HELD"


def test_completion_commit_ack_loss_never_retries_remote_and_old_fence_stays_invalid():
    database = Database()
    gate = adapter(database)
    req = request()
    calls = []

    def backend(_):
        calls.append(True)
        database.commit_failure = "after"
        return "terminal"

    with pytest.raises(admission.AdmissionUnavailable):
        with gate(req):
            gate.wrap_backend(backend)(req)
    assert calls == [True]
    assert database.rows[0]["STATE"] == "FREE"
    assert database.rows[0]["FENCE"] == 2


def test_unwrapped_backend_with_swallowed_failure_is_not_treated_as_completion():
    database = Database()
    gate = adapter(database)
    req = request()
    with pytest.raises(admission.UnreportedCompletion):
        with gate(req):
            try:
                raise TimeoutError("remote may still be running")
            except TimeoutError:
                pass  # Same exception visibility problem as scan_registry.
    assert database.rows[0]["STATE"] == "QUARANTINED"
