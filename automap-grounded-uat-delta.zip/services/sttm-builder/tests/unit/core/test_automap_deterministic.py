"""Offline preservation tests, including the real FtPitt upload and graph."""
from collections import Counter
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
from time import perf_counter
from types import SimpleNamespace

import pytest
from sqlglot import exp, parse_one

import app.core.automap_deterministic as deterministic
from app.core.automap_deterministic import resolve_authored_targets
from app.core.mapping_sql import MappingSqlService
from app.schema.sttm_builder import STTMBuilderEnvelopeRequest


TABLE = {"database": "DB", "schema": "SRC", "table": "CONTACTS"}
TARGET = {"database": "DB", "schema": "TGT", "table": "PEOPLE"}


@pytest.fixture(autouse=True)
def deny_remote_io(monkeypatch):
    def denied(*args, **kwargs):
        pytest.fail("Deterministic preservation attempted remote execution")

    monkeypatch.setattr(MappingSqlService, "_compile_preview_sql", denied)
    monkeypatch.setattr(MappingSqlService, "parse", denied)
    monkeypatch.setattr(MappingSqlService, "review", denied)
    monkeypatch.setattr(MappingSqlService, "preview", denied)
    import socket
    monkeypatch.setattr(socket.socket, "connect", denied)


def request(rows=None, sql=None, *, targets=("RESULT",), graph=None):
    graph = graph if graph is not None else {"nodes": [{"relation_id": "contacts", "kind": "PHYSICAL_TABLE",
        "alias": "src", "table": TABLE, "output_columns": [{"name": name} for name in ("ID", "NAME", "OTHER", "RESULT", "Id", "Odd.Name", 'a"b')]}]}
    return STTMBuilderEnvelopeRequest.model_validate({
        "operation": "sttm.auto_map", "data": {"intent": "AUTO_MAP", "attributes": [
            {"target_table": TARGET, "target_attribute": name, "target_data_type": "VARCHAR"} for name in targets]},
        "context": {"source_tables": [TABLE], "relation_graph": graph,
            "workspace_context": {"target_table": TARGET, "source_tables": [TABLE],
                "mapping_rows": rows or [], "mapping_sql": sql}},
    })


def row(**updates):
    return {"id": "row-1", "target_column": "RESULT", "target_type": "VARCHAR", **updates}


def only(req, **kwargs):
    return resolve_authored_targets(req, **kwargs).targets[0]


def assert_pending(result, code):
    assert result.status == "pending"
    assert result.mapping is None
    assert result.execution_status == "blocked"
    assert code in {note.code for note in result.diagnostics}


def test_imports_are_from_requested_new_worktree():
    assert Path(deterministic.__file__).resolve().parents[2] == Path(__file__).resolve().parents[3]
    import app.core.mapping_sql as compiler_module
    assert Path(compiler_module.__file__).resolve().parents[2] == Path(__file__).resolve().parents[3]


def test_current_direct_is_proven_without_inference_or_manual_origin():
    result = only(request([row(source_columns=["src.ID"], rule="Direct", provenance="AUTO_MAP", status="MAPPED")]))
    assert result.status == "definition_preserved"
    assert result.origin == "current_rule"
    assert result.mapping.preprocessing_rule == "src.ID"
    assert result.mapping.source_dependencies == ["src.ID"]
    assert result.required_relation_ids == ("contacts",)
    assert result.compiler_valid
    assert result.execution_status == "not_validated"


def test_fully_authored_partition_emits_source_mapping_result():
    sql = "SELECT src.ID AS ID, CASE WHEN src.NAME IS NULL THEN 'unknown' ELSE src.NAME END AS NAME FROM DB.SRC.CONTACTS src"
    req = request(sql=sql, targets=("ID", "NAME"))
    result = resolve_authored_targets(req)
    assert not result.pending_attributes
    assert len(result.source_mapping_results["DB.TGT.PEOPLE"].mappings) == 2
    assert result.mapping_sql == sql
    assert all(target.origin == "authored_sql" and target.requires_authored_query for target in result.targets)


def test_exact_expression_spelling_and_full_population_remain_unchanged():
    expression = "case  when src.ID > 0 then 'O''Brien' else src.NAME end"
    sql = f"SELECT {expression} AS RESULT FROM DB.SRC.CONTACTS src WHERE src.OTHER IS NOT NULL ORDER BY src.ID LIMIT 5;"
    req = request(sql=sql)
    result = resolve_authored_targets(req)
    target = result.targets[0]
    assert target.mapping.preprocessing_rule == expression
    assert target.definition_sql == expression
    assert target.mapping.source_dependencies == ["src.ID", "src.NAME"]
    assert result.mapping_sql == sql


@pytest.mark.parametrize("expression", ["'fixed'", "NULL", "$Firm", "CURRENT_TIMESTAMP()", "COALESCE('a', 'b')"])
def test_authored_values_win_over_same_named_source_columns(expression):
    result = only(request(sql=f"SELECT {expression} AS RESULT FROM DB.SRC.CONTACTS src"))
    assert result.status == "definition_preserved"
    assert result.mapping.source_attributes == []
    assert result.mapping.preprocessing_rule == expression
    assert result.mapping.preprocessing_rule_type != "Direct"
    if expression == "$Firm":
        assert result.execution_status == "blocked"
        assert result.unresolved_values == ("$Firm",)


def test_constant_function_is_never_rendered_as_null():
    result = only(request([row(mapping_mode="constant", rule="Value", expression="CURRENT_TIMESTAMP()")]))
    assert result.status == "definition_preserved"
    assert result.mapping.mapping_mode == "source"
    assert result.mapping.preprocessing_rule == "CURRENT_TIMESTAMP()"
    assert result.mapping.constant_value is None
    assert result.mapping.preprocessing_rule_type == "Custom"


@pytest.mark.parametrize("expression, mode", [("NULL", "constant"), ("'NULL'", "source"), ("''", "source"), ("'null'", "source"), ("' false '", "source")])
def test_null_and_literal_text_are_not_conflated(expression, mode):
    result = only(request(sql=f"SELECT {expression} AS RESULT FROM DB.SRC.CONTACTS src"))
    assert result.status == "definition_preserved"
    assert result.mapping.preprocessing_rule == expression
    assert result.mapping.mapping_mode == mode


@pytest.mark.parametrize("value", [None, ""])
def test_missing_value_does_not_invent_null(value):
    assert_pending(only(request([row(mapping_mode="constant", constant_value=value, rule="Value")])), "missing_value")


@pytest.mark.parametrize("value, data_type", [("0", "NUMBER"), ("FALSE", "BOOLEAN"), ("O'Brien", "VARCHAR"), ("C:\\new", "VARCHAR")])
def test_current_explicit_values_preserved(value, data_type):
    result = only(request([row(mapping_mode="constant", constant_value=value, target_type=data_type, rule="Value")]))
    assert result.status == "definition_preserved"
    assert result.mapping.preprocessing_rule != "NULL"
    assert result.baseline_rows[0].constant_value == value


def test_project_value_resolves_only_when_explicitly_supplied():
    req = request([row(mapping_mode="attribute", constant_value="$Firm", attribute_name="Firm", rule="Value")])
    before = req.model_dump(mode="json")
    result = only(req, project_attributes=[SimpleNamespace(attribute_name="Firm", attribute_value="Acme", attribute_type="VARCHAR")])
    assert result.status == "definition_preserved"
    assert result.mapping.mapping_mode == "attribute"
    assert result.mapping.constant_value == "$Firm"
    assert result.mapping.value_binding_ids == ["project-Firm"]
    assert result.execution_status == "not_validated"
    assert req.model_dump(mode="json") == before


def test_empty_project_values_remove_stale_snapshot_resolution():
    req = request(sql="SELECT $Firm AS RESULT FROM DB.SRC.CONTACTS src")
    from app.schema.sttm_builder import ValueBinding
    req.context.relation_graph.value_bindings = [ValueBinding(binding_id="firm", value="$Firm", resolved_value="prior-project", is_placeholder=True)]
    result = only(req, project_attributes=[])
    assert result.status == "definition_preserved"
    assert result.execution_status == "blocked"
    assert result.mapping.constant_value == "$Firm"


def test_unknown_explicit_value_binding_is_pending_not_fabricated():
    req = request([row(expression="$Firm", value_binding_ids=["missing-value"])])
    result = only(req)
    assert_pending(result, "invalid_value_binding")
    assert result.definition_sql == "$Firm"
    assert result.baseline_rows[0].model_extra["value_binding_ids"] == ["missing-value"]


def test_conflicting_value_bindings_are_not_last_writer_wins():
    req = request(sql="SELECT $Firm AS RESULT FROM DB.SRC.CONTACTS src")
    from app.schema.sttm_builder import ValueBinding
    req.context.relation_graph.value_bindings = [ValueBinding(binding_id=str(index), value="$Firm", resolved_value=value, is_placeholder=True)
                                                for index, value in enumerate(("one", "two"))]
    assert_pending(only(req), "invalid_value_binding")


def test_two_operand_direct_is_pending_and_exact_baseline_retained():
    source = row(source_columns=["src.ID", "src.OTHER"], rule="Direct", status="MAPPED", accepted=True, arbitrary={"keep": [1, 2]})
    req = request([source])
    before = req.model_dump(mode="json")
    result = resolve_authored_targets(req)
    assert_pending(result.targets[0], "incomplete_rule")
    assert [item.model_dump() for item in result.baseline_rows] == [item.model_dump() for item in req.context.workspace_context.mapping_rows]
    assert result.pending_attributes[0].target_attribute == "RESULT"
    result.baseline_rows[0].model_extra["arbitrary"]["keep"].append(3)
    assert req.model_dump(mode="json") == before


def test_bad_second_operand_never_reduces_to_direct():
    expression = "COALESCE(src.NAME, missing.NAME)"
    result = only(request([row(expression=expression, source_columns=["src.NAME"])], sql=f"SELECT {expression} AS RESULT FROM DB.SRC.CONTACTS src"))
    assert_pending(result, "unknown_alias")
    assert result.baseline_rows[0].expression == expression


def test_dependencies_completed_from_every_expression_operand():
    result = only(request([row(expression="COALESCE(src.NAME, src.OTHER)", source_columns=["src.NAME"])]))
    assert result.status == "definition_preserved"
    assert result.mapping.source_dependencies == ["src.NAME", "src.OTHER"]
    assert result.mapping.preprocessing_rule_type == "Custom"


def test_unrelated_selected_operand_cannot_be_discarded():
    assert_pending(only(request([row(expression="src.NAME", source_columns=["src.ID", "src.NAME"])])), "baseline_conflict")


@pytest.mark.parametrize("sql", [
    "SELECT src.ID AS RESULT FROM DB.SRC.CONTACTS src; SELECT 2 AS RESULT",
    "SELECT src.ID AS RESULT FROM DB.SRC.CONTACTS src; garbage invalid sql",
    "SELECT CASE WHEN THEN END AS RESULT FROM DB.SRC.CONTACTS src",
    "SELECT src.ID AS RESULT FROM DB.SRC.CONTACTS src WHERE (",
    "SELECT src.ID AS RESULT FROM DB.SRC.CONTACTS src; DROP TABLE DB.SRC.CONTACTS",
])
def test_strict_full_parse_rejects_invalid_tail_without_row_fallback(sql):
    req = request([row(source_columns=["src.ID"], rule="Direct")], sql)
    result = resolve_authored_targets(req)
    assert result.targets[0].status == "pending"
    assert result.mapping_sql == sql
    assert result.baseline_rows[0].source_columns == ["src.ID"]


@pytest.mark.parametrize("alias, target, preserved", [('"Result"', '"Result"', True), ('"Result"', "RESULT", False), ("result", '"RESULT"', True), ('"Odd.Name"', '"Odd.Name"', True)])
def test_target_alias_binding_is_quote_aware(alias, target, preserved):
    result = only(request(sql=f"SELECT src.ID AS {alias} FROM DB.SRC.CONTACTS src", targets=(target,)))
    assert (result.status == "definition_preserved") == preserved


@pytest.mark.parametrize("source, preserved", [('src."Id"', True), ('src."id"', False), ('src.id', True), ('src."Odd.Name"', True), ('src."a""b"', True)])
def test_source_column_identity_is_quote_aware(source, preserved):
    result = only(request(sql=f"SELECT {source} AS RESULT FROM DB.SRC.CONTACTS src"))
    assert (result.status == "definition_preserved") == preserved


def test_sql_relation_alias_can_bind_to_current_graph_without_changing_expression():
    result = only(request(sql='SELECT "Input"."Id" AS RESULT FROM DB.SRC.CONTACTS "Input"'))
    assert result.status == "definition_preserved"
    assert result.mapping.preprocessing_rule == '"Input"."Id"'
    assert result.mapping.source_attributes == ['src."Id"']


def test_quoted_alias_mismatch_is_not_repaired():
    assert_pending(only(request(sql='SELECT input.ID AS RESULT FROM DB.SRC.CONTACTS "Input"')), "unknown_alias")


def test_absent_column_contract_is_not_proof():
    req = request([row(source_columns=["src.ID"], rule="Direct")])
    req.context.relation_graph.nodes[0].output_columns = []
    assert_pending(only(req), "unknown_column")


def test_baseline_sql_conflict_preserves_both_and_defers():
    req = request([row(expression="src.OTHER", rule="Custom", status="ACCEPTED")], "SELECT src.ID AS RESULT FROM DB.SRC.CONTACTS src")
    result = resolve_authored_targets(req)
    assert_pending(result.targets[0], "baseline_conflict")
    assert result.baseline_rows[0].expression == "src.OTHER"
    assert result.targets[0].definition_sql == "src.ID"


def test_status_does_not_make_empty_row_a_complete_manual_mapping():
    assert_pending(only(request([row(status="MAPPED", accepted=True, provenance="MANUAL")])), "incomplete_rule")


def test_empty_current_row_can_be_completed_from_exact_sql_alias():
    result = only(request([row(status="UNMAPPED")], "SELECT src.ID AS RESULT FROM DB.SRC.CONTACTS src"))
    assert result.status == "definition_preserved"
    assert result.origin == "authored_sql"
    assert result.baseline_rows[0].status == "UNMAPPED"


def test_no_same_name_guess_for_an_undefined_target():
    result = only(request())
    assert_pending(result, "no_current_definition")


def test_duplicate_sql_aliases_fail_closed():
    result = only(request(sql="SELECT src.ID AS RESULT, src.NAME AS result FROM DB.SRC.CONTACTS src"))
    assert_pending(result, "ambiguous_target")


def test_duplicate_current_rows_remain_exact_and_pending():
    req = request([row(source_columns=["src.ID"]), row(id="second", source_columns=["src.NAME"])])
    result = resolve_authored_targets(req)
    assert len(result.baseline_rows) == 2
    assert_pending(result.targets[0], "ambiguous_baseline")


def test_duplicate_requested_targets_do_not_overwrite_result_dictionary():
    result = resolve_authored_targets(request([row(source_columns=["src.ID"])], targets=("RESULT", "result")))
    assert len(result.pending_attributes) == 2
    assert result.source_mapping_results == {}


def test_cte_scope_and_definition_are_bound_without_flattening():
    body = "SELECT src.ID AS ID, src.NAME AS NAME FROM DB.SRC.CONTACTS src WHERE src.ID > 0"
    req = request(sql=f"WITH selected AS ({body}) SELECT selected.ID AS RESULT FROM selected")
    from app.schema.sttm_builder import RelationNode
    req.context.relation_graph.nodes.append(RelationNode(relation_id="selection", kind="CTE", alias="selected",
        sql_text=body, output_columns=[{"name": "ID"}, {"name": "NAME"}]))
    result = only(req)
    assert result.status == "definition_preserved"
    assert result.mapping.source_attributes == ["selected.ID"]
    assert result.required_relation_ids == ("contacts", "selection")
    assert result.requires_authored_query


def test_cte_definition_mismatch_is_not_reused_by_name():
    req = request(sql="WITH selected AS (SELECT src.ID AS ID FROM DB.SRC.CONTACTS src WHERE src.ID > 0) SELECT selected.ID AS RESULT FROM selected")
    from app.schema.sttm_builder import RelationNode
    req.context.relation_graph.nodes.append(RelationNode(relation_id="selection", kind="CTE", alias="selected",
        sql_text="SELECT src.ID AS ID FROM DB.SRC.CONTACTS src", output_columns=[{"name": "ID"}]))
    assert_pending(only(req), "unknown_cte")


def test_unused_cte_with_unknown_relation_invalidates_full_query():
    sql = "WITH ignored AS (SELECT missing.ID AS ID FROM DB.SRC.UNKNOWN missing) SELECT src.ID AS RESULT FROM DB.SRC.CONTACTS src"
    assert_pending(only(request(sql=sql)), "unknown_relation")


def test_missing_cte_output_is_not_bound_to_inner_physical_column():
    body = "SELECT src.NAME AS NAME FROM DB.SRC.CONTACTS src"
    req = request(sql=f"WITH selected AS ({body}) SELECT selected.ID AS RESULT FROM selected")
    from app.schema.sttm_builder import RelationNode
    req.context.relation_graph.nodes.append(RelationNode(relation_id="selection", kind="CTE", alias="selected", sql_text=body,
                                                       output_columns=[{"name": "ID"}, {"name": "NAME"}]))
    assert_pending(only(req), "unknown_cte_output")


@pytest.mark.parametrize("sql", [
    "SELECT * FROM DB.SRC.CONTACTS",
    "SELECT src.ID AS RESULT FROM DB.SRC.CONTACTS src UNION ALL SELECT src.OTHER AS RESULT FROM DB.SRC.CONTACTS src",
    "WITH RECURSIVE selected AS (SELECT src.ID AS ID FROM DB.SRC.CONTACTS src) SELECT ID AS RESULT FROM selected",
])
def test_unsupported_full_query_is_preserved_but_not_scalar_salvaged(sql):
    result = resolve_authored_targets(request(sql=sql))
    assert result.targets[0].mapping is None
    assert result.mapping_sql == sql


@pytest.mark.parametrize("literal", ["'$Firm'", "COALESCE('$Firm', 'x')"])
def test_quoted_placeholder_literal_never_becomes_project_value(literal):
    result = only(request(sql=f"SELECT {literal} AS RESULT FROM DB.SRC.CONTACTS src"),
                  project_attributes=[SimpleNamespace(attribute_name="Firm", attribute_value="secret", attribute_type="VARCHAR")])
    assert_pending(result, "literal_placeholder_contract")
    assert result.definition_sql == literal


def test_raw_and_current_sql_conflict_is_explicit():
    req = request(sql="SELECT src.ID AS RESULT FROM DB.SRC.CONTACTS src")
    req.context.workspace_context.raw_mapping_sql = "SELECT src.NAME AS RESULT FROM DB.SRC.CONTACTS src"
    assert_pending(only(req), "conflicting_sql")


def test_insert_select_requires_exact_destination_and_alias_order():
    sql = "INSERT INTO DB.TGT.PEOPLE (RESULT) SELECT src.ID AS RESULT FROM DB.SRC.CONTACTS src"
    assert only(request(sql=sql)).status == "definition_preserved"
    assert_pending(only(request(sql=sql.replace("(RESULT)", "(OTHER)"))), "target_mismatch")
    assert_pending(only(request(sql=sql.replace("DB.TGT.PEOPLE", "DB.TGT.OTHER"))), "target_mismatch")


def test_only_requested_partition_is_resolved_and_all_rows_preserved():
    req = request([row(source_columns=["src.ID"]), row(id="outside", target_column="UNREQUESTED", expression="BROKEN(")])
    result = resolve_authored_targets(req)
    assert len(result.targets) == 1
    assert len(result.baseline_rows) == 2
    assert result.targets[0].status == "definition_preserved"


def test_determinism_and_caller_input_nonmutation():
    req = request([row(expression="COALESCE(src.ID, src.OTHER)", source_dependencies=["src.ID"])])
    before = req.model_dump(mode="json")
    first = resolve_authored_targets(req)
    second = resolve_authored_targets(req)
    assert first == second
    assert req.model_dump(mode="json") == before
    first.source_mapping_results["DB.TGT.PEOPLE"].mappings["RESULT"].source_attributes.append("bad")
    assert first == second


def test_real_compiler_rejects_disconnected_required_relation():
    req = request([row(expression="COALESCE(src.NAME, other.NAME)")])
    from app.schema.sttm_builder import RelationNode
    req.context.relation_graph.nodes.append(RelationNode(relation_id="other", kind="PHYSICAL_TABLE", alias="other",
        table={"database": "DB", "schema": "SRC", "table": "OTHER"}, output_columns=[{"name": "NAME"}]))
    result = only(req)
    assert_pending(result, "compiler_rejected")
    assert "disconnected" in result.diagnostics[0].message


def test_compiler_receives_all_dependencies_with_execution_explicitly_disabled(monkeypatch):
    calls = []
    real_compile = MappingSqlService.compile

    def capture(self, body):
        assert self._session is None
        assert self._analyst is None
        assert body.validate_with_explain is False
        assert body.allow_unresolved_placeholders is True
        calls.append(body.model_copy(deep=True))
        return real_compile(self, body)

    monkeypatch.setattr(MappingSqlService, "compile", capture)
    result = only(request([row(expression="COALESCE(src.NAME, src.OTHER)")]))
    assert result.status == "definition_preserved"
    assert calls[0].mappings[0].source_dependencies == ["contacts"]
    assert result.mapping.source_dependencies == ["src.NAME", "src.OTHER"]
    assert isinstance(parse_one(calls[0].mappings[0].expression, read="snowflake"), exp.Coalesce)


@pytest.mark.parametrize("expression", ["src.ID + (", "src.ID; SELECT 1", "Direct", "COALESCE", "src.ID AS OTHER"])
def test_incomplete_current_expressions_never_become_direct(expression):
    result = only(request([row(expression=expression, source_columns=["src.ID"], rule="Direct")]))
    assert result.status == "pending"
    assert result.mapping is None
    assert result.baseline_rows[0].expression == expression


def test_current_value_expression_conflict_is_not_silently_chosen():
    result = only(request([row(mapping_mode="constant", constant_value="fixed", expression="src.ID", rule="Value")]))
    assert_pending(result, "baseline_conflict")


def test_project_attribute_name_conflicts_are_not_first_writer_wins():
    attributes = [SimpleNamespace(attribute_name=name, attribute_value=value, attribute_type="VARCHAR")
                  for name, value in (("Firm", "one"), ("FIRM", "two"))]
    assert_pending(only(request(sql="SELECT $Firm AS RESULT FROM DB.SRC.CONTACTS src"), project_attributes=attributes), "invalid_value_binding")


@pytest.mark.parametrize("sql", [
    "SELECT src.ID AS RESULT FROM DB.SRC.CONTACTS src WHERE absent.ID > 0",
    "SELECT src.ID AS RESULT FROM DB.SRC.CONTACTS src ORDER BY src.MISSING",
])
def test_binding_validation_covers_query_clauses_not_just_projection(sql):
    assert only(request(sql=sql)).status == "pending"


def test_unresolved_values_in_full_query_filters_block_execution():
    result = only(request(sql="SELECT src.ID AS RESULT FROM DB.SRC.CONTACTS src WHERE src.OTHER = $Firm"))
    assert result.status == "definition_preserved"
    assert result.execution_status == "blocked"
    assert result.unresolved_values == ("$Firm",)


def test_matching_authored_row_uses_sql_owned_alias_not_global_alias_guess():
    expression = '"Input"."Id"'
    result = only(request([row(expression=expression)], f'SELECT {expression} AS RESULT FROM DB.SRC.CONTACTS "Input"'))
    assert result.status == "definition_preserved"
    assert result.mapping.preprocessing_rule == expression


@pytest.mark.parametrize("body", ["SELECT missing.ID AS ID FROM DB.SRC.MISSING missing", "SELECT src.NAME AS NAME FROM DB.SRC.CONTACTS src"])
def test_current_derived_output_contract_cannot_hide_invalid_saved_sql(body):
    req = request([row(source_columns=["selected.ID"], rule="Direct")])
    from app.schema.sttm_builder import RelationNode
    req.context.relation_graph.nodes.append(RelationNode(relation_id="selection", kind="CTE", alias="selected", sql_text=body,
                                                       output_columns=[{"name": "ID"}]))
    assert only(req).status == "pending"


def test_current_derived_expression_validates_saved_body_and_closure():
    req = request([row(source_columns=["selected.ID"], rule="Direct")])
    from app.schema.sttm_builder import RelationNode
    req.context.relation_graph.nodes.append(RelationNode(relation_id="selection", kind="CTE", alias="selected",
        sql_text="SELECT src.ID AS ID FROM DB.SRC.CONTACTS src", output_columns=[{"name": "ID"}]))
    result = only(req)
    assert result.status == "definition_preserved"
    assert result.required_relation_ids == ("contacts", "selection")


def test_cte_and_target_quoted_names_preserved():
    body = 'SELECT src."Id" AS "Id" FROM DB.SRC.CONTACTS src'
    sql = f'WITH "Selected" AS ({body}) SELECT "Selected"."Id" AS "Result" FROM "Selected"'
    req = request(sql=sql, targets=('"Result"',))
    from app.schema.sttm_builder import RelationNode
    req.context.relation_graph.nodes.append(RelationNode(relation_id="selection", kind="CTE", alias="selected",
        sql_text=body, output_columns=[{"name": "Id"}]))
    result = only(req)
    assert result.status == "definition_preserved"
    assert result.mapping.preprocessing_rule == '"Selected"."Id"'
    assert result.mapping.source_attributes == ['selected."Id"']


def test_parent_partition_does_not_alias_another_target_table():
    req = request([row(source_columns=["src.ID"])])
    req.data.attributes[0].target_table.table = "OTHER"
    result = resolve_authored_targets(req)
    assert_pending(result.targets[0], "target_mismatch")
    assert result.source_mapping_results == {}


def test_compiler_scalar_rewrite_is_not_claimed_preserved(monkeypatch):
    real_compile = MappingSqlService.compile

    def rewrite(self, body):
        compiled = real_compile(self, body)
        compiled.canonical_preview_sql = "SELECT NULL AS RESULT FROM DB.SRC.CONTACTS src"
        return compiled

    monkeypatch.setattr(MappingSqlService, "compile", rewrite)
    assert_pending(only(request([row(expression="CURRENT_TIMESTAMP()", mapping_mode="constant")])), "compiler_changed_definition")


def test_actual_compiler_source_keyword_rewrite_is_not_accepted():
    req = request([row(expression="COALESCE(source, src.OTHER)")])
    req.context.relation_graph.nodes[0].output_columns.append({"name": "SOURCE"})
    result = only(req)
    assert_pending(result, "compiler_changed_definition")


def test_empty_graph_cannot_claim_execution_or_binding_readiness():
    result = only(request([row(expression="CURRENT_TIMESTAMP()")], graph={"nodes": []}))
    assert_pending(result, "compiler_rejected")


def test_expression_commas_comments_and_quoted_alias_as_are_not_split():
    expression = "COALESCE(src.NAME, 'FROM, AS x') /* preserved */"
    result = only(request(sql=f'SELECT {expression} AS "AS" FROM DB.SRC.CONTACTS src', targets=('"AS"',)))
    assert result.status == "definition_preserved"
    assert result.definition_sql == expression


def test_constant_without_from_still_preserves_exact_current_definition():
    result = only(request(sql="SELECT CURRENT_TIMESTAMP() AS RESULT"))
    assert result.status == "definition_preserved"
    assert result.requires_authored_query


def test_set_script_is_pending_not_partial_query_salvage():
    result = only(request(sql="SET Firm='not-approved'; SELECT $Firm AS RESULT FROM DB.SRC.CONTACTS src"))
    assert_pending(result, "invalid_sql")


def test_nested_cte_alias_is_not_a_global_physical_binding():
    sql = "WITH one AS (SELECT src.ID AS ID FROM DB.SRC.CONTACTS src), two AS (SELECT absent.ID AS ID FROM one) SELECT src.ID AS RESULT FROM DB.SRC.CONTACTS src"
    assert_pending(only(request(sql=sql)), "unknown_alias")


def test_self_contained_cte_dependency_wrapper_is_validated_as_whole():
    from app.schema.sttm_builder import RelationNode
    prefix = "WITH base AS (SELECT src.ID AS ID FROM DB.SRC.CONTACTS src), selected AS (SELECT base.ID AS ID FROM base WHERE base.ID > 0)"
    req = request(sql=prefix + " SELECT selected.ID AS RESULT FROM selected")
    req.context.relation_graph.nodes.append(RelationNode(relation_id="selection", kind="CTE", alias="selected",
        sql_text=prefix + " SELECT * FROM selected", output_columns=[{"name": "ID"}]))
    result = only(req)
    assert result.status == "definition_preserved"
    assert result.required_relation_ids == ("contacts", "selection")


def test_join_only_population_dependencies_are_completed_without_rewriting_sql():
    from app.schema.sttm_builder import RelationNode, RelationEdge
    sql = "SELECT 'fixed' AS RESULT FROM DB.SRC.CONTACTS src LEFT JOIN DB.SRC.OTHER other ON src.ID = other.ID AND other.NAME <> 'skip'"
    req = request(sql=sql)
    req.context.relation_graph.nodes.append(RelationNode(relation_id="other", kind="PHYSICAL_TABLE", alias="other",
        table={"database": "DB", "schema": "SRC", "table": "OTHER"}, output_columns=[{"name": "ID"}, {"name": "NAME"}]))
    req.context.relation_graph.edges.append(RelationEdge(edge_id="join", left_relation_id="contacts", right_relation_id="other",
        join_type="LEFT", conditions=[{"left_column": "ID", "right_column": "ID"}], additional_predicate="other.NAME <> 'skip'"))
    result = resolve_authored_targets(req)
    assert result.targets[0].status == "definition_preserved"
    assert result.targets[0].required_relation_ids == ("contacts", "other")
    assert result.mapping_sql == sql


def test_relation_column_alias_list_is_not_ignored():
    sql = "WITH selected(RENAMED) AS (SELECT src.ID AS ID FROM DB.SRC.CONTACTS src) SELECT selected.ID AS RESULT FROM selected"
    assert_pending(only(request(sql=sql)), "unsupported_query")


def test_self_join_cannot_collapse_two_sql_instances_to_one_graph_node():
    sql = "SELECT COALESCE(src.NAME, second.NAME) AS RESULT FROM DB.SRC.CONTACTS src JOIN DB.SRC.CONTACTS second ON src.ID = second.ID"
    assert_pending(only(request(sql=sql)), "ambiguous_relation_instance")


def test_two_current_cte_targets_both_get_complete_cached_closure():
    from app.schema.sttm_builder import RelationNode
    req = request([row(target_column="ID", source_columns=["selected.ID"]), row(id="second", target_column="NAME", source_columns=["selected.NAME"])], targets=("ID", "NAME"))
    req.context.relation_graph.nodes.append(RelationNode(relation_id="selection", kind="CTE", alias="selected",
        sql_text="SELECT src.ID AS ID, src.NAME AS NAME FROM DB.SRC.CONTACTS src", output_columns=[{"name": "ID"}, {"name": "NAME"}]))
    result = resolve_authored_targets(req)
    assert not result.pending_attributes
    assert all(target.required_relation_ids == ("contacts", "selection") for target in result.targets)


def test_unknown_graph_join_column_cannot_be_proven_by_compiler_syntax_alone():
    from app.schema.sttm_builder import RelationNode, RelationEdge
    req = request([row(source_columns=["src.ID"])])
    req.context.relation_graph.nodes.append(RelationNode(relation_id="other", kind="PHYSICAL_TABLE", alias="other",
        table={"database": "DB", "schema": "SRC", "table": "OTHER"}, output_columns=[{"name": "ID"}]))
    req.context.relation_graph.edges.append(RelationEdge(edge_id="join", left_relation_id="contacts", right_relation_id="other",
        conditions=[{"left_column": "ID", "right_column": "MISSING"}]))
    assert_pending(only(req), "unknown_column")


def test_value_bindings_in_saved_derived_body_are_completed():
    from app.schema.sttm_builder import RelationNode, ValueBinding
    req = request([row(source_columns=["selected.ID"])])
    req.context.relation_graph.nodes.append(RelationNode(relation_id="selection", kind="CTE", alias="selected",
        sql_text="SELECT src.ID AS ID FROM DB.SRC.CONTACTS src WHERE src.NAME = $Firm", output_columns=[{"name": "ID"}]))
    req.context.relation_graph.value_bindings.append(ValueBinding(binding_id="firm", value="$Firm", is_placeholder=True,
                                                                resolution_status="placeholder_contract"))
    result = only(req)
    assert result.status == "definition_preserved"
    assert result.execution_status == "blocked"
    assert result.mapping.value_binding_ids == ["firm"]
    assert result.unresolved_values == ("$Firm",)


@pytest.mark.parametrize("value", ["   ", " fixed ", " NULL "])
def test_current_value_whitespace_is_not_silently_trimmed_or_nullified(value):
    result = only(request([row(mapping_mode="constant", constant_value=value)]))
    assert_pending(result, "unrepresentable_value")
    assert result.baseline_rows[0].constant_value == value


@pytest.mark.parametrize("key, value", [("value_binding_ids", [{}]), ("source_dependencies", [{}]), ("source_dependencies", "src.ID")])
def test_malformed_extra_dependency_fields_return_diagnostics(key, value):
    result = only(request([row(expression="src.ID", **{key: value})]))
    assert_pending(result, "invalid_dependency_contract")
    assert result.baseline_rows[0].model_extra[key] == value


def test_full_query_literal_placeholder_filter_is_not_reinterpreted():
    result = only(request(sql="SELECT src.ID AS RESULT FROM DB.SRC.CONTACTS src WHERE src.NAME = '$Firm'"))
    assert_pending(result, "literal_placeholder_contract")


def test_model_reevaluation_metadata_is_not_implemented_in_pure_resolver():
    req = request([row(expression="src.ID")])
    first = resolve_authored_targets(req)
    req.meta["reevaluate"] = True
    req.context.replay_exact_precedent = True
    assert resolve_authored_targets(req) == first


def test_current_graph_query_modifier_unknown_column_is_pending():
    req = request([row(expression="src.ID")])
    req.context.relation_graph.query_modifiers = {"qualify": "QUALIFY missing.ID > 0"}
    assert_pending(only(req), "unknown_alias")


def test_value_dependency_in_graph_query_modifier_is_completed():
    from app.schema.sttm_builder import ValueBinding
    req = request([row(expression="src.ID")])
    req.context.relation_graph.query_modifiers = {"qualify": "QUALIFY src.ID > $Minimum"}
    req.context.relation_graph.value_bindings.append(ValueBinding(binding_id="minimum", value="$Minimum", is_placeholder=True,
                                                                resolution_status="placeholder_contract"))
    result = only(req)
    assert result.status == "definition_preserved"
    assert result.mapping.value_binding_ids == ["minimum"]
    assert result.execution_status == "blocked"


@pytest.fixture(scope="module")
def real_ft_pitt_upload():
    # Reuse the real fixture/hash and production parser, not a simplified SQL copy.
    path = Path(__file__).with_name("test_sql_upload_real_fixture.py")
    spec = importlib.util.spec_from_file_location("ft_pitt_fixture_helpers", path)
    helpers = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helpers)
    uploaded = helpers.upload.__wrapped__()
    # Explicit offline catalog contract for this scenario, not column existence
    # inferred from SQL references (which would make a typo its own evidence).
    namespace = helpers.NAMESPACE
    source_columns = {
        f"{namespace}.ACCOUNTS": "SI_PORTFOLIOSYSTEMCLIENTID ACCOUNTID SI_LASTNAME SI_FIRSTNAME SI_CLIENTSERVICEASSOCIATE SI_CLIENTSERVICEASSOCIATE_FORMATTEDVALUE CUSTOMERTYPECODE_FORMATTEDVALUE ADDRESS1_LINE1 ADDRESS1_LINE2 ADDRESS1_LINE3 ADDRESS1_CITY ADDRESS1_STATEORPROVINCE ADDRESS1_POSTALCODE ADDRESS1_COUNTRY FP_INITIALSOURCEOFBUSINESS_FORMATTEDVALUE FP_CONSENTAPPROACH_FORMATTEDVALUE NAME_R SI_STARTDATE SI_LASTREVIEWDATE SI_NEXTREVIEWDATE SI_REVIEWFREQUENCY_FORMATTEDVALUE FP_STATUS_FORMATTEDVALUE STATECODE_FORMATTEDVALUE SI_RELATIONSHIPSTAGE_FORMATTEDVALUE",
        f"{namespace}.MAPPER_USER": "TARGETCRMID DYNAMICS_USER_GUID",
        f"{namespace}.MAPPER_HH_MASTER": "LEGACYHHNAME TARGETCRMHOUSEHOLDSOURCESYSTEMID LEGACYPORTFOLIOACCOUNTID",
        f"{namespace}.MAPPER_REFERRAL_MASTER": "REFERRAL_SOURCE__C LEGACY_ID__C SALESFORCEID",
        "FFP_HDP_CRM_MIG_DB_DEV.SCH_OPS.COUNTRY_CODES": "COUNTRY_CODE COUNTRY_ALIAS",
        "FFP_HDP_CRM_MIG_DB_DEV.SCH_OPS.STATE_CODES": "STATE_CODE STATE_ALIAS",
    }
    node = shutil.which("node")
    assert node, "Existing Node runtime is required (no installs in this test)"
    root = helpers.ROOT
    main_modules = root / "frontend/node_modules"
    if not main_modules.exists():
        main_modules = root.parent / "ffp_ai_mig_workbench/frontend/node_modules"
    env = dict(os.environ)
    env["NODE_PATH"] = os.pathsep.join(filter(None, [str(main_modules), env.get("NODE_PATH")]))
    # Execute only the harness's module loader and real Apply reducer extraction;
    # unrelated script assertions must not stand in for this regression.
    script = r"""
const fs = require('node:fs'), path = require('node:path'), ts = require('typescript');
const Module = require('node:module');
const root = process.argv[1];
const cache = new Map();
function load(filename) {
  filename = path.resolve(root, filename);
  if (cache.has(filename)) return cache.get(filename).exports;
  const loaded = new Module(filename, module);
  cache.set(filename, loaded);
  loaded.require = name => name.startsWith('@/') ? load('frontend/src/' + name.slice(2) + '.ts')
    : name.startsWith('.') ? load(path.resolve(path.dirname(filename), name + '.ts')) : require(name);
  loaded._compile(ts.transpileModule(fs.readFileSync(filename, 'utf8'), {compilerOptions: {
    module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020,
  }}).outputText, filename);
  return loaded.exports;
}
const slicePath = path.join(root, 'frontend/src/features/sttm/store/sttm-builder-slice.ts');
const slice = ts.createSourceFile(slicePath, fs.readFileSync(slicePath, 'utf8'), ts.ScriptTarget.Latest, true);
let reducer, tableRef;
function visit(node) {
  if (ts.isFunctionDeclaration(node) && node.name?.text === 'qualifiedTableRefOrNull') tableRef = node.getText(slice);
  if (ts.isPropertyAssignment(node) && node.name.getText(slice) === 'applyParsedSqlWorkspace') reducer = node.initializer.getText(slice);
  ts.forEachChild(node, visit);
}
visit(slice);
if (!reducer || !tableRef) throw new Error('Existing Apply helpers not found');
const {buildSqlUploadWorkspace} = load('frontend/src/features/sttm/mapping/sql-upload-workspace.ts');
const {computeAuthoredSqlSemanticKey} = load('frontend/src/features/sttm/mapping/authored-sql-key.ts');
const {hydrateDerivedColumns} = load('frontend/src/features/sttm/shared/derived-source-columns.ts');
const {buildCompilerRelationGraph} = load('frontend/src/features/sttm/mapping/mapping-utils.ts');
const {buildWorkbenchContextSnapshot} = load('frontend/src/features/sttm/context/workbench-context.ts');
const {sqlIdentifierParts} = load('frontend/src/features/sttm/shared/sql-identifiers.ts');
const applyModule = new Module(slicePath, module);
applyModule._compile(ts.transpileModule(tableRef + '\nmodule.exports = (authoredSqlKeyFromState, hydrateDerivedColumns) => (' + reducer + ');',
  {compilerOptions: {module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020}}).outputText, slicePath);
const input = JSON.parse(fs.readFileSync(0, 'utf8'));
const workspace = buildSqlUploadWorkspace(input.uploaded);
const state = {sources:[], targets:[], sourceDatabases:[], targetDatabases:[], derivedSources:[]};
applyModule.exports(computeAuthoredSqlSemanticKey, hydrateDerivedColumns)(state, {payload:workspace});
const tables = workspace.sourceTableFqns.map(fqn => {
  const [database, schema, table] = sqlIdentifierParts(fqn); return {database, schema, table};
});
const graph = buildCompilerRelationGraph({sourceTables:tables, derivedSources:state.derivedSources,
  relationships:state.relationships, mappings:state.mappings, queryModifiers:state.sourceQueryModifiers});
const hydratedGraph = buildCompilerRelationGraph({sourceTables:tables, derivedSources:state.derivedSources,
  relationships:state.relationships, mappings:state.mappings, queryModifiers:state.sourceQueryModifiers,
  sourceColumnsByTable:input.sourceColumns});
const snapshot = buildWorkbenchContextSnapshot({action:'automap.run', page:'mapping', surface:'MAPPING',
  sourceTables:state.sources, derivedSources:state.derivedSources, drivingTableId:state.drivingTableId,
  mappings:state.mappings, relationships:state.relationships, mappingSql:state.mappingSql});
console.log(JSON.stringify({workspace, state, graph, hydratedGraph, snapshot}));
"""
    start = perf_counter()
    completed = subprocess.run([node, "-e", script, str(root)], input=json.dumps({"uploaded": uploaded,
        "sourceColumns": {table: [{"name": name, "type": "TEXT"} for name in names.split()] for table, names in source_columns.items()}}),
                               text=True, capture_output=True, timeout=60, env=env)
    assert completed.returncode == 0, completed.stdout + completed.stderr
    result = json.loads(completed.stdout)
    result["frontend_seconds"] = perf_counter() - start
    result["uploaded"] = uploaded
    return result


def real_ft_pitt_request(uploaded, *, catalog=True, hydrated=True):
    graph = uploaded["hydratedGraph" if hydrated else "graph"]
    tables = [node["table"] for node in graph["nodes"] if node["kind"] == "PHYSICAL_TABLE"]
    rows = uploaded["snapshot"]["mapping_rows"]
    req = STTMBuilderEnvelopeRequest.model_validate({
        "operation": "sttm.auto_map", "data": {"intent": "AUTO_MAP", "attributes": [
            {"target_table": TARGET, "target_attribute": item["target_column"].upper() if catalog else item["target_column"],
             "target_data_type": item["target_type"]} for item in rows]},
        "context": {"source_tables": tables, "relation_graph": graph, "workspace_context": {
            **uploaded["snapshot"], "target_table": TARGET, "source_tables": tables}},
    })
    if hydrated:
        from app.core.automap_fast_context import hydrate_authored_cte_graph
        req = hydrate_authored_cte_graph(req)
    return req


@pytest.mark.parametrize("catalog_names", [True, False])
def test_real_ft_pitt_parser_frontend_graph_baseline(real_ft_pitt_upload, catalog_names):
    req = real_ft_pitt_request(real_ft_pitt_upload, catalog=catalog_names)
    before = req.model_dump(mode="json")
    start = perf_counter()
    result = resolve_authored_targets(req, project_attributes=[])
    elapsed = perf_counter() - start
    print("FTPITT_BASELINE:", json.dumps({"catalog_names": catalog_names, "targets": len(result.targets),
        "preserved": sum(target.status == "definition_preserved" for target in result.targets),
        "pending": dict(Counter(note.code for target in result.targets if target.status == "pending" for note in target.diagnostics)),
        "seconds": elapsed, "frontend_seconds": real_ft_pitt_upload["frontend_seconds"]}))
    assert len(result.targets) == 35
    assert result.mapping_sql == real_ft_pitt_upload["uploaded"]["import_preview"]["sql"]
    assert req.model_dump(mode="json") == before
    assert len(result.pending_attributes) == 0
    assert result.baseline_rows == tuple(req.context.workspace_context.mapping_rows)
    assert len(result.source_mapping_results["DB.TGT.PEOPLE"].mappings) == 35
    graph = req.context.relation_graph
    ctes = {node.original_cte_name: node for node in graph.nodes if node.kind != "PHYSICAL_TABLE"}
    assert len(ctes) == 4
    assert len(graph.nodes) == 10
    assert ctes["ReferralLookup"].parent_relation_ids == [ctes["JimsHH"].relation_id]
    assert [edge.join_type for edge in graph.edges] == ["LEFT"] * 5
    assert [len(edge.conditions) for edge in graph.edges] == [1, 1, 1, 1, 2]
    sql_tree = parse_one(result.mapping_sql, read="snowflake")
    assert len(list(sql_tree.find_all(exp.Union))) == 3
    assert all(union.args["distinct"] for union in sql_tree.find_all(exp.Union))
    assert len(list(sql_tree.find_all(exp.Distinct))) == 2
    for target in result.targets:
        assert target.origin == "authored_sql"
        assert target.requires_authored_query and target.compiler_valid
        assert target.execution_status == "blocked"
        assert set(target.required_relation_ids) == {node.relation_id for node in graph.nodes}
        assert {value.upper() for value in target.unresolved_values} == {
            "$TRANSACTIONFIRMID", "$PARENTOFFICEID", "$LEGACYHHCPREFIX", "$CLIENTSTARTDATE",
            "$HHRECORDTYPE", "$MASTER_PAYOUT_DATE"}
        assert {note.code for note in target.diagnostics} == {"unbound_values"}
    owner = next(target for target in result.targets if target.attribute.target_attribute == ("OWNERID" if catalog_names else "OwnerId"))
    assert owner.definition_sql == "mu.TARGETCRMID"
    assert owner.mapping.source_attributes != [owner.definition_sql]
    assert owner.mapping.source_attributes == owner.baseline_rows[0].source_columns
    assert owner.baseline_rows[0].target_column == "OwnerId"
    assert next(target for target in result.targets if target.attribute.target_attribute == "FINSERV__STATUS__C").mapping.constant_value == "Current Client"


def test_real_ft_pitt_unhydrated_graph_stays_pending(real_ft_pitt_upload):
    req = real_ft_pitt_request(real_ft_pitt_upload, hydrated=False)
    start = perf_counter()
    result = resolve_authored_targets(req)
    print("FTPITT_UNHYDRATED:", json.dumps({"preserved": 35 - len(result.pending_attributes),
        "pending": dict(Counter(note.code for target in result.targets for note in target.diagnostics)),
        "seconds": perf_counter() - start}))
    assert len(result.pending_attributes) == 35
    assert all({note.code for note in target.diagnostics} == {"unknown_column"} for target in result.targets)
    assert result.baseline_rows == tuple(req.context.workspace_context.mapping_rows)


@pytest.mark.parametrize("change, code", [
    ("no_rows", "unbound_target"), ("uppercase_row", "unbound_target"),
    ("different_expression", "baseline_conflict"), ("missing_union_column", "unknown_column"),
    ("changed_union_definition", "unknown_cte"), ("missing_parent", "invalid_graph"),
    ("wrong_output_sql_name", "unknown_cte_output"),
])
def test_real_ft_pitt_does_not_guess_or_skip_cte_evidence(real_ft_pitt_upload, change, code):
    req = real_ft_pitt_request(real_ft_pitt_upload)
    req.data.attributes = [item for item in req.data.attributes if item.target_attribute == "OWNERID"]
    workspace = req.context.workspace_context
    row = next(item for item in workspace.mapping_rows if item.target_column == "OwnerId")
    referral = next(node for node in req.context.relation_graph.nodes if node.original_cte_name == "ReferralLookup")
    if change == "no_rows":
        workspace.mapping_rows = []
    elif change == "uppercase_row":
        row.target_column = "OWNERID"
    elif change == "different_expression":
        row.expression = "'different'"
    elif change == "missing_union_column":
        node = next(node for node in req.context.relation_graph.nodes if node.table and node.table.table == "COUNTRY_CODES")
        node.output_columns = [output for output in node.output_columns if output["name"] != "COUNTRY_ALIAS"]
    elif change == "changed_union_definition":
        referral.sql_text = referral.sql_text.replace("UNION", "UNION ALL")
    elif change == "missing_parent":
        referral.parent_relation_ids = ["nonexistent"]
    elif change == "wrong_output_sql_name":
        node = next(node for node in req.context.relation_graph.nodes if node.original_cte_name == "JimsHH")
        next(output for output in node.output_columns if output["name"] == "LegacyCRMID")["sql_name"] = '"LegacyCRMID"'
    before = req.model_dump(mode="json")
    result = only(req)
    assert_pending(result, code)
    assert req.model_dump(mode="json") == before


@pytest.mark.parametrize("prefix", ["DISTINCT", "distinct /* modifier comment */", "DISTINCT -- modifier comment\n"])
def test_distinct_token_boundary_is_lossless(prefix):
    expression = "case  when src.ID > 0 then 'O''Brien, FROM' else src.NAME end /* exact */"
    sql = f"SELECT {prefix} {expression} AS RESULT FROM DB.SRC.CONTACTS src WHERE src.ID > 0 ORDER BY src.ID LIMIT 3;"
    result = resolve_authored_targets(request(sql=sql))
    target = result.targets[0]
    assert target.status == "definition_preserved"
    assert target.definition_sql.endswith(expression)
    assert deterministic._equivalent(parse_one(target.definition_sql, read="snowflake"), parse_one(expression, read="snowflake"))
    assert result.mapping_sql == sql
    assert target.requires_authored_query


@pytest.mark.parametrize("expression", ["[src.ID, src.OTHER]", "{'first': src.ID, 'second': src.OTHER}"])
def test_projection_commas_inside_brackets_and_braces_are_not_boundaries(expression):
    query = parse_one(f"SELECT DISTINCT {expression} AS RESULT, src.NAME AS NAME FROM DB.SRC.CONTACTS src", read="snowflake")
    sql = f"SELECT DISTINCT {expression} AS RESULT, src.NAME AS NAME FROM DB.SRC.CONTACTS src"
    assert deterministic._projection_texts(sql, query) == [expression, "src.NAME"]


@pytest.mark.parametrize("modifier", ["TOP 5", "DISTINCT TOP 5", "DISTINCT ON (src.ID)"])
def test_unsupported_projection_modifiers_still_fail_closed(modifier):
    result = only(request(sql=f"SELECT {modifier} src.ID AS RESULT FROM DB.SRC.CONTACTS src"))
    assert_pending(result, "unsupported_projection")


@pytest.mark.parametrize("body, code", [
    ("SELECT ID AS ID FROM DB.SRC.CONTACTS UNION SELECT ID AS ID, NAME AS NAME FROM DB.SRC.CONTACTS", "unknown_cte_output"),
    ("SELECT ID AS ID FROM DB.SRC.CONTACTS UNION BY NAME SELECT ID AS ID FROM DB.SRC.CONTACTS", "unsupported_query"),
    ("SELECT ID AS ID FROM DB.SRC.CONTACTS INTERSECT SELECT ID AS ID FROM DB.SRC.CONTACTS", "unsupported_query"),
    ("SELECT ID AS ID FROM DB.SRC.CONTACTS UNION SELECT missing AS ID FROM DB.SRC.CONTACTS", "unknown_column"),
    ("SELECT ID AS ID FROM DB.SRC.CONTACTS UNION SELECT ID AS ID FROM DB.SRC.UNKNOWN", "unknown_relation"),
])
def test_unsupported_or_unproven_union_arm_cannot_be_bypassed(body, code):
    from app.schema.sttm_builder import RelationNode
    req = request(sql=f"WITH selected AS ({body}) SELECT 'fixed' AS RESULT FROM selected")
    req.context.relation_graph.nodes.append(RelationNode(relation_id="selection", kind="CTE", alias="selected", sql_text=body,
        output_columns=[{"name": "ID"}]))
    assert_pending(only(req), code)


@pytest.mark.parametrize("all_keyword", ["", "ALL "])
def test_union_all_branches_and_population_are_preserved(all_keyword):
    from app.schema.sttm_builder import RelationNode
    body = f"SELECT DISTINCT ID AS ID FROM DB.SRC.CONTACTS WHERE ID > 0 UNION {all_keyword}SELECT OTHER AS DIFFERENT_NAME FROM DB.SRC.CONTACTS WHERE OTHER < 0"
    req = request(sql=f"WITH selected AS ({body}) SELECT DISTINCT selected.ID AS RESULT FROM selected")
    req.context.relation_graph.nodes.append(RelationNode(relation_id="selection", kind="CTE", alias="selected", sql_text=body,
        output_columns=[{"name": "ID"}]))
    result = resolve_authored_targets(req)
    assert result.targets[0].status == "definition_preserved"
    assert result.targets[0].required_relation_ids == ("contacts", "selection")
    assert result.mapping_sql == req.context.workspace_context.mapping_sql


@pytest.mark.parametrize("row_changes, code", [
    ({"expression": None, "source_columns": []}, "unbound_target"),
    ({"target_column": "RESULT"}, "unbound_target"),
    ({"expression": "src.NAME"}, "baseline_conflict"),
    ({"source_columns": ["src.NAME"]}, "baseline_conflict"),
])
def test_existing_display_alias_requires_exact_current_binding(row_changes, code):
    current = row(target_column="Result", expression="src.ID")
    current.update(row_changes)
    assert_pending(only(request([current], 'SELECT DISTINCT src.ID AS "Result" FROM DB.SRC.CONTACTS src')), code)


def test_existing_display_alias_with_matching_binding_is_not_sql_identifier_casefold():
    current = row(target_column="Result", expression="src.ID")
    sql = 'SELECT DISTINCT src.ID AS "Result" FROM DB.SRC.CONTACTS src'
    result = only(request([current], sql))
    assert result.status == "definition_preserved"
    assert result.attribute.target_attribute == "RESULT"
    assert result.baseline_rows[0].target_column == "Result"
    assert_pending(only(request(sql=sql)), "unbound_target")
    assert_pending(only(request([current], sql, targets=('"RESULT"',))), "unbound_target")


@pytest.mark.parametrize("other", ['"result"', '"RESULT"', 'RESULT'])
def test_case_distinct_quoted_outputs_cannot_share_one_catalog_target(other):
    sql = f'SELECT src.ID AS "Result", src.NAME AS {other} FROM DB.SRC.CONTACTS src'
    assert_pending(only(request([row(target_column="Result", expression="src.ID")], sql)), "ambiguous_target")


@pytest.mark.parametrize("token, constant", [("'NULL'", "NULL"), ("'null'", "null"), ("''", ""), ("' padded '", " padded ")])
def test_distinct_literal_value_row_cannot_be_misrepresented(token, constant):
    sql = f'SELECT DISTINCT {token} AS "Result" FROM DB.SRC.CONTACTS src'
    current = row(target_column="Result", mapping_mode="constant", constant_value=constant, rule="Value")
    result = resolve_authored_targets(request([current], sql))
    assert result.targets[0].status == "pending"
    assert result.targets[0].mapping is None
    assert result.baseline_rows[0].constant_value == constant
    assert result.mapping_sql == sql


@pytest.mark.parametrize("token", ["'NULL'", "'null'", "''", "' padded '", "CURRENT_TIMESTAMP()"])
def test_source_free_custom_scalars_are_marked_baseline_only(token):
    sql = f'SELECT DISTINCT {token} AS RESULT FROM DB.SRC.CONTACTS src'
    result = only(request(sql=sql))
    assert result.status == "definition_preserved"
    assert result.mapping.preprocessing_rule == token
    assert result.mapping.constant_value is None
    assert result.mapping.source_attributes == []
    assert result.requires_authored_query
    assert {note.code for note in result.diagnostics} == {"baseline_only_scalar"}


def test_physical_sql_name_cannot_override_exact_catalog_column():
    req = request(sql="SELECT DISTINCT src.MISSING AS RESULT FROM DB.SRC.CONTACTS src")
    req.context.relation_graph.nodes[0].output_columns = [{"name": "ID", "sql_name": "MISSING"}]
    assert_pending(only(req), "unknown_column")
