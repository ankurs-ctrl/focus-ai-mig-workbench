# Combined release verification — 13 November 2026

## v4 publication and Deep Agent authentication follow-up

Latest verification: the full backend run had **5,751 passed, 32 skipped** and one admission assertion expecting only HELD. The production coordinator also conservatively protects an active timed-out call as QUARANTINED. The assertion now accepts either non-free state and explicitly checks its retained owner/job. The complete admission/publication/worker-authentication rerun passed **157 tests**. There are no remaining failing assertions from that run; this is reported as a full run plus corrected focused rerun, not a second all-green full-suite invocation. Deployment/rendering regression suite: **291 passed, 4 skipped**; final OAuth/worker checks: **31 passed**. All **482 frontend checks** passed. Two shell deployers passed bash syntax checks; all three PowerShell deployers parsed. Mapping-agent specification hashes verified.

Native test: read-only SELECT EXPLAIN, one scratch metadata definition, zero target rows; two independent refresh connections, exactly one synthetic provider exchange. No grants, roles, actual user OAuth session or business objects changed. The mounted SPCS-token path and denied-target-DML publication behavior are offline regression checks, not a claimed new SPCS deployment.

Read `PUBLICATION-DEEP-AUTH.md` first for the latest changes and deployment steps. Publication validates SELECT only and writes definitions to metadata; target INSERT grants are not required. Deep housekeeping uses explicit SPCS service identity while user work reuses the app OAuth session. Existing Deep flags now reach the backend through all supported deployment scripts. Apply the existing Deep migrations if not installed, retain shared OAuth secret mappings and rebuild matching images. No new OAuth credential or production schema migration is introduced by v4. `PUBLICATION-OAUTH-RESULTS.json` records the accepted isolated native checks and their limits.


## v3 cached-preparation release

Read [CACHED-PREPARATION.md](CACHED-PREPARATION.md) and [CACHED-PREPARATION-RESULTS.json](CACHED-PREPARATION-RESULTS.json) for the latest actual prepare/job/private-worker acceptance. Both Loan Income runs began with null execution context and completed: 32 supported proposals plus one explicit missing dependency per run, numeric confidence throughout, 5 source submissions per run and 4/3 transformation submissions. Persisted server snapshots and preparation proofs were independently checked. The first run’s 32 definitions compiled together and previewed three rows with LIMIT 5. Times were 200.72 and 223.70 seconds. This replaces the earlier manually seeded worker acceptance as evidence of the preparation path.

Final backend suite: **5,737 passed, 32 skipped**, 326.48 seconds, including SQL-upload/preview/publication, confidence/FIR, administration and Deep Agent regressions. Additional final preparation/authorization/OAuth checks: **35 passed** (including a later browser-proof regression). Frontend: **482 passed** across all scripts, plus final TypeScript verification. The 32 skipped backend cases remain opt-in/environment-specific tests, not claimed as executed.

The first full run exposed three obsolete test stubs that bypassed context attachment and two sandbox-blocked UDP tests. Stubs now exercise real attachment with only persistence mocked; UDP tests passed with loopback access. The complete corrected-environment suite passed.

The v3 follow-up adds no production table, new environment variable or agent instruction. No client job was replayed, client mapping changed, remote branch pushed or new SPCS image deployed. Local endpoint concurrency is verified; fresh SPCS deployment and the 140-second performance target remain unverified.

The sections below retain earlier cumulative-release evidence and its explicit limitations.

## Auto-map correctness

The latest completed mixed acceptance returned **40/40 valid definitions**, confidence **0.79–0.95**, with expected Snowflake output values matching for all three synthetic rows. It exercised twelve sources, five parallel source batches of eight targets, five actual source model POSTs and two actual transformation POSTs. There were zero failed batches and zero occupied execution slots afterward. FIR was cited/reused; direct columns, direct Firm Value assignment, intentional SQL NULL, column-plus-Value custom SQL and Value-only CASE rules were all present.

Elapsed mapping runtime was **184.40 seconds**, excluding 50.25 seconds creating the isolated fixture and test agents. An earlier normal-policy run passed at 179.82 seconds. The 120–140-second performance target and a new SPCS deployment are not claimed as passed. Context sizes fit both the existing 180,000-character and UTF-8-byte limits. No extra evidence-review model call was submitted.

The 184.40-second run used an additional strict wiring assertion requiring both agents to retrieve native evidence even when initial evidence was complete. Transformation retrieval returned one complete FIR record (2,412 bytes). Source retrieval was skipped. Consequently the **overall strict-tool test is recorded as failed**, while the independent mapping/SQL/confidence checks all passed. This distinction is preserved in `NATIVE-MAPPING-RESULTS.json`; the failed assertion is not relabeled as a fully passing acceptance.

A further normal-policy run and a small source-tool test were blocked by Snowflake `CREDIT_LIMIT` (native code 90073) before completion. Source-agent native retrieval with a deliberate evidence gap therefore remains unverified in this release. Complete initial packets work without it. The normal-policy run did not produce a new accepted result or a retained live review fixture. No client mappings were modified.

Representative returned definitions:

| Target | Definition | Estimated mapping confidence | Route |
| --- | --- | --- | --- |
| ID | `src."ID"` | 0.95 | direct |
| DISPLAY_NAME | `$FirmPrefix || COALESCE(TRIM(src.NAME), 'Unknown')` | 0.90 | rule complete |
| FIRM_VALUE | approved `$FirmPrefix` | 0.95 | Value |
| VALUE_CASE | `CASE WHEN $FirmPrefix = 'TEST-' THEN 'Test firm' ELSE 'Other firm' END` | 0.90 | rule complete |
| OWNERNAME | intentional SQL `NULL` | 0.79 | Value |

Confidence is an estimate for human review. The response retains original source-model and specialist scores separately, plus backend evidence estimates/caps and provenance. It is not an execution approval or a calibrated probability.

## Automated checks

- Combined backend core/runtime/preflight/job suite: **5,416 passed, 31 skipped** on the initial combined run. Six remaining tests were blocked by sandbox UDP access or a missing test-only JSON Schema dependency. Their corrected-environment rerun, including new regressions: **79 passed**. No known failing assertion remains from that suite.
- Final prepared-context/preflight/job regression run after the authored-SQL dependency fix: **409 passed**.
- Original Auto-map full run: 4,800 passed with two obsolete four-target batch assertions; the corrected focused run: **94 passed**.
- All **35 frontend regression scripts** passed across the complete run and the corrected scope rerun (51 scope checks). These include SQL-upload recovery/preview, mapping preservation, confidence/candidates, administration-related integration contracts and Deep Agent composer/results.
- TypeScript passed; production frontend `next build --webpack` passed. Installed dependencies are outside this worktree, so webpack was used for the local build. Built assets are excluded from the overlay.
- Agent specification manifest verified. Offline checks cover exact citation normalization, complete/multibyte context budgeting and subdivision, per-target specialist isolation, confidence fallback, semantic gaps, fenced contention/recovery and native tool scope/response parsing.

## Deep Agent and packaging

All 206 files from the supplied Deep Agent ZIP are included. The seven shared files are merged with Auto-map changes; the other 199 match the supplied ZIP after newline normalization. Existing DataHub settings were restored because its unchanged adapter still reads them. Dedicated regression checks cover this shared configuration boundary.

The supplied Deep Agent verification document retains the team's earlier native acceptance evidence. This combined release reran its automated checks but did not perform a fresh native Deep Agent business workflow. Apply its dependency lock, additive migrations, model settings and worker enablement as described in `INSTALL.md` and the original deployment notes.

The cumulative overlay is relative to the supplied client ZIP, preserves every file from the prior combined Auto-map overlay, and excludes environment files, credentials, private keys, installed dependencies and runtime locks. No CodeCommit branch push or SPCS deployment was performed for this package.
