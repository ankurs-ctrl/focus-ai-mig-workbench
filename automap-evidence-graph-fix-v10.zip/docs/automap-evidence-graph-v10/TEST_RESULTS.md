# V10 offline verification

## Final results

- **2,442 backend tests passed**, zero failures/errors/skips, in **167.62 seconds** across the final 46-file selected suite. JUnit totals independently checked.
- **All 20 frontend harnesses passed** individually. The new V10 harness executes the real default thunk, request metadata, partial/terminal reducers and acceptance thunk. Its 40 checks include 29 shared preservation checks; overlapping harness counts are not added together.
- TypeScript no-emit validation passed with no diagnostics. CRLF-aware Git whitespace validation passed.
- Pytest collection used the source IDs without in-memory changes: **2,442 collected**, longest remaining node ID **3,099 characters**. The two formerly enormous V9 suffix IDs are now under 200 characters each, while the literal test inputs/assertions remain unchanged. The collected suite was run unchanged locally; an actual Windows/AVD run remains the client's verification.
- ZIP entries, all manifest SHA-256 hashes, archive integrity, Windows ZIP entry metadata and byte parity are checked during packaging. ZIP SHA-256 is supplied separately.

## New V10 regression controls

- All root/data combinations of absent/canonical/enum/short source-agent labels; mixed supported aliases normalize to one source identity. Missing, unknown, malformed and transformation-agent labels remain rejected.
- Alias normalization combined with nested delegation, conflicting results, explicit failure, extra fact fields and fabricated quotes stays fail-closed.
- Each of the three supported identities is exercised through the owning guarded model runtime. Each block is reviewed once, the mapping-decision call runs, a validated mapping is returned and fake-runtime permits are free.
- A 37-target frontend control with an existing source mapping, an empty constant and a project attribute produces **34 new mappings and three queued replacements**. All originals remain intact, with partial/terminal replay and both explicit acceptance actions tested.
- A separate backend control verifies all 37 targets enter pending reevaluation and review totals distinguish 34 new results from three replacements.
- Unresolved results retain all three originals/statuses and alternatives. Originally unproven/UNMAPPED definitions stay unproven until acceptance. Explicit preserve-only compatibility behavior still does not certify an invalid baseline.
- Checkbox scope, saved edits during a default run, stale proposals, current Values, and unsupported reevaluation (no POST or silent preserve fallback) remain covered.

## Verification scope

The included V9 regression module continues to exercise:

- Explicit normal-v1, legacy and matching duplicate block envelopes; malformed status/agent/result/error/action/artifact/metadata/fact cases remain rejected.
- Naturally generated null lineage bindings from a selected CTE plus cached semantic relation, at 1/10/37 targets with a 600-column parent. Cached/hidden parent columns remain nonselectable.
- Large primary-key elimination lists as typed, exact optional nodes, confirmed key metadata retained, unknown roots/bindings rejected, identical mandatory text retained, and explicit optional-root navigation through the owning guarded runtime.
- Real parent preparation, frozen restore, proxy wire, same-caller governance and four workers processing 37 targets with normal review envelopes, plus separate guarded source/specialist calls and compiled transformation expressions. Model/HTTP/Snowflake boundaries are fake.
- Actual frontend reducers with complete pending reevaluation diagnostics, partial/terminal replay, mapped source/empty-constant/project-attribute rows and originally unmapped definitions. Existing fields/status remain unchanged until explicit replacement acceptance. Unproven non-reevaluation baselines remain unproven.
- Actual completion-state counts, older/unchecked proposal exclusion, chat-opening review actions and the single checked/all Auto-map sidebar action.
- Long delimiter-free text factoring with exact ASCII/Unicode/SQL reassembly and large-target complete-message packing attempt bounds.

V8's stale-proposal, unresolved-acceptance, alternative-preservation, literal-quote, strict envelope, call fencing, uncertain transport, permit quarantine, SQL/CTE scope and project Values tests remain included.

These fixtures are synthetic except the existing authored Ft. Pitt SQL/frontend processing fixture with its explicit limited offline catalog. They are not exports of live mapping 3001, 3101 or a 996k-character request. A completed offline four-worker control does not establish actual model reasoning accuracy, Snowflake compilation or client runtime latency.

No live UAT, actual provider, browser or Snowflake acceptance occurred here. No local Docker build, commit, push, shared-agent edit, mapping publication or target loading occurred. The real pinned @noble/hashes 1.8.0 implementation is used; no crypto substitute is installed in the harness. No test threshold, deadline, permit count or output limit is raised to pass the suite.

## Windows AVD repeat commands

From the repository root using the existing pinned Python/frontend dependencies:

```powershell
$env:PYTHONPATH = "services/sttm-builder"
$files = @(
  Get-ChildItem services/sttm-builder/tests/unit/core/test_automap*.py
  Get-ChildItem services/sttm-builder/tests/unit/core/test_sql_upload*.py
  Get-ChildItem services/sttm-builder/tests/test_automap*.py
  Get-Item services/sttm-builder/tests/unit/core/test_auto_mapping_proxy.py
  Get-Item services/sttm-builder/tests/unit/core/test_render_spcs_spec.py
  Get-Item services/sttm-builder/tests/unit/core/test_parallel_uat_ci.py
) | Sort-Object FullName -Unique | ForEach-Object FullName
python -m pytest -q --durations=8 $files
python -m pytest -q services/sttm-builder/tests/unit/core/test_automap_client_v10.py services/sttm-builder/tests/unit/core/test_automap_client_v9.py
Get-ChildItem frontend/scripts/test-*.cjs | ForEach-Object {
  node $_.FullName
  if ($LASTEXITCODE -ne 0) { throw "Frontend harness failed: $($_.Name)" }
}
Push-Location frontend
npm exec tsc -- --project tsconfig.json --noEmit --incremental false
Pop-Location
git -c core.whitespace=cr-at-eol diff --check
```

Local verification toolchain: Python 3.11, SQLGlot 30.12.0, the existing installed frontend dependencies and PowerShell 7.5 for spec/CI rendering tests. Local dependency symlinks, toolchain adapters, runner paths, caches and raw test output are excluded from the ZIP. The separate deployment environment-wrapper module with earlier unchanged-baseline macOS failures is outside this selected suite; deployment scripts were not rewritten to hide them.

## Client acceptance

Rebuild/update both frontend/web and Auto-map workers together through the existing client pipeline. Preflight receipt version is `fast-target-preflight-v5-typed-evidence`; use fresh controlled jobs after rollout. Never blindly replay an uncertain remote POST.

1. Fresh manual mapping: 37 targets / four planned batches, agent decisions reached, report actual proposals and unresolved reasons. Inspect archived ownership, normal envelopes and message/byte sizes. Primary-key elimination must not remove selectable mapping candidates.
2. Fresh SQL upload: reproduce the full original request, inspect CTE proof/output identifiers and parent scope, and verify preparation proceeds past null metadata bindings without selecting hidden fields.
3. Checked single/multiple targets: only checked targets processed; none checked explicitly reevaluates all, retaining existing definitions until replacement acceptance.
4. Checked existing mapping reevaluation: progress/status unchanged before acceptance, queued replacement shown and reachable through Review proposals. Reject/accept or edit while the run is active; stale results must not overwrite later edits. Repeat for empty constants and project attributes.
5. A target requiring a genuine complex rule: confirm AGT_TRANSFORMATION_RULE was called, selected/alternative bindings are grounded, generated rule compiles and matches intended business/population logic. Direct bindings chosen by a small test do not validate this path.
6. Failed or optional evidence reads: explicit unresolved reason, verified alternatives retained, valid siblings preserved, coverage honest and permits correctly released/quarantined.

Mapping 3101's already persisted incorrect UNMAPPED status is not automatically certified as MAPPED by this patch. Restore/validate its known saved definition through the normal workflow or start a controlled copy. No replacement must be accepted merely to repair the historical display issue.
