-- ============================================================
-- SP_FIR_PRECOMPUTE_PERMUTATIONS
-- Discovers all meaningful table combinations from semantic views
-- and invokes AGT_FIR_SYSTEM for proactive recommendation generation.
-- Only generates permutations for tables with actual relationships
-- at MEDIUM+ confidence — NOT blind N² enumeration.
-- ============================================================

CREATE OR REPLACE PROCEDURE __STTM_METADATA_NAMESPACE__.SP_FIR_PRECOMPUTE_PERMUTATIONS(
    "OPTIONS" VARIANT DEFAULT NULL
)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.12'
PACKAGES = ('snowflake-snowpark-python')
HANDLER = 'precompute_permutations'
EXECUTE AS CALLER
AS
$$
import json
import _snowflake
from datetime import datetime


def _current_namespace(session):
    row = session.sql("SELECT CURRENT_DATABASE() AS DB, CURRENT_SCHEMA() AS SCH").collect()[0]
    return str(row['DB']), str(row['SCH'])


def _get_all_semantic_views_with_relationships(session, namespace):
    """Get all tables with active semantic views and extract FK relationships
    from semantic_model.attributes[].constraints (the actual data structure)."""
    rows = session.sql(f"""
        SELECT
            FQN,
            TABLE_NAME,
            SCHEMA_NAME,
            DATABASE_NAME,
            COALESCE(SEMANTIC_VIEW:semantic_level::STRING, 'L1_CONTEXT') AS SEMANTIC_LEVEL,
            SEMANTIC_VIEW:semantic_model:attributes AS ATTRIBUTES,
            SEMANTIC_VIEW:relationships AS TOP_RELATIONSHIPS,
            COLUMN_COUNT,
            ROW_COUNT
        FROM {namespace}.SEM_TABLE_VIEWS
        WHERE STATUS = 'ACTIVE'
        ORDER BY SCHEMA_NAME, TABLE_NAME
    """).collect()
    results = []
    for row in rows:
        # Extract FK relationships from attributes constraints
        rels = []
        attrs = row['ATTRIBUTES']
        if isinstance(attrs, str):
            try:
                attrs = json.loads(attrs)
            except Exception:
                attrs = []
        if isinstance(attrs, list):
            for attr in attrs:
                constraints = attr.get('constraints', []) if isinstance(attr, dict) else []
                for c in constraints:
                    if isinstance(c, dict) and c.get('type') == 'FOREIGN_KEY':
                        confidence = c.get('confidence', 'LOW')
                        refs = c.get('references', {})
                        if refs.get('table'):
                            rels.append({
                                'related_table': refs['table'],
                                'related_column': refs.get('column'),
                                'source_column': attr.get('name'),
                                'confidence': confidence,
                            })

        # Also check top-level relationships if present
        top_rels = row['TOP_RELATIONSHIPS']
        if isinstance(top_rels, str):
            try:
                top_rels = json.loads(top_rels)
            except Exception:
                top_rels = []
        if isinstance(top_rels, list):
            rels.extend(top_rels)

        results.append({
            'fqn': row['FQN'],
            'table_name': row['TABLE_NAME'],
            'schema_name': row['SCHEMA_NAME'],
            'database_name': row['DATABASE_NAME'],
            'semantic_level': row['SEMANTIC_LEVEL'],
            'relationships': rels,
            'column_count': row['COLUMN_COUNT'],
            'row_count': row['ROW_COUNT'],
        })
    return results


def _get_document_table_learnings(session, namespace):
    """Query TBL_WORKBENCH_CLIENT_SQL_ASSETS for active documents and extract
    table references, join patterns, CTE patterns, and transformations from
    the ATTRIBUTES JSON column."""
    rows = session.sql(f"""
        SELECT
            SQL_ASSET_ID,
            TITLE,
            ATTRIBUTES
        FROM {namespace}.TBL_WORKBENCH_CLIENT_SQL_ASSETS
        WHERE STATUS = 'active'
          AND ATTRIBUTES IS NOT NULL
        ORDER BY UPDATED_AT DESC
        LIMIT 50
    """).collect()

    learnings = []
    for row in rows:
        attrs = row['ATTRIBUTES']
        if isinstance(attrs, str):
            try:
                attrs = json.loads(attrs)
            except Exception:
                continue
        if not isinstance(attrs, dict):
            continue

        source_tables = attrs.get('source_tables', [])
        join_patterns = attrs.get('join_patterns', [])
        cte_patterns = attrs.get('ctes', [])
        transformations = attrs.get('transformations', [])

        if not source_tables and not join_patterns:
            continue

        learnings.append({
            'asset_id': row['SQL_ASSET_ID'],
            'filename': row['TITLE'],
            'tables': source_tables if isinstance(source_tables, list) else [],
            'join_patterns': join_patterns if isinstance(join_patterns, list) else [],
            'ctes': cte_patterns if isinstance(cte_patterns, list) else [],
            'transformations': transformations if isinstance(transformations, list) else [],
        })

    return learnings


def _extract_meaningful_combinations(tables):
    """Find all meaningful table combinations based on FK relationships.

    Relationships come from semantic_model.attributes[].constraints FK references.
    The related_table is just a table name (not FQN), so we match by table_name
    within the same schema/database.
    """
    table_map = {t['fqn']: t for t in tables}
    # Build name lookup: table_name -> list of FQNs (same schema preferred)
    name_to_fqns = {}
    for t in tables:
        name_to_fqns.setdefault(t['table_name'].upper(), []).append(t)

    pairs = set()

    for table in tables:
        for rel in table.get('relationships', []):
            related_name = (rel.get('related_table') or rel.get('right_table') or '').upper()
            confidence = (rel.get('confidence') or 'LOW').upper()
            if confidence not in ('HIGH', 'MEDIUM'):
                continue
            if not related_name:
                continue

            # Find matching table by name (prefer same schema)
            candidates = name_to_fqns.get(related_name, [])
            matched = None
            for c in candidates:
                if c['fqn'] == table['fqn']:
                    continue
                if c['schema_name'] == table['schema_name'] and c['database_name'] == table['database_name']:
                    matched = c
                    break
            if not matched and candidates:
                matched = next((c for c in candidates if c['fqn'] != table['fqn']), None)

            if matched:
                pair_key = tuple(sorted([table['fqn'], matched['fqn']]))
                pairs.add(pair_key)

    pair_list = [
        {'table_a': p[0], 'table_b': p[1]}
        for p in pairs
    ]

    # Build adjacency graph for multi-table groups
    adjacency = {}
    for p in pairs:
        adjacency.setdefault(p[0], set()).add(p[1])
        adjacency.setdefault(p[1], set()).add(p[0])

    groups = []
    for table_fqn, neighbors in adjacency.items():
        if len(neighbors) >= 2:
            group_tables = sorted([table_fqn] + list(neighbors))
            if len(group_tables) <= 5:
                groups.append(group_tables)

    seen_groups = set()
    unique_groups = []
    for g in groups:
        key = tuple(g)
        if key not in seen_groups:
            seen_groups.add(key)
            unique_groups.append(g)

    return pair_list, unique_groups


def _check_existing_recommendations(session, namespace, table_fqns):
    """Check if recommendations already exist for these tables to avoid duplicates."""
    fqn_array = "ARRAY_CONSTRUCT(" + ",".join(f"'{fqn}'" for fqn in table_fqns) + ")"
    rows = session.sql(f"""
        SELECT COUNT(*) AS CNT
        FROM {namespace}.TBL_FIR_AGENT_RECOMMENDATIONS
        WHERE STATUS = 'active'
          AND ARRAYS_OVERLAP(APPLICABLE_TABLES, {fqn_array})
          AND CREATED_AT > DATEADD('day', -7, CURRENT_TIMESTAMP())
    """).collect()
    return rows[0]['CNT'] if rows else 0


def _invoke_fir_agent_for_precomputation(session, db, schema, precompute_payload):
    """Invoke AGT_FIR_SYSTEM with pre-computation context."""
    agent_message = {
        'task_type': 'semantic_precomputation',
        'streams_with_data': ['STM_FIR_SEM_TABLE_VIEWS'],
        'pending_counts': {},
        'unprocessed_documents': [],
        'activity_summary': {},
        'batch_size': 50,
        'processing_options': {
            'collect_feedback': False,
            'generate_inferences': True,
            'create_semantic_versions': False,
            'generate_recommendations': True,
            'apply_decay': False,
            'parse_documents': False,
            'precompute_recommendations': True,
        },
        'precomputation_context': precompute_payload,
        'instructions': (
            'This is a SEMANTIC PRE-COMPUTATION run. Your job is to generate proactive '
            'recommendations for the table combinations provided. For each table pair or group, '
            'generate recommendations covering: '
            '1. Single table selected: table meaning, related tables, possible targets, business context '
            '2. Table pairs with relationships: explain relationship, confidence, join patterns '
            '3. Multi-table groups: derived source suggestions with business meaning '
            '4. Source-to-target combinations: automapping hints, preprocessing rules '
            '5. Q&A pairs: common questions users would ask about these tables '
            'Use SearchFIRRecommendations to avoid duplicates. '
            'Set APPLICABLE_TABLES on each recommendation so it triggers at the right time. '
            'CRITICAL: For every APP_USER_NOTIFICATION recommendation, you MUST provide a '
            'display_message that is clear, conversational, and actionable. Never pass None. '
            'Example: "FACT_SALES joins to ORDER_DIM via ORDER_KEY. This is the primary '
            'fact-dimension link in this star schema — consider adding ORDER_DIM for date/shipping context." '
            'Also provide display_options with at least: '
            '[{"id":"useful","label":"Looks useful"},{"id":"dismiss","label":"Not relevant"}] '
            'The precomputation_context includes document_context from uploaded SQL scripts. '
            'Use these to connect document learnings with table relationships: '
            '- If a document shows TABLE_A JOIN TABLE_B, create recommendations for that pair '
            '- If a document has CTEs combining multiple tables, create derived_source_suggestion recs '
            '- Set applicable_tables to the FULL FQNs so they connect when users select those tables '
            'CRITICAL: Every APP_USER_NOTIFICATION must have a non-empty display_message. '
        ),
    }

    agent_payload = {
        'models': {'orchestration': 'claude-sonnet-4-6'},
        'messages': [
            {
                'role': 'user',
                'content': [{'type': 'text', 'text': json.dumps(agent_message)}]
            }
        ],
        'stream': False
    }

    response = _snowflake.send_snow_api_request(
        'POST',
        f'/api/v2/databases/{db}/schemas/{schema}/agents/AGT_FIR_SYSTEM:run',
        {},
        {},
        agent_payload,
        None,
        600000  # 10 minute timeout for comprehensive pre-computation
    )
    return response


def precompute_permutations(session, options=None):
    """Discover meaningful table combinations and invoke FIR for pre-computation."""
    db, schema = _current_namespace(session)
    namespace = f"{db}.{schema}"

    result = {
        'status': 'success',
        'started_at': datetime.utcnow().isoformat(),
        'tables_with_views': 0,
        'meaningful_pairs': 0,
        'table_groups': 0,
        'recommendations_skipped': 0,
        'agent_invocations': 0,
        'errors': [],
    }

    opts = {}
    if options:
        if isinstance(options, str):
            try:
                opts = json.loads(options)
            except Exception:
                pass
        else:
            opts = dict(options) if options else {}

    max_pairs_per_batch = opts.get('max_pairs_per_batch', 10)
    skip_if_recent = opts.get('skip_if_recent_days', 7)

    # Allow overriding where to read semantic views from
    sem_views_ns = opts.get('semantic_views_namespace', namespace)
    tables = _get_all_semantic_views_with_relationships(session, sem_views_ns)
    result['tables_with_views'] = len(tables)

    if not tables:
        result['status'] = 'no_semantic_views'
        return result

    # Merge document learnings from TBL_WORKBENCH_CLIENT_SQL_ASSETS
    document_learnings = _get_document_table_learnings(session, namespace)
    result['document_learnings_count'] = len(document_learnings)

    # Build a set of existing table FQNs and names for lookup
    existing_fqns = {t['fqn'].upper() for t in tables}
    existing_names = {t['table_name'].upper() for t in tables}

    for doc in document_learnings:
        # Add tables mentioned in documents but NOT in semantic views
        for tbl_ref in doc.get('tables', []):
            tbl_name = tbl_ref.upper() if isinstance(tbl_ref, str) else ''
            if not tbl_name:
                continue
            # Check if this table (by name or FQN) is already known
            if tbl_name not in existing_fqns and tbl_name.split('.')[-1] not in existing_names:
                # Determine if it looks like an FQN (has dots)
                parts = tbl_name.split('.')
                if len(parts) == 3:
                    db_part, sch_part, tbl_part = parts
                else:
                    tbl_part = parts[-1]
                    sch_part = ''
                    db_part = ''
                tables.append({
                    'fqn': tbl_name if len(parts) == 3 else tbl_name,
                    'table_name': tbl_part,
                    'schema_name': sch_part,
                    'database_name': db_part,
                    'semantic_level': 'DOCUMENT_REFERENCED',
                    'relationships': [],
                    'column_count': None,
                    'row_count': None,
                })
                existing_fqns.add(tbl_name)
                existing_names.add(tbl_part)

        # For join patterns in documents, add as relationships (pairs)
        for jp in doc.get('join_patterns', []):
            if isinstance(jp, dict):
                left = (jp.get('left_table') or jp.get('table_a') or '').upper()
                right = (jp.get('right_table') or jp.get('table_b') or '').upper()
                if left and right:
                    # Find or create entries for these tables and add relationship
                    for t in tables:
                        if t['fqn'].upper() == left or t['table_name'].upper() == left.split('.')[-1]:
                            t['relationships'].append({
                                'related_table': right.split('.')[-1],
                                'related_column': jp.get('join_column'),
                                'source_column': jp.get('source_column'),
                                'confidence': 'MEDIUM',
                            })
                            break

    pairs, groups = _extract_meaningful_combinations(tables)
    result['meaningful_pairs'] = len(pairs)
    result['table_groups'] = len(groups)

    if not pairs and not groups:
        result['status'] = 'no_relationships_found'
        return result

    batch_payload = {
        'tables': [
            {
                'fqn': t['fqn'],
                'table_name': t['table_name'],
                'schema_name': t['schema_name'],
                'semantic_level': t['semantic_level'],
                'column_count': t['column_count'],
            }
            for t in tables
        ],
        'pairs': [],
        'groups': groups[:5],
        'document_context': [
            {
                'filename': doc['filename'],
                'tables': doc['tables'],
                'join_patterns': doc['join_patterns'],
                'ctes': doc['ctes'],
            }
            for doc in document_learnings[:10]
        ],
    }

    for pair in pairs[:max_pairs_per_batch]:
        table_fqns = [pair['table_a'], pair['table_b']]
        existing = _check_existing_recommendations(session, namespace, table_fqns)
        if existing > 3:
            result['recommendations_skipped'] += 1
            continue
        batch_payload['pairs'].append(pair)

    if not batch_payload['pairs'] and not batch_payload['groups']:
        result['status'] = 'all_skipped_recent_exists'
        return result

    try:
        response = _invoke_fir_agent_for_precomputation(session, db, schema, batch_payload)
        result['agent_invocations'] = 1
        if response:
            status_code = response.get('status', 0)
            if status_code not in (200, 201):
                result['errors'].append(f'Agent HTTP {status_code}')
    except Exception as e:
        result['errors'].append(str(e))
        result['status'] = 'partial'

    result['completed_at'] = datetime.utcnow().isoformat()
    return result
$$;
