"""Infer cross-mapping dependencies for a multi-target migration plan.

Target schemas often declare no keys (Salesforce-style loads link records by
columns such as HOUSEHOLD__C or ACCOUNTID), so ordering evidence must come from
what earlier mappings actually did. Rules, strongest first:

1. A declared foreign key between two requested targets        -> 0.95
2. A governed FIR dependency learning naming both targets       -> 0.85
3. Old mappings built a consumer reference column and a
   producer identifier column from the same source key column   -> 0.75
4. Only the column name suggests the producer                   -> 0.50

Rules 1-3 become column-scoped scheduler edges: only the dependent column
waits for the producer's mapped key, every other column runs in parallel.
Rule 4 is never an edge; it is returned as a candidate for the plan's review
list because a name alone cannot establish a crosswalk.
"""
from __future__ import annotations

import re
from typing import Any

_IDENTITY = re.compile(r"(^ID$|_ID$|ID__C$|SOURCESYSTEMID|EXTERNAL_?ID|LEGACY_?ID|_KEY$|^KEY$)")
_EDGE_THRESHOLD = 0.75


def _leaf(table: str) -> str:
    return str(table or "").strip('"').split(".")[-1].upper()


def _name_tokens(table: str) -> set[str]:
    """HOUSEHOLD -> {HOUSEHOLD}; BIZ_ACCOUNTS -> {ACCOUNT, ACCOUNTS}; PERSONACCOUNT -> {PERSONACCOUNT}."""
    leaf = _leaf(table)
    tokens = {leaf}
    parts = [part for part in leaf.split("_") if part and part not in {"BIZ", "TBL", "DIM", "FACT", "STG"}]
    tokens.update(parts)
    tokens.update(part[:-1] for part in parts if part.endswith("S") and len(part) > 3)
    return {token for token in tokens if len(token) >= 4}


def _is_identity(column: str) -> bool:
    return bool(_IDENTITY.search(column.upper()))


def _references(column: str, token: str) -> bool:
    """HOUSEHOLD__C, FINSERV__HOUSEHOLD__C, ACCOUNTID reference; HOUSEHOLD_TYPE__C does not."""
    return bool(re.search(rf"(?:^|_){re.escape(token)}(?:ID|_ID|__C|_KEY)$", column.upper()))


def _source_key(value: str) -> str:
    """Compare source columns by TABLE.COLUMN; databases differ across environments."""
    parts = str(value or "").strip('"').upper().split(".")
    return ".".join(parts[-2:]) if len(parts) >= 2 else parts[-1]


def _edge(consumer: dict[str, Any], consumer_column: str, producer: dict[str, Any], producer_column: str,
          *, evidence_id: str, confidence: float, rule: str) -> dict[str, Any]:
    return {
        "consumer_mapping": consumer["mapping_key"],
        "producer_mapping": producer["mapping_key"],
        "producer_output": f"{producer['mapping_key']}:{producer_column}",
        "producer_columns": [producer_column],
        "consumer_columns": [consumer_column],
        "blocking_scope": "column",
        "required_producer_stage": "mapped",
        "required": True,
        "evidence_id": evidence_id,
        "confidence": confidence,
        "dependency_type": "ARTIFACT_CONTRACT",
        "_rule": rule,
    }


def infer_mapping_dependencies(
    specs: list[dict[str, Any]],
    *,
    target_columns: dict[str, list[str]],
    precedent_lineage: dict[str, list[dict[str, Any]]] | None = None,
    fir_cards: dict[str, list[dict[str, Any]]] | None = None,
    target_foreign_keys: dict[str, list[dict[str, str]]] | None = None,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Return (scheduler edges, low-confidence candidates) for the given specs.

    `specs` need `mapping_key` and `target_table`. `target_columns` maps an
    upper-case target FQN to its contract column names. `precedent_lineage`
    maps a target FQN to precedent entries carrying `column_lineage`
    ({TARGET_COLUMN: [SOURCE.TABLE.COLUMN, ...]}), `sttm_id` and `sttm_status`.
    """
    by_target = {str(spec["target_table"]).strip('"').upper(): spec for spec in specs}
    columns_by_target = {
        target: {str(column).upper(): str(column) for column in columns}
        for target, columns in target_columns.items()
    }
    lineage_by_target: dict[str, dict[str, tuple[set[str], str, float]]] = {}
    for target, entries in (precedent_lineage or {}).items():
        merged: dict[str, tuple[set[str], str, float]] = {}
        for entry in entries or []:
            status = str(entry.get("sttm_status") or "").upper()
            # An in-progress precedent is weaker evidence than a finished one.
            weight = 0.75 if status in {"COMPLETE", "COMPLETED", "PUBLISHED", "APPROVED"} else 0.7
            for column, sources in dict(entry.get("column_lineage") or {}).items():
                keys = {_source_key(value) for value in sources or [] if value}
                if keys and column.upper() not in merged:
                    merged[column.upper()] = (keys, str(entry.get("sttm_id") or "precedent"), weight)
        lineage_by_target[target.strip('"').upper()] = merged

    edges: dict[tuple[str, str], dict[str, Any]] = {}
    candidates: list[dict[str, Any]] = []

    def offer(edge: dict[str, Any]) -> None:
        key = (edge["consumer_mapping"], edge["consumer_columns"][0])
        current = edges.get(key)
        if current is None or edge["confidence"] > current["confidence"]:
            edges[key] = edge

    # Rule 1: declared foreign keys.
    for consumer_target, keys in (target_foreign_keys or {}).items():
        consumer = by_target.get(consumer_target.upper())
        if not consumer:
            continue
        for key in keys or []:
            producer = by_target.get(str(key.get("pk_table") or "").upper())
            fk_column = columns_by_target.get(consumer_target.upper(), {}).get(str(key.get("fk_column") or "").upper())
            pk_column = columns_by_target.get(str(key.get("pk_table") or "").upper(), {}).get(str(key.get("pk_column") or "").upper())
            if producer and producer is not consumer and fk_column and pk_column:
                offer(_edge(consumer, fk_column, producer, pk_column, confidence=0.95, rule="target_fk",
                            evidence_id=f"target_fk:{_leaf(consumer_target)}.{fk_column}"))

    # Rule 2: governed dependency learnings that name both targets.
    for consumer_target, cards in (fir_cards or {}).items():
        consumer = by_target.get(consumer_target.upper())
        if not consumer:
            continue
        consumer_columns = columns_by_target.get(consumer_target.upper(), {})
        for card in cards or []:
            kind = str(card.get("learning_type") or card.get("type") or card.get("kind") or "").lower()
            if kind not in {"mapping_dependency", "column_dependency"}:
                continue
            text = " ".join(str(value) for value in card.values() if isinstance(value, (str, int, float))).upper()
            for producer_target, producer in by_target.items():
                if producer is consumer or _leaf(producer_target) not in text:
                    continue
                producer_columns = columns_by_target.get(producer_target, {})
                mentioned = [original for upper, original in consumer_columns.items()
                             if upper != "ID" and re.search(rf"\b{re.escape(upper)}\b", text)]
                # Prefer the consumer column that names the producer.
                consumer_hit = next((column for column in mentioned if any(
                    _references(column.upper(), token) for token in _name_tokens(producer_target))),
                    mentioned[0] if mentioned else None)
                producer_hit = next((original for upper, original in producer_columns.items()
                                     if _is_identity(upper) and re.search(rf"\b{re.escape(upper)}\b", text)), None)
                if consumer_hit and producer_hit:
                    card_id = str(card.get("learning_id") or card.get("card_id") or card.get("id") or "card")
                    offer(_edge(consumer, consumer_hit, producer, producer_hit, confidence=0.85, rule="fir_dependency",
                                evidence_id=f"fir:{card_id}"))

    # Rule 3: shared source keys in old mappings.
    for consumer_target, consumer in by_target.items():
        consumer_lineage = lineage_by_target.get(consumer_target, {})
        consumer_columns = columns_by_target.get(consumer_target, {})
        for column_upper, (consumer_keys, consumer_sttm, weight) in consumer_lineage.items():
            column = consumer_columns.get(column_upper)
            # A table's own identifier is not a reference to another table.
            if not column or column_upper == "ID" or re.search(r"SOURCESYSTEMID|EXTERNAL_?ID|LEGACY_?ID", column_upper):
                continue
            matches = []
            for producer_target, producer in by_target.items():
                if producer is consumer:
                    continue
                producer_columns = columns_by_target.get(producer_target, {})
                for producer_upper, (producer_keys, producer_sttm, producer_weight) in lineage_by_target.get(producer_target, {}).items():
                    producer_column = producer_columns.get(producer_upper)
                    if producer_column and _is_identity(producer_upper) and consumer_keys & producer_keys:
                        named = any(_references(column_upper, token) for token in _name_tokens(producer_target))
                        matches.append((named, min(weight, producer_weight), producer, producer_column, producer_sttm))
            if not matches:
                continue
            named = [match for match in matches if match[0]]
            chosen = named or matches
            producers = {match[2]["mapping_key"] for match in chosen}
            if len(producers) != 1:
                # Several targets share the key: evidence cannot pick a producer.
                candidates.append({
                    "consumer_mapping": consumer["mapping_key"], "consumer_column": column,
                    "producer_mappings": sorted(producers), "confidence": 0.5,
                    "reason": "Old mappings derive this column from a key shared by several requested targets.",
                })
                continue
            _, confidence, producer, producer_column, producer_sttm = max(chosen, key=lambda match: match[1])
            offer(_edge(consumer, column, producer, producer_column, confidence=confidence, rule="precedent_lineage",
                        evidence_id=f"sttm_precedent:{consumer_sttm}:{column}->{producer_sttm}:{producer_column}"))

    # Rule 4: names only; never an edge.
    for consumer_target, consumer in by_target.items():
        for column_upper, column in columns_by_target.get(consumer_target, {}).items():
            if (consumer["mapping_key"], column) in edges or any(
                candidate["consumer_mapping"] == consumer["mapping_key"] and candidate["consumer_column"] == column
                for candidate in candidates
            ):
                continue
            hinted = [
                producer for producer_target, producer in by_target.items()
                if producer is not consumer and any(
                    _references(column_upper, token) for token in _name_tokens(producer_target)
                )
            ]
            if len(hinted) == 1:
                candidates.append({
                    "consumer_mapping": consumer["mapping_key"], "consumer_column": column,
                    "producer_mappings": [hinted[0]["mapping_key"]], "confidence": 0.5,
                    "reason": "Only the column name suggests this reference; confirm the key crosswalk.",
                })

    accepted = [edge for edge in edges.values() if edge["confidence"] >= _EDGE_THRESHOLD]
    accepted, demoted = _break_cycles(accepted)
    candidates.extend(demoted)
    for edge in accepted:
        edge.pop("_rule", None)
    return accepted, candidates


def _break_cycles(edges: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Drop the weakest edge of any mapping-level cycle until the graph is a DAG."""
    kept = sorted(edges, key=lambda edge: -edge["confidence"])
    demoted: list[dict[str, Any]] = []
    while True:
        graph: dict[str, set[str]] = {}
        for edge in kept:
            graph.setdefault(edge["consumer_mapping"], set()).add(edge["producer_mapping"])
        cycle = find_cycle(graph)
        if not cycle:
            return kept, demoted
        in_cycle = [edge for edge in kept if edge["consumer_mapping"] in cycle and edge["producer_mapping"] in cycle]
        weakest = min(in_cycle, key=lambda edge: edge["confidence"])
        kept.remove(weakest)
        demoted.append({
            "consumer_mapping": weakest["consumer_mapping"], "consumer_column": weakest["consumer_columns"][0],
            "producer_mappings": [weakest["producer_mapping"]], "confidence": weakest["confidence"],
            "reason": "This reference would create a dependency cycle between mappings; review which side owns the key.",
        })


def find_cycle(graph: dict[str, set[str]]) -> set[str]:
    state: dict[str, int] = {}
    stack: list[str] = []

    def visit(node: str) -> set[str]:
        state[node] = 1
        stack.append(node)
        for parent in graph.get(node, ()):
            if state.get(parent) == 1:
                return set(stack[stack.index(parent):])
            if state.get(parent) is None:
                found = visit(parent)
                if found:
                    return found
        stack.pop()
        state[node] = 2
        return set()

    for node in list(graph):
        if state.get(node) is None:
            found = visit(node)
            if found:
                return found
    return set()
