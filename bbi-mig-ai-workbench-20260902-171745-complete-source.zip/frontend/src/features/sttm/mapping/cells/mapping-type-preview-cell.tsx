import { AiaTableCellPrimitive } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import { aiaTableCellSx } from '@/components/ui/aia-table';
import type { SxProps, Theme } from '@mui/material/styles';
import { formatSqlType } from '../mapping-utils';
import { MAPPING_TABLE_BODY_TEXT_SX } from '../mapping-table-styles';

type MappingTypePreviewCellProps = {
  dataType?: string;
  width?: number | string;
  minWidth?: number | string;
  sx?: SxProps<Theme>;
};

export const MappingTypePreviewCell = ({
  dataType,
  width = 140,
  minWidth,
  sx,
}: MappingTypePreviewCellProps) => (
  <AiaTableCellPrimitive sx={aiaTableCellSx({ width, minWidth, sx })}>
    {dataType ? (
      <AiaText sx={{ ...MAPPING_TABLE_BODY_TEXT_SX, textAlign: 'left' }}>
        {formatSqlType(dataType).toLowerCase()}
      </AiaText>
    ) : null}
  </AiaTableCellPrimitive>
);
