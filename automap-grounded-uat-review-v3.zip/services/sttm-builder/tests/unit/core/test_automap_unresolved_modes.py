import json
from types import SimpleNamespace

import pytest

from app.core.automap_batch import invoke_batch
from app.schema.sttm_builder import STTMBuilderEnvelopeRequest
from tests.unit.core.test_automap_fast_batch import FinalAgent, invoke as fast_invoke
from tests.unit.core.test_automap_parallel_integration import enabled_service, request_payload
from tests.unit.core.test_automap_retrieval import service


@pytest.mark.parametrize("mode", ["legacy", "parallel", "fast"])
def test_mixed_completed_and_unresolved_answers_finalize_without_replaying(mode):
    value = request_payload(target_count=2)
    answer = {"agent": "AGT_SOURCE_MAPPING", "data": {"result": {"mappings": {
        "NAME0": {"source_attributes": ["a.X47"], "confidence_score": .9, "transformation_classification": "direct"},
        "NAME1": {"source_attributes": [], "confidence_score": 0, "transformation_classification": "unresolved",
                  "unmatched_reason": "No source has evidence for the required household population"}}}}}
    agent = FinalAgent([json.dumps(answer)])
    if mode == "fast":
        from tests.unit.core.test_automap_fast_context import fast_payload
        value = fast_payload(2)
        _, _, output = fast_invoke(value, agent)
    else:
        builder = enabled_service(agent)[0] if mode == "parallel" else service(agent)
        # The completed positive target's exact source read belongs to the
        # existing retrieval protocol; request it before the terminal answer.
        if mode == "legacy":
            value["context"]["selected_columns_by_table"] = {"a": ["X47"]}
        output = invoke_batch(builder, STTMBuilderEnvelopeRequest.model_validate(value), SimpleNamespace())
    mappings = json.loads(output[0])["data"]["result"]["mappings"]
    assert mappings["NAME1"]["transformation_classification"] == "unresolved"
    assert "repeated batch decisions" not in mappings["NAME1"]["unmatched_reason"]
    if mode == "legacy":
        assert mappings["NAME1"]["unmatched_reason"] == answer["data"]["result"]["mappings"]["NAME1"]["unmatched_reason"]
    assert len(agent.calls) == 1
