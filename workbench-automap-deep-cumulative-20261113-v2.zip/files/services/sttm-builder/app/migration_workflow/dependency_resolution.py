"""Resolve a consumer column that depends on another target's output.

A multi-target migration links records through keys the other targets build:
a contact's account reference must equal the account target's own key. The
producer's mapped row states how that key is built (for example
``'EN-' || BUSINESSES.ID``). When the consumer's selected sources hold a verified
foreign key to the producer's key source (``CONTACTS.BUSINESS_ID`` ->
``BUSINESSES.ID``), the consumer column uses the same rule over its own
foreign key, so the two targets agree without a lookup at load time.

A value that exists only once the producer is loaded (a system-assigned
identifier) cannot be built from a draft; it is reported as filled at load
time from the producer instead of being guessed.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable

_QUALIFIED_COLUMN = re.compile(r'(?<![A-Za-z0-9_$."])((?:"?[A-Za-z_][A-Za-z0-9_$]*"?\.){1,3}"?[A-Za-z_][A-Za-z0-9_$]*"?)')
_STRING_LITERAL = re.compile(r"('(?:''|[^'])*')")


def _split(value: str) -> tuple[str, str]:
    table, _, column = str(value).replace('"', "").rpartition(".")
    return table.upper(), column.upper()


@dataclass
class ForeignKey:
    """A verified join from a consumer source column to the producer's key column."""

    child_table: str
    child_column: str
    parent_table: str
    parent_column: str
    confidence: float
    evidence_id: str


@dataclass
class Resolution:
    target_column: str
    producer_mapping: str
    producer_column: str
    status: str  # "resolved" | "load_time" | "unresolved"
    expression: str | None = None
    source_columns: list[str] = field(default_factory=list)
    confidence: float = 0.0
    reason: str = ""
    evidence_ids: list[str] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        return {
            "target_column": self.target_column, "producer_mapping": self.producer_mapping,
            "producer_column": self.producer_column, "status": self.status, "expression": self.expression,
            "source_columns": self.source_columns, "confidence": round(self.confidence, 4), "reason": self.reason,
            "evidence_ids": self.evidence_ids,
        }


def translate(expression: str, replacements: dict[tuple[str, str], str]) -> str | None:
    """Rewrite ``table.column`` references with ``replacements``; None if any reference is not covered."""
    missing = False

    def replace(match: re.Match[str]) -> str:
        nonlocal missing
        key = _split(match.group(1))
        found = replacements.get(key)
        if found is None:
            missing = True
            return match.group(0)
        return found

    segments = _STRING_LITERAL.split(expression)
    rebuilt = "".join(segment if index % 2 else _QUALIFIED_COLUMN.sub(replace, segment)
                      for index, segment in enumerate(segments))
    return None if missing else rebuilt


def _producer_rule(row: dict[str, Any]) -> tuple[str, list[str]]:
    sources = [str(value) for value in row.get("source_columns") or [] if "." in str(value)]
    expression = str(row.get("expression") or "").strip() or (sources[0] if len(sources) == 1 else "")
    return expression, sources


def resolve(
    *,
    consumer_key: str,
    rows: list[dict[str, Any]],
    edges: Iterable[dict[str, Any]],
    contracts: Iterable[dict[str, Any]],
    consumer_tables: set[str],
    foreign_keys: Callable[[str, str], list[ForeignKey]],
    min_confidence: float,
) -> list[Resolution]:
    """Resolve every consumer column a declared dependency names.

    ``foreign_keys(parent_table, parent_column)`` returns verified joins from
    the consumer's sources to that producer key column. Rows are updated in
    place: a resolved column becomes a draft rule over the consumer's own
    foreign key; a load-time value becomes unresolved with that reason.
    """
    by_target = {str(row.get("target_column") or "").upper(): row for row in rows}
    contracts_by_id = {str(item.get("artifact_id")): item for item in contracts}
    tables = {table.upper() for table in consumer_tables}
    resolutions: list[Resolution] = []
    for edge in edges:
        if str(edge.get("consumer_mapping") or "") != consumer_key:
            continue
        producer = str(edge.get("producer_mapping") or "")
        consumer_columns = [str(value) for value in edge.get("consumer_columns") or []]
        producer_columns = [str(value) for value in edge.get("producer_columns") or []]
        if not consumer_columns or not producer_columns:
            continue
        pairs = list(zip(consumer_columns, producer_columns)) if len(producer_columns) == len(consumer_columns) \
            else [(column, producer_columns[0]) for column in consumer_columns]
        contract = contracts_by_id.get(str(edge.get("producer_output") or ""))
        for consumer_column, producer_column in pairs:
            row = by_target.get(consumer_column.upper())
            if row is None:
                continue
            if str(edge.get("availability") or "draft") == "load_time":
                resolution = Resolution(consumer_column, producer, producer_column, "load_time",
                                        reason=f"Filled at load time from {producer}.{producer_column}.")
                row.update({"status": "unresolved", "expression": None, "source_columns": [],
                            "mapping_classification": "dependency", "confidence": 0.0,
                            "confidence_reason": resolution.reason,
                            "missing_dependencies": [f"load_time:{producer}.{producer_column}"]})
                resolutions.append(resolution)
                continue
            producer_rows = {str(item.get("target_column") or "").upper(): item
                             for item in ((contract or {}).get("payload") or {}).get("mapping_rows") or []}
            producer_row = producer_rows.get(producer_column.upper())
            if producer_row is None:
                resolutions.append(Resolution(consumer_column, producer, producer_column, "unresolved",
                                              reason=f"{producer} has not produced a verified rule for {producer_column}."))
                continue
            expression, sources = _producer_rule(producer_row)
            replacements: dict[tuple[str, str], str] = {}
            used_keys: list[ForeignKey] = []
            covered = 0
            for source in sources:
                table, column = _split(source)
                if table in tables:
                    replacements[(table, column)] = f"{table}.{column}"
                    covered += 1
                    continue
                candidates = sorted(
                    (key for key in foreign_keys(table, column)
                     if key.child_table.upper() in tables and key.confidence >= min_confidence),
                    key=lambda key: -key.confidence,
                )
                if not candidates or (len(candidates) > 1 and candidates[0].confidence == candidates[1].confidence):
                    break
                chosen = candidates[0]
                replacements[(table, column)] = f"{chosen.child_table}.{chosen.child_column}"
                used_keys.append(chosen)
                covered += 1
            complete = bool(sources) and covered == len(sources)
            # Short forms (TABLE.COLUMN) of the same sources.
            for (table, column), value in list(replacements.items()):
                replacements.setdefault((table.rsplit(".", 1)[-1], column), value)
            translated = translate(expression, replacements) if expression and complete else None
            if not translated:
                resolutions.append(Resolution(
                    consumer_column, producer, producer_column, "unresolved",
                    reason=(f"No verified join from this mapping's sources to "
                            f"{', '.join(sorted({_split(source)[0] for source in sources})) or producer}, "
                            f"where {producer}.{producer_column} comes from."),
                ))
                continue
            confidence = min([key.confidence for key in used_keys] or [1.0])
            evidence = sorted({*[key.evidence_id for key in used_keys], *[str(e) for e in producer_row.get("evidence_ids") or []],
                               str(edge.get("evidence_id") or "")} - {""})
            resolution = Resolution(
                consumer_column, producer, producer_column, "resolved", expression=translated,
                source_columns=[value for value in dict.fromkeys(replacements[_split(source)] for source in sources)],
                confidence=confidence, evidence_ids=evidence,
                reason=(f"Uses {producer}'s rule for {producer_column} over "
                        + ", ".join(f"{key.child_table.rsplit('.', 1)[-1]}.{key.child_column}" for key in used_keys)
                        + " so both targets build the same key." if used_keys else
                        f"Uses {producer}'s rule for {producer_column}; its source is already in this mapping."),
            )
            row.update({
                "status": "draft", "expression": translated, "source_columns": resolution.source_columns,
                "mapping_classification": "derived", "confidence": max(float(row.get("confidence") or 0), confidence),
                "confidence_reason": resolution.reason,
                "evidence_ids": sorted({*[str(e) for e in row.get("evidence_ids") or []], *evidence}),
                "missing_dependencies": [], "dependency": resolution.as_dict(),
            })
            resolutions.append(resolution)
    return resolutions
