from types import SimpleNamespace
import pytest
from app.agent_runs.capacity import CapacityLeasePool
from app.agent_runs.policy import validate_worker_configuration
from app.core.config import Settings


def test_project_capacity_uses_actual_project_and_unambiguous_scope_identity():
    pool=CapacityLeasePool(client_factory=lambda:None,table='slots',scopes=['tenant:{tenant}:project:{project}'],
        scope_values={'tenant':'tenant:a','project':''},scope_limits={'tenant:{tenant}:project:{project}':3})
    with pytest.raises(ValueError,match='missing'):
        pool.resolved_scopes()
    first=pool.resolved_scopes('project:b')
    pool.scope_values['tenant']='tenant'
    assert first != pool.resolved_scopes('a:project:b')
    assert first[0][1] == 3


def test_capacity_provisions_once_then_releases_on_specialist_error():
    calls=[]
    class Row(dict):
        def as_dict(self):return dict(self)
    class Session:
        def sql(self, sql, params):
            calls.append((sql,params))
            rows=[Row(SLOT_ID='0')] if sql.startswith('SELECT') else [Row(updated=1)]
            return SimpleNamespace(collect=lambda:rows)
    pool=CapacityLeasePool(client_factory=lambda:SimpleNamespace(session=Session(),close=lambda:None),
        table='slots',scopes=['account'],scope_limits={'account':1},provision_procedure='provision')
    with pytest.raises(RuntimeError,match='specialist'):
        with pool.acquire():raise RuntimeError('specialist')
    with pool.acquire():pass
    assert sum(sql.startswith('CALL') for sql,_ in calls)==1
    assert sum('SET OWNER_TOKEN=NULL' in sql for sql,_ in calls)==2


def test_capacity_config_rejects_missing_and_unsafe_template_limits():
    settings=Settings(_env_file=None,migration_agent_enabled=True,migration_agent_true_resume_v1=True,
        migration_agent_host_terminalization_v1=True,migration_agent_tool_governance_v1=True,
        migration_agent_model_light='model',migration_agent_model_medium='model',migration_agent_model_high='model',
        migration_agent_capacity_scopes=['project:{project}'])
    with pytest.raises(ValueError,match='explicit limit'):validate_worker_configuration(settings)
    settings.migration_agent_capacity_limits={'project:{project}':3}
    validate_worker_configuration(settings)
    settings.migration_agent_capacity_scopes=['{project.__class__}']
    with pytest.raises(ValueError,match='templates'):validate_worker_configuration(settings)


def test_spcs_requires_independent_limits_not_one_combined_scope():
    settings=SimpleNamespace(migration_agent_enabled=True,migration_agent_true_resume_v1=True,
        migration_agent_host_terminalization_v1=True,migration_agent_tool_governance_v1=True,
        migration_agent_model_light='model',migration_agent_model_medium='model',migration_agent_model_high='model',
        non_local_env=True,migration_agent_heartbeat_seconds=10,migration_agent_lease_seconds=120,
        migration_agent_max_concurrency=2,migration_agent_effort_overrides={},
        migration_agent_capacity_scopes=['{account}:{tenant}:{role}:{project}'],
        migration_agent_capacity_limits={'{account}:{tenant}:{role}:{project}':3})
    with pytest.raises(ValueError,match='independent'):validate_worker_configuration(settings)
    settings.migration_agent_capacity_scopes=['{account}','{account}:{tenant}','{account}:{role}','{account}:{tenant}:{project}']
    settings.migration_agent_capacity_limits={scope:3 for scope in settings.migration_agent_capacity_scopes}
    validate_worker_configuration(settings)
