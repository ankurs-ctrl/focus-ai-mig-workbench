"""Durable ownership per logical call, without a shared execution-slot ceiling.

An enforced unique operation key serializes duplicate operation identities. It
never waits for another model call to finish. Terminal and uncertain operations
remain recorded; neither is recycled into a permit for a different call.
"""
from dataclasses import asdict
import hashlib
import json
import math
import time
from uuid import uuid4

from app.core.automap_admission import (
    AdmissionError, AdmissionInvariantError, AdmissionUnavailable, _CONTROL_DEADLINE, CallIdentity, Permit, StalePermit, _affected, _row,
)
from app.core.automap_durable_admission import DurableRunAdmission


class OperationAlreadyRecorded(AdmissionError):
    """Exact original call is retained; inspect/recover, never replay or queue."""


def operations_enabled(settings, req=None):
    if req is not None:
        # Frozen pre-upgrade requests must continue against their original store.
        return req.meta.get('_automap_call_tracking') == 'operation_v3'
    return not getattr(settings, 'automap_shared_capacity_limit', True)


def operation_table(settings):
    return settings.qualify_metadata_object_name('TBL_AUTOMAP_CALL_OPERATIONS')


class OperationCallTracking(DurableRunAdmission):
    shared_capacity_limit = False
    separate_wait_budget = False
    waiting_capacity = None

    def __init__(self, **kwargs):
        # Legacy fields are constructor compatibility only, never a dispatch cap.
        kwargs.update(capacity=1, recovery_capacity=1)
        super().__init__(**kwargs)

    def _permit_params(self, permit):
        if (type(permit) is not Permit or permit.account_namespace != self.account_namespace
                or permit.pool_epoch != self.pool_epoch or type(permit.slot_id) is not int or permit.slot_id < 1):
            raise StalePermit('Operation belongs to a different tracking scope')
        return [permit.account_namespace, permit.pool_epoch, permit.slot_id, permit.owner, permit.fence,
                permit.identity.job_id, permit.identity.caller_id, permit.identity.generation, permit.identity.shard_id]

    def _sql(self, session, query, params=None):
        deadline = _CONTROL_DEADLINE.get()
        remaining = self._timeout if deadline is None else min(self._timeout, deadline-time.monotonic())
        if remaining <= 0:
            raise AdmissionUnavailable('Operation control deadline exhausted')
        return session.sql(query,params=params).collect(statement_params={
            'STATEMENT_TIMEOUT_IN_SECONDS':str(max(1,math.ceil(remaining))),
            'LOCK_TIMEOUT':'1','READ_LATEST_WRITES':'true'})

    def try_claim(self, identity):
        if type(identity) is not CallIdentity:
            raise TypeError('Trusted call identity required')
        key=hashlib.sha256(json.dumps([self.account_namespace,self.pool_epoch,asdict(identity)],sort_keys=True).encode()).hexdigest()
        params=[self.account_namespace,self.pool_epoch,identity.job_id,identity.caller_id,
                identity.generation,identity.shard_id]
        owner=uuid4().hex
        # Enforced operation-key uniqueness replaces the shared stripe UPDATE.
        # A hybrid table locks this operation's row, not an execution inventory.
        class DuplicateInsert(AdmissionError):pass
        try:
            with self._transaction() as session:
                existing=self._sql(session,f'SELECT SLOT_ID, STATE FROM {self._table} WHERE OPERATION_KEY=? LIMIT 2',[key])
                if existing:
                    raise OperationAlreadyRecorded('Original operation is already recorded; awaiting its result or recovery')
                try:
                    inserted=self._sql(session,f'INSERT INTO {self._table} '
                        '(OPERATION_KEY,ACCOUNT_NAMESPACE,POOL_EPOCH,JOB_ID,CALLER_ID,GENERATION,SHARD_ID,STATE,OWNER_TOKEN,FENCE,'
                        'LEASE_EXPIRES_AT,UPDATED_AT,DISPATCH_PROTOCOL) '
                        "SELECT ?,?,?,?,?,?,?,'HELD',?,1,DATEADD('second',?,CURRENT_TIMESTAMP()),CURRENT_TIMESTAMP(),'background_v2'",
                        [key,*params,owner,self.lease_seconds])
                except Exception as error:
                    from app.core.sql_failure import sql_failure_details
                    from app.core.automap_admission import _is_contention
                    details=sql_failure_details(error)
                    if details.get('sql_error_code') and not _is_contention(error):
                        failure=DuplicateInsert()
                        failure.sql_failure=details
                        raise failure from None
                    raise
                receipt=_row(inserted[0]) if len(inserted)==1 else {}
                count={str(k).lower():v for k,v in receipt.items()}.get('number of rows inserted')
                if type(count) is not int or count!=1:
                    raise AdmissionInvariantError('Operation insert was not acknowledged')
                rows=self._sql(session,f'SELECT SLOT_ID, STATE FROM {self._table} WHERE OPERATION_KEY=? AND OWNER_TOKEN=? LIMIT 2',[key,owner])
                if len(rows)!=1:
                    raise AdmissionInvariantError('Exact inserted operation required')
                identifier=_row(rows[0]).get('SLOT_ID')
                if type(identifier) is not int or identifier<1:
                    raise AdmissionInvariantError('Invalid operation identity')
                return Permit(self.account_namespace,self.pool_epoch,identifier,owner,1,identity)
        except DuplicateInsert as failure:
            # _transaction acknowledged rollback. Unknown commit/rollback errors
            # propagate instead, and cannot authorize another model submission.
            with self._transaction() as session:
                rows=self._sql(session,f'SELECT SLOT_ID, STATE FROM {self._table} WHERE OPERATION_KEY=? LIMIT 2',[key])
                if len(rows)>1:
                    raise AdmissionInvariantError('Conflicting insert has duplicate operations')
                if not rows:
                    error=AdmissionUnavailable('Operation insert failed after acknowledged rollback')
                    error.sql_failure=failure.sql_failure
                    error.control_outcome='rolled_back'
                    raise error
            raise OperationAlreadyRecorded('Original operation is already recorded; awaiting its result or recovery') from None

    def quarantine(self, permit):
        # Uncertainty stays on its original operation. It cannot consume capacity
        # needed by an unrelated batch, and never authorizes replay of this call.
        self._change(permit,"STATE='QUARANTINED', NEXT_RECOVERY_AT=CURRENT_TIMESTAMP()",[],
                     "STATE IN ('HELD','QUARANTINED')")

    def health(self):
        with self._transaction() as session:
            rows=self._sql(session,f"SELECT STATE, COUNT(*) AS N, "
                "COUNT_IF(STATE='HELD' AND LEASE_EXPIRES_AT<=CURRENT_TIMESTAMP()) AS EXPIRED "
                f'FROM {self._table} WHERE ACCOUNT_NAMESPACE=? AND POOL_EPOCH=? GROUP BY STATE',
                [self.account_namespace,self.pool_epoch])
        counts={str(_row(row)['STATE']):_row(row) for row in rows}
        if set(counts)-{'FREE','HELD','QUARANTINED'}:
            raise AdmissionInvariantError('Invalid operation state')
        return {'shared_capacity_limit':False,'capacity':None,'execution_capacity':None,
            'execution_free':None,'recovery_capacity':None,'outstanding_ceiling':None,
            'held':counts.get('HELD',{}).get('N',0),'quarantined':counts.get('QUARANTINED',{}).get('N',0),
            'free':0,'completed':counts.get('FREE',{}).get('N',0),
            'expired_held':sum(row.get('EXPIRED',0) for row in counts.values()),
            'oldest_quarantine_seconds':None}
