"""Native tool/port contracts. Model, Search and Snowflake I/O are simulated.

Uses the actual request preparation, compiler and SQLGlot validation. These are
release regressions, not evidence of live Cortex tool availability/accuracy.
"""

from contextlib import contextmanager
from copy import deepcopy
from types import SimpleNamespace
import json
import time
import pytest
from app.core.automap_native_contract import (
    VERSION,
    build_snapshot,
    digest,
    encoded,
    identifier_key,
    initial_state,
    seed_packet,
    target_id,
)
from app.core.automap_native_tools import NativeTools, NativeToolError, covered
from app.core.automap_native_ports import (
    compile_proposal,
    validate_analyst_sql,
    compile_request,
)
from app.core.automap_native import (
    make_response,
    continuation_packet,
    validate_final,
    project_native,
)
from tests.unit.core.test_automap_fast_context import fast_payload, add_table
from tests.unit.core.test_automap_fast_batch import prepared_request

HANDLE = "a" * 64


class MemoryStore:
    def __init__(self, snap, config=None):
        self.row = {
            "SNAPSHOT": deepcopy(snap),
            "SNAPSHOT_HASH": snap["snapshot_hash"],
            "STATE": initial_state(),
            "CONFIG": config
            or {
                "max_tool_calls": 128,
                "window_tool_calls": 64,
                "tool_output_bytes": 32768,
                "evidence_budget_bytes": 180000,
            },
            "DEADLINE_EPOCH": time.time() + 180,
        }

    def load(self, handle, **kw):
        if handle != HANDLE:
            raise ValueError("unavailable")
        return deepcopy(self.row)

    @contextmanager
    def edit(self, handle, **kw):
        self.load(handle)
        state = deepcopy(self.row["STATE"])
        yield state
        state["revision"] += 1
        self.row["STATE"] = state


def system(count=1):
    req = prepared_request(fast_payload(count))
    snap = build_snapshot(req, validated_derived=[])
    store = MemoryStore(snap)
    tools = NativeTools(
        store,
        compile_proposal=lambda snap, target, mapping, needs, config: compile_proposal(
            None, snap, target, mapping, needs, config
        ),
    )
    return req, snap, store, tools


def call(tools, snap, tool, params, *, targets=None, question=""):
    return tools.execute(
        tool,
        encoded(
            {
                "job_handle": HANDLE,
                "snapshot_hash": snap["snapshot_hash"],
                "target_ids": targets or [next(iter(snap["targets"]))],
                "params": params,
                "question": question,
            }
        ),
    )


def read_required(tools, snap, target, refs):
    ids = sorted(tools._required(snap, target, refs))
    for identity in ids:
        offset = 0
        while True:
            result = call(
                tools,
                snap,
                "ReadEvidence",
                {"evidence_ids": [identity], "offset": offset, "page_bytes": 8192},
                targets=[target],
            )
            record = result["evidence"][0]
            if record["next_offset"] is None:
                break
            offset = record["next_offset"]


def proposal(snap, target, *, status="supported", **changes):
    source = next(iter(snap["sources"].values()))
    target_record = next(
        (
            identity
            for identity, record in snap["records"].items()
            if record["kind"] == "target"
            and identifier_key(record["body"]["target_id"])
            == identifier_key(snap["targets"][target]["name"])
        )
    )
    mapping = {
        "source_attributes": [source["source_ref"]],
        "confidence_score": 0.9,
        "confidence_reason": "Exact synthetic source meaning and target meaning agree.",
        "preprocessing_rule_type": "Direct",
        "transformation_classification": "direct",
        **changes,
    }
    support = {
        "status": status,
        "source_meaning": "Synthetic name value",
        "target_meaning": "Synthetic target name",
        "grain": "Same frozen source population",
        "contradictions": [],
        "citations": [
            {"evidence_id": source["evidence_id"], "quote": "X47"},
            {"evidence_id": target_record, "quote": snap["targets"][target]["name"]},
        ],
    }
    return {"mapping": mapping, "semantic_support": support}


def test_complete_native_seed_has_no_repeated_large_table_or_parent_catalog():
    value = fast_payload(37)
    add_table(value, columns=600, size=500, connected=True)
    req = prepared_request(value)
    before = req.model_dump(mode="json")
    snap = build_snapshot(req, validated_derived=[])
    wire = encoded(seed_packet(snap, HANDLE, max_chars=180000, max_bytes=180000))
    assert len(wire.encode()) < 60000 and len(snap["sources"]) == 601
    assert "Other 599" not in wire
    assert req.model_dump(mode="json") == before
    assert all(
        "output_columns" not in record["body"]
        for record in snap["records"].values()
        if record["kind"] == "relation_contract"
    )
    assert all(
        source["evidence_id"] in snap["records"] for source in snap["sources"].values()
    )


@pytest.mark.parametrize(
    "a,b,equal",
    [
        ("BillingCity", "BILLINGCITY", True),
        ('"BILLINGCITY"', "BillingCity", True),
        ('"BillingCity"', "BILLINGCITY", False),
        ('"a.b"', '"A.B"', False),
    ],
    ids=["fold", "quoted-upper", "quoted-case", "quoted-dot"],
)
def test_canonical_target_identity(a, b, equal):
    assert (target_id("D.S.T", a) == target_id("d.s.t", b)) is equal


def test_no_proposal_before_exact_reads_then_admission_error_is_cleared():
    req, snap, store, tools = system()
    target = next(iter(snap["targets"]))
    item = proposal(snap, target)
    first = call(tools, snap, "ValidateProposal", item)
    assert not first["valid"] and first["code"] == "missing_exact_evidence"
    read_required(tools, snap, target, item["mapping"]["source_attributes"])
    final = call(tools, snap, "SubmitProposals", {"proposals": {target: item}})
    assert (
        final["targets"][target]["valid"]
        and target not in store.row["STATE"]["deficits"]
    )
    result = make_response(req, store.row)
    assert result.result.mappings["NAME0"].source_attributes == ['a."X47"']
    assert result.meta["auto_map_native_checkpoint_targets"] == ["NAME0"]


def test_search_failure_and_later_pages_never_evict_an_active_candidate():
    req, snap, store, tools = system()
    target = next(iter(snap["targets"]))
    tools.search = lambda *a: (_ for _ in ()).throw(RuntimeError("unavailable"))
    found = call(tools, snap, "SearchSources", {"limit": 1}, question="name")
    identity = found["candidates"][0]["binding_id"]
    assert found["search_status"] == "unavailable_frozen_inventory_used"
    call(tools, snap, "SearchSources", {"cursor": 1}, question="different question")
    assert identity in store.row["STATE"]["candidates"][target]
    repeat = call(tools, snap, "SearchSources", {"limit": 1}, question="name")
    assert repeat["status"] == "cached" and repeat["new_information"] is False


def test_exact_multibyte_record_can_be_read_in_bounded_pages_without_loss():
    req, snap, store, tools = system()
    source = next(iter(snap["sources"].values()))
    identity = source["evidence_id"]
    store.row["SNAPSHOT"]["records"][identity]["body"]["large"] = "证据" * 20000
    body = encoded(store.row["SNAPSHOT"]["records"][identity])
    text = ""
    offset = 0
    # Give this isolated paging probe enough delivery/tool capacity.
    store.row["CONFIG"].update(
        evidence_budget_bytes=400000, max_tool_calls=256, window_tool_calls=256
    )
    while True:
        result = call(
            tools,
            snap,
            "ReadEvidence",
            {"evidence_ids": [identity], "offset": offset, "page_bytes": 8192},
        )
        assert len(encoded(result).encode()) <= 32768
        page = result["evidence"][0]
        text += page["text"]
        offset = page["end"]
        if page["next_offset"] is None:
            break
    assert text == body and covered(store.row["STATE"]["reads"][identity], len(body))


def test_one_invalid_target_does_not_drop_the_valid_sibling_checkpoint():
    req, snap, store, tools = system(2)
    targets = list(snap["targets"])
    items = {target: proposal(snap, target) for target in targets}
    for target in targets:
        read_required(
            tools, snap, target, items[target]["mapping"]["source_attributes"]
        )
    items[targets[1]]["mapping"]["source_attributes"] = ["b.("]
    final = call(tools, snap, "SubmitProposals", {"proposals": items}, targets=targets)
    assert (
        final["targets"][targets[0]]["valid"]
        and not final["targets"][targets[1]]["valid"]
    )
    assert set(store.row["STATE"]["proposals"]) == {targets[0]}


@pytest.mark.parametrize(
    "field,poison",
    [
        ("source_attributes", ['parent."HIDDEN"']),
        ("candidate_source_attributes", ["b.X47"]),
        ("used_learning_ids", ["fabricated"]),
        ("preprocessing_rule", "(SELECT MAX(X47) FROM D.S.A)"),
    ],
    ids=[
        "hidden-parent",
        "foreign-alternative",
        "fabricated-learning",
        "query-expression",
    ],
)
def test_validation_rejects_foreign_or_unread_claims(field, poison):
    req, snap, store, tools = system()
    target = next(iter(snap["targets"]))
    item = proposal(snap, target)
    read_required(tools, snap, target, item["mapping"]["source_attributes"])
    item["mapping"][field] = poison
    with pytest.raises(NativeToolError):
        call(tools, snap, "ValidateProposal", item)
    assert not store.row["STATE"]["proposals"]


def test_declared_semantic_contradiction_stays_unresolved_with_alternative():
    req, snap, store, tools = system()
    target = next(iter(snap["targets"]))
    item = proposal(snap, target)
    read_required(tools, snap, target, item["mapping"]["source_attributes"])
    item["semantic_support"]["contradictions"] = [
        "Deal activity is not payout evidence"
    ]
    call(tools, snap, "SubmitProposals", {"proposals": {target: item}})
    mapping = make_response(req, store.row).result.mappings["NAME0"]
    assert mapping.transformation_classification == "unresolved"
    assert (
        mapping.candidate_source_attributes == ['a."X47"']
        and not mapping.source_attributes
    )


def test_uncertain_alternative_remains_same_schema_and_is_review_only():
    req, snap, store, tools = system()
    target = next(iter(snap["targets"]))
    item = proposal(snap, target, status="uncertain")
    read_required(tools, snap, target, item["mapping"]["source_attributes"])
    call(tools, snap, "SubmitProposals", {"proposals": {target: item}})
    result = make_response(req, store.row)
    assert result.meta["automap_evidence_review_only_targets"] == ["NAME0"]
    assert result.result.mappings["NAME0"].confidence_score == 0.9


def test_rule_work_is_frozen_to_the_original_selected_bindings():
    req, snap, store, tools = system()
    target = next(iter(snap["targets"]))
    item = proposal(
        snap,
        target,
        transformation_classification="complex",
        preprocessing_rule='TRIM(a."X47")',
        preprocessing_rule_type="Custom",
    )
    read_required(tools, snap, target, item["mapping"]["source_attributes"])
    call(tools, snap, "SubmitProposals", {"proposals": {target: item}})
    old = deepcopy(store.row["STATE"]["proposals"][target])
    assert old["stage"] == "needs_rule"
    item["mapping"]["transformation_classification"] = "direct"
    item["mapping"]["preprocessing_rule"] = None
    call(
        tools,
        snap,
        "SubmitProposals",
        {"proposals": {target: item}},
        question="changed",
    )
    assert store.row["STATE"]["proposals"][target] == old


@pytest.mark.parametrize(
    "sql",
    [
        "DELETE FROM D.S.V",
        "SELECT * FROM D.S.OTHER",
        "SELECT SECRET FROM D.S.V",
        "SELECT SYSTEM$WAIT(60)",
        "SELECT C_1 FROM D.S.V; DROP TABLE D.S.V",
        "CALL P()",
        "SELECT EXTERNAL_FUNC(C_1) FROM D.S.V",
        "SELECT * FROM D.S.V AT (OFFSET => -60)",
    ],
    ids=[
        "delete",
        "foreign",
        "hidden",
        "system",
        "multi",
        "call",
        "udf",
        "historical-population",
    ],
)
def test_analyst_sql_rejects_data_changes_scope_escape_and_unbounded_functions(sql):
    with pytest.raises((NativeToolError, ValueError)):
        validate_analyst_sql(sql, "D.S.V", {"C_1"})


def test_analyst_aggregate_query_is_bounded_and_readonly():
    sql = validate_analyst_sql(
        "SELECT COUNT(*) AS N FROM D.S.V WHERE C_1 IS NOT NULL", "D.S.V", {"C_1"}
    )
    assert "LIMIT 100" in sql and "COUNT(*)" in sql


@pytest.mark.parametrize("status", ["failed", "in_progress", "unknown"])
def test_native_final_status_does_not_fail_open(status):
    with pytest.raises(Exception):
        validate_final(
            encoded(
                {
                    "agent": "AGT_SOURCE_MAPPING",
                    "status": status,
                    "result": {"mappings": {}},
                }
            )
        )


def test_final_text_cannot_sneak_mappings_outside_checkpoint_validation():
    validate_final(
        encoded(
            {
                "agent": "SOURCE_MAPPING_AGENT",
                "status": "completed",
                "result": {"mappings": {}},
            }
        )
    )
    with pytest.raises(Exception):
        validate_final(
            encoded(
                {
                    "agent": "AGT_SOURCE_MAPPING",
                    "status": "completed",
                    "result": {"mappings": {"NAME0": {}}},
                }
            )
        )


def test_missing_business_policy_is_not_a_reason_to_restart_a_window():
    req, snap, store, tools = system()
    target = next(iter(snap["targets"]))
    item = proposal(snap, target, status="missing_business_input")
    read_required(tools, snap, target, item["mapping"]["source_attributes"])
    call(tools, snap, "SubmitProposals", {"proposals": {target: item}})
    assert store.row["STATE"]["proposals"][target]["stage"] == "validated"
    settings = SimpleNamespace(
        agent_outbound_message_max_chars=180000, agent_outbound_message_max_bytes=180000
    )
    assert continuation_packet(snap, HANDLE, store.row["STATE"], settings) is None


def test_target_scoped_continuation_omits_completed_siblings_and_keeps_recovered_candidates():
    req, snap, store, tools = system(2)
    done, remaining = list(snap["targets"])
    item = proposal(snap, done)
    read_required(tools, snap, done, item["mapping"]["source_attributes"])
    call(tools, snap, "SubmitProposals", {"proposals": {done: item}}, targets=[done])
    source = next(iter(snap["sources"]))
    store.row["STATE"]["candidates"][remaining] = [source]
    store.row["STATE"]["deficits"][remaining] = {
        "code": "missing_exact_evidence",
        "evidence_ids": ["node"],
    }
    settings = SimpleNamespace(
        agent_outbound_message_max_chars=180000, agent_outbound_message_max_bytes=180000
    )
    packet = json.loads(
        continuation_packet(snap, HANDLE, store.row["STATE"], settings)[0]["content"][
            0
        ]["text"]
    )
    assert [t["binding_id"] for t in packet["targets"]] == [remaining]
    assert (
        source in packet["active_candidates"][remaining]
        and done not in packet["current_deficits"]
    )


def test_population_filters_grouping_and_distinct_are_preserved():
    req, snap, _, _ = system()
    snap["constraints"].update(
        source_filter_sql='a."X47" IS NOT NULL',
        source_group_by_sql='a."X47"',
        source_order_by_sql='a."X47" DESC',
        source_query_modifiers={"distinct": "DISTINCT"},
    )
    from app.schema.mapping_sql import MappingSqlMappingItem
    from app.core.mapping_sql import MappingSqlService

    body = compile_request(
        snap,
        [
            MappingSqlMappingItem(
                target_column="NAME0", source_columns=['a."X47"'], rule="Direct"
            )
        ],
    )
    result = MappingSqlService(session=None, analyst_client=None).compile(body)
    assert result.valid and all(
        token in result.preview_sql
        for token in ["DISTINCT", "WHERE", "GROUP BY", "ORDER BY"]
    )


def test_checkpoint_hash_and_deadline_are_verified_before_parent_delivery():
    req, snap, store, tools = system()
    target = next(iter(snap["targets"]))
    item = proposal(snap, target)
    read_required(tools, snap, target, item["mapping"]["source_attributes"])
    call(tools, snap, "SubmitProposals", {"proposals": {target: item}})
    store.row["STATE"]["proposals"][target]["mapping"]["source_attributes"] = ["fake.X"]
    with pytest.raises(ValueError):
        make_response(req, store.row)


def test_request_scoped_tool_inputs_cannot_select_another_project_or_service():
    req, snap, store, tools = system()
    with pytest.raises(NativeToolError):
        call(tools, snap, "SearchSources", {"project_id": "502"}, question="name")
    with pytest.raises(NativeToolError):
        call(tools, snap, "ReadEvidence", {"evidence_ids": ["other-job-node"]})
    with pytest.raises(NativeToolError):
        call(tools, snap, "InspectRelationships", {"binding_ids": ["foreign"]})


def test_semantic_support_does_not_claim_historical_learning_was_searched():
    req, snap, store, tools = system()
    target = next(iter(snap["targets"]))
    item = proposal(snap, target)
    read_required(tools, snap, target, item["mapping"]["source_attributes"])
    call(tools, snap, "SubmitProposals", {"proposals": {target: item}})
    response = make_response(req, store.row)
    assert (
        response.meta["auto_map_retrieval"]["targets"][0]["coverage"][
            "learning_evidence"
        ]
        is False
    )
    tools.precedents = lambda *args: []
    call(
        tools,
        snap,
        "SearchPrecedents",
        {},
        question="Are there applicable verified country mappings?",
    )
    response = make_response(req, store.row)
    assert (
        response.meta["auto_map_retrieval"]["targets"][0]["coverage"][
            "learning_evidence"
        ]
        is True
    )


def test_flattened_tool_contract_never_marks_evidence_as_returned():
    _, snap, store, tools = system()
    target = next(iter(snap["targets"]))
    source = next(iter(snap["sources"].values()))
    raw = encoded(
        {
            "job_handle": HANDLE,
            "snapshot_hash": snap["snapshot_hash"],
            "target_ids": [target],
            "evidence_ids": [source["evidence_id"]],
        }
    )
    with pytest.raises(NativeToolError, match="invalid_tool_contract"):
        tools.execute("ReadEvidence", raw)
    assert store.row["STATE"]["reads"] == {} and store.row["STATE"]["tool_calls"] == 0
