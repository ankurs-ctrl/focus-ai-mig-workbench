import { getApiData } from '@/api/axiosInstance';
import { API_ROUTES } from '@/api/routes';

export type PerformanceDuration = {
  count: number;
  total_ms: number;
  max_ms: number;
  avg_ms: number;
  p50_ms: number;
  p95_ms: number;
  p99_ms: number;
  sample_count: number;
};

export type RuntimeDiagnostics = {
  performance?: {
    counters?: Record<string, number>;
    durations?: Record<string, PerformanceDuration>;
    rates?: Record<string, number>;
  };
  backend_read_cache?: { entries?: number; inflight?: number };
  durable_context_caches?: Record<string, unknown>;
  runtime_optimization?: {
    warehouse_routing?: Record<string, string>;
    session_lease_pool?: boolean;
    prepare_parallel?: boolean;
    learning_parallel?: boolean;
    async_postsave?: boolean;
    automap_max_in_flight?: number;
    automap_worker_concurrency?: number;
  };
  [key: string]: unknown;
};

export function getRuntimeDiagnostics(): Promise<RuntimeDiagnostics> {
  return getApiData<RuntimeDiagnostics>(API_ROUTES.diagnostics.readiness, {
    timeout: 15_000,
  });
}
