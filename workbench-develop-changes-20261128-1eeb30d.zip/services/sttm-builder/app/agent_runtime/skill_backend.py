"""Expose packaged Workbench skills separately from the writable run workspace."""
from pathlib import Path

from deepagents.backends import CompositeBackend, FilesystemBackend, StateBackend
from deepagents.backends.protocol import DeleteResult, EditResult, FileUploadResponse, WriteResult


class _PackagedSkills(FilesystemBackend):
    def write(self, file_path, content):
        return WriteResult(error="Packaged skills are read-only")

    def edit(self, file_path, old_string, new_string, replace_all=False):
        return EditResult(error="Packaged skills are read-only")

    def delete(self, file_path):
        return DeleteResult(error="Packaged skills are read-only")

    def upload_files(self, files):
        return [FileUploadResponse(path=path, error="permission_denied") for path, _ in files]


def workbench_skill_backend() -> CompositeBackend:
    skills = Path(__file__).resolve().parents[2] / "knowledge" / "skills"
    return CompositeBackend(StateBackend(), {"/skills/": _PackagedSkills(root_dir=skills)})
