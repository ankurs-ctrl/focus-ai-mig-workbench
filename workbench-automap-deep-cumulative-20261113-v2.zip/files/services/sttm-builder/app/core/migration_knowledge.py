"""Governed projections over existing FIR evidence and learning records."""
from __future__ import annotations
import hashlib
import json
from datetime import date, datetime, timezone
from enum import Enum
from typing import Any, Literal
from pydantic import BaseModel, Field, field_validator, model_validator


def digest(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), default=str).encode()).hexdigest()


class LearningType(str, Enum):
    MAPPING = 'MAPPING'
    TRANSFORMATION = 'TRANSFORMATION'
    CORRECTION = 'CORRECTION'
    CONSTANT = 'CONSTANT'
    EXCLUSION = 'EXCLUSION'
    MAPPING_DEPENDENCY = 'MAPPING_DEPENDENCY'
    COLUMN_DEPENDENCY = 'COLUMN_DEPENDENCY'
    ARTIFACT_CONTRACT = 'ARTIFACT_CONTRACT'
    CROSSWALK_CONTRACT = 'CROSSWALK_CONTRACT'
    ENTITY_EXECUTION_ORDER = 'ENTITY_EXECUTION_ORDER'
    SOURCE_SELECTION_PATTERN = 'SOURCE_SELECTION_PATTERN'
    JOIN_PATTERN = 'JOIN_PATTERN'
    CTE_PATTERN = 'CTE_PATTERN'
    VALIDATION_REQUIREMENT = 'VALIDATION_REQUIREMENT'
    BUSINESS_RULE = 'BUSINESS_RULE'
    KNOWN_EXCEPTION = 'KNOWN_EXCEPTION'


class EvidenceScope(BaseModel):
    tenant_id: str = Field(min_length=1)
    account: str = Field(min_length=1)
    authorization_fingerprint: str = Field(min_length=1)
    project_id: str = Field(min_length=1)
    source_system: str = ''
    target_system: str = ''
    entity: str = ''
    source_objects: list[str] = Field(default_factory=list)
    target_objects: list[str] = Field(default_factory=list)


class LearningDraft(BaseModel):
    kind: LearningType
    subject_key: str = Field(min_length=1)
    summary: str = Field(min_length=1)
    structured_rule: dict[str, Any]
    evidence_ids: list[str] = Field(min_length=1)
    confidence: float = Field(ge=0, le=1)
    semantic_version: str = Field(min_length=1)
    contract_version: str = Field(min_length=1)
    extractor_version: str = Field(min_length=1)
    origin_document: str = Field(min_length=1)
    document_version: str = Field(min_length=1)
    applicable_from: str | None = None
    applicable_until: str | None = None
    supersedes: str | None = None

    @field_validator('applicable_from', 'applicable_until')
    @classmethod
    def canonical_date(cls, value):
        return date.fromisoformat(value).isoformat() if value is not None else None

    @model_validator(mode='after')
    def ordered_dates(self):
        if self.applicable_from and self.applicable_until and self.applicable_from > self.applicable_until:
            raise ValueError('Learning applicability end precedes its start')
        return self


def learning_applicable(record: dict, scope: EvidenceScope, *, semantic_version: str, contract_version: str, at: str | None = None) -> bool:
    at = at or datetime.now(timezone.utc).date().isoformat()
    return (record.get('scope') == scope.model_dump(mode='json')
        and record.get('approval_status') == 'APPROVED_BUSINESS_RULE'
        and record.get('semantic_version') == semantic_version
        and record.get('contract_version') == contract_version
        and not record.get('superseded_by')
        and (not record.get('applicable_from') or record['applicable_from'] <= at)
        and (not record.get('applicable_until') or at <= record['applicable_until']))


def search_projection(record: dict) -> dict:
    """Index language, not operational secrets or unrestricted structured payloads."""
    status = record.get('approval_status', 'UNVERIFIED')
    import re
    text = str(record.get('summary', ''))
    sensitive = re.search(r'(?i)(?:-----BEGIN .*PRIVATE KEY-----|(?:password|secret|access_token|refresh_token|api_key)\s*[:=]|\beyJ[A-Za-z0-9_-]{12,}\.)', text)
    return {'text': '' if sensitive else text, 'excluded_sensitive': bool(sensitive), 'evidence_ids': record.get('evidence_ids', []),
            'approval_status': status, 'scope': record.get('scope', {}),
            'authoritative': status == 'APPROVED_BUSINESS_RULE'}


def transcript_chunks(text: str, *, meeting_id: str, document_version: str, chunk_chars: int = 3000) -> list[dict]:
    import re
    if not text.strip() or chunk_chars < 100:
        raise ValueError('A transcript and a usable chunk size are required')
    chunks = []
    for line in text.splitlines():
        if not line.strip():
            continue
        match = re.match(r'^\s*(?:\[?(\d{1,2}:\d{2}(?::\d{2})?)\]?\s*)?([^:]{1,80}):\s*(.*)$', line)
        timestamp, speaker, excerpt = match.groups() if match else (None, None, line)
        for start in range(0, len(excerpt), chunk_chars):
            chunks.append({'meeting_id': meeting_id, 'document_version': document_version,
                'speaker': speaker, 'timestamp': timestamp, 'topic': None,
                'source_excerpt': excerpt[start:start+chunk_chars], 'ordinal': len(chunks)})
    return chunks


class MigrationKnowledgeService:
    def __init__(self, session, settings, scope: EvidenceScope, *, authorized_project_reviewer: bool = False, evidence_table: str | None = None, learning_table: str | None = None):
        self.session, self.scope = session, scope
        self.authorized_project_reviewer = authorized_project_reviewer
        self.search_service = getattr(settings, 'migration_agent_learning_search_service', '')
        # Identifiers come from deployment settings and use SQL identifier binding.
        namespace = '.'.join(v for v in [settings.snowflake_database, settings.snowflake_schema] if v)
        self.evidence_table = evidence_table or f'{namespace}.TBL_FIR_EVIDENCE_ITEMS'
        self.learning_table = learning_table or f'{namespace}.TBL_AGENT_LEARNINGS'

    def search(self, query: str, *, semantic_version: str, contract_version: str, limit: int = 20) -> list[dict]:
        """Cortex finds candidates; current structured records alone grant authority."""
        if not self.search_service or not query.strip():
            return []
        limit = max(1, min(limit,100))
        filters = {'ACCOUNT_ID':self.scope.account, 'TENANT_ID':self.scope.tenant_id,
            'PROJECT_ID':self.scope.project_id, 'AUTHORIZATION_FINGERPRINT':self.scope.authorization_fingerprint,
            'SEMANTIC_VERSION':semantic_version, 'CONTRACT_VERSION':contract_version,
            'APPROVAL_STATUS':'APPROVED_BUSINESS_RULE'}
        request = {'query':query,'columns':['LEARNING_ID','REVISION'], 'limit':limit,
            'filter':{'@and':[{'@eq':{key:value}} for key,value in filters.items()]}}
        rows = self.session.sql('SELECT SNOWFLAKE.CORTEX.SEARCH_PREVIEW(?, ?) AS RESULT',
            [self.search_service,json.dumps(request)]).collect()
        if not rows:
            return []
        raw = rows[0]['RESULT']; result = json.loads(raw) if isinstance(raw,str) else raw
        hits = result.get('results') or []
        found = []
        seen = set()
        for hit in hits[:limit]:
            learning_id = str(hit.get('LEARNING_ID') or '')
            if not learning_id or learning_id in seen:
                continue
            seen.add(learning_id)
            try:
                record = self._read_learning(learning_id)
            except LookupError:
                continue
            # Search refresh is asynchronous. Never reuse an old revision, revoked
            # permission, superseded rule or stale contract from the search copy.
            if (str(record.get('revision')) == str(hit.get('REVISION'))
                    and learning_applicable(record,self.scope,semantic_version=semantic_version,contract_version=contract_version)
                    and search_projection(record)['text']):
                found.append({'learning_id':learning_id,**record})
        return found

    def store_transcript(self, text: str, *, meeting_id: str, document_version: str) -> dict:
        chunks = transcript_chunks(text, meeting_id=meeting_id, document_version=document_version)
        payload = {'scope': self.scope.model_dump(mode='json'), 'approval_status': 'RAW_TRANSCRIPT',
                   'original_text': text, 'meeting_id': meeting_id, 'document_version': document_version,
                   'extractor_version': 'text-lines-v1', 'chunks': chunks}
        evidence_id = 'evidence_' + digest(payload)
        self.session.sql('''MERGE INTO IDENTIFIER(?) t USING (SELECT ? EVIDENCE_ID) s
            ON t.EVIDENCE_ID=s.EVIDENCE_ID WHEN NOT MATCHED THEN INSERT
            (EVIDENCE_ID,SOURCE_TYPE,TITLE,SUMMARY,STRUCTURED_PAYLOAD,PROJECT_ID,SOURCE_HASH)
            VALUES (?, 'transcript', ?, 'Unverified immutable text transcript', PARSE_JSON(?), ?, ?)''',
            [self.evidence_table,evidence_id,evidence_id,meeting_id,json.dumps(payload),self.scope.project_id,digest(text)]).collect()
        return {'evidence_id': evidence_id, 'approval_status': 'RAW_TRANSCRIPT', 'chunks': chunks}

    def read_evidence(self, evidence_id: str) -> dict:
        rows=self.session.sql('SELECT STRUCTURED_PAYLOAD FROM IDENTIFIER(?) WHERE EVIDENCE_ID=?',
                              [self.evidence_table,evidence_id]).collect()
        if not rows:
            raise LookupError('Evidence not found')
        raw=rows[0]['STRUCTURED_PAYLOAD']; value=json.loads(raw) if isinstance(raw,str) else dict(raw)
        if value.get('scope') != self.scope.model_dump(mode='json'):
            raise PermissionError('Evidence is outside the delegated scope')
        return value

    def propose(self, draft: LearningDraft, *, actor_user_id: str) -> dict:
        # Resolve every citation under the caller's exact delegated scope first.
        for evidence_id in draft.evidence_ids:
            rows = self.session.sql('SELECT STRUCTURED_PAYLOAD FROM IDENTIFIER(?) WHERE EVIDENCE_ID=?', [self.evidence_table,evidence_id]).collect()
            if not rows:
                raise ValueError('Learning references missing evidence')
            value = rows[0]['STRUCTURED_PAYLOAD']
            payload = json.loads(value) if isinstance(value,str) else value
            if payload.get('scope') != self.scope.model_dump(mode='json'):
                raise PermissionError('Evidence is outside the delegated scope')
        payload = {**draft.model_dump(mode='json'), 'scope': self.scope.model_dump(mode='json'),
                   'approval_status':'EXTRACTED_NOTE_DRAFT', 'revision':1}
        learning_id = 'learning_' + digest(payload)
        self.session.sql('''MERGE INTO IDENTIFIER(?) t USING (SELECT ? LEARNING_ID) s
            ON t.LEARNING_ID=s.LEARNING_ID WHEN NOT MATCHED THEN INSERT
            (LEARNING_ID,AGENT_TYPE,LEARNING_TYPE,LEARNING_KEY,SUMMARY,CONFIDENCE,ATTRIBUTES,STATUS,CREATED_BY,
             SUBJECT_TYPE,SUBJECT_KEY,CLAIM_KEY,TRUST_STAGE,EVIDENCE_IDS,ENTITY_IDS)
            VALUES (?, 'DEEP_MIGRATION', ?, ?, ?, ?, PARSE_JSON(?), 'draft', ?,
                    ?, ?, ?, 'draft_candidate', PARSE_JSON(?), PARSE_JSON(?))''',
            [self.learning_table,learning_id,learning_id,draft.kind.value,draft.subject_key,draft.summary,draft.confidence,json.dumps(payload),actor_user_id,draft.kind.value.lower(),draft.subject_key,digest(draft.structured_rule),
             json.dumps(draft.evidence_ids),json.dumps({"project_id":self.scope.project_id})]).collect()
        stored = self._read_learning(learning_id)
        return {'learning_id':learning_id, **stored}

    def _read_learning(self, learning_id: str) -> dict:
        rows = self.session.sql('SELECT ATTRIBUTES FROM IDENTIFIER(?) WHERE LEARNING_ID=?', [self.learning_table,learning_id]).collect()
        if not rows:
            raise LookupError('Learning not found')
        raw = rows[0]['ATTRIBUTES']
        return json.loads(raw) if isinstance(raw,str) else dict(raw)

    def review(self, learning_id: str, *, decision: Literal['submit','approve','reject'], expected_revision: int, actor_user_id: str) -> dict:
        payload = self._read_learning(learning_id)
        original_scope = payload.get('scope') or {}
        exact_scope = original_scope == self.scope.model_dump(mode='json')
        reviewer_scope = self.authorized_project_reviewer and all(original_scope.get(key) == getattr(self.scope,key) for key in ('account','tenant_id','project_id'))
        if not (exact_scope or reviewer_scope):
            raise PermissionError('Learning is outside the delegated scope')
        if payload.get('revision') != expected_revision:
            raise ValueError('Stale learning revision')
        transitions = {('EXTRACTED_NOTE_DRAFT','submit'):'BUSINESS_REVIEW', ('BUSINESS_REVIEW','approve'):'APPROVED_BUSINESS_RULE', ('BUSINESS_REVIEW','reject'):'REJECTED_NOTE'}
        status = transitions.get((payload.get('approval_status'),decision))
        if not status:
            raise ValueError('Invalid learning-review transition')
        prior = None
        if status == 'APPROVED_BUSINESS_RULE' and payload.get('supersedes'):
            prior = self._read_learning(payload['supersedes'])
            if (prior.get('scope') != original_scope or prior.get('subject_key') != payload.get('subject_key')
                    or prior.get('superseded_by') or prior.get('approval_status') != 'APPROVED_BUSINESS_RULE'):
                raise ValueError('Supersession requires the current approved learning in the same scope and subject')
        payload['review_history'] = [*payload.get('review_history', []), {
            'revision':expected_revision,'approval_status':payload.get('approval_status'),
            'decision':decision,'actor_user_id':actor_user_id,'at':datetime.now(timezone.utc).isoformat()}]
        payload.update(approval_status=status, revision=expected_revision+1, reviewed_by=actor_user_id,
                       reviewed_at=datetime.now(timezone.utc).isoformat(), review_authorization=self.scope.authorization_fingerprint)
        payload['search_projection'] = search_projection(payload)
        self.session.sql('BEGIN TRANSACTION').collect()
        try:
            result = self.session.sql("""UPDATE IDENTIFIER(?) SET ATTRIBUTES=PARSE_JSON(?), STATUS=?, TRUST_STAGE=?, UPDATED_AT=CURRENT_TIMESTAMP()
                WHERE LEARNING_ID=? AND ATTRIBUTES:revision::INT=?""",
                [self.learning_table,json.dumps(payload),'active' if status=='APPROVED_BUSINESS_RULE' else 'draft',
                 'validated' if status=='APPROVED_BUSINESS_RULE' else 'draft_candidate',learning_id,expected_revision]).collect()
            if not result or int(list(result[0].as_dict().values())[0]) != 1:
                raise ValueError('Concurrent learning review; reload the current revision')
            if prior is not None:
                prior_revision=prior['revision']
                prior.update(superseded_by=learning_id,revision=prior_revision+1)
                prior['supersession_history']=[*prior.get('supersession_history',[]),{
                    'learning_id':learning_id,'reviewed_by':actor_user_id,'at':payload['reviewed_at']}]
                changed=self.session.sql("""UPDATE IDENTIFIER(?) SET ATTRIBUTES=PARSE_JSON(?), TRUST_STAGE='superseded',
                    UPDATED_AT=CURRENT_TIMESTAMP() WHERE LEARNING_ID=? AND ATTRIBUTES:revision::INT=?
                    AND ATTRIBUTES:superseded_by IS NULL""",
                    [self.learning_table,json.dumps(prior),payload['supersedes'],prior_revision]).collect()
                if not changed or int(list(changed[0].as_dict().values())[0]) != 1:
                    raise ValueError('Concurrent supersession; reload the current learning')
            self.session.sql('COMMIT').collect()
        except Exception:
            self.session.sql('ROLLBACK').collect()
            raise
        # Cortex Search consumes the governed projection view; no external vector write.
        return {'learning_id':learning_id, **payload}

    def list_notes(self, *, limit: int = 50) -> list[dict]:
        predicate = "" if self.authorized_project_reviewer else " AND ATTRIBUTES:scope:authorization_fingerprint::STRING=?"
        params = [self.learning_table,self.scope.account,self.scope.tenant_id,self.scope.project_id]
        if not self.authorized_project_reviewer:
            params.append(self.scope.authorization_fingerprint)
        params.append(max(1,min(limit,100)))
        rows=self.session.sql("""SELECT LEARNING_ID, ATTRIBUTES FROM IDENTIFIER(?)
            WHERE AGENT_TYPE='DEEP_MIGRATION' AND ATTRIBUTES:scope:account::STRING=?
              AND ATTRIBUTES:scope:tenant_id::STRING=? AND ATTRIBUTES:scope:project_id::STRING=?"""
            + predicate + " ORDER BY CREATED_AT DESC LIMIT ?",params).collect()
        return [{'learning_id':row['LEARNING_ID'],**(json.loads(row['ATTRIBUTES']) if isinstance(row['ATTRIBUTES'],str) else dict(row['ATTRIBUTES']))} for row in rows]

    def retrieve(self, subject_keys: list[str], *, semantic_version: str, contract_version: str, limit: int = 20) -> list[dict]:
        if not subject_keys:
            return []
        rows = self.session.sql("""SELECT LEARNING_ID, ATTRIBUTES FROM IDENTIFIER(?)
            WHERE AGENT_TYPE='DEEP_MIGRATION' AND STATUS='active'
              AND ARRAY_CONTAINS(TO_VARIANT(SUBJECT_KEY), PARSE_JSON(?))
              AND ATTRIBUTES:scope:account::STRING=? AND ATTRIBUTES:scope:tenant_id::STRING=?
              AND ATTRIBUTES:scope:project_id::STRING=?
              AND ATTRIBUTES:scope:authorization_fingerprint::STRING=?
              AND ATTRIBUTES:semantic_version::STRING=? AND ATTRIBUTES:contract_version::STRING=?
              AND ATTRIBUTES:approval_status::STRING='APPROVED_BUSINESS_RULE'
              AND ATTRIBUTES:superseded_by IS NULL
            ORDER BY CREATED_AT DESC LIMIT ?""",
            [self.learning_table,json.dumps(subject_keys),self.scope.account,self.scope.tenant_id,self.scope.project_id,
             self.scope.authorization_fingerprint,semantic_version,contract_version,max(1,min(limit,100))]).collect()
        result=[]
        for row in rows:
            raw=row['ATTRIBUTES']; record=json.loads(raw) if isinstance(raw,str) else dict(raw)
            if learning_applicable(record,self.scope,semantic_version=semantic_version,contract_version=contract_version):
                result.append({'learning_id':row['LEARNING_ID'],**record})
        return result
