import asyncio
import pytest

from app.core.sttm_builder import STTMBuilderService
from app.schema.sttm_builder import STTMBuilderEnvelopeRequest, STTMBuilderResponse, SourceMappingResult, TransformationResult


def test_confident_selection_with_alternatives_still_requests_review():
    from app.core.auto_mapping_proxy import AutoMappingProxyClient
    result = SourceMappingResult.model_validate({"mappings": {"CITY": {
        "source_attributes": ["prepared.CITY"], "confidence_score": .95,
        "candidate_source_attributes": ["alternate.CITY"],
        "confidence_reason": "Prepared population is strongest; alternate population differs.",
        "transformation_classification": "direct"}}})
    _, review = AutoMappingProxyClient._build_mapping_review(result.mappings)
    assert review["mapped_count"] == 1
    assert review["mapped_with_review_count"] == 1
    assert review["recommendations"][0]["category"] == "alternative_candidates"
    assert "alternate.CITY" in review["recommendations"][0]["candidate_sources"]


def test_automap_projection_preserves_driver_and_uncertain_candidate_policy():
    import json
    from app.core.config import Settings
    req = STTMBuilderEnvelopeRequest.model_validate({"operation": "sttm.auto_map",
        "context": {"workspace_context": {"page": "mapping", "driving_relation_id": "prepared"}},
        "data": {"intent": "AUTO_MAP", "message": "Map the requested targets."}})
    routed = STTMBuilderService._with_intent_route(req)
    assert "candidate_source_attributes" in routed.data.message
    assert "even when confidence is uncertain" in routed.data.message
    assert STTMBuilderService._with_intent_route(routed).data.message == routed.data.message
    payload = json.loads(STTMBuilderService.project_agent_payload(req, Settings(_env_file=None)).text)
    assert payload["context"]["workspace_context"]["driving_relation_id"] == "prepared"
    assert "candidate_source_attributes" in payload["data"]["message"]
    assert req.data.message == "Map the requested targets."


@pytest.mark.parametrize("valid_expression", [True, False])
def test_focused_pending_complex_selection_requires_final_expression(valid_expression):
    from tests.unit.core.test_automap_retrieval import payload, service, ScriptedAgent
    from app.core.automap_policy import focused_learning
    from app.core.automap_retrieval import AutoMapContext
    from app.schema.sttm_builder import AttributeMapping, STTMAgentRequestEnvelope
    value = payload(description_size=0)
    value["context"]["learning_context"] = {}
    value["data"]["attributes"][0]["target_data_type"] = "VARCHAR"
    req = STTMBuilderEnvelopeRequest.model_validate(value)
    instance = service(ScriptedAgent())
    raw = STTMAgentRequestEnvelope.from_builder_request(req).model_dump(mode="json", exclude_none=True)
    raw["context"]["learning_context"] = focused_learning({})
    store = AutoMapContext(raw)
    store.manifest()
    store.discover_batch(lambda targets: {target: {"evidence": {}, "diagnostics": {"status": "no_match"}} for target in targets})
    candidate = AttributeMapping(source_attributes=["a.X47"], source_dependencies=["a.X47"], confidence_score=.9,
                                 preprocessing_rule=None, preprocessing_rule_type="Custom", transformation_classification="complex")
    for operation in store.required_operations("NAME0", candidate.model_dump(mode="json")):
        store.read({"tool": "AUTO_MAP_CONTEXT", "snapshot_hash": store.snapshot_hash, **operation}, max_bytes=12000)
    assert not instance._validate_auto_map_candidate(req, store, req.data.attributes[0], candidate)
    response = STTMBuilderResponse.from_invocation(req, thread_id="test", parent_message_id=None,
        agent="SOURCE_MAPPING_AGENT", result=SourceMappingResult(mappings={"NAME0": candidate}), message="", status="completed")
    calls = []
    def invoke(transform_req, **kwargs):
        calls.append(transform_req)
        rules = TransformationResult.model_validate({"rules": [{"target_attribute": "NAME0",
            "rule": "TRIM(a.X47)" if valid_expression else "TRIM(a.INVENTED)", "source_dependencies": ["a.X47"]}]})
        return STTMBuilderResponse.from_invocation(transform_req, thread_id="transform", parent_message_id=None,
            agent="TRANSFORMATION_AGENT", result=rules, message="", status="completed")
    instance.invoke = invoke
    final = asyncio.run(instance._apply_complex_transformation_stage(req, response, governance_decision=None))
    assert len(calls) == (1 if valid_expression else 2)
    assert final.result.mappings["NAME0"].transformation_classification == ("complex" if valid_expression else "unresolved")
    assert final.result.mappings["NAME0"].source_attributes == ["a.X47"]


def test_fast_specialist_never_falls_back_to_legacy_without_owning_runtime():
    from tests.unit.core.test_automap_fast_context import fast_payload
    from tests.unit.core.test_automap_fast_batch import service, FinalAgent
    from app.schema.sttm_builder import AttributeMapping
    from unittest.mock import Mock
    req = STTMBuilderEnvelopeRequest.model_validate(fast_payload())
    candidate = AttributeMapping(source_attributes=["a.X47"], confidence_score=.81,
        preprocessing_rule_type="Custom", transformation_classification="complex")
    response = STTMBuilderResponse.from_invocation(req, thread_id=None, parent_message_id=None,
        agent="SOURCE_MAPPING_AGENT", result=SourceMappingResult(mappings={"NAME0": candidate}),
        message="", status="completed")
    instance = service(FinalAgent())
    instance.invoke = Mock(side_effect=AssertionError("Legacy fallback is forbidden"))
    final = asyncio.run(instance._apply_complex_transformation_stage(req, response, governance_decision=None))
    instance.invoke.assert_not_called()
    assert final.result.mappings["NAME0"].transformation_classification == "unresolved"
    assert final.result.mappings["NAME0"].source_attributes == ["a.X47"]


def test_specialist_distinguishes_quoted_target_case():
    table = {"database": "D", "schema": "S", "table": "T"}
    names = ['"Name"', '"NAME"']
    req = STTMBuilderEnvelopeRequest.model_validate({"operation": "sttm.auto_map", "data": {"intent": "AUTO_MAP",
        "attributes": [{"target_table": table, "target_attribute": name} for name in names]}})
    mappings = SourceMappingResult.model_validate({"mappings": {name: {"source_attributes": ["a.X47"],
        "transformation_classification": "complex", "preprocessing_rule_type": "Custom", "confidence_score": .9}
        for name in names}})
    response = STTMBuilderResponse.from_invocation(req, thread_id=None, parent_message_id=None,
        agent="SOURCE_MAPPING_AGENT", result=mappings, message="", status="completed")
    instance = STTMBuilderService.__new__(STTMBuilderService)
    def invoke(request, **kwargs):
        rules = TransformationResult.model_validate({"rules": [
            {"target_attribute": name, "rule": f"{function}(a.X47)"}
            for name, function in zip(names, ["TRIM", "UPPER"])]})
        return STTMBuilderResponse.from_invocation(request, thread_id=None, parent_message_id=None,
            agent="TRANSFORMATION_AGENT", result=rules, message="", status="completed")
    instance.invoke = invoke
    final = asyncio.run(instance._apply_complex_transformation_stage(req, response, governance_decision=None))
    assert final.result.mappings['"Name"'].preprocessing_rule == "TRIM(a.X47)"
    assert final.result.mappings['"NAME"'].preprocessing_rule == "UPPER(a.X47)"


def test_focused_project_value_rejects_literal_with_valid_binding():
    from tests.unit.core.test_automap_retrieval import payload, service, ScriptedAgent
    from app.core.automap_retrieval import AutoMapContext
    from app.schema.sttm_builder import AttributeMapping, STTMAgentRequestEnvelope
    value = payload(description_size=0)
    value["context"]["learning_context"] = {}
    req = STTMBuilderEnvelopeRequest.model_validate(value)
    store = AutoMapContext(STTMAgentRequestEnvelope.from_builder_request(req).model_dump(mode="json", exclude_none=True))
    candidate = AttributeMapping(source_attributes=[], mapping_mode="attribute", attribute_name="FirmID",
        constant_value="historical", value_binding_ids=["firm"], confidence_score=1, transformation_classification="value")
    missing = service(ScriptedAgent())._validate_auto_map_candidate(req, store, req.data.attributes[0], candidate)
    assert "Project Value name, placeholder and approved binding must agree" in missing


def test_simple_cast_missing_sql_routes_once_and_preserves_selected_mapping():
    table = {"database": "DB", "schema": "TGT", "table": "HOUSEHOLD"}
    req = STTMBuilderEnvelopeRequest.model_validate({"operation": "sttm.auto_map",
        "context": {"prepared_context_hash": "prepared", "project_id": "firm-a"},
        "data": {"intent": "AUTO_MAP", "attributes": [{"target_table": table, "target_attribute": "NAME"}]}})
    result = SourceMappingResult.model_validate({"mappings": {"NAME": {
        "source_attributes": ["prepared_cte.VALUE"], "source_dependencies": ["prepared_cte.VALUE"],
        "confidence_score": .9, "preprocessing_rule": "CAST", "preprocessing_rule_type": "Cast",
        "transformation_classification": "simple_multi_source", "precedent_decision": "accept_precedent"}}})
    response = STTMBuilderResponse.from_invocation(req, thread_id="test-thread", parent_message_id=None,
        agent="SOURCE_MAPPING_AGENT", result=result, message="", status="completed")
    response.meta["auto_map_retrieval"] = {"targets": [{"target": "NAME", "evidence_ids": ["published-pattern"]}]}
    service = STTMBuilderService.__new__(STTMBuilderService)
    calls = []

    def invoke(transform_req, **kwargs):
        calls.append(transform_req)
        assert transform_req.data.attributes[0].selected_mapping["source_attributes"] == ["prepared_cte.VALUE"]
        assert transform_req.context.prepared_context_hash == "prepared"
        rules = TransformationResult.model_validate({"rules": [{"target_attribute": "NAME",
            "rule": "CAST(prepared_cte.VALUE AS VARCHAR)", "source_dependencies": ["prepared_cte.VALUE"],
            "learning_evidence": ["published-pattern"]}]})
        return STTMBuilderResponse.from_invocation(transform_req, thread_id="transform-thread", parent_message_id=None,
            agent="TRANSFORMATION_AGENT", result=rules, message="", status="completed")

    service.invoke = invoke
    transformed = asyncio.run(service._apply_complex_transformation_stage(req, response, governance_decision=None))
    assert len(calls) == 1
    assert transformed.result.mappings["NAME"].preprocessing_rule == "CAST(prepared_cte.VALUE AS VARCHAR)"
    assert transformed.result.mappings["NAME"].used_learning_ids == ["published-pattern"]
    asyncio.run(service._apply_complex_transformation_stage(req, transformed, governance_decision=None))
    assert len(calls) == 1


def test_parseable_expression_with_unknown_alias_is_repaired(monkeypatch):
    from app.core.mapping_sql import MappingSqlService
    table = {"database": "DB", "schema": "TGT", "table": "HOUSEHOLD"}
    req = STTMBuilderEnvelopeRequest.model_validate({"operation": "sttm.auto_map",
        "context": {"relation_graph": {"nodes": [{"relation_id": "src", "kind": "PHYSICAL_TABLE",
            "table": {"database": "DB", "schema": "S", "table": "SRC"}, "alias": "src",
            "output_columns": [{"name": "VALUE", "data_type": "VARCHAR"}]}], "edges": []}},
        "data": {"intent": "AUTO_MAP", "attributes": [{"target_table": table, "target_attribute": "NAME"}]}})
    result = SourceMappingResult.model_validate({"mappings": {"NAME": {
        "source_attributes": ["src.VALUE"], "source_dependencies": ["src.VALUE"],
        "confidence_score": .9, "preprocessing_rule": "TRIM(wrong.VALUE)", "preprocessing_rule_type": "Custom"}}})
    response = STTMBuilderResponse.from_invocation(req, thread_id="test", parent_message_id=None,
        agent="SOURCE_MAPPING_AGENT", result=result, message="", status="completed")
    def compile_expression(self, request):
        if "wrong." in request.mappings[0].expression:
            raise ValueError("Unknown alias")
    monkeypatch.setattr(MappingSqlService, "compile", compile_expression)
    calls = []
    def invoke(request, **kwargs):
        calls.append(request)
        rules = TransformationResult.model_validate({"rules": [{"target_attribute": "NAME", "rule": "TRIM(src.VALUE)", "source_dependencies": ["src.VALUE"]}]})
        return STTMBuilderResponse.from_invocation(request, thread_id="transform", parent_message_id=None,
            agent="TRANSFORMATION_AGENT", result=rules, message="", status="completed")
    service = STTMBuilderService.__new__(STTMBuilderService)
    service.invoke = invoke
    repaired = asyncio.run(service._apply_complex_transformation_stage(req, response, governance_decision=None))
    assert len(calls) == 1
    assert repaired.result.mappings["NAME"].preprocessing_rule == "TRIM(src.VALUE)"


def test_worker_replaces_invented_value_id_with_project_placeholder():
    from app.core.auto_mapping_proxy import AutoMappingProxyClient
    req = STTMBuilderEnvelopeRequest.model_validate({"operation": "sttm.auto_map",
        "context": {"relation_graph": {"value_bindings": [{"binding_id": "actual", "value": "$FirmID",
            "resolved_value": "current", "is_placeholder": True, "resolution_status": "project_attribute"}]}},
        "data": {"intent": "AUTO_MAP"}})
    result = SourceMappingResult.model_validate({"mappings": {"FIRM": {
        "source_attributes": [], "mapping_mode": "attribute", "attribute_name": "FirmID",
        "constant_value": "$FirmID", "confidence_score": 1, "value_binding_ids": ["invented-uuid"]}}})
    response = STTMBuilderResponse.from_invocation(req, thread_id="test", parent_message_id=None,
        agent="SOURCE_MAPPING_AGENT", result=result, message="", status="completed")
    AutoMappingProxyClient._demote_undefined_firm_values(response, req=req)
    assert response.result.mappings["FIRM"].value_binding_ids == ["$FirmID"]


def test_serialized_worker_result_has_same_validated_value_ids_at_both_levels():
    from app.core.auto_mapping_proxy import AutoMappingProxyClient
    req = STTMBuilderEnvelopeRequest.model_validate({"operation": "sttm.auto_map",
        "context": {"relation_graph": {"value_bindings": [{"binding_id": "actual", "value": "$FirmID",
            "resolved_value": "current", "is_placeholder": True, "resolution_status": "project_attribute"}]}},
        "data": {"intent": "AUTO_MAP"}})
    result = SourceMappingResult.model_validate({"mappings": {"FIRM": {
        "source_attributes": [], "mapping_mode": "attribute", "attribute_name": "FirmID",
        "constant_value": "$FirmID", "confidence_score": 1, "value_binding_ids": ["invented-uuid"]}}})
    original = STTMBuilderResponse.from_invocation(req, thread_id="test", parent_message_id=None,
        agent="SOURCE_MAPPING_AGENT", result=result, message="", status="completed")
    serialized = STTMBuilderResponse.model_validate_json(original.model_dump_json())
    AutoMappingProxyClient._validate_worker_response(serialized, req=req, batch_index=0)
    assert serialized.result.mappings["FIRM"].value_binding_ids == ["$FirmID"]
    assert serialized.result == serialized.data.result


@pytest.mark.parametrize("shortlist_only", [False, True])
@pytest.mark.parametrize("repair_succeeds", [True, False])
def test_direct_mapping_cannot_bypass_connected_prepared_cte(repair_succeeds, shortlist_only):
    table = {"database": "DB", "schema": "TGT", "table": "HOUSEHOLD"}
    req = STTMBuilderEnvelopeRequest.model_validate({"operation": "sttm.auto_map", "context": {
        "driving_table": {"database": "DB", "schema": "SRC", "table": "CONTACTS"},
        "relation_graph": {"nodes": [
            {"relation_id": "DB.SRC.CONTACTS", "alias": "contacts", "kind": "PHYSICAL_TABLE",
             "table": {"database": "DB", "schema": "SRC", "table": "CONTACTS"}, "output_columns": [{"name": "ID"}]},
            {"relation_id": "DB.SRC.ADDRESSES", "alias": "raw_addresses", "kind": "PHYSICAL_TABLE",
             "table": {"database": "DB", "schema": "SRC", "table": "ADDRESSES"}, "output_columns": [{"name": "CITY"}]},
            {"relation_id": "prepared", "alias": "prepared", "kind": "DERIVED_SOURCE",
             "sql_text": "SELECT CONTACT_ID, CITY FROM DB.SRC.ADDRESSES QUALIFY ROW_NUMBER() OVER (PARTITION BY CONTACT_ID ORDER BY ID)=1",
             "output_columns": [{"name": "CONTACT_ID"}, {"name": "CITY"}]}],
            "edges": [{"edge_id": "address", "left_relation_id": "DB.SRC.CONTACTS", "right_relation_id": "prepared",
                       "join_type": "LEFT", "conditions": [{"left_column": "ID", "right_column": "CONTACT_ID"}]}]}},
        "data": {"intent": "AUTO_MAP", "attributes": [{"target_table": table, "target_attribute": "CITY"}]}})
    original = SourceMappingResult.model_validate({"mappings": {"CITY": {"source_attributes": ["DB.SRC.ADDRESSES.CITY"],
        "preprocessing_rule_type": "Direct", "confidence_score": .9}}})
    if shortlist_only:
        original.mappings["CITY"].source_attributes = []
        original.mappings["CITY"].candidate_source_attributes = ["DB.SRC.ADDRESSES.CITY"]
        original.mappings["CITY"].transformation_classification = "unresolved"
    response = STTMBuilderResponse.from_invocation(req, thread_id="test", parent_message_id=None,
        agent="SOURCE_MAPPING_AGENT", result=original, message="", status="completed")
    calls = []
    service = STTMBuilderService.__new__(STTMBuilderService)
    def invoke(repair_req, **kwargs):
        calls.append(repair_req)
        assert ("shortlist" if shortlist_only else "disconnected") in repair_req.data.attributes[0].selected_mapping["compiler_error"]
        assert repair_req.context.relation_graph == req.context.relation_graph
        candidate = original.model_copy(deep=True)
        candidate.mappings["CITY"].candidate_source_attributes = ["prepared.CITY", "contacts.ID"]
        candidate.mappings["CITY"].confidence_score = .55
        candidate.mappings["CITY"].confidence_reason = "Best available semantic match; review alternatives."
        if repair_succeeds:
            candidate.mappings["CITY"].source_attributes = ["prepared.CITY"]
            candidate.mappings["CITY"].transformation_classification = "direct"
        return STTMBuilderResponse.from_invocation(repair_req, thread_id="repair", parent_message_id=None,
            agent="SOURCE_MAPPING_AGENT", result=candidate, message="", status="completed")
    service.invoke = invoke
    repaired = asyncio.run(service._repair_direct_source_bindings(req, response, governance_decision=None))
    assert len(calls) == 1
    assert repaired.result == repaired.data.result
    if repair_succeeds:
        assert repaired.result.mappings["CITY"].source_attributes == ["prepared.CITY"]
        assert repaired.result.mappings["CITY"].confidence_score == .55
        assert repaired.result.mappings["CITY"].candidate_source_attributes == ["contacts.ID", "DB.SRC.ADDRESSES.CITY"]
        from app.core.auto_mapping_proxy import AutoMappingProxyClient
        _, review = AutoMappingProxyClient._build_mapping_review(repaired.result.mappings)
        assert review["mapped_count"] == 1
        assert review["unresolved_count"] == 0
        assert review["mapped_with_review_count"] == 1
    else:
        assert repaired.result.mappings["CITY"].transformation_classification == "unresolved"
        assert "prepared.CITY" in repaired.result.mappings["CITY"].candidate_source_attributes
    assert len(req.context.relation_graph.edges) == 1


@pytest.mark.parametrize("repair_succeeds", [True, False])
def test_transformation_repair_replaces_dependencies_and_keeps_prepared_driver(repair_succeeds):
    from app.core.mapping_sql import MappingSqlService
    from app.schema.mapping_sql import MappingSqlCompileRequest, MappingSqlMappingItem

    table = {"database": "DB", "schema": "TGT", "table": "HOUSEHOLD"}
    req = STTMBuilderEnvelopeRequest.model_validate({"operation": "sttm.auto_map", "context": {
        "driving_table": {"database": "DB", "schema": "SRC", "table": "CONTACTS"},
        "relation_graph": {"nodes": [
            {"relation_id": "DB.SRC.ADDRESSES", "alias": "raw_addresses", "kind": "PHYSICAL_TABLE",
             "table": {"database": "DB", "schema": "SRC", "table": "ADDRESSES"},
             "output_columns": [{"name": "CITY"}]},
            {"relation_id": "DB.SRC.CONTACTS", "alias": "contacts", "kind": "PHYSICAL_TABLE",
             "table": {"database": "DB", "schema": "SRC", "table": "CONTACTS"},
             "output_columns": [{"name": "ID"}]},
            {"relation_id": "prepared", "alias": "prepared", "kind": "DERIVED_SOURCE",
             "sql_text": "SELECT CONTACT_ID, CITY FROM DB.SRC.ADDRESSES QUALIFY ROW_NUMBER() OVER (PARTITION BY CONTACT_ID ORDER BY ID)=1",
             "output_columns": [{"name": "CONTACT_ID"}, {"name": "CITY"}]}],
            "edges": [{"edge_id": "address", "left_relation_id": "DB.SRC.CONTACTS", "right_relation_id": "prepared",
                       "join_type": "LEFT", "conditions": [{"left_column": "ID", "right_column": "CONTACT_ID"}]}]}},
        "data": {"intent": "AUTO_MAP", "attributes": [{"target_table": table, "target_attribute": "CITY"}]}})
    graph_before = req.context.relation_graph.model_dump()
    original = SourceMappingResult.model_validate({"mappings": {"CITY": {
        "source_attributes": ["prepared.CITY"], "source_dependencies": ["raw_addresses.CITY"],
        "value_binding_ids": ["obsolete-binding"], "used_learning_ids": ["source-evidence"],
        "preprocessing_rule": "TRIM(prepared.CITY)", "preprocessing_rule_type": "Custom",
        "transformation_classification": "complex", "confidence_score": .9}}})
    response = STTMBuilderResponse.from_invocation(req, thread_id="test", parent_message_id=None,
        agent="SOURCE_MAPPING_AGENT", result=original, message="", status="completed")
    response.meta["auto_map_retrieval"] = {"targets": [{"target": "CITY", "evidence_ids": ["rule-evidence"]}]}
    calls = []
    service = STTMBuilderService.__new__(STTMBuilderService)

    def invoke(repair_req, **kwargs):
        calls.append(repair_req)
        dependency = "prepared.CITY" if repair_succeeds else "raw_addresses.CITY"
        rules = TransformationResult.model_validate({"rules": [{"target_attribute": "CITY",
            "rule": "TRIM(prepared.CITY)", "source_dependencies": [dependency],
            "learning_evidence": ["rule-evidence"]}]})
        return STTMBuilderResponse.from_invocation(repair_req, thread_id="repair", parent_message_id=None,
            agent="TRANSFORMATION_AGENT", result=rules, message="", status="completed")

    service.invoke = invoke
    repaired = asyncio.run(service._apply_complex_transformation_stage(req, response, governance_decision=None))
    mapping = repaired.result.mappings["CITY"]
    assert repaired.result == repaired.data.result
    assert req.context.relation_graph.model_dump() == graph_before
    if repair_succeeds:
        assert len(calls) == 1
        assert mapping.source_dependencies == ["prepared.CITY"]
        assert mapping.value_binding_ids == []
        assert mapping.used_learning_ids == ["rule-evidence", "source-evidence"]
        compiled = MappingSqlService(session=None, analyst_client=None).compile(MappingSqlCompileRequest(
            relation_graph=req.context.relation_graph, driving_relation_id="DB.SRC.CONTACTS",
            validate_with_explain=False, mappings=[MappingSqlMappingItem(target_column="CITY",
                source_columns=mapping.source_attributes, expression=mapping.preprocessing_rule,
                source_dependencies=mapping.source_dependencies, value_binding_ids=mapping.value_binding_ids)]))
        assert compiled.ready
        assert "DB.SRC.ADDRESSES" not in compiled.required_relation_ids
        assert "FROM DB.SRC.CONTACTS" in compiled.preview_sql
        assert "LEFT JOIN prepared" in compiled.preview_sql
        asyncio.run(service._apply_complex_transformation_stage(req, repaired, governance_decision=None))
        assert len(calls) == 1
    else:
        assert len(calls) == 2
        assert mapping.transformation_classification == "unresolved"
