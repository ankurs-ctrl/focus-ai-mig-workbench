"""Convert source objects only through an unambiguous admitted binding."""
from copy import deepcopy

from sqlglot.errors import ParseError, TokenError

from app.core.automap_fast_context import _reference_key


def normalize_source_objects(envelope, plan):
    value = deepcopy(envelope)
    data = value.get("data") if isinstance(value.get("data"), dict) else value
    result = data.get("result") or value.get("result") or {}
    mappings = result.get("mappings") if isinstance(result, dict) else None
    rows = mappings.values() if isinstance(mappings, dict) else mappings if isinstance(mappings, list) else []
    cards = [card.body for card in plan.admitted_sources()]

    def resolve(item):
        if (type(item) is not dict or set(item) - {"source_column", "source_table", "sql_qualifier"}
                or type(item.get("source_column")) is not str
                or not (item.get("source_table") or item.get("sql_qualifier"))):
            raise ValueError("Unsupported source-reference object")
        # This object format has separate column, table and binding fields.
        # Reject qualified columns, even when their qualifier happens to agree;
        # discarding a supplied qualifier could silently rebind a self-join.
        column_key = _reference_key("dummy." + item["source_column"])
        if len(column_key) != 2:
            raise ValueError("Source object requires one unqualified column identifier")
        column = column_key[-1]
        matches = []
        for card in cards:
            binding = card["binding"]
            source_ref = f'{binding["sql_qualifier"]}.{card["column"]}'
            key = _reference_key(source_ref)
            if column != key[-1] and item["source_column"] != card["name"]:
                continue
            qualifier = item.get("sql_qualifier")
            if qualifier is not None and _reference_key(qualifier + ".dummy")[:-1] != key[:-1]:
                continue
            table = item.get("source_table")
            if table is not None:
                node = plan.store.nodes[binding["relation_id"]]
                owner = node.get("table") or {}
                fqn = ".".join(owner.get(part, "") for part in ("database", "schema", "table"))
                if not fqn.strip("."):
                    continue
                provided = _reference_key(table + ".dummy")[:-1]
                # Catalog names retain exact case. Do not casefold a genuinely
                # quoted physical table into a different uppercase table.
                actual = tuple(_reference_key(part + ".dummy")[0] if part.startswith('"') else part
                               for part in (owner.get("database", ""), owner.get("schema", ""), owner.get("table", "")))
                if not provided or actual[-len(provided):] != provided:
                    continue
            matches.append(source_ref)
        if len(matches) != 1:
            raise ValueError("Source object does not uniquely match an admitted binding")
        return matches[0]

    for row in rows:
        if not isinstance(row, dict):
            continue
        for field in ("source_attributes", "candidate_source_attributes"):
            items = row.get(field)
            if not isinstance(items, list) or not any(isinstance(item, dict) for item in items):
                continue
            try:
                converted = [resolve(item) if isinstance(item, dict) else item for item in items]
                if any(type(item) is not str for item in converted):
                    continue
                row[field] = list(dict.fromkeys(converted))
            except (ValueError, TypeError, AttributeError, ParseError, TokenError):
                # Keep the invalid field intact for target-level schema rejection
                # and focused repair. Other rows retain their valid mappings.
                pass
    return value
