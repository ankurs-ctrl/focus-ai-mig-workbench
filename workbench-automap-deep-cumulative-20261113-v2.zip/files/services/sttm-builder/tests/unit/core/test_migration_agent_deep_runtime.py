from __future__ import annotations

import threading
import time
from typing import Any

import pytest
from langchain_core.language_models.fake_chat_models import FakeMessagesListChatModel
from langchain_core.messages import AIMessage, AIMessageChunk
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.types import Command

from app.agent_tools.capability_registry import CapabilityRegistry
from app.agent_tools.workbench import WorkbenchWorkflowHandlers
from app.agent_runtime.deepagents_runtime import DeepAgentsRuntime
from app.agent_runtime.execution import (
    BudgetExceededError,
    ExecutionBudget,
    ExecutionCancelledError,
)
from app.agent_runtime.interface import RuntimeInvocation
from app.agent_runs.models import EFFORT_POLICIES, EffortLevel, RunCreateRequest, resolve_effort
from app.agent_runs.models import ToolResult
from app.migration_workflow.graph import DefaultWorkflowHandlers, build_migration_graph
from app.migration_workflow.validation import validate_mapping_set


class _DelegatingModel(FakeMessagesListChatModel):
    def bind_tools(self, tools: Any, **kwargs: Any) -> "_DelegatingModel":
        del tools, kwargs
        return self


def _model() -> _DelegatingModel:
    return _DelegatingModel(
        responses=[
            AIMessage(
                content="",
                tool_calls=[{
                    "name": "task",
                    "args": {"description": "Execute the authorized run.", "subagent_type": "migration-workflow"},
                    "id": "delegate-1",
                    "type": "tool_call",
                }],
            ),
            AIMessage(content="[FINAL] Draft is ready for review."),
        ]
    )


def _workflow_input() -> dict[str, Any]:
    return {
        "messages": [],
        "run_id": "run-1",
        "prompt": "Build Household",
        "effort": "light",
        "actor_user_id": "user-1",
        "effective_role": "MIGRATION_EDITOR",
        "tenant_id": "tenant-1",
        "requested_mappings": ["Household"],
        "authorized_target_scope": [],
        "attachment_ids": [],
    }


def test_supervisor_delegates_and_resumes_compiled_workflow_after_restart() -> None:
    saver = InMemorySaver()
    graph = build_migration_graph(checkpointer=saver)
    first_budget = ExecutionBudget(model_limit=10, tool_limit=40)
    first_runtime = DeepAgentsRuntime(
        model=_model(), migration_graph=graph, budget=first_budget, checkpointer=saver
    )
    first_runtime._registry._validated_supervisor_plan = {
        "normalized_intent": "Build Household",
        "source_preparation": {
            "driving_source": "CRM.SOURCE.FAMILIES",
            "target_table": "CRM.PUBLIC.HOUSEHOLD",
        },
        "auto_map": {"requested_mappings": ["Household"]},
        "_deep_supervisor_validated": True,
    }
    workflow_input = {
        **_workflow_input(),
        "run_mode": "plan",
        "authorized_source_scope": ["CRM.SOURCE.FAMILIES"],
        "authorized_target_scope": ["CRM.PUBLIC.HOUSEHOLD"],
    }
    first = first_runtime.invoke(
        RuntimeInvocation(
            run_id="run-1",
            thread_id="run-1",
            prompt="Build Household",
            effort=EffortLevel.LIGHT,
            workflow_input=workflow_input,
        )
    )

    assert first.status == "AWAITING_CONFIRMATION"
    assert first.interrupt and first.interrupt["category"] == "plan_approval"
    assert [(choice["choice_id"], choice["label"]) for choice in first.interrupt["choices"][:2]] == [
        ("approve", "Implement plan"), ("edit", "Update plan"),
    ]

    restarted_runtime = DeepAgentsRuntime(
        model=_model(),
        migration_graph=graph,
        budget=ExecutionBudget(
            model_limit=10,
            tool_limit=40,
            model_used=first.model_calls_used,
            tool_used=first.tool_calls_used,
        ),
        checkpointer=saver,
    )

    class _MustNotStreamOnApprovalResume:
        def stream(self, *_args: Any, **_kwargs: Any):
            raise AssertionError("A structured workflow approval must bypass the supervisor model")

    restarted_runtime._agent = _MustNotStreamOnApprovalResume()  # type: ignore[assignment]
    restarted = restarted_runtime.invoke(
        RuntimeInvocation(
            run_id="run-1",
            thread_id="run-1",
            prompt="Build Household",
            effort=EffortLevel.LIGHT,
            resume_value={"decision": "approve"},
            workflow_input=workflow_input,
        )
    )

    assert restarted.status == "NEEDS_REVIEW"  # Shadow mode cannot claim execution.
    assert restarted.workflow_state["manifest"][0]["target_table"] == "CRM.PUBLIC.HOUSEHOLD"
    assert "CRM.PUBLIC.HOUSEHOLD" in restarted.workflow_state["authorized_target_scope"]


def test_governed_plan_target_is_forwarded_without_redundant_tool_argument() -> None:
    class _RecordingGraph:
        received: dict[str, Any] | None = None

        def invoke(self, value: dict[str, Any], **_kwargs: Any) -> dict[str, Any]:
            self.received = value
            return {"status": "READY_FOR_REVIEW", "manifest": []}

    graph = _RecordingGraph()
    runtime = DeepAgentsRuntime(
        model=_model(),
        migration_graph=graph,
        budget=ExecutionBudget(model_limit=10, tool_limit=40),
    )
    runtime._active_invocation = RuntimeInvocation(
        run_id="run-plan-target",
        thread_id="run-plan-target",
        prompt="Show the plan first. After approval, build Household.",
        effort=EffortLevel.HIGH,
        workflow_input={
            **_workflow_input(),
            "authorized_source_scope": ["DB.SRC.CONTACTS"],
        },
    )

    runtime._execute_workflow_with_scope(
        [],
        ["Household"],
        {
            "source_preparation": {
                "driving_source": "DB.SRC.CONTACTS",
                "target_table": "DB.TGT.EVERNEST_HH",
            }
        },
    )

    assert graph.received is not None
    assert graph.received["authorized_target_scope"] == ["DB.TGT.EVERNEST_HH"]
    assert graph.received["target_candidates"] == ["DB.TGT.EVERNEST_HH"]
    assert graph.received["run_mode"] == "plan"


def test_valid_prepared_evidence_hands_off_at_first_completed_supervisor_boundary() -> None:
    class _Graph:
        calls = 0

        def invoke(self, value: dict[str, Any], **_kwargs: Any) -> dict[str, Any]:
            self.calls += 1
            assert value["supervisor_plan"]["source_preparation"]["supporting_sources"] == ["DB.SRC.CONTACTS"]
            return {"status": "READY_FOR_REVIEW", "mapping_results": [{"mapping_key": "household"}]}

    graph = _Graph()
    runtime = DeepAgentsRuntime(
        model=_model(), migration_graph=graph,
        budget=ExecutionBudget(model_limit=10, tool_limit=40),
    )

    class _Supervisor:
        calls = 0

        def stream(self, _input: Any, **_kwargs: Any):
            self.calls += 1
            runtime._registry._prepared_plan_candidate = {"normalized_intent": "Build Household"}
            runtime._registry._validated_supervisor_plan = {
                "normalized_intent": "Build Household",
                "source_preparation": {
                    "driving_source": "DB.SRC.FAMILIES",
                    "supporting_sources": ["DB.SRC.CONTACTS"],
                    "target_table": "DB.TGT.HOUSEHOLD",
                },
                "auto_map": {"requested_mappings": ["Household"]},
                "_deep_supervisor_validated": True,
            }
            yield "values", {"messages": [AIMessage(content="Evidence is ready.")],
                             "todos": [{"content": "Create draft", "status": "in_progress"}]}
            raise AssertionError("The supervisor should stop once a validated evidence plan is ready")

    supervisor = _Supervisor()
    runtime._agent = supervisor  # type: ignore[assignment]
    runtime._registry.validate_prepared_plan = lambda: {"status": "succeeded"}  # type: ignore[method-assign]
    result = runtime.invoke(RuntimeInvocation(
        run_id="run-prepared-boundary", thread_id="run-prepared-boundary", prompt="Build Household",
        effort=EffortLevel.MEDIUM,
        workflow_input={**_workflow_input(), "intent": "NEW_MIGRATION_TASK", "run_mode": "auto"},
    ))

    assert supervisor.calls == 1
    assert graph.calls == 1
    assert result.status == "READY_FOR_REVIEW"


def test_incomplete_evidence_allows_supervisor_to_research_sources_before_handoff() -> None:
    class _Graph:
        calls = 0

        def invoke(self, *_args: Any, **_kwargs: Any) -> dict[str, Any]:
            self.calls += 1
            return {"status": "READY_FOR_REVIEW", "mapping_results": [{"mapping_key": "household"}]}

    graph = _Graph()
    runtime = DeepAgentsRuntime(
        model=_model(), migration_graph=graph,
        budget=ExecutionBudget(model_limit=10, tool_limit=40),
    )

    class _Supervisor:
        calls = 0

        def stream(self, _input: Any, **_kwargs: Any):
            self.calls += 1
            runtime._registry._prepared_plan_review = {
                "target_table": "DB.TGT.HOUSEHOLD",
                "error_code": "source_design_incomplete",
                "unresolved": ["Target column requires source/rule evidence: OWNER_ID"],
                "evidence_refs": ["sttm_precedent:1101"],
            }
            yield "values", {"messages": [AIMessage(content="Evidence inspected")],
                             "todos": [{"content": "Build mapping", "status": "in_progress"}]}
            runtime._registry._prepared_plan_candidate = {"normalized_intent": "Build Household"}
            runtime._registry._validated_supervisor_plan = {
                "normalized_intent": "Build Household",
                "source_preparation": {
                    "driving_source": "DB.SRC.FAMILIES", "supporting_sources": [],
                    "target_table": "DB.TGT.HOUSEHOLD",
                },
                "auto_map": {"requested_mappings": ["Household"]},
                "_deep_supervisor_validated": True,
            }
            runtime._registry._prepared_plan_review = None
            yield "values", {"messages": [AIMessage(content="Current source verified")],
                             "todos": [{"content": "Build mapping", "status": "in_progress"}]}
            raise AssertionError("The supervisor must hand off the validated plan")

    supervisor = _Supervisor()
    runtime._agent = supervisor  # type: ignore[assignment]
    runtime._registry.validate_prepared_plan = lambda: {"status": "succeeded"}  # type: ignore[method-assign]
    result = runtime.invoke(RuntimeInvocation(
        run_id="incomplete-evidence", thread_id="incomplete-evidence", prompt="Build Household",
        effort=EffortLevel.MEDIUM,
        workflow_input={**_workflow_input(), "intent": "NEW_MIGRATION_TASK"},
    ))

    assert supervisor.calls == 1
    assert result.status == "READY_FOR_REVIEW"
    assert graph.calls == 1
    assert supervisor.calls == 1


def test_evidence_review_reports_all_target_columns_and_pending_work() -> None:
    result = DeepAgentsRuntime._evidence_boundary_state({
        "target_table": "DB.TGT.HOUSEHOLD",
        "target_columns": ["HOUSEHOLD_ID", "OWNER_ID"],
        "unresolved": ["Join between CONTACTS and ADDRESSES needs verification"],
        "plan_candidate": {
            "source_preparation": {
                "driving_source": "DB.SRC.CONTACTS",
                "supporting_sources": ["DB.SRC.ADDRESSES"],
                "relationships": [],
                "derived_sources": [{"name": "ADDRESS_CTE", "purpose": "Normalize addresses"}],
            },
            "auto_map": {"evidence_gaps": ["OWNER_ID"]},
        },
        "fir_cards": [{"target_column": "HOUSEHOLD_ID", "source_columns": ["DB.SRC.CONTACTS.ID"]}],
        "source_candidate_evidence": [{
            "table": "DB.SRC.FAMILIES", "target_column_lineage_count": 2,
            "accepted_precedent_count": 1, "fir_learning_count": 3,
        }],
    }, None)
    message = result["assistant_message"]
    assert result["status"] == "NEEDS_REVIEW"
    assert "HOUSEHOLD_ID" in message and "OWNER_ID" in message
    assert "**ID**  `DB.SRC.CONTACTS`" in message
    assert "ADDRESS_CTE" in message
    assert "**FAMILIES**  `DB.SRC`" in message and "| 3 |" in message
    assert "No draft was created" in message
    assert "Approval becomes available" in message
    assert "| Role | Table | Selected columns | Why included |" in message
    assert "| Target column | Source column or rule | Classification | Evidence |" in message


def test_preflight_source_candidates_reach_supervisor_as_research_not_plan() -> None:
    runtime = DeepAgentsRuntime(
        model=_model(), migration_graph=build_migration_graph(),
        budget=ExecutionBudget(model_limit=10, tool_limit=40),
    )
    runtime._registry._prepared_plan_review = {
        "target_table": "DB.TGT.HOUSEHOLD",
        "historical_source_candidates": ["DB.SRC.FAMILIES"],
        "source_candidate_evidence": [{"table": "DB.SRC.FAMILIES", "precedent_count": 2}],
        "fir_cards": [{"learning_id": "learning-1"}],
    }
    invocation = RuntimeInvocation(
        run_id="preflight-research", thread_id="preflight-research", prompt="Plan Household",
        effort=EffortLevel.MEDIUM,
        workflow_input={**_workflow_input(), "intent": "NEW_MIGRATION_TASK"},
    )
    runtime._active_invocation = invocation
    content = runtime._agent_input(invocation)["messages"][-1]["content"]
    assert "DB.SRC.FAMILIES" in content
    assert "not a validated plan" in content
    assert "Continue current-catalog source research" in content


def test_source_research_idle_boundary_nudges_to_domain_action() -> None:
    class _Graph:
        def invoke(self, *_args: Any, **_kwargs: Any) -> dict[str, Any]:
            return {"status": "READY_FOR_REVIEW"}

    runtime = DeepAgentsRuntime(
        model=_model(), migration_graph=_Graph(),
        budget=ExecutionBudget(model_limit=20, tool_limit=40),
    )

    class _Supervisor:
        calls = 0

        def stream(self, agent_input: Any, **_kwargs: Any):
            self.calls += 1
            if self.calls == 1:
                runtime._registry._prepared_plan_review = {
                    "target_table": "DB.TGT.HOUSEHOLD",
                    "source_candidate_evidence": [{"table": "DB.SRC.FAMILIES"}],
                    "unresolved": ["Select a verified driving source"],
                }
                for _ in range(6):
                    yield "values", {"messages": [AIMessage(content="Still thinking")],
                                     "todos": [{"content": "Research source", "status": "in_progress"}]}
                raise AssertionError("Idle reasoning must be interrupted before another loop")
            assert "DB.SRC.FAMILIES" in agent_input["messages"][-1]["content"]
            assert "Host source-research boundary" in agent_input["messages"][-1]["content"]
            runtime._registry._prepared_plan_review = None
            runtime._registry._prepared_plan_candidate = {"normalized_intent": "Build Household"}
            runtime._registry._validated_supervisor_plan = {
                "normalized_intent": "Build Household",
                "source_preparation": {"driving_source": "DB.SRC.FAMILIES", "target_table": "DB.TGT.HOUSEHOLD"},
                "auto_map": {"requested_mappings": ["Household"]},
                "_deep_supervisor_validated": True,
            }
            yield "values", {"messages": [AIMessage(content="Current source verified")],
                             "todos": [{"content": "Build mapping", "status": "in_progress"}]}

    supervisor = _Supervisor()
    runtime._agent = supervisor  # type: ignore[assignment]
    runtime._registry.validate_prepared_plan = lambda: {"status": "succeeded"}  # type: ignore[method-assign]
    result = runtime.invoke(RuntimeInvocation(
        run_id="idle-source-research", thread_id="idle-source-research", prompt="Build Household",
        effort=EffortLevel.MEDIUM,
        workflow_input={**_workflow_input(), "intent": "NEW_MIGRATION_TASK"},
    ))
    assert supervisor.calls == 2
    assert result.status == "READY_FOR_REVIEW"


def test_configured_target_request_reaches_supervisor_before_preparation() -> None:
    runtime = DeepAgentsRuntime(
        model=_model(), migration_graph=build_migration_graph(checkpointer=InMemorySaver()),
        budget=ExecutionBudget(model_limit=3, tool_limit=10),
    )
    runtime._registry.prepare_configured_target = lambda: (_ for _ in ()).throw(  # type: ignore[method-assign]
        AssertionError("Configured-target preparation must follow supervisor intent")
    )

    class _Supervisor:
        calls = 0

        def stream(self, *_args: Any, **_kwargs: Any):
            self.calls += 1
            yield "messages", AIMessageChunk(content="[PROGRESS] I’ll inspect the saved Household mapping and its sources first.")
            yield "values", {"messages": [AIMessage(content="[FINAL] Source evidence is needed.")], "todos": []}

    supervisor = _Supervisor()
    runtime._agent = supervisor  # type: ignore[assignment]
    runtime.invoke(RuntimeInvocation(
        run_id="configured-plan", thread_id="configured-plan", prompt="Plan Household mapping",
        effort=EffortLevel.MEDIUM,
        workflow_input={**_workflow_input(), "intent": "NEW_MIGRATION_TASK", "run_mode": "plan",
                        "authorized_source_scope": ["DB.SRC.FAMILIES"],
                        "authorized_target_scope": ["DB.TGT.HOUSEHOLD"]},
    ))
    assert supervisor.calls >= 1


def test_compiled_subagent_refuses_unvalidated_supervisor_handoff() -> None:
    runtime = DeepAgentsRuntime(
        model=_model(), migration_graph=build_migration_graph(),
        budget=ExecutionBudget(model_limit=10, tool_limit=40),
    )
    runtime._active_invocation = RuntimeInvocation(
        run_id="run-unvalidated-handoff",
        thread_id="run-unvalidated-handoff",
        prompt="Build Household",
        effort=EffortLevel.LIGHT,
        workflow_input=_workflow_input(),
    )

    result = runtime._invoke_compiled_workflow({})

    assert result["status"] == "PLAN_REVISION_REQUIRED"
    assert result["review_items"][0]["category"] == "supervisor_plan_required"


def test_source_preparation_block_preserves_draft_ids_and_exact_findings() -> None:
    class _BlockedGraph:
        def invoke(self, *_args: Any, **_kwargs: Any) -> dict[str, Any]:
            return {
                "status": "PLAN_REVISION_REQUIRED",
                "project_id": "project-42",
                "manifest": [{"sttm_id": "sttm-7"}],
                "plan_revision_request": {
                    "category": "source_preparation",
                    "evidence_ids": ["sttm_precedent:old"],
                    "diagnostics": {"validation_findings": [{
                        "category": "relationship_graph",
                        "blocking": True,
                        "safe_summary": "The source graph is disconnected.",
                        "details": {"disconnected_tables": ["DB.SRC.EXTRA"]},
                    }]},
                },
            }

    runtime = DeepAgentsRuntime(
        model=_model(), migration_graph=_BlockedGraph(),
        budget=ExecutionBudget(model_limit=10, tool_limit=40),
    )
    runtime._active_invocation = RuntimeInvocation(
        run_id="blocked-source", thread_id="blocked-source", prompt="Build Household",
        effort=EffortLevel.MEDIUM, workflow_input=_workflow_input(),
    )
    result = runtime._run_workflow({})
    assert result["status"] == "NEEDS_REVIEW"
    assert result["project_id"] == "project-42"
    assert result["manifest"][0]["sttm_id"] == "sttm-7"
    assert result["review_items"][0]["category"] == "relationship_graph"
    assert result["review_items"][0]["evidence_refs"] == ["sttm_precedent:old"]
    terminal = runtime._to_result({"messages": []})
    assert terminal.status == "NEEDS_REVIEW"
    assert "Source preparation blocked Auto Map" in terminal.assistant_message


def test_durable_resume_retries_unchanged_approved_source_plan(monkeypatch: pytest.MonkeyPatch) -> None:
    from types import SimpleNamespace

    class _SourceRetryGraph:
        def __init__(self) -> None:
            self.updated: tuple[Any, Any, Any] | None = None
            self.invoked: Any = "not called"

        def get_state(self, _config: Any) -> Any:
            return SimpleNamespace(values={
                "run_id": "run-source-retry", "status": "PLAN_REVISION_REQUIRED",
                "project_id": "project-42", "manifest": [{"sttm_id": "sttm-7"}],
                "migration_plan": {"plan_hash": "approved-hash"},
                "plan_revision_request": {"category": "source_preparation"},
            })

        def update_state(self, config: Any, values: Any, *, as_node: str) -> None:
            self.updated = (config, values, as_node)

        def invoke(self, value: Any, **_kwargs: Any) -> dict[str, Any]:
            self.invoked = value
            return {"status": "READY_FOR_REVIEW", "project_id": "project-42"}

    graph = _SourceRetryGraph()
    monkeypatch.setattr(
        "app.agent_runtime.deepagents_runtime.MigrationPlanArtifactV1",
        SimpleNamespace(model_validate=lambda _value: SimpleNamespace(plan_hash="approved-hash")),
    )
    runtime = DeepAgentsRuntime(
        model=_model(), migration_graph=graph,
        budget=ExecutionBudget(model_limit=10, tool_limit=40),
    )
    invocation = RuntimeInvocation(
        run_id="run-source-retry", thread_id="run-source-retry", prompt="continue",
        effort=EffortLevel.HIGH, is_resume=True, workflow_input=_workflow_input(),
    )
    runtime._active_invocation = invocation
    result = runtime._retry_approved_source_preparation(invocation)

    assert result["status"] == "READY_FOR_REVIEW"
    assert graph.updated is not None
    assert graph.updated[1]["approved_plan_hash"] == "approved-hash"
    assert graph.updated[2] == "create_draft_mappings"
    assert graph.invoked is None


def test_durable_resume_continues_scheduled_source_retry() -> None:
    from types import SimpleNamespace

    class _ScheduledGraph:
        def __init__(self) -> None:
            self.invoked: Any = "not called"

        def get_state(self, _config: Any) -> Any:
            return SimpleNamespace(next=("prepare_sources",), values={
                "run_id": "run-source-retry", "status": "EXECUTING",
                "project_id": "project-42", "approved_plan_hash": "approved-hash",
            })

        def update_state(self, *_args: Any, **_kwargs: Any) -> None:
            raise AssertionError("The prepared node was already scheduled")

        def invoke(self, value: Any, **_kwargs: Any) -> dict[str, Any]:
            self.invoked = value
            return {"status": "READY_FOR_REVIEW", "project_id": "project-42"}

    graph = _ScheduledGraph()
    runtime = DeepAgentsRuntime(
        model=_model(), migration_graph=graph,
        budget=ExecutionBudget(model_limit=10, tool_limit=40),
    )
    invocation = RuntimeInvocation(
        run_id="run-source-retry", thread_id="run-source-retry", prompt="continue",
        effort=EffortLevel.HIGH, is_resume=True, workflow_input=_workflow_input(),
    )
    runtime._active_invocation = invocation
    result = runtime._retry_approved_source_preparation(invocation)

    assert result["status"] == "READY_FOR_REVIEW"
    assert graph.invoked is None


def test_durable_resume_retries_failed_mapping_partition_without_research() -> None:
    from types import SimpleNamespace

    class _MappingRetryGraph:
        def __init__(self) -> None:
            self.updated = None

        def get_state(self, _config: Any) -> Any:
            return SimpleNamespace(next=(), values={
                "run_id": "run-mapping-retry", "status": "NEEDS_REVIEW",
                "project_id": "project-42", "approved_plan_hash": "approved-hash",
                "source_preparation_result": {"status": "succeeded"},
                "mapping_results": [{"partitions": [{"state": "NEEDS_REVIEW"}]}],
            })

        def update_state(self, config, values, *, as_node):
            self.updated = (config, values, as_node)

        def invoke(self, value, **_kwargs):
            assert value is None
            return {"status": "READY_FOR_REVIEW", "project_id": "project-42"}

    graph = _MappingRetryGraph()
    runtime = DeepAgentsRuntime(
        model=_model(), migration_graph=graph,
        budget=ExecutionBudget(model_limit=10, tool_limit=40),
    )
    invocation = RuntimeInvocation(
        run_id="run-mapping-retry", thread_id="run-mapping-retry", prompt="continue",
        effort=EffortLevel.HIGH, is_resume=True, workflow_input=_workflow_input(),
    )
    runtime._active_invocation = invocation
    result = runtime._retry_approved_source_preparation(invocation)
    assert result["status"] == "READY_FOR_REVIEW"
    assert graph.updated[1]["mapping_results"] == []
    assert graph.updated[2] == "prepare_sources"


def test_scoped_sql_lineage_satisfies_relationship_gate_only_after_validation() -> None:
    mapping = {
        "mapping_key": "household", "source_table_count": 3, "relationship_count": 0,
        "scoped_sql_lineage_verified": True,
    }
    report = validate_mapping_set([], [mapping], ["relationships"])
    assert report["passed"] is True
    report = validate_mapping_set([], [{**mapping, "scoped_sql_lineage_verified": False}], ["relationships"])
    assert report["passed"] is False


def test_auto_run_creates_run_owned_drafts_without_plan_approval() -> None:
    saver = InMemorySaver()
    graph = build_migration_graph(checkpointer=saver)
    handlers = DefaultWorkflowHandlers()
    state = {
        **_workflow_input(),
        "run_mode": "auto",
        "authorized_target_scope": ["CRM.PUBLIC.HOUSEHOLD"],
    }

    result = graph.invoke(state, config={"configurable": {"thread_id": "approval-run"}})

    assert result["status"] == "NEEDS_REVIEW"  # Shadow handlers leave required work unresolved.
    assert "__interrupt__" not in result
    assert result["approved_plan_hash"] == result["migration_plan"]["plan_hash"]
    assert result.get("project_id") is None
    assert result["migration_plan"]["execution_steps"]
    assert result["migration_plan"]["execution_steps"][-1]["title"] == "Return the unpublished draft"


def test_complex_agent_run_executes_without_optional_mode_switch_question() -> None:
    saver = InMemorySaver()
    graph = build_migration_graph(checkpointer=saver)
    config = {"configurable": {"thread_id": "complex-plan-offer"}}
    state = {
        **_workflow_input(),
        "run_mode": "auto",
        "authorized_source_scope": ["DB.SRC.A", "DB.SRC.B", "DB.SRC.C"],
        "authorized_target_scope": ["DB.TGT.HOUSEHOLD"],
        "supervisor_plan": {
            "normalized_intent": "Build a multi-source household mapping",
            "source_preparation": {
                "driving_source": "DB.SRC.A",
                "supporting_sources": ["DB.SRC.B", "DB.SRC.C"],
                "target_table": "DB.TGT.HOUSEHOLD",
                "relationships": [
                    {"left_table": "DB.SRC.A", "right_table": "DB.SRC.B", "join_type": "LEFT", "condition": "A.ID = B.ID"},
                    {"left_table": "DB.SRC.A", "right_table": "DB.SRC.C", "join_type": "LEFT", "condition": "A.ID = C.ID"},
                ],
            },
            "auto_map": {"requested_mappings": ["Household"]},
            "recommend_plan_review": True,
            "plan_review_reason": "Three sources and two joins make fanout review valuable.",
        },
    }

    completed = graph.invoke(state, config=config)
    assert "__interrupt__" not in completed
    assert completed["status"] == "NEEDS_REVIEW"  # No domain adapters were configured.
    assert completed["run_mode"] == "auto"
    assert completed["approved_plan_hash"] == completed["migration_plan"]["plan_hash"]
    assert completed["migration_plan"]["source_preparation"]["supporting_sources"] == ["DB.SRC.B", "DB.SRC.C"]


def test_follow_up_carries_prior_receipts_into_the_context_package() -> None:
    graph = build_migration_graph()
    result = graph.invoke({
        **_workflow_input(),
        "run_mode": "auto",
        "authorized_target_scope": ["CRM.PUBLIC.HOUSEHOLD"],
        "page_context": {
            "prior_run_evidence": [{
                "event_type": "workspace.synced",
                "capability": "Existing Household draft",
                "evidence_refs": ["contract:household"],
                "artifact_refs": ["sttm:existing-household"],
            }],
        },
    })

    reused = result["mapping_context_package"]["precedent_evidence"]
    assert reused[0]["evidence_id"] == "contract:household"
    assert reused[0]["artifact_ref"] == "sttm:existing-household"
    assert reused[0]["validated"] is True


def test_plan_edit_supersedes_the_hash_and_returns_to_approval() -> None:
    saver = InMemorySaver()
    graph = build_migration_graph(checkpointer=saver)
    config = {"configurable": {"thread_id": "plan-edit-run"}}
    first = graph.invoke(
        {
            **_workflow_input(),
            "run_mode": "plan",
            "authorized_target_scope": ["CRM.PUBLIC.HOUSEHOLD"],
        },
        config=config,
    )
    first_hash = first["migration_plan"]["plan_hash"]

    edit_prompt = graph.invoke(Command(resume={"choice_id": "edit"}), config=config)
    assert edit_prompt["__interrupt__"][0].value["category"] == "plan_edit"

    revision_request = graph.invoke(
        Command(resume={"answer": "Use the customer relationship and validate fan-out."}),
        config=config,
    )

    assert revision_request["status"] == "PLAN_REVISION_REQUIRED"
    assert "__interrupt__" not in revision_request

    revised = graph.invoke(
        {
            **_workflow_input(),
            "run_mode": "plan",
            "authorized_target_scope": ["CRM.PUBLIC.HOUSEHOLD"],
            "supervisor_plan": {
                "normalized_intent": "Use the customer relationship and validate fan-out",
                "source_preparation": {},
                "auto_map": {"requested_mappings": ["Household"]},
                "execution_steps": [{
                    "sequence": 1,
                    "title": "Validate customer fan-out",
                    "description": "Measure fan-out before accepting the relationship.",
                    "phase": "validation",
                    "query_kind": "join_check",
                    "dynamic_sql": True,
                }],
            },
        },
        config=config,
    )

    assert revised["__interrupt__"][0].value["category"] == "plan_approval"
    assert revised["migration_plan"]["revision"] == 2
    assert revised["migration_plan"]["plan_hash"] != first_hash
    assert revised.get("project_id") is None


def test_close_verified_candidates_pause_with_immutable_ranked_choices() -> None:
    saver = InMemorySaver()
    graph = build_migration_graph(checkpointer=saver)
    config = {"configurable": {"thread_id": "confidence-gate-run"}}
    first = graph.invoke(
        {
            **_workflow_input(),
            "run_mode": "auto",
            "authorized_source_scope": ["DB.SRC.CUSTOMER", "DB.SRC.PARTY"],
            "authorized_target_scope": ["DB.TGT.CUSTOMER"],
            "supervisor_plan": {
                "normalized_intent": "Build customer mapping",
                "source_preparation": {
                    "driving_source": "DB.SRC.CUSTOMER",
                    "target_table": "DB.TGT.CUSTOMER",
                },
                "auto_map": {"requested_mappings": ["Customer"]},
                "decisions": [{
                    "subject": "source",
                    "selected_value": "DB.SRC.CUSTOMER",
                    "confidence": 0.72,
                    "score_margin": 0.05,
                    "rationale": "Best contract match, but the scores are close.",
                    "evidence_ids": ["contract:customer"],
                    "alternatives": [{
                        "value": "DB.SRC.PARTY",
                        "label": "DB.SRC.PARTY",
                        "description": "Broader party-grain contract.",
                        "impact": "May include non-customer party rows.",
                        "evidence_ids": ["contract:party"],
                    }],
                }],
            },
        },
        config=config,
    )

    payload = first["__interrupt__"][0].value
    assert payload["category"] == "confidence_gate"
    assert len(payload["choices"]) == 2
    assert sum(bool(choice["recommended"]) for choice in payload["choices"]) == 0
    assert payload["choices"][1]["selection_payload"]["selected_value"] == "DB.SRC.PARTY"

    completed = graph.invoke(
        Command(resume=payload["choices"][1]["selection_payload"]),
        config=config,
    )
    assert completed["migration_plan"]["source_preparation"]["driving_source"] == "DB.SRC.PARTY"


def test_historical_firm_value_requires_current_answer_before_plan_approval() -> None:
    saver = InMemorySaver()
    graph = build_migration_graph(checkpointer=saver)
    config = {"configurable": {"thread_id": "firm-binding-run"}}
    first = graph.invoke({
        **_workflow_input(),
        "run_mode": "plan",
        "authorized_source_scope": ["DB.SRC.CONTACTS"],
        "authorized_target_scope": ["DB.TGT.HOUSEHOLD"],
        "supervisor_plan": {
            "normalized_intent": "Build household mapping",
            "source_preparation": {
                "driving_source": "DB.SRC.CONTACTS",
                "target_table": "DB.TGT.HOUSEHOLD",
                "value_bindings": [{
                    "name": "FirmId", "placeholder": "$FirmId", "candidate_value": "1101",
                    "target_columns": ["FIRM_ID"], "source": "historical_sql", "data_type": "INT",
                    "resolution_status": "unresolved", "approval_state": "candidate",
                }],
            },
            "auto_map": {"target_columns": ["FIRM_ID"]},
            "decisions": [{
                "subject": "value_binding", "decision_key": "FirmId",
                "selected_value": "1101", "confidence": 0.3, "score_margin": 0,
                "rationale": "1101 came from a prior firm's SQL.",
                "question": "Which firm ID applies to this project?",
                "alternatives": [{"value": "__provide_current__", "label": "Enter current firm ID"}],
                "allow_free_text": True,
            }],
        },
    }, config=config)
    prompt = first["__interrupt__"][0].value
    assert prompt["category"] == "confidence_gate"
    assert prompt["recommended_choice_id"] is None
    assert prompt["question"] == "Which firm ID applies to this project?"
    second = graph.invoke(Command(resume=prompt["choices"][1]["selection_payload"]), config=config)
    assert second["__interrupt__"][0].value["category"] == "value_binding_input"
    invalid = graph.invoke(Command(resume="not-a-number"), config=config)
    assert invalid["__interrupt__"][0].value["category"] == "value_binding_input"
    approved = graph.invoke(Command(resume="2202"), config=config)
    assert approved["__interrupt__"][0].value["category"] == "plan_approval"
    binding = approved["migration_plan"]["source_preparation"]["value_bindings"][0]
    assert binding["resolved_value"] == "2202"
    assert binding["source"] == "user_answer"


def test_join_clarification_replaces_only_the_chosen_verified_pair() -> None:
    saver = InMemorySaver()
    graph = build_migration_graph(checkpointer=saver)
    config = {"configurable": {"thread_id": "join-choice-run"}}
    original = {"left_table": "DB.SRC.CONTACTS", "right_table": "DB.SRC.ADDRESSES",
                "join_type": "LEFT", "conditions": [{"left_column": "ID", "right_column": "CONTACT_ID"}]}
    alternative = {**original, "conditions": [{"left_column": "ID", "right_column": "PARENT_ID"}]}
    first = graph.invoke({
        **_workflow_input(), "run_mode": "plan",
        "authorized_source_scope": ["DB.SRC.CONTACTS", "DB.SRC.ADDRESSES"],
        "authorized_target_scope": ["DB.TGT.HOUSEHOLD"],
        "supervisor_plan": {
            "normalized_intent": "Build household mapping",
            "source_preparation": {"driving_source": "DB.SRC.CONTACTS",
                                   "supporting_sources": ["DB.SRC.ADDRESSES"],
                                   "relationships": [original], "target_table": "DB.TGT.HOUSEHOLD"},
            "auto_map": {"target_columns": ["ID"]},
            "decisions": [{"subject": "join", "decision_key": "DB.SRC.ADDRESSES / DB.SRC.CONTACTS",
                           "selected_value": "join_0", "confidence": 0.5, "score_margin": 0,
                           "rationale": "Two current join contracts disagree.",
                           "question": "Which join rule applies?",
                           "alternatives": [{"value": "join_1", "label": "Use parent ID",
                                             "relationship": alternative}]}],
        },
    }, config=config)
    prompt = first["__interrupt__"][0].value
    assert prompt["category"] == "confidence_gate"
    revised = graph.invoke(Command(resume=prompt["choices"][1]["selection_payload"]), config=config)
    assert revised["__interrupt__"][0].value["category"] == "plan_approval"
    assert revised["migration_plan"]["source_preparation"]["relationships"] == [alternative]


def test_source_research_answer_rebuilds_plan_on_same_durable_checkpoint() -> None:
    class Resolver(DefaultWorkflowHandlers):
        def resolve_source_clarification(self, _state: dict[str, Any], selected: str) -> dict[str, Any]:
            assert selected == "DB.SRC.CONTACTS"
            return {"status": "succeeded", "supervisor_plan": {
                "_deep_supervisor_validated": True,
                "normalized_intent": "Build household mapping",
                "source_preparation": {"driving_source": selected,
                                       "target_table": "DB.TGT.HOUSEHOLD"},
                "auto_map": {"target_columns": ["ID"], "mapping_evidence": [
                    {"target_column": "ID", "source_columns": ["CONTACTS.ID"],
                     "mapping_mode": "direct"}]},
            }}

    graph = build_migration_graph(Resolver(), checkpointer=InMemorySaver())
    config = {"configurable": {"thread_id": "source-research-run"}}
    first = graph.invoke({
        **_workflow_input(), "run_mode": "plan",
        "authorized_target_scope": ["DB.TGT.HOUSEHOLD"],
        "target_candidates": ["DB.TGT.HOUSEHOLD"],
        "research_clarification": {
            "target_table": "DB.TGT.HOUSEHOLD",
            "question": "Which source defines one Household row?",
            "choices": [{"choice_id": "source_1", "label": "DB.SRC.CONTACTS",
                         "selection_payload": {"selected_value": "DB.SRC.CONTACTS"}}],
            "action_digest": "research-digest", "artifact_revision": "1",
        },
        "supervisor_plan": {"source_preparation": {"driving_source": "DB.SRC.CONTACTS",
                                                   "target_table": "DB.TGT.HOUSEHOLD"}},
    }, config=config)
    prompt = first["__interrupt__"][0].value
    assert prompt["category"] == "source_research_choice"
    assert first.get("project_id") is None
    resumed = graph.invoke(Command(resume=prompt["choices"][0]["selection_payload"]), config=config)
    assert resumed["__interrupt__"][0].value["category"] == "plan_approval"
    assert resumed["migration_plan"]["source_preparation"]["driving_source"] == "DB.SRC.CONTACTS"
    assert resumed.get("project_id") is None


def test_source_research_answer_exposes_each_unverified_join_before_drafting() -> None:
    findings = [
        "Current relationship evidence has no join path to DB.SRC.CONTACTS: DB.SRC.ADDRESSES",
        "Current relationship evidence has no join path to DB.SRC.CONTACTS: DB.SRC.COUNTRY_CODES",
    ]

    class Resolver(DefaultWorkflowHandlers):
        def resolve_source_clarification(self, _state: dict[str, Any], selected: str) -> dict[str, Any]:
            assert selected == "DB.SRC.CONTACTS"
            return {"status": "needs_input", "error_code": "source_design_incomplete",
                    "summary": "Source design has unresolved evidence; investigate before draft execution.",
                    "data": {"unresolved": findings, "next_action": "research_source_design"}}

    graph = build_migration_graph(Resolver(), checkpointer=InMemorySaver())
    config = {"configurable": {"thread_id": "source-research-unverified-joins"}}
    first = graph.invoke({
        **_workflow_input(), "run_mode": "plan",
        "authorized_target_scope": ["DB.TGT.HOUSEHOLD"],
        "target_candidates": ["DB.TGT.HOUSEHOLD"],
        "research_clarification": {
            "target_table": "DB.TGT.HOUSEHOLD",
            "question": "Which source defines one Household row?",
            "choices": [{"choice_id": "source_1", "label": "DB.SRC.CONTACTS",
                         "selection_payload": {"selected_value": "DB.SRC.CONTACTS"}}],
            "action_digest": "research-digest", "artifact_revision": "1",
        },
        "supervisor_plan": {"source_preparation": {"driving_source": "DB.SRC.CONTACTS",
                                                   "target_table": "DB.TGT.HOUSEHOLD"}},
    }, config=config)
    prompt = first["__interrupt__"][0].value
    result = graph.invoke(Command(resume=prompt["choices"][0]["selection_payload"]), config=config)

    assert result["status"] == "NEEDS_REVIEW"
    assert [item["safe_summary"] for item in result["review_items"]] == findings
    assert "Your choice of DB.SRC.CONTACTS was recorded" in result["assistant_message"]
    assert all(finding in result["assistant_message"] for finding in findings)
    assert result.get("project_id") is None


def test_source_research_asks_for_join_paths_one_at_a_time_before_plan_approval() -> None:
    driver = "DB.SRC.CONTACTS"
    first_table, second_table = "DB.SRC.ADDRESSES", "DB.SRC.COUNTRY_CODES"
    captured: list[dict[str, Any]] = []

    class Resolver(DefaultWorkflowHandlers):
        def resolve_source_clarification(self, _state: dict[str, Any], selected: str) -> dict[str, Any]:
            assert selected == driver
            return {"status": "needs_input", "error_code": "source_design_incomplete",
                    "data": {"unresolved": ["missing join paths"]},
                    "join_questions": [
                        {"target": first_table, "driver": driver, "options": [{"id": "path_1",
                            "label": "Use CONTACTS to ADDRESSES", "joins": [{"left_table": driver,
                            "right_table": first_table, "conditions": [{"left_column": "ID", "right_column": "CONTACT_ID"}]}]}]},
                        {"target": second_table, "driver": driver, "options": []},
                    ]}

        def resolve_join_clarifications(self, _state: dict[str, Any], answers: list[dict[str, Any]]) -> dict[str, Any]:
            captured.extend(answers)
            return {"status": "succeeded", "supervisor_plan": {
                "_deep_supervisor_validated": True, "normalized_intent": "Build household mapping",
                "source_preparation": {"driving_source": driver, "supporting_sources": [first_table, second_table],
                                       "target_table": "DB.TGT.HOUSEHOLD"},
                "auto_map": {"target_columns": ["ID"], "mapping_evidence": [{"target_column": "ID",
                    "source_columns": ["CONTACTS.ID"], "mapping_mode": "direct"}]},
            }}

    graph = build_migration_graph(Resolver(), checkpointer=InMemorySaver())
    config = {"configurable": {"thread_id": "join-question-sequence"}}
    initial = graph.invoke({**_workflow_input(), "run_mode": "plan",
        "authorized_target_scope": ["DB.TGT.HOUSEHOLD"], "target_candidates": ["DB.TGT.HOUSEHOLD"],
        "research_clarification": {"target_table": "DB.TGT.HOUSEHOLD", "question": "Which driver?",
            "choices": [{"choice_id": "source_1", "label": driver,
                         "selection_payload": {"selected_value": driver}}]},
        "supervisor_plan": {"source_preparation": {"driving_source": driver,
                                                   "target_table": "DB.TGT.HOUSEHOLD"}}}, config=config)
    source_prompt = initial["__interrupt__"][0].value
    first = graph.invoke(Command(resume=source_prompt["choices"][0]["selection_payload"]), config=config)
    first_prompt = first["__interrupt__"][0].value
    assert first_prompt["category"] == "source_join_path"
    assert first_table in first_prompt["question"]
    second = graph.invoke(Command(resume=first_prompt["choices"][0]["selection_payload"]), config=config)
    second_prompt = second["__interrupt__"][0].value
    assert second_prompt["category"] == "source_join_path"
    assert second_table in second_prompt["question"]
    final = graph.invoke(Command(resume={"answer": "ADDRESSES.COUNTRY = COUNTRY_CODES.CODE"}), config=config)
    assert final["__interrupt__"][0].value["category"] == "plan_approval"
    assert captured[0]["joins"][0]["right_table"] == first_table
    assert captured[1]["rule"] == "ADDRESSES.COUNTRY = COUNTRY_CODES.CODE"


def test_invalid_reviewed_join_reopens_question_with_validated_alternative() -> None:
    driver, target = "DB.SRC.CONTACTS", "DB.SRC.MEMBERS"
    seen: list[list[dict[str, Any]]] = []

    class Resolver(DefaultWorkflowHandlers):
        def resolve_source_clarification(self, _state: dict[str, Any], _selected: str) -> dict[str, Any]:
            return {"status": "needs_input", "join_questions": [{"target": target, "driver": driver,
                "options": [
                    {"id": "stale", "label": "Old key", "joins": [{"left_table": driver, "right_table": target,
                        "conditions": [{"left_column": "OLD_ID", "right_column": "CONTACT_ID"}]}]},
                    {"id": "current", "label": "Current key", "joins": [{"left_table": driver, "right_table": target,
                        "conditions": [{"left_column": "ID", "right_column": "CONTACT_ID"}]}]},
                ]}]}

        def validate_join_candidate(self, joins: list[dict[str, Any]]) -> dict[str, Any]:
            if joins[0]["conditions"][0]["left_column"] == "OLD_ID":
                return {"status": "needs_input", "summary": f"{driver} has no column OLD_ID."}
            return {"status": "succeeded"}

        def resolve_join_clarifications(self, _state: dict[str, Any], answers: list[dict[str, Any]]) -> dict[str, Any]:
            seen.extend(answer["joins"] for answer in answers)
            return {"status": "needs_input", "summary": "More evidence needed"}

    graph = build_migration_graph(Resolver(), checkpointer=InMemorySaver())
    config = {"configurable": {"thread_id": "join-retry-valid-option"}}
    initial = graph.invoke({**_workflow_input(), "run_mode": "plan",
        "authorized_target_scope": ["DB.TGT.HOUSEHOLD"], "target_candidates": ["DB.TGT.HOUSEHOLD"],
        "research_clarification": {"target_table": "DB.TGT.HOUSEHOLD", "question": "Which driver?",
            "choices": [{"choice_id": "driver", "label": driver,
                         "selection_payload": {"selected_value": driver}}]},
        "supervisor_plan": {"source_preparation": {"driving_source": driver,
                                                   "target_table": "DB.TGT.HOUSEHOLD"}}}, config=config)
    source = initial["__interrupt__"][0].value
    first = graph.invoke(Command(resume=source["choices"][0]["selection_payload"]), config=config)
    question = first["__interrupt__"][0].value
    rejected = graph.invoke(Command(resume=question["choices"][0]["selection_payload"]), config=config)
    corrected = rejected["__interrupt__"][0].value
    assert "OLD_ID" in corrected["safe_summary"]
    assert [choice["label"] for choice in corrected["choices"]] == ["Current key", "Leave MEMBERS out of this mapping"]
    assert corrected["choices"][-1]["recommended"] is False  # a verified alternative exists
    graph.invoke(Command(resume=corrected["choices"][0]["selection_payload"]), config=config)
    assert seen and seen[0][0]["conditions"][0]["left_column"] == "ID"


def test_reviewed_join_path_checks_current_columns_before_staging() -> None:
    from unittest.mock import Mock

    registry = CapabilityRegistry.__new__(CapabilityRegistry)
    registry._prepared_plan_candidate = {"source_preparation": {
        "driving_source": "DB.SRC.CONTACTS", "supporting_sources": ["DB.SRC.ADDRESSES"],
        "relationships": [], "unresolved_items": [
            "Current relationship evidence has no join path to DB.SRC.CONTACTS: DB.SRC.ADDRESSES",
        ],
    }}
    registry._validated_supervisor_plan = None
    registry._catalog_candidates = {"DB.SRC.CONTACTS", "DB.SRC.ADDRESSES"}
    registry._workbench = Mock()
    registry._workbench._type_family.side_effect = lambda value: value.split("(")[0]
    registry._workbench.inspect_table_contract.side_effect = lambda table: ToolResult(
        status="succeeded", summary="Current contract", data={
            "columns": ["ID"] if table.endswith("CONTACTS") else ["CONTACT_ID"],
            "column_contracts": [{"name": "ID" if table.endswith("CONTACTS") else "CONTACT_ID",
                                  "type": "NUMBER(38,0)"}],
        })
    captured = []
    registry._plan_validator = lambda plan: (captured.append(plan) or {"status": "succeeded"})
    join = {"left_table": "DB.SRC.CONTACTS", "right_table": "DB.SRC.ADDRESSES",
            "conditions": [{"left_column": "ID", "right_column": "CONTACT_ID"}]}
    assert registry.apply_reviewed_join_path([join])["status"] == "succeeded"
    assert captured[0]["source_preparation"]["unresolved_items"] == []
    assert captured[0]["source_preparation"]["relationships"][0]["source"] == "HISTORICAL_CANDIDATE"

    invalid = {**join, "conditions": [{"left_column": "MISSING", "right_column": "CONTACT_ID"}]}
    assert registry.apply_reviewed_join_path([invalid])["error_code"] == "join_column_invalid"


def test_reviewed_bridge_is_added_to_source_plan_with_join_columns() -> None:
    from unittest.mock import Mock

    driver, bridge, target = "DB.SRC.CONTACTS", "DB.SRC.FAMILIES", "DB.SRC.ADDRESSES"
    registry = CapabilityRegistry.__new__(CapabilityRegistry)
    registry._prepared_plan_candidate = {"source_preparation": {
        "driving_source": driver, "supporting_sources": [target], "relationships": [],
        "precedent_reference": {"sttm_id": "1101"},
        "unresolved_items": [f"Current relationship evidence has no join path to {driver}: {target}"],
    }}
    registry._catalog_candidates = {driver, bridge, target}
    registry._validated_supervisor_plan = None
    registry._workbench = Mock()
    registry._workbench._type_family.side_effect = lambda value: value.split("(")[0]
    registry._workbench.inspect_table_contract.side_effect = lambda _table: ToolResult(
        status="succeeded", summary="Current contract",
        data={"columns": ["ID", "FAMILY_ID"], "column_contracts": [
            {"name": "ID", "type": "NUMBER(38,0)"},
            {"name": "FAMILY_ID", "type": "NUMBER(38,0)"},
        ]})
    captured = []
    registry._plan_validator = lambda plan: (captured.append(plan) or {"status": "succeeded"})
    joins = [
        {"left_table": driver, "right_table": bridge,
         "conditions": [{"left_column": "FAMILY_ID", "right_column": "ID"}]},
        {"left_table": bridge, "right_table": target,
         "conditions": [{"left_column": "ID", "right_column": "FAMILY_ID"}]},
    ]
    assert registry.apply_reviewed_join_path(joins)["status"] == "succeeded"
    staged = captured[0]["source_preparation"]
    assert bridge in staged["supporting_sources"]
    assert staged["selected_columns_by_table"][bridge] == ["ID"]
    assert staged["precedent_reference"] == {}


def test_runtime_offers_ranked_source_checkpoint_from_incomplete_research() -> None:
    handlers = DefaultWorkflowHandlers()
    runtime = DeepAgentsRuntime(
        model=_model(), migration_graph=build_migration_graph(handlers, checkpointer=InMemorySaver()),
        budget=ExecutionBudget(model_limit=8, tool_limit=20), workbench=handlers,
    )
    runtime._active_invocation = RuntimeInvocation(
        run_id="source-offer", thread_id="source-offer", prompt="Build household mapping",
        effort=EffortLevel.LIGHT,
        workflow_input={**_workflow_input(), "run_id": "source-offer", "run_mode": "plan",
                        "authorized_target_scope": ["DB.TGT.HOUSEHOLD"]},
    )
    review = {
        "target_table": "DB.TGT.HOUSEHOLD",
        "plan_candidate": {"source_preparation": {"driving_source": None}},
        "catalog_candidates": ["DB.SRC.CONTACTS", "DB.SRC.ADDRESSES"],
        "source_candidate_evidence": [
            {"table": "DB.SRC.CONTACTS", "target_column_lineage_count": 20,
             "accepted_precedent_count": 1, "evidence_ids": ["sttm_precedent:prior"]},
            {"table": "DB.SRC.ADDRESSES", "target_column_lineage_count": 5,
             "accepted_precedent_count": 0, "evidence_ids": ["fir_learning:address"]},
        ],
    }
    assert runtime._offer_source_research_checkpoint(review)
    prompt = runtime._workflow_result["__interrupt__"][0].value
    assert prompt["category"] == "source_research_choice"
    assert len(prompt["choices"]) == 2
    assert prompt["recommended_choice_id"] is None
    assert runtime._workflow_result.get("project_id") is None


def test_source_checkpoint_uses_contracts_verified_after_review_snapshot() -> None:
    handlers = DefaultWorkflowHandlers()
    runtime = DeepAgentsRuntime(
        model=_model(), migration_graph=build_migration_graph(handlers, checkpointer=InMemorySaver()),
        budget=ExecutionBudget(model_limit=8, tool_limit=20), workbench=handlers,
    )
    runtime._active_invocation = RuntimeInvocation(
        run_id="late-source-offer", thread_id="late-source-offer", prompt="Build household mapping",
        effort=EffortLevel.LIGHT,
        workflow_input={**_workflow_input(), "run_id": "late-source-offer", "run_mode": "plan",
                        "authorized_target_scope": ["DB.TGT.HOUSEHOLD"]},
    )
    # The prepared evidence was captured before a subsequent contract batch
    # verified the source candidates. Its own catalog snapshot is stale.
    runtime._registry._catalog_candidates.update({"DB.SRC.CONTACTS", "DB.SRC.ADDRESSES"})
    review = {
        "target_table": "DB.TGT.HOUSEHOLD",
        "plan_candidate": {"source_preparation": {"driving_source": None}},
        "catalog_candidates": [],
        "source_candidate_evidence": [
            {"table": "DB.SRC.CONTACTS", "target_column_lineage_count": 20,
             "accepted_precedent_count": 0, "evidence_ids": ["contract:contacts"]},
            {"table": "DB.SRC.ADDRESSES", "target_column_lineage_count": 5,
             "accepted_precedent_count": 0, "evidence_ids": ["contract:addresses"]},
        ],
    }
    assert runtime._offer_source_research_checkpoint(review)
    prompt = runtime._workflow_result["__interrupt__"][0].value
    assert prompt["category"] == "source_research_choice"
    assert len(prompt["choices"]) == 2


def test_explicit_driving_source_skips_redundant_source_question() -> None:
    from types import SimpleNamespace

    handlers = DefaultWorkflowHandlers()
    runtime = DeepAgentsRuntime(
        model=_model(), migration_graph=build_migration_graph(handlers, checkpointer=InMemorySaver()),
        budget=ExecutionBudget(model_limit=8, tool_limit=20), workbench=handlers,
    )
    driver, support, target = "DB.SRC.CONTACTS", "DB.SRC.ADDRESSES", "DB.TGT.HOUSEHOLD"
    runtime._active_invocation = RuntimeInvocation(
        run_id="explicit-driver", thread_id="explicit-driver",
        prompt="Use CONTACTS as the driving table for Household", effort=EffortLevel.LIGHT,
        workflow_input={**_workflow_input(), "run_id": "explicit-driver", "run_mode": "plan",
                        "authorized_target_scope": [target]},
    )
    captured_sources: list[str] = []
    def prepare(value: dict[str, Any]) -> dict[str, Any]:
        captured_sources.extend(value["source_tables"])
        runtime._registry._prepared_plan_review = {
            "target_table": target, "catalog_candidates": [driver, support],
            "plan_candidate": {"source_preparation": {"driving_source": driver,
                                                          "supporting_sources": [support]}},
            "unresolved": [f"Current relationship evidence has no join path to {driver}: {support}"],
        }
        return {"status": "succeeded"}
    runtime._registry.tools = lambda: [SimpleNamespace(name="prepare_migration_evidence", invoke=prepare)]
    handlers.resolve_source_clarification = lambda state, _selected: {
        "status": "needs_input", "join_questions": state["research_clarification"]["join_questions"]}
    handlers.resolve_join_clarifications = lambda _state, _answers: {"status": "needs_input"}
    initial_review = {"target_table": target, "plan_candidate": {"source_preparation": {}},
                      "catalog_candidates": [driver, support],
                      "source_candidate_evidence": [
                          {"table": driver, "target_column_lineage_count": 10},
                          {"table": support, "target_column_lineage_count": 3}]}
    assert runtime._offer_source_research_checkpoint(initial_review)
    assert captured_sources == [driver, support]
    assert runtime._workflow_result["__interrupt__"][0].value["category"] == "source_join_path"


def test_runtime_offers_join_question_when_driver_was_already_selected() -> None:
    handlers = DefaultWorkflowHandlers()
    runtime = DeepAgentsRuntime(
        model=_model(), migration_graph=build_migration_graph(handlers, checkpointer=InMemorySaver()),
        budget=ExecutionBudget(model_limit=8, tool_limit=20), workbench=handlers,
    )
    driver, target = "DB.SRC.CONTACTS", "DB.TGT.HOUSEHOLD"
    runtime._active_invocation = RuntimeInvocation(
        run_id="named-driver-join-review", thread_id="named-driver-join-review",
        prompt="Build Household using CONTACTS", effort=EffortLevel.LIGHT,
        workflow_input={**_workflow_input(), "run_id": "named-driver-join-review", "run_mode": "plan",
                        "authorized_target_scope": [target]},
    )
    seen_questions: list[dict[str, Any]] = []
    def resolve_questions(state: dict[str, Any], selected: str) -> dict[str, Any]:
        seen_questions.extend(dict(state.get("research_clarification") or {}).get("join_questions") or [])
        return {
        "status": "needs_input", "error_code": "source_design_incomplete",
        "join_questions": seen_questions,
        } if selected == driver else {}
    handlers.resolve_source_clarification = resolve_questions
    handlers.resolve_join_clarifications = lambda _state, _answers: {"status": "needs_input"}
    supporting = ["DB.SRC.ADDRESSES", "DB.SRC.COUNTRY_CODES", "DB.SRC.STATE_CODES", "DB.SRC.MAPPER_USER"]
    review = {"target_table": target, "catalog_candidates": [],
              "plan_candidate": {"source_preparation": {"driving_source": driver,
                                                          "supporting_sources": supporting}},
              "unresolved": [f"Current relationship evidence has no join path to {driver}: {name}"
                             for name in supporting]}

    assert runtime._offer_source_research_checkpoint(review)
    prompt = runtime._workflow_result["__interrupt__"][0].value
    assert prompt["category"] == "source_join_path"
    assert "1 of 4" in prompt["question"]
    assert [question["target"] for question in seen_questions] == supporting
    assert runtime._workflow_result.get("project_id") is None


def test_existing_prepared_join_questions_do_not_reprepare_with_driver_only() -> None:
    handlers = DefaultWorkflowHandlers()
    runtime = DeepAgentsRuntime(
        model=_model(), migration_graph=build_migration_graph(handlers, checkpointer=InMemorySaver()),
        budget=ExecutionBudget(model_limit=8, tool_limit=20), workbench=handlers,
    )
    driver = "DB.SRC.CONTACTS"
    runtime._active_invocation = RuntimeInvocation(
        run_id="restored-join-review", thread_id="restored-join-review",
        prompt="Build Household using CONTACTS", effort=EffortLevel.LIGHT,
        workflow_input={**_workflow_input(), "run_id": "restored-join-review", "run_mode": "plan"},
    )
    candidate = {"source_preparation": {"driving_source": driver,
                                         "supporting_sources": ["DB.SRC.ADDRESSES"]}}
    questions = [{"driver": driver, "target": "DB.SRC.ADDRESSES", "options": []}]
    resolved = handlers.resolve_source_clarification(
        {"research_clarification": {"target_table": "DB.TGT.HOUSEHOLD",
                                    "join_questions": questions,
                                    "prepared_plan_candidate": candidate,
                                    "catalog_candidates": [driver, "DB.SRC.ADDRESSES"]}}, driver)
    assert resolved["join_questions"] == questions
    assert resolved["status"] == "needs_input"
    assert runtime._registry.prepared_plan_candidate == candidate


def test_hard_budget_rejects_operation_before_overrun() -> None:
    budget = ExecutionBudget(model_limit=1, tool_limit=1)
    budget.consume_model("first")
    budget.consume_tool("first")
    with pytest.raises(BudgetExceededError, match="Model-call budget exhausted"):
        budget.consume_model("second")
    with pytest.raises(BudgetExceededError, match="Tool-call budget exhausted"):
        budget.consume_tool("second")
    assert budget.snapshot() == (1, 1)


def test_effort_policies_have_expanded_work_and_finalization_capacity() -> None:
    assert (
        EFFORT_POLICIES[EffortLevel.LIGHT].model_call_budget,
        EFFORT_POLICIES[EffortLevel.LIGHT].tool_call_budget,
        EFFORT_POLICIES[EffortLevel.LIGHT].max_parallel_mappings,
    ) == (32, 80, 1)
    assert (
        EFFORT_POLICIES[EffortLevel.MEDIUM].model_call_budget,
        EFFORT_POLICIES[EffortLevel.MEDIUM].tool_call_budget,
        EFFORT_POLICIES[EffortLevel.MEDIUM].max_parallel_mappings,
    ) == (128, 480, 3)
    assert (
        EFFORT_POLICIES[EffortLevel.HIGH].model_call_budget,
        EFFORT_POLICIES[EffortLevel.HIGH].tool_call_budget,
        EFFORT_POLICIES[EffortLevel.HIGH].max_parallel_mappings,
    ) == (128, 600, 5)


def test_finalization_budget_is_inaccessible_until_host_boundary() -> None:
    budget = ExecutionBudget(
        model_limit=5, tool_limit=10,
        finalization_model_reserve=2, finalization_tool_reserve=3,
    )
    for _ in range(3):
        budget.consume_model("working")
    with pytest.raises(BudgetExceededError, match="working phase"):
        budget.consume_model("working-overrun")

    budget.begin_finalization()
    budget.consume_model("final-synthesis-1")
    budget.consume_model("final-synthesis-2")
    assert budget.snapshot()[0] == 5


def test_cancelled_tool_is_traced_as_cancelled_instead_of_failed() -> None:
    traces: list[tuple[str, str, str]] = []
    registry = CapabilityRegistry(
        context_provider=lambda: {},
        workflow_executor=lambda _sources, _targets, _plan=None: {},
        workbench=None,
        budget=ExecutionBudget(model_limit=1, tool_limit=1),
        trace=lambda event_type, status, summary, _data: traces.append(
            (event_type, status, summary)
        ),
    )

    def _cancelled_operation() -> None:
        raise ExecutionCancelledError("cancelled")

    result = registry._execute("list_projects", _cancelled_operation)

    assert result["error_code"] == "execution_cancelled"
    assert traces[-1][0:2] == ("tool.cancelled", "cancelled")


def test_a_tool_that_hits_the_budget_is_traced_and_raises_the_phase_boundary() -> None:
    """Swallowing it let a multi-target plan go ahead with targets silently missing."""
    from app.agent_runtime.execution import BudgetExceededError

    traces: list[tuple[str, str, dict]] = []
    registry = CapabilityRegistry(
        context_provider=lambda: {},
        workflow_executor=lambda _sources, _targets, _plan=None: {},
        workbench=None,
        budget=ExecutionBudget(model_limit=1, tool_limit=1),
        trace=lambda event_type, status, _summary, data: traces.append((event_type, status, data)),
    )

    def _exhausted() -> None:
        raise BudgetExceededError("snowflake_queries budget exhausted", kind="category")

    try:
        registry._execute("prepare_migration_evidence", _exhausted)
    except BudgetExceededError as exc:
        assert exc.kind == "category"
    else:
        raise AssertionError("the budget boundary was swallowed")
    assert traces[-1][0] == "tool.failed" and traces[-1][2]["error_code"] == "budget_exhausted"


def test_catalog_discovery_stops_repeating_after_viable_candidates() -> None:
    class _Catalog:
        calls = 0

        def search_catalog(self, search_term: str, _limit: int) -> ToolResult:
            self.calls += 1
            return ToolResult(
                status="succeeded",
                summary="Found candidates.",
                data={
                    "query": search_term,
                    "candidates": [
                        {"table": f"DB.SCHEMA.{search_term.upper()}_SOURCE"},
                        {"table": f"DB.SCHEMA.{search_term.upper()}_TARGET"},
                    ],
                },
            )

    catalog = _Catalog()
    registry = CapabilityRegistry(
        context_provider=lambda: {},
        workflow_executor=lambda _sources, _targets, _plan=None: {},
        workbench=catalog,
        budget=ExecutionBudget(model_limit=5, tool_limit=20),
    )

    for term in ("loan", "income", "amount", "calculation"):
        assert registry._search_catalog(term, 10).status == "succeeded"
    bounded = registry._search_catalog("borrower", 10)

    # A light/low-budget run stops after two distinct searches once both a
    # source and target candidate exist. Medium and high policies retain wider
    # ceilings for genuinely ambiguous scopes.
    assert catalog.calls == 2
    assert bounded.data["discovery_complete"] is True
    assert bounded.data["candidate_count"] == 4


def test_contract_batch_compares_verified_sources_without_expanding_scope() -> None:
    class _Catalog:
        calls: list[str] = []

        def inspect_table_contract(self, table: str) -> ToolResult:
            self.calls.append(table)
            return ToolResult(status="succeeded", summary="Current contract",
                              data={"columns": ["ID", "NAME"]})

    catalog = _Catalog()
    events: list[tuple[str, str]] = []
    registry = CapabilityRegistry(
        context_provider=lambda: {"authorized_schemas": ["DB.SRC"]},
        workflow_executor=lambda _sources, _targets, _plan=None: {},
        workbench=catalog,
        budget=ExecutionBudget(model_limit=5, tool_limit=20),
        trace=lambda event_type, _status, summary, _data: events.append((event_type, summary)),
    )
    registry._catalog_candidates.update({"DB.SRC.FAMILIES", "DB.SRC.CONTACTS"})
    tool = next(item for item in registry.tools() if item.name == "inspect_table_contracts_batch")
    result = tool.invoke({"table_fqns": ["DB.SRC.FAMILIES", "DB.SRC.CONTACTS"]})
    assert result["status"] == "succeeded"
    assert len(result["data"]["contracts"]) == 2
    assert catalog.calls == ["DB.SRC.FAMILIES", "DB.SRC.CONTACTS"]
    assert not any(event_type == "tool.denied" for event_type, _ in events)
    denied = tool.invoke({"table_fqns": ["OTHER.SRC.SECRET"]})
    assert denied["error_code"] == "unverified_evidence_selection"
    assert len(catalog.calls) == 2
    # An early refusal is visible in the chat trace, exactly once.
    refusals = [summary for event_type, summary in events if event_type == "tool.denied"]
    assert len(refusals) == 1 and "search_catalog_batch" in refusals[0]


def test_batch_catalog_discovery_resolves_synonyms_with_one_workbench_call() -> None:
    class _BatchCatalog:
        calls = 0

        def search_catalog_batch(self, terms: list[str], _limit: int) -> ToolResult:
            self.calls += 1
            return ToolResult(
                status="succeeded", summary="Resolved candidates.",
                data={"terms": terms, "candidates": ["DB.SRC.FAMILIES", "DB.TGT.HOUSEHOLD"]},
            )

    catalog = _BatchCatalog()
    registry = CapabilityRegistry(
        context_provider=lambda: {},
        workflow_executor=lambda _sources, _targets, _plan=None: {},
        workbench=catalog,
        budget=ExecutionBudget(model_limit=5, tool_limit=20),
    )
    tool = next(item for item in registry.tools() if item.name == "search_catalog_batch")

    result = tool.invoke({"search_terms": ["household", "family", "account"], "limit_per_term": 8})

    assert result["status"] == "succeeded"
    assert catalog.calls == 1
    assert registry._catalog_candidates == {"DB.SRC.FAMILIES", "DB.TGT.HOUSEHOLD"}


def test_catalog_evidence_cannot_expand_declared_schema_scope() -> None:
    class _Catalog:
        def search_catalog_batch(self, terms: list[str], _limit: int) -> ToolResult:
            return ToolResult(
                status="succeeded",
                summary="Resolved candidates.",
                data={
                    "terms": terms,
                    "candidates": [
                        "CRM.SOURCE.CONTACT_FAMILIES",
                        "FINANCE.CORE.CLIENT_ACCOUNTS",
                    ],
                },
            )

    registry = CapabilityRegistry(
        context_provider=lambda: {
            "authorized_schemas": ["CRM.SOURCE"],
            "authorized_target_scope": ["CRM.TARGET.HOUSEHOLD"],
        },
        workflow_executor=lambda _targets, _mappings, _plan=None: {},
        workbench=_Catalog(),
        budget=ExecutionBudget(model_limit=5, tool_limit=20),
    )
    tool = next(item for item in registry.tools() if item.name == "search_catalog_batch")

    result = tool.invoke({"search_terms": ["household"], "limit_per_term": 8})

    assert result["status"] == "succeeded"
    assert registry._catalog_candidates == {"CRM.SOURCE.CONTACT_FAMILIES"}


def test_identical_fir_read_reuses_verified_result_without_requerying() -> None:
    traces: list[str] = []

    class _FirWorkbench:
        calls = 0

        def retrieve_fir_evidence(self, _context, target_table, target_columns) -> ToolResult:
            self.calls += 1
            return ToolResult(
                status="succeeded",
                summary="No exact FIR evidence was found.",
                data={"target_table": target_table, "target_columns": target_columns, "cards": []},
            )

    workbench = _FirWorkbench()
    registry = CapabilityRegistry(
        context_provider=lambda: {},
        workflow_executor=lambda _sources, _targets, _plan=None: {},
        workbench=workbench,
        budget=ExecutionBudget(model_limit=5, tool_limit=20),
        trace=lambda event_type, _status, _summary, _data: traces.append(event_type),
    )
    tool = next(item for item in registry.tools() if item.name == "retrieve_fir_evidence")
    request = {"target_table": "DB.SCHEMA.TARGET", "target_columns": ["AMOUNT"]}

    first = tool.invoke(request)
    second = tool.invoke(request)

    assert first == second
    assert workbench.calls == 1
    assert traces.count("tool.completed") == 1
    assert traces.count("tool.reused") == 1


def test_stored_semantic_context_is_read_for_verified_discovered_tables() -> None:
    class _SemanticWorkbench:
        calls: list[tuple[list[str], str | None]] = []

        def read_stored_semantic_context(
            self, _context, source_tables: list[str], target_table: str | None
        ) -> ToolResult:
            self.calls.append((source_tables, target_table))
            return ToolResult(
                status="succeeded", summary="Read stored table semantics.",
                data={"status": "available", "coverage": {"table_count": len(source_tables)}},
            )

    workbench = _SemanticWorkbench()
    registry = CapabilityRegistry(
        context_provider=lambda: {
            "authorized_target_scope": ["DB.TGT.HOUSEHOLD"],
        },
        workflow_executor=lambda _targets, _mappings, _plan=None: {},
        workbench=workbench,
        budget=ExecutionBudget(model_limit=5, tool_limit=20),
    )
    registry._catalog_candidates.add("DB.SRC.FAMILIES")
    tool = next(item for item in registry.tools() if item.name == "read_stored_semantic_context")

    result = tool.invoke({
        "source_tables": ["DB.SRC.FAMILIES"],
        "target_table": "DB.TGT.HOUSEHOLD",
    })
    denied = tool.invoke({"source_tables": ["DB.OTHER.UNKNOWN"]})

    assert result["status"] == "succeeded"
    assert workbench.calls == [(["DB.SRC.FAMILIES"], "DB.TGT.HOUSEHOLD")]
    assert denied["error_code"] == "unverified_semantic_selection"


def test_compact_migration_evidence_tool_bundles_verified_context_once() -> None:
    calls: list[tuple[list[str], str, list[str]]] = []

    class _EvidenceWorkbench:
        def prepare_migration_evidence(
            self,
            _context,
            *,
            source_tables: list[str],
            target_table: str,
            precedent_project_ids: list[str],
        ) -> ToolResult:
            calls.append((source_tables, target_table, precedent_project_ids))
            return ToolResult(
                status="succeeded",
                summary="Prepared compact evidence.",
                data={"stored_semantic_context": {"status": "available"}},
                evidence_refs=["sem-household", "fir-household"],
            )

    registry = CapabilityRegistry(
        context_provider=lambda: {
            "authorized_target_scope": ["DB.TGT.HOUSEHOLD"],
        },
        workflow_executor=lambda _targets, _mappings, _plan=None: {},
        workbench=_EvidenceWorkbench(),
        budget=ExecutionBudget(model_limit=5, tool_limit=20),
    )
    registry._catalog_candidates.add("DB.SRC.FAMILIES")
    tool = next(item for item in registry.tools() if item.name == "prepare_migration_evidence")

    result = tool.invoke({
        "source_tables": ["DB.SRC.FAMILIES"],
        "target_table": "DB.TGT.HOUSEHOLD",
        "precedent_project_ids": ["1101"],
    })

    assert result["status"] == "succeeded"
    assert result["evidence_refs"] == ["sem-household", "fir-household"]
    assert calls == [(["DB.SRC.FAMILIES"], "DB.TGT.HOUSEHOLD", ["1101"])]


def test_configured_target_recovers_full_precedent_graph_without_source_guessing() -> None:
    evidence_calls: list[tuple[list[str], str]] = []

    class _Workbench:
        def list_project_templates(self, *_args: Any) -> ToolResult:
            return ToolResult(status="succeeded", summary="Configured targets", data={"templates": [{
                "available_targets": [{"table_name": "HOUSEHOLD", "logical_target_key": "CRM.HOUSEHOLD",
                                       "physical_fqn": "DB.TGT.HOUSEHOLD"}],
            }]})

        def inspect_table_contract(self, table_fqn: str) -> ToolResult:
            return ToolResult(status="succeeded", summary="Target contract", data={"table": table_fqn, "columns": ["ID"]})

        def prepare_migration_evidence(self, _context: dict[str, Any], *, source_tables: list[str],
                                       target_table: str, precedent_project_ids: list[str]) -> ToolResult:
            evidence_calls.append((source_tables, target_table))
            return ToolResult(status="succeeded", summary="Recovered complete source graph", data={
                "source_tables": ["DB.SRC.FAMILIES", "DB.SRC.CONTACTS"],
                "plan_candidate": {"source_preparation": {"driving_source": "DB.SRC.FAMILIES",
                                                          "supporting_sources": ["DB.SRC.CONTACTS"],
                                                          "target_table": target_table}},
            })

    context = {"intent": "NEW_MIGRATION_TASK", "requested_mappings": ["Household"],
               "authorized_schemas": ["DB.TGT", "DB.SRC"]}
    registry = CapabilityRegistry(
        context_provider=lambda: context,
        workflow_executor=lambda _targets, _mappings, _plan=None: {},
        workbench=_Workbench(), budget=ExecutionBudget(model_limit=5, tool_limit=20),
    )
    registry.begin_run({**context, "run_id": "configured-target"})
    result = registry.prepare_configured_target()

    assert result and result["status"] == "succeeded"
    assert evidence_calls == [([], "DB.TGT.HOUSEHOLD")]
    assert registry.prepared_plan_candidate["source_preparation"]["supporting_sources"] == ["DB.SRC.CONTACTS"]


def test_project_target_and_contract_trigger_one_evidence_package_in_either_order() -> None:
    for inspect_first in (True, False):
        calls: list[str] = []

        class _Workbench:
            def inspect_table_contract(self, table_fqn: str) -> ToolResult:
                return ToolResult(status="succeeded", summary="Contract", data={"table": table_fqn, "columns": ["ID"]})

            def get_project_context(self, _project_id: str) -> ToolResult:
                return ToolResult(status="succeeded", summary="Precedent", data={"mappings": [
                    {"target_table": "DB.TGT.HOUSEHOLD", "coverage_percent": 100},
                ]})

            def prepare_migration_evidence(self, _context: dict[str, Any], *, source_tables: list[str],
                                           target_table: str, precedent_project_ids: list[str]) -> ToolResult:
                calls.append(target_table)
                return ToolResult(status="succeeded", summary="Evidence", data={"source_tables": ["DB.SRC.FAMILIES"]})

        registry = CapabilityRegistry(
            context_provider=lambda: {"intent": "NEW_MIGRATION_TASK", "authorized_schemas": ["DB.TGT", "DB.SRC"]},
            workflow_executor=lambda _targets, _mappings, _plan=None: {},
            workbench=_Workbench(), budget=ExecutionBudget(model_limit=5, tool_limit=20),
        )
        tools = {item.name: item for item in registry.tools()}
        steps = [
            ("inspect_table_contract", {"table_fqn": "DB.TGT.HOUSEHOLD"}),
            ("get_project_context", {"project_id": "1401"}),
        ]
        for name, args in (steps if inspect_first else reversed(steps)):
            tools[name].invoke(args)
        assert calls == ["DB.TGT.HOUSEHOLD"]


def test_configured_multi_mapping_plan_keeps_distinct_target_and_source_specs() -> None:
    names = [f"ENTITY_{index}" for index in range(10)]

    class _Workbench:
        def list_project_templates(self, *_args: Any) -> ToolResult:
            return ToolResult(status="succeeded", summary="Targets", data={"templates": [{
                "available_targets": [{"table_name": name, "logical_target_key": f"CRM.{name}",
                                       "physical_fqn": f"DB.TGT.{name}"} for name in names],
            }]})

        def inspect_table_contract(self, table_fqn: str) -> ToolResult:
            return ToolResult(status="succeeded", summary="Contract", data={"table": table_fqn, "columns": ["ID"]})

        def prepare_migration_evidence(self, _context: dict[str, Any], *, source_tables: list[str],
                                       target_table: str, precedent_project_ids: list[str]) -> ToolResult:
            name = target_table.split(".")[-1]
            return ToolResult(status="succeeded", summary="Evidence", data={
                "source_tables": [f"DB.SRC.{name}"],
                "plan_candidate": {
                    "normalized_intent": f"Map {name}",
                    "source_preparation": {"driving_source": f"DB.SRC.{name}", "target_table": target_table},
                    "auto_map": {"requested_mappings": [name]},
                    "evidence_ids_used": [f"contract:{name}"],
                },
            })

    context = {"intent": "NEW_MIGRATION_TASK", "requested_mappings": names,
               "authorized_schemas": ["DB.TGT", "DB.SRC"]}
    registry = CapabilityRegistry(
        context_provider=lambda: context,
        workflow_executor=lambda _targets, _mappings, _plan=None: {},
        workbench=_Workbench(), budget=ExecutionBudget(model_limit=5, tool_limit=60),
    )
    registry._plan_validator = lambda plan: (
        setattr(registry, "_validated_supervisor_plan", dict(plan))
        or {"status": "succeeded"}
    )
    registry.begin_run({**context, "run_id": "ten-mappings"})
    registry.prepare_configured_target()
    combined = registry.validated_supervisor_plan

    assert combined is not None
    assert len(combined["mapping_specs"]) == 10
    assert [spec["target_table"] for spec in combined["mapping_specs"]] == [f"DB.TGT.{name}" for name in names]
    assert [spec["source_preparation"]["driving_source"] for spec in combined["mapping_specs"]] == [
        f"DB.SRC.{name}" for name in names
    ]

    class _Graph:
        received: dict[str, Any] | None = None

        def invoke(self, value: dict[str, Any], **_kwargs: Any) -> dict[str, Any]:
            self.received = value
            return {"status": "READY_FOR_REVIEW"}

    graph = _Graph()
    runtime = DeepAgentsRuntime(
        model=_model(), migration_graph=graph,
        budget=ExecutionBudget(model_limit=5, tool_limit=60),
    )
    runtime._active_invocation = RuntimeInvocation(
        run_id="ten-mappings", thread_id="ten-mappings", prompt="Map all ten entities",
        effort=EffortLevel.HIGH,
        workflow_input={**_workflow_input(), "requested_mappings": names, "intent": "NEW_MIGRATION_TASK"},
    )
    runtime._execute_workflow_with_scope([], names, combined)

    assert graph.received is not None
    assert [item["target_table"] for item in graph.received["manifest"]] == [f"DB.TGT.{name}" for name in names]


def test_incomplete_configured_mapping_cannot_execute_an_earlier_valid_partition() -> None:
    class _Workbench:
        def list_project_templates(self, *_args: Any) -> ToolResult:
            return ToolResult(status="succeeded", summary="Targets", data={"templates": [{
                "available_targets": [{"table_name": name, "physical_fqn": f"DB.TGT.{name}"}
                                      for name in ("ALPHA", "BETA")],
            }]})

        def inspect_table_contract(self, table_fqn: str) -> ToolResult:
            return ToolResult(status="succeeded", summary="Contract", data={"table": table_fqn, "columns": ["ID"]})

        def prepare_migration_evidence(self, _context: dict[str, Any], *, source_tables: list[str],
                                       target_table: str, precedent_project_ids: list[str]) -> ToolResult:
            if target_table.endswith("BETA"):
                return ToolResult(status="failed", summary="Source design unavailable", error_code="source_design_incomplete")
            return ToolResult(status="succeeded", summary="Evidence", data={
                "source_tables": ["DB.SRC.ALPHA"],
                "plan_candidate": {"source_preparation": {"driving_source": "DB.SRC.ALPHA",
                                                          "target_table": target_table}},
            })

    context = {"intent": "NEW_MIGRATION_TASK", "requested_mappings": ["ALPHA", "BETA"],
               "authorized_schemas": ["DB.TGT", "DB.SRC"]}
    registry = CapabilityRegistry(
        context_provider=lambda: context,
        workflow_executor=lambda _targets, _mappings, _plan=None: {},
        workbench=_Workbench(), budget=ExecutionBudget(model_limit=5, tool_limit=20),
    )
    registry._plan_validator = lambda plan: (
        setattr(registry, "_validated_supervisor_plan", dict(plan))
        or {"status": "succeeded"}
    )
    registry.begin_run({**context, "run_id": "incomplete-multi"})
    result = registry.prepare_configured_target()

    assert result and result["error_code"] == "source_design_incomplete"
    assert registry.validated_supervisor_plan is None


def test_prepared_evidence_can_be_host_validated_and_promotes_verified_precedent_sources() -> None:
    class _EvidenceWorkbench:
        def prepare_migration_evidence(self, *_args, **_kwargs) -> ToolResult:
            return ToolResult(
                status="succeeded",
                summary="Prepared compact evidence.",
                data={
                    "source_tables": ["DB.SRC.FAMILIES", "DB.SRC.CONTACTS"],
                    "plan_candidate": {
                        "normalized_intent": "Build household migration",
                        "project_decision": {"operation": "create", "run_owned": True},
                        "source_preparation": {
                            "driving_source": "DB.SRC.FAMILIES",
                            "supporting_sources": ["DB.SRC.CONTACTS"],
                            "relationships": [{
                                "name": "family_contacts",
                                "left_table": "DB.SRC.FAMILIES",
                                "right_table": "DB.SRC.CONTACTS",
                                "conditions": [{"left_column": "ID", "right_column": "FAMILY_ID"}],
                            }],
                            "target_table": "DB.TGT.HOUSEHOLD",
                        },
                        "auto_map": {
                            "target_columns": ["ID"],
                            "mapping_evidence": [{"target_column": "ID", "source_columns": ["FAMILIES.ID"], "mapping_mode": "direct"}],
                        },
                        "execution_steps": [{
                            "sequence": 1,
                            "title": "Propose mapping SQL",
                            "description": "Review the proposed SQL before approval.",
                            "phase": "plan_analysis",
                            "query_kind": "mapping",
                            "sql": "SELECT 1 AS ID",
                            "runs_before_approval": True,
                            "runs_after_approval": False,
                        }],
                    },
                },
            )

    registry = CapabilityRegistry(
        context_provider=lambda: {
            "effective_run_mode": "plan",
            "authorized_target_scope": ["DB.TGT.HOUSEHOLD"],
        },
        workflow_executor=lambda _targets, _mappings, _plan=None: {},
        workbench=_EvidenceWorkbench(),
        budget=ExecutionBudget(model_limit=5, tool_limit=20),
    )
    registry._catalog_candidates.add("DB.SRC.FAMILIES")
    tool = next(item for item in registry.tools() if item.name == "prepare_migration_evidence")

    tool.invoke({
        "source_tables": ["DB.SRC.FAMILIES"],
        "target_table": "DB.TGT.HOUSEHOLD",
        "precedent_project_ids": [],
    })
    validated = registry.validate_prepared_plan()

    assert validated["status"] == "succeeded"
    assert registry.validated_supervisor_plan is not None
    assert registry.validated_supervisor_plan["source_preparation"]["supporting_sources"] == [
        "DB.SRC.CONTACTS"
    ]


def test_deep_supervisor_validates_its_plan_without_exposing_quick_orchestrator() -> None:
    registry = CapabilityRegistry(
        context_provider=lambda: {
            "authorized_source_scope": ["DB.SRC.CUSTOMER"],
            "authorized_target_scope": ["DB.TGT.CUSTOMER"],
        },
        workflow_executor=lambda _targets, _mappings, _plan=None: {},
        workbench=None,
        budget=ExecutionBudget(model_limit=5, tool_limit=20),
    )
    tools = {tool.name: tool for tool in registry.tools()}
    validated = tools["validate_migration_plan"].invoke({"plan": {
        "normalized_intent": "Build customer mapping",
        "source_preparation": {
            "driving_source": "DB.SRC.CUSTOMER",
            "target_table": "DB.TGT.CUSTOMER",
        },
        "auto_map": {"requested_mappings": ["Customer"]},
        "evidence_ids_used": ["semantic:customer"],
    }})

    assert validated["status"] == "succeeded"
    assert "sttm_builder" not in tools
    assert "execute_migration_workflow" not in tools
    contract = next(
        item for item in CapabilityRegistry.public_contracts()
        if item["name"] == "execute_migration_workflow"
    )
    assert contract["owning_agent"] == "migration-workflow"
    assert contract["when_not_to_use"] == "Never expose directly to the supervisor."
    assert registry.validated_supervisor_plan
    assert registry.validated_supervisor_plan["_deep_supervisor_validated"] is True


def test_plan_validator_normalizes_business_facing_plan_vocabulary() -> None:
    registry = CapabilityRegistry(
        context_provider=lambda: {
            "authorized_source_scope": ["DB.SRC.FAMILIES", "DB.SRC.STATUS"],
            "authorized_target_scope": ["DB.TGT.HOUSEHOLD"],
        },
        workflow_executor=lambda _targets, _mappings, _plan=None: {},
        workbench=None,
        budget=ExecutionBudget(model_limit=5, tool_limit=20),
    )
    tool = next(item for item in registry.tools() if item.name == "validate_migration_plan")

    result = tool.invoke({"plan": {
        "normalized_intent": "Build the household mapping",
        "source_preparation": {
            "driving_table": "DB.SRC.FAMILIES",
            "target": "DB.TGT.HOUSEHOLD",
            "joins": [{"left_table": "DB.SRC.FAMILIES", "right_table": "DB.SRC.STATUS",
                       "condition": "F.STATUS_ID = S.ID",
                       "conditions": [{"left_column": "STATUS_ID", "right_column": "ID"}]}],
            "supporting_sources": ["DB.SRC.STATUS"],
            "ctes": [{"name": "member_names", "sql_outline": "SELECT 1"}],
        },
        "auto_map": {
            "mappings": ["Household"],
            "classifications": {"STATUS": "lookup", "DISPLAY_NAME": "transformation"},
        },
        "execution_steps": [
            {"step": 1, "name": "Inspect", "action": "Inspect contracts", "stage": "planning", "query_type": "contract"},
            {"step": 2, "name": "Validate", "action": "Validate SQL", "stage": "sql_validation", "query_type": "validate"},
        ],
    }})

    assert result["status"] == "succeeded"
    assert registry.validated_supervisor_plan["auto_map"]["mapping_classifications"] == {
        "STATUS": "direct",
        "DISPLAY_NAME": "derived",
    }
    assert [step["phase"] for step in registry.validated_supervisor_plan["execution_steps"]] == [
        "plan_analysis", "validation"
    ]


def test_plan_validator_rejects_disconnected_but_visible_sources() -> None:
    registry = CapabilityRegistry(
        context_provider=lambda: {
            "authorized_source_scope": ["DB.SRC.CONTACTS", "DB.SRC.STATUS", "DB.SRC.ADDRESSES"],
            "authorized_target_scope": ["DB.TGT.HOUSEHOLD"],
        },
        workflow_executor=lambda _targets, _mappings, _plan=None: {},
        workbench=None,
        budget=ExecutionBudget(model_limit=5, tool_limit=20),
    )
    tool = next(item for item in registry.tools() if item.name == "validate_migration_plan")
    result = tool.invoke({"plan": {
        "normalized_intent": "Build Household",
        "source_preparation": {
            "driving_source": "DB.SRC.CONTACTS", "target_table": "DB.TGT.HOUSEHOLD",
            "supporting_sources": ["DB.SRC.STATUS", "DB.SRC.ADDRESSES"],
            "relationships": [{
                "left_table": "DB.SRC.CONTACTS", "right_table": "DB.SRC.STATUS",
                "conditions": [{"left_column": "STATUS_ID", "right_column": "ID"}],
            }],
        },
        "auto_map": {"target_columns": ["ID"]},
    }})
    assert result["status"] == "needs_input"
    assert result["error_code"] == "join_graph_incomplete"
    assert result["data"]["disconnected_sources"] == ["DB.SRC.ADDRESSES"]


def test_plan_cannot_promote_unverified_join_after_current_evidence_preparation() -> None:
    registry = CapabilityRegistry(
        context_provider=lambda: {
            "authorized_source_scope": ["DB.SRC.FAMILIES", "DB.SRC.CONTACTS"],
            "authorized_target_scope": ["DB.TGT.HOUSEHOLD"],
        },
        workflow_executor=lambda _targets, _mappings, _plan=None: {},
        workbench=None,
        budget=ExecutionBudget(model_limit=5, tool_limit=20),
    )
    registry._prepared_plan_candidate = {
        "source_preparation": {
            "driving_source": "DB.SRC.FAMILIES",
            "supporting_sources": ["DB.SRC.CONTACTS"],
            "target_table": "DB.TGT.HOUSEHOLD",
            "relationships": [],
        },
    }
    tool = next(item for item in registry.tools() if item.name == "validate_migration_plan")
    plan = {
        "normalized_intent": "Map Household",
        "source_preparation": {
            "driving_source": "DB.SRC.FAMILIES",
            "supporting_sources": ["DB.SRC.CONTACTS"],
            "target_table": "DB.TGT.HOUSEHOLD",
            "relationships": [{
                "left_table": "DB.SRC.FAMILIES", "right_table": "DB.SRC.CONTACTS",
                "conditions": [{"left_column": "ID", "right_column": "FAMILY_ID"}],
            }],
        },
        "auto_map": {"target_columns": ["ID"]},
    }
    result = tool.invoke({"plan": plan})
    assert result["error_code"] == "unverified_plan_relationship"

    registry._prepared_plan_candidate["source_preparation"]["relationships"] = [
        plan["source_preparation"]["relationships"][0]
    ]
    assert tool.invoke({"plan": plan})["status"] == "succeeded"
    plan["source_preparation"]["supporting_sources"] = []
    assert tool.invoke({"plan": plan})["error_code"] == "source_graph_evidence_stale"


def test_plan_mode_validator_requires_proposed_or_dynamic_sql() -> None:
    registry = CapabilityRegistry(
        context_provider=lambda: {
            "effective_run_mode": "plan",
            "authorized_source_scope": ["DB.SRC.FAMILIES"],
            "authorized_target_scope": ["DB.TGT.HOUSEHOLD"],
        },
        workflow_executor=lambda _targets, _mappings, _plan=None: {},
        workbench=None,
        budget=ExecutionBudget(model_limit=5, tool_limit=20),
    )
    tool = next(item for item in registry.tools() if item.name == "validate_migration_plan")
    base_plan = {
        "normalized_intent": "Build household mapping",
        "source_preparation": {
            "driving_source": "DB.SRC.FAMILIES",
            "target_table": "DB.TGT.HOUSEHOLD",
        },
        "auto_map": {
            "requested_mappings": ["Household"],
            "target_columns": ["ID"],
            "mapping_evidence": [{"target_column": "ID", "source_columns": ["FAMILIES.ID"], "mapping_mode": "direct"}],
        },
        "execution_steps": [{
            "sequence": 1, "title": "Mapping SQL", "description": "Build mapping",
            "phase": "draft_execution", "query_kind": "mapping",
        }],
    }

    missing = tool.invoke({"plan": base_plan})
    assert missing["error_code"] == "planned_sql_required"
    base_plan["execution_steps"][0]["sql"] = "SELECT * FROM DB.SRC.FAMILIES"
    accepted = tool.invoke({"plan": base_plan})
    assert accepted["status"] == "succeeded"


def test_plan_mode_rejects_empty_target_design_and_unasked_firm_value() -> None:
    registry = CapabilityRegistry(
        context_provider=lambda: {
            "effective_run_mode": "plan",
            "authorized_source_scope": ["DB.SRC.CONTACTS"],
            "authorized_target_scope": ["DB.TGT.HOUSEHOLD"],
        },
        workflow_executor=lambda _targets, _mappings, _plan=None: {},
        workbench=None,
        budget=ExecutionBudget(model_limit=5, tool_limit=20),
    )
    tool = next(item for item in registry.tools() if item.name == "validate_migration_plan")
    plan = {
        "normalized_intent": "Build household mapping",
        "source_preparation": {
            "driving_source": "DB.SRC.CONTACTS", "target_table": "DB.TGT.HOUSEHOLD",
        },
        "auto_map": {"target_columns": [f"COLUMN_{index}" for index in range(26)]},
        "execution_steps": [{"sequence": 1, "title": "Generate SQL", "description": "Compile the mapping",
                             "phase": "draft_execution", "query_kind": "mapping", "dynamic_sql": True}],
    }
    missing = tool.invoke({"plan": plan})
    assert missing["error_code"] == "mapping_plan_incomplete"
    assert len(missing["data"]["uncovered_target_columns"]) == 26

    plan["auto_map"] = {
        "target_columns": ["FIRM_ID"],
        "mapping_evidence": [{"target_column": "FIRM_ID", "mapping_mode": "constant",
                              "constant_value": "1101"}],
    }
    plan["source_preparation"]["value_bindings"] = [{
        "name": "FirmId", "placeholder": "$FirmId", "candidate_value": "1101",
        "target_columns": ["FIRM_ID"], "source": "historical_sql",
        "resolution_status": "unresolved", "approval_state": "candidate",
    }]
    unasked = tool.invoke({"plan": plan})
    assert unasked["error_code"] == "value_bindings_unresolved"


def test_plan_mode_can_approve_explicit_partial_mapping_scope() -> None:
    registry = CapabilityRegistry(
        context_provider=lambda: {
            "effective_run_mode": "plan",
            "authorized_source_scope": ["DB.SRC.CONTACTS"],
            "authorized_target_scope": ["DB.TGT.HOUSEHOLD"],
        },
        workflow_executor=lambda _targets, _mappings, _plan=None: {},
        workbench=None,
        budget=ExecutionBudget(model_limit=5, tool_limit=20),
    )
    tool = next(item for item in registry.tools() if item.name == "validate_migration_plan")
    plan = {
        "normalized_intent": "Build a partial household draft for review",
        "source_preparation": {"driving_source": "DB.SRC.CONTACTS", "target_table": "DB.TGT.HOUSEHOLD"},
        "auto_map": {
            "target_columns": ["ID", "UNRESOLVED_ATTRIBUTE"],
            "mapping_evidence": [{"target_column": "ID", "source_columns": ["DB.SRC.CONTACTS.ID"],
                                  "mapping_mode": "direct"}],
            "allow_partial_coverage": True,
        },
        "execution_steps": [{"sequence": 1, "title": "Build draft", "description": "Map available columns",
                             "phase": "draft_execution", "query_kind": "mapping", "dynamic_sql": True}],
    }
    result = tool.invoke({"plan": plan})
    assert result["status"] == "succeeded"
    auto_map = result["data"]["auto_map"]
    assert auto_map["evidence_gaps"] == ["UNRESOLVED_ATTRIBUTE"]
    assert auto_map["mapping_classifications"]["UNRESOLVED_ATTRIBUTE"] == "unresolved"
    assert auto_map["expected_coverage"] == 0.5


def test_host_rejects_join_choice_changed_after_evidence_preparation() -> None:
    import copy
    original = {"left_table": "DB.SRC.CONTACTS", "right_table": "DB.SRC.ADDRESSES",
                "join_type": "LEFT", "conditions": [{"left_column": "ID", "right_column": "CONTACT_ID"}]}
    alternative = {**original, "conditions": [{"left_column": "ID", "right_column": "PARENT_ID"}]}
    plan = {
        "normalized_intent": "Build household mapping",
        "source_preparation": {"driving_source": "DB.SRC.CONTACTS",
                               "supporting_sources": ["DB.SRC.ADDRESSES"],
                               "relationships": [original], "target_table": "DB.TGT.HOUSEHOLD"},
        "auto_map": {"target_columns": ["ID"], "mapping_evidence": [
            {"target_column": "ID", "source_columns": ["CONTACTS.ID"], "mapping_mode": "direct"}]},
        "decisions": [{"subject": "join", "decision_key": "DB.SRC.ADDRESSES / DB.SRC.CONTACTS",
                       "selected_value": "join_0", "confidence": 0.5, "score_margin": 0,
                       "rationale": "Current joins conflict.",
                       "alternatives": [{"value": "join_1", "relationship": alternative}]}],
        "execution_steps": [{"sequence": 1, "title": "Compile", "description": "Compile mapping",
                             "phase": "draft_execution", "query_kind": "mapping", "dynamic_sql": True}],
    }
    registry = CapabilityRegistry(
        context_provider=lambda: {"effective_run_mode": "plan",
                                  "authorized_source_scope": ["DB.SRC.CONTACTS", "DB.SRC.ADDRESSES"],
                                  "authorized_target_scope": ["DB.TGT.HOUSEHOLD"]},
        workflow_executor=lambda _targets, _mappings, _plan=None: {}, workbench=None,
        budget=ExecutionBudget(model_limit=5, tool_limit=20),
    )
    registry._prepared_plan_candidate = copy.deepcopy(plan)
    tool = next(item for item in registry.tools() if item.name == "validate_migration_plan")
    assert tool.invoke({"plan": plan})["status"] == "succeeded"
    tampered = copy.deepcopy(plan)
    tampered["decisions"][0]["alternatives"][0]["relationship"]["conditions"][0]["right_column"] = "OTHER_ID"
    assert tool.invoke({"plan": tampered})["error_code"] == "unverified_join_choice"


def test_supervisor_continues_when_generated_plan_is_unfinished() -> None:
    traces: list[tuple[str, str]] = []
    runtime = DeepAgentsRuntime(
        model=_model(),
        migration_graph=build_migration_graph(),
        budget=ExecutionBudget(model_limit=10, tool_limit=20),
        trace=lambda event_type, _status, summary, _data: traces.append((event_type, summary)),
    )

    class _PlanStub:
        calls = 0

        def stream(self, _input: Any, **_kwargs: Any):
            self.calls += 1
            if self.calls == 1:
                yield "values", {
                    "messages": [AIMessage(content="I will inspect FIR evidence next.")],
                    "todos": [
                        {"content": "Inspect FIR evidence", "status": "in_progress"},
                        {"content": "Return recommendation", "status": "pending"},
                    ],
                }
            else:
                yield "values", {
                    "messages": [AIMessage(content="[FINAL] The verified recommendation is ready.")],
                    "todos": [
                        {"content": "Inspect FIR evidence", "status": "completed"},
                        {"content": "Return recommendation", "status": "completed"},
                    ],
                }

    stub = _PlanStub()
    runtime._agent = stub  # type: ignore[assignment]
    result = runtime.invoke(
        RuntimeInvocation(
            run_id="run-continuation",
            thread_id="run-continuation",
            prompt="Recommend a verified source and target",
            effort=EffortLevel.MEDIUM,
            workflow_input=_workflow_input(),
        )
    )

    assert stub.calls == 2
    assert result.assistant_message == "The verified recommendation is ready."
    assert any(event_type == "plan.continued" for event_type, _summary in traces)
    assert not any(event_type == "assistant.preamble" for event_type, _summary in traces)


def test_completed_todos_with_unmarked_answer_terminalize_without_continuation() -> None:
    runtime = DeepAgentsRuntime(
        model=_model(), migration_graph=build_migration_graph(),
        budget=ExecutionBudget(model_limit=10, tool_limit=20),
    )

    class _TerminalStub:
        calls = 0

        def stream(self, _input: Any, **_kwargs: Any):
            self.calls += 1
            yield "values", {
                "messages": [AIMessage(content="The verified recommendation is ready.")],
                "todos": [{"content": "Return recommendation", "status": "completed"}],
            }

    stub = _TerminalStub()
    runtime._agent = stub  # type: ignore[assignment]
    result = runtime.invoke(RuntimeInvocation(
        run_id="run-host-terminal", thread_id="run-host-terminal",
        prompt="Explain the result", effort=EffortLevel.LIGHT,
        workflow_input=_workflow_input(),
    ))

    assert stub.calls == 1
    assert result.status == "COMPLETED"
    assert result.assistant_message == "The verified recommendation is ready."


def test_plan_mode_cannot_terminalize_with_prose_only_approval_request() -> None:
    traces: list[str] = []
    runtime = DeepAgentsRuntime(
        model=_model(), migration_graph=build_migration_graph(),
        budget=ExecutionBudget(model_limit=10, tool_limit=20),
        trace=lambda event_type, _status, _summary, _data: traces.append(event_type),
    )

    class _ProseApprovalStub:
        calls = 0

        def stream(self, _input: Any, **_kwargs: Any):
            self.calls += 1
            yield "values", {
                "messages": [AIMessage(content="The plan is ready. Please type approved to continue.")],
                "todos": [{"content": "Present plan", "status": "completed"}],
            }

    stub = _ProseApprovalStub()
    runtime._agent = stub  # type: ignore[assignment]
    result = runtime.invoke(RuntimeInvocation(
        run_id="run-plan-prose", thread_id="run-plan-prose",
        prompt="Plan a household migration", effort=EffortLevel.MEDIUM,
        workflow_input={**_workflow_input(), "run_mode": "plan"},
    ))

    assert stub.calls == 3
    assert result.status == "NEEDS_REVIEW"
    assert "required governed migration checkpoint was not created" in result.assistant_message.lower()
    assert traces.count("plan.checkpoint_required") == 2
    assert "plan.checkpoint_missing" in traces


def test_auto_migration_cannot_claim_completion_without_workflow_result() -> None:
    runtime = DeepAgentsRuntime(
        model=_model(), migration_graph=build_migration_graph(),
        budget=ExecutionBudget(model_limit=10, tool_limit=20),
    )

    class _FalseCompletionStub:
        calls = 0

        def stream(self, _input: Any, **_kwargs: Any):
            self.calls += 1
            yield "values", {
                "messages": [AIMessage(content="Execution summary: the draft is ready.")],
                "todos": [{"content": "Create migration", "status": "completed"}],
            }

    stub = _FalseCompletionStub()
    runtime._agent = stub  # type: ignore[assignment]
    result = runtime.invoke(RuntimeInvocation(
        run_id="run-auto-false-complete", thread_id="run-auto-false-complete",
        prompt="Build Household", effort=EffortLevel.LIGHT,
        workflow_input={
            **_workflow_input(),
            "run_mode": "auto",
            "intent": "NEW_MIGRATION_TASK",
        },
    ))

    assert stub.calls == 3
    assert result.status == "NEEDS_REVIEW"
    assert "No draft migration was executed" in result.assistant_message


def test_read_only_followup_can_complete_without_draft_workflow() -> None:
    runtime = DeepAgentsRuntime(
        model=_model(), migration_graph=build_migration_graph(),
        budget=ExecutionBudget(model_limit=10, tool_limit=20),
    )

    class _PreviewStub:
        calls = 0

        def stream(self, _input: Any, **_kwargs: Any):
            self.calls += 1
            yield "values", {
                "messages": [AIMessage(content="[FINAL] Preview returned 2 rows.")],
                "todos": [{"content": "Run preview", "status": "completed"}],
            }

    stub = _PreviewStub()
    runtime._agent = stub  # type: ignore[assignment]
    result = runtime.invoke(RuntimeInvocation(
        run_id="run-preview-followup", thread_id="run-preview-followup",
        prompt="Execute the proposed SQL", effort=EffortLevel.LIGHT,
        workflow_input={
            **_workflow_input(), "run_mode": "auto", "intent": "NEW_MIGRATION_TASK",
            "page_context": {"continuation_kind": "READ_ONLY_SQL"},
        },
    ))

    assert stub.calls == 1
    assert result.status == "COMPLETED"
    assert "2 rows" in result.assistant_message


def test_open_deep_request_answered_in_prose_completes_without_checkpoint() -> None:
    traces: list[str] = []
    runtime = DeepAgentsRuntime(
        model=_model(), migration_graph=build_migration_graph(),
        budget=ExecutionBudget(model_limit=10, tool_limit=20),
        trace=lambda event_type, _status, _summary, _data: traces.append(event_type),
    )

    class _CapabilityStub:
        calls = 0

        def stream(self, _input: Any, **_kwargs: Any):
            self.calls += 1
            yield "values", {
                "messages": [AIMessage(content="I can research sources, draft STTMs, and preview SQL.")],
                "todos": [{"content": "Explain capabilities", "status": "completed"}],
            }

    stub = _CapabilityStub()
    runtime._agent = stub  # type: ignore[assignment]
    result = runtime.invoke(RuntimeInvocation(
        run_id="run-open-capability", thread_id="run-open-capability",
        prompt="Hello, walk me through how you would approach my data", effort=EffortLevel.LIGHT,
        workflow_input={
            **_workflow_input(), "run_mode": "auto", "intent": "NEW_MIGRATION_TASK",
            "page_context": {"continuation_kind": "OPEN_REQUEST"},
        },
    ))

    assert stub.calls == 1
    assert result.status == "COMPLETED"
    assert "draft STTMs" in result.assistant_message
    assert not any(event.startswith("plan.checkpoint") for event in traces)


def test_open_deep_request_that_entered_governed_flow_still_requires_checkpoint() -> None:
    runtime = DeepAgentsRuntime(
        model=_model(), migration_graph=build_migration_graph(),
        budget=ExecutionBudget(model_limit=10, tool_limit=20),
    )

    class _EnteredWorkflowStub:
        calls = 0

        def stream(self, _input: Any, **_kwargs: Any):
            self.calls += 1
            # The supervisor tried to prepare migration evidence: the request
            # is now a migration and cannot end with a prose-only claim.
            runtime._registry._evidence_failure = {"attempts": 1}
            yield "values", {
                "messages": [AIMessage(content="Execution summary: the draft is ready.")],
                "todos": [{"content": "Create migration", "status": "completed"}],
            }

    stub = _EnteredWorkflowStub()
    runtime._agent = stub  # type: ignore[assignment]
    result = runtime.invoke(RuntimeInvocation(
        run_id="run-open-entered", thread_id="run-open-entered",
        prompt="I need the household information moved over", effort=EffortLevel.LIGHT,
        workflow_input={
            **_workflow_input(), "run_mode": "auto", "intent": "NEW_MIGRATION_TASK",
            "page_context": {"continuation_kind": "OPEN_REQUEST"},
        },
    ))

    assert stub.calls == 3
    assert result.status == "NEEDS_REVIEW"
    assert "No draft migration was executed" in result.assistant_message
    # Auto mode must not describe the failure as a Plan-mode checkpoint.
    assert "plan mode" not in result.assistant_message.lower()
    categories = [item.get("category") for item in result.workflow_state.get("review_items") or []]
    assert "migration_checkpoint_missing" in categories
    assert "plan_checkpoint_missing" not in categories


def test_supervisor_emits_one_model_authored_update_after_an_action_batch() -> None:
    traces: list[tuple[str, str]] = []
    runtime = DeepAgentsRuntime(
        model=_model(),
        migration_graph=build_migration_graph(),
        budget=ExecutionBudget(model_limit=10, tool_limit=20),
        trace=lambda event_type, _status, summary, _data: traces.append(
            (event_type, summary)
        ),
    )

    class _MilestoneStub:
        def stream(self, _input: Any, **_kwargs: Any):
            yield "messages", AIMessageChunk(
                content="I inspected the context and candidate projects. Next I will compare the strongest tables."
            )
            runtime._completed_tool_actions = 2
            yield "values", {
                "messages": [AIMessage(content="[FINAL] **Recommendation:** Use the verified target.")],
                "todos": [{"content": "Return recommendation", "status": "completed"}],
            }

    runtime._agent = _MilestoneStub()  # type: ignore[assignment]
    result = runtime.invoke(
        RuntimeInvocation(
            run_id="run-milestone",
            thread_id="run-milestone",
            prompt="Recommend a target",
            effort=EffortLevel.MEDIUM,
            workflow_input=_workflow_input(),
        )
    )

    updates = [summary for event_type, summary in traces if event_type == "assistant.update"]
    assert updates == [
        "I inspected the context and candidate projects. Next I will compare the strongest tables."
    ]
    assert result.assistant_message == "**Recommendation:** Use the verified target."


def test_supervisor_emits_model_authored_preamble_before_first_tool_batch() -> None:
    traces: list[tuple[str, str]] = []
    runtime = DeepAgentsRuntime(
        model=_model(),
        migration_graph=build_migration_graph(),
        budget=ExecutionBudget(model_limit=10, tool_limit=20),
        trace=lambda event_type, _status, summary, _data: traces.append((event_type, summary)),
    )

    class _PreambleStub:
        def stream(self, _input: Any, **_kwargs: Any):
            yield "messages", AIMessageChunk(
                content="[PROGRESS] I understand you want the generated mapping verified."
            )
            assert ("assistant.update", "I understand you want the generated mapping verified.") in traces
            yield "values", {
                "messages": [AIMessage(content="[FINAL] The query is verified.")],
                "todos": [],
            }

    runtime._agent = _PreambleStub()  # type: ignore[assignment]
    result = runtime.invoke(
        RuntimeInvocation(
            run_id="run-preamble",
            thread_id="run-preamble",
            prompt="Verify the generated SQL",
            effort=EffortLevel.LIGHT,
            workflow_input=_workflow_input(),
        )
    )

    assert [summary for event_type, summary in traces if event_type == "assistant.update"] == [
        "I understand you want the generated mapping verified."
    ]
    assert result.assistant_message == "The query is verified."


def test_resume_suppresses_repeated_future_only_narration_and_returns_partial_synthesis() -> None:
    traces: list[tuple[str, str]] = []
    runtime = DeepAgentsRuntime(
        model=_model(), migration_graph=build_migration_graph(),
        budget=ExecutionBudget(model_limit=20, tool_limit=40),
        trace=lambda event_type, _status, summary, _data: traces.append((event_type, summary)),
    )

    class _StalledResumeStub:
        calls = 0
        finalization_input = ""

        def stream(self, value: Any, **_kwargs: Any):
            self.calls += 1
            if self.calls == 6:
                self.finalization_input = str(value)
                yield "values", {
                    "messages": [AIMessage(content="Verified: the contact contract was inspected. Unresolved: household target selection requires user scope.")],
                    "todos": [{"content": "Select household target", "status": "in_progress"}],
                }
                return
            yield "messages", AIMessageChunk(content="I'll continue by inspecting the tables and retrieving the necessary evidence.")
            yield "values", {
                "messages": [AIMessage(content="I'll continue by inspecting the tables and retrieving the necessary evidence.")],
                "todos": [{"content": "Select household target", "status": "in_progress"}],
            }

    stub = _StalledResumeStub()
    runtime._agent = stub  # type: ignore[assignment]
    result = runtime.invoke(RuntimeInvocation(
        run_id="run-stalled-resume", thread_id="run-stalled-resume",
        prompt="continue", effort=EffortLevel.HIGH, is_resume=True,
        workflow_input=_workflow_input(),
    ))

    assert result.status == "NEEDS_REVIEW"
    assert "Unresolved:" in result.assistant_message
    assert "available governed tools" in stub.finalization_input
    assert [summary for event_type, summary in traces if event_type == "assistant.update"] == []
    assert any(event_type == "plan.finalization_fallback" for event_type, _ in traces)


def test_completed_plan_with_only_future_narration_forces_protected_synthesis() -> None:
    runtime = DeepAgentsRuntime(
        model=_model(), migration_graph=build_migration_graph(),
        budget=ExecutionBudget(
            model_limit=10, tool_limit=20, finalization_model_reserve=2,
        ),
    )

    class _CompletedWithoutAnswerStub:
        calls = 0

        def stream(self, value: Any, **_kwargs: Any):
            self.calls += 1
            if self.calls == 1:
                yield "values", {
                    "messages": [AIMessage(content="I'll inspect the target and recommend the best sources.")],
                    "todos": [{"content": "Find sources", "status": "completed"}],
                }
                return
            assert "do not call any more tools" in str(value)
            yield "values", {
                "messages": [AIMessage(content="The verified best source is DB.CRM.HOUSEHOLDS because its contract matches the target key and address columns.")],
                "todos": [{"content": "Find sources", "status": "completed"}],
            }

    stub = _CompletedWithoutAnswerStub()
    runtime._agent = stub  # type: ignore[assignment]
    result = runtime.invoke(RuntimeInvocation(
        run_id="run-completed-synthesis", thread_id="run-completed-synthesis",
        prompt="Find the best source", effort=EffortLevel.LIGHT,
        workflow_input=_workflow_input(),
    ))

    assert stub.calls == 2
    assert result.status == "COMPLETED"
    assert result.assistant_message.startswith("The verified best source")


def test_completed_answer_is_not_emitted_as_progress_before_final() -> None:
    traces: list[tuple[str, str]] = []
    answer = "The verified source is DB.CRM.CONTACT_FAMILIES because its household grain matches the target."
    runtime = DeepAgentsRuntime(
        model=_model(), migration_graph=build_migration_graph(),
        budget=ExecutionBudget(model_limit=10, tool_limit=20),
        trace=lambda event_type, _status, summary, _data: traces.append((event_type, summary)),
    )

    class _StreamedFinalStub:
        def stream(self, _value: Any, **_kwargs: Any):
            yield "messages", AIMessageChunk(content=answer)
            yield "values", {
                "messages": [AIMessage(content=answer)],
                "todos": [{"content": "Recommend source", "status": "completed"}],
            }

    runtime._agent = _StreamedFinalStub()  # type: ignore[assignment]
    result = runtime.invoke(RuntimeInvocation(
        run_id="run-streamed-final", thread_id="run-streamed-final",
        prompt="Recommend a source", effort=EffortLevel.LIGHT,
        workflow_input=_workflow_input(),
    ))

    assert result.assistant_message == answer
    assert [summary for event_type, summary in traces if event_type == "assistant.update"] == []


def test_supervisor_receives_prior_visible_conversation_for_follow_up() -> None:
    runtime = DeepAgentsRuntime(
        model=_model(),
        migration_graph=build_migration_graph(),
        budget=ExecutionBudget(model_limit=10, tool_limit=20),
    )
    workflow_input = _workflow_input() | {
        "conversation_history": [
            {"role": "user", "content": "Generate the mapping SQL."},
            {"role": "assistant", "content": "```sql\nSELECT * FROM DB.SCHEMA.SOURCE\n```"},
        ]
    }
    invocation = RuntimeInvocation(
        run_id="run-follow-up",
        thread_id="run-follow-up",
        prompt="Run the generated SQL and return the result.",
        effort=EffortLevel.LIGHT,
        workflow_input=workflow_input,
    )
    runtime._active_invocation = invocation

    messages = runtime._agent_input(invocation)["messages"]

    assert messages[0] == {"role": "user", "content": "Generate the mapping SQL."}
    assert "SELECT * FROM DB.SCHEMA.SOURCE" in messages[1]["content"]
    assert "Run the generated SQL" in messages[-1]["content"]


def test_auto_effort_resolves_simple_read_only_sql_follow_up_to_light() -> None:
    request = RunCreateRequest(
        prompt="Can you run the generated SQL and return the answer?",
        conversation_history=[{"role": "assistant", "content": "```sql\nSELECT 1\n```"}],
    )

    assert resolve_effort(request) is EffortLevel.LIGHT


def test_auto_effort_scales_mapping_generation_follow_up_to_medium() -> None:
    request = RunCreateRequest(
        prompt="Can you generate the mapping then?",
        conversation_history=[{
            "role": "assistant",
            "content": "Recommended source candidates are CONTACT_FAMILIES, CONTACTS, and ADDRESSES with verified join evidence.",
        }],
    )

    assert resolve_effort(request) is EffortLevel.MEDIUM


def test_budget_snapshot_exposes_live_remaining_capacity() -> None:
    budget = ExecutionBudget(
        model_limit=20,
        tool_limit=40,
        finalization_model_reserve=4,
        finalization_tool_reserve=8,
    )
    budget.consume_model("test.model")
    budget.consume_tool("test.tool")

    snapshot = budget.structured_snapshot()

    assert snapshot["active_model_remaining"] == 15
    assert snapshot["active_tool_remaining"] == 31
    assert snapshot["total_model_remaining"] == 19
    assert snapshot["total_tool_remaining"] == 39


def test_auto_budget_can_promote_to_the_next_bounded_tier() -> None:
    budget = ExecutionBudget(
        model_limit=20,
        tool_limit=40,
        finalization_model_reserve=4,
        finalization_tool_reserve=8,
        adaptive_limits=[{
            "model_limit": 30,
            "tool_limit": 120,
            "finalization_model_reserve": 6,
            "finalization_tool_reserve": 20,
        }],
    )
    for index in range(16):
        budget.consume_model(f"working-{index}")

    with pytest.raises(BudgetExceededError):
        budget.consume_model("before-scale")

    scaled = budget.try_auto_scale()

    assert scaled and scaled["model_limit"] == 30
    budget.consume_model("after-scale")
    assert budget.structured_snapshot()["active_model_remaining"] == 7


def test_explicit_effort_returns_bounded_result_if_finalization_capacity_ends() -> None:
    runtime = DeepAgentsRuntime(
        model=_model(), migration_graph=build_migration_graph(),
        budget=ExecutionBudget(
            model_limit=2, tool_limit=4, finalization_model_reserve=1,
        ),
    )

    class _FinalizationExhaustedStub:
        calls = 0

        def stream(self, _value: Any, **_kwargs: Any):
            self.calls += 1
            if self.calls == 1:
                yield "values", {
                    "messages": [AIMessage(content="I'll inspect the remaining evidence.")],
                    "todos": [{"content": "Inspect verified evidence", "status": "completed"}],
                }
                return
            raise BudgetExceededError("finalization reserve ended")

    runtime._agent = _FinalizationExhaustedStub()  # type: ignore[assignment]
    result = runtime.invoke(RuntimeInvocation(
        run_id="run-bounded-final", thread_id="run-bounded-final",
        prompt="Inspect evidence", effort=EffortLevel.LIGHT,
        workflow_input=_workflow_input(),
    ))

    assert result.status == "COMPLETED"
    assert "configured research boundary" in result.assistant_message
    assert "Inspect verified evidence" in result.assistant_message


def test_elapsed_boundary_finalizes_without_auto_effort_promotion() -> None:
    budget = ExecutionBudget(
        model_limit=4, tool_limit=8, finalization_model_reserve=1,
        adaptive_limits=[{"policy": {"effort": "medium"}}],
    )
    runtime = DeepAgentsRuntime(
        model=_model(), migration_graph=build_migration_graph(), budget=budget,
    )

    class _DeadlineStub:
        calls = 0

        def stream(self, _value: Any, **_kwargs: Any):
            self.calls += 1
            todos = [{"content": "Create mapping draft", "status": "pending"}]
            if self.calls == 1:
                yield "values", {"messages": [AIMessage(content="Target contract verified.")], "todos": todos}
                raise BudgetExceededError("Elapsed-time budget exhausted", kind="elapsed")
            yield "values", {"messages": [AIMessage(content="The target contract is verified; no draft was saved.")], "todos": todos}

    stub = _DeadlineStub()
    runtime._agent = stub  # type: ignore[assignment]
    with pytest.raises(BudgetExceededError):
        runtime.invoke(RuntimeInvocation(
            run_id="run-deadline", thread_id="run-deadline", prompt="Create mapping draft",
            effort=EffortLevel.AUTO, workflow_input=_workflow_input(),
        ))
    assert stub.calls == 1
    assert budget.model_limit == 4


def test_read_only_sql_tool_uses_only_tables_discovered_in_the_run() -> None:
    calls: list[tuple[str, int, set[str]]] = []

    class _SqlWorkbench:
        def search_catalog(self, _search_term: str, _limit: int) -> ToolResult:
            return ToolResult(
                status="succeeded",
                summary="Found one table.",
                data={"candidates": [{"table": "DB.SCHEMA.SOURCE"}]},
            )

        def execute_read_only_sql(
            self,
            _context: dict[str, Any],
            sql: str,
            *,
            max_rows: int,
            allowed_tables: set[str],
        ) -> ToolResult:
            calls.append((sql, max_rows, allowed_tables))
            return ToolResult(
                status="succeeded",
                summary="Query complete.",
                data={"rows": [{"VALUE": 1}]},
            )

    registry = CapabilityRegistry(
        context_provider=lambda: {"authorized_source_scope": [], "authorized_target_scope": []},
        workflow_executor=lambda _sources, _targets, _plan=None: {},
        workbench=_SqlWorkbench(),
        budget=ExecutionBudget(model_limit=5, tool_limit=20),
    )
    tools = {tool.name: tool for tool in registry.tools()}
    tools["search_catalog"].invoke({"search_term": "source", "limit": 10})
    result = tools["execute_read_only_sql"].invoke({
        "sql": "SELECT * FROM DB.SCHEMA.SOURCE",
        "max_rows": 100,
    })

    assert result["status"] == "succeeded"
    assert calls == [("SELECT * FROM DB.SCHEMA.SOURCE", 20, {"DB.SCHEMA.SOURCE"})]


def test_workbench_read_only_sql_is_single_statement_scoped_and_bounded() -> None:
    executed: list[str] = []

    class _Field:
        name = "VALUE"
        datatype = "NUMBER"

    class _Frame:
        schema = type("Schema", (), {"fields": [_Field()]})()

        def collect(self):
            return [type("Row", (), {"as_dict": lambda self, recursive=True: {"VALUE": 1}})()]

    class _Session:
        def sql(self, query: str, _params: Any = None):
            executed.append(query)
            return _Frame()

    handlers = WorkbenchWorkflowHandlers(
        repository=object(),
        project_service=object(),  # type: ignore[arg-type]
        session=_Session(),
        budget=ExecutionBudget(model_limit=2, tool_limit=5),
    )

    result = handlers.execute_read_only_sql(
        {},
        "WITH S AS (SELECT * FROM DB.SCHEMA.SOURCE) SELECT * FROM S",
        max_rows=100,
        allowed_tables={"DB.SCHEMA.SOURCE"},
    )

    assert result.status == "succeeded"
    assert result.data["rows"] == [{"VALUE": 1}]
    assert "LIMIT 20" in executed[0]
    commented = handlers.execute_read_only_sql(
        {},
        "-- Diagnostic: verify join coverage\nSELECT * FROM DB.SCHEMA.SOURCE",
        allowed_tables={"DB.SCHEMA.SOURCE"},
    )
    assert commented.status == "succeeded"
    with pytest.raises(PermissionError, match="authorized or discovered"):
        handlers.execute_read_only_sql(
            {},
            "SELECT * FROM OTHER.SCHEMA.SECRET",
            allowed_tables={"DB.SCHEMA.SOURCE"},
        )
    with pytest.raises(PermissionError, match="SELECT or WITH"):
        handlers.execute_read_only_sql(
            {},
            "DELETE FROM DB.SCHEMA.SOURCE",
            allowed_tables={"DB.SCHEMA.SOURCE"},
        )


class _ConcurrentHandlers(DefaultWorkflowHandlers):
    def __init__(self) -> None:
        self.active = 0
        self.maximum = 0
        self.lock = threading.Lock()

    def execute_mapping(self, state: dict[str, Any], mapping: dict[str, Any]) -> dict[str, Any]:
        del state
        with self.lock:
            self.active += 1
            self.maximum = max(self.maximum, self.active)
        time.sleep(0.03)
        with self.lock:
            self.active -= 1
        return {"mapping_key": mapping["mapping_key"], "status": "READY_FOR_REVIEW"}


def test_high_effort_executes_independent_dag_nodes_in_parallel() -> None:
    handlers = _ConcurrentHandlers()
    names = [f"Entity{index}" for index in range(10)]
    result = build_migration_graph(handlers).invoke({
        "messages": [], "run_id": "run-2", "prompt": "map", "effort": "high",
        "actor_user_id": "user-1", "effective_role": "MIGRATION_EDITOR",
        "requested_mappings": names,
        "authorized_target_scope": [f"D.S.{name.upper()}" for name in names],
    })
    assert result["status"] == "READY_FOR_REVIEW"
    assert len(result["mapping_results"]) == 10
    assert 1 < handlers.maximum <= 5


def test_generic_request_pauses_before_creating_mapping_without_target_scope() -> None:
    result = build_migration_graph(checkpointer=InMemorySaver()).invoke(
        {
            "messages": [],
            "run_id": "run-generic",
            "prompt": "Verify the migration runtime without making changes.",
            "effort": "light",
            "actor_user_id": "user-1",
            "effective_role": "MIGRATION_EDITOR",
            "authorized_target_scope": [],
            "requested_mappings": [],
            "attachment_ids": [],
        },
        config={"configurable": {"thread_id": "run-generic"}},
    )

    interrupts = result.get("__interrupt__")
    assert interrupts
    assert interrupts[0].value["category"] == "target_scope"
    assert interrupts[0].value["affected_mappings"] == ["Mapping"]
    assert interrupts[0].value["choices"] == []
    assert interrupts[0].value["recommended_choice_id"] is None


def test_authorized_target_repairs_a_resumed_manifest_without_reasking() -> None:
    result = build_migration_graph().invoke({
        "messages": [],
        "run_id": "run-resumed-target",
        "prompt": "Build Household",
        "effort": "light",
        "run_mode": "auto",
        "actor_user_id": "user-1",
        "effective_role": "MIGRATION_EDITOR",
        "authorized_source_scope": ["DB.SRC.CONTACTS"],
        "authorized_target_scope": ["DB.TGT.EVERNEST_HH"],
        "requested_mappings": ["Household"],
        "manifest": [{
            "mapping_key": "household",
            "mapping_name": "Household",
            "target_table": None,
            "dependencies": [],
            "status": "PENDING",
        }],
    })

    assert not result.get("__interrupt__")
    assert result["manifest"][0]["target_table"] == "DB.TGT.EVERNEST_HH"


def test_full_validation_reports_contract_key_reconciliation_and_blast_radius() -> None:
    report = validate_mapping_set(
        [
            {"mapping_key": "parent", "target_table": "D.S.P", "dependencies": []},
            {"mapping_key": "child", "target_table": "D.S.C", "dependencies": ["parent"]},
        ],
        [
            {"mapping_key": "parent", "status": "NEEDS_REVIEW", "target_columns": ["ID", "NAME"], "target_key_columns": ["ID"], "mapped_target_columns": ["NAME"], "unresolved_target_columns": ["ID"]},
            {"mapping_key": "child", "status": "READY_FOR_REVIEW", "target_columns": ["ID"], "target_key_columns": ["ID"], "mapped_target_columns": ["ID"], "unresolved_target_columns": []},
        ],
        ["contract", "keys", "dependencies", "reconciliation", "blast_radius"],
    )
    assert report["passed"] is False
    assert all(name in report["gates"] for name in ("contract", "keys", "dependencies", "reconciliation", "blast_radius"))
    assert {issue["category"] for issue in report["issues"]} >= {"key_validation", "reconciliation", "blast_radius"}


class _JoinContractWorkbench:
    """Current contracts for a contact graph that needs a many-to-many bridge."""

    _columns = {
        "DB.SRC.CONTACT_FAMILIES": ["ID", "NAME"],
        "DB.SRC.CONTACT_FAMILY_MEMBERS": ["ID", "FAMILY_ID", "CONTACT_ID"],
        "DB.SRC.CONTACTS": ["ID", "FIRST_NAME"],
    }

    def inspect_table_contract(self, table_fqn: str) -> ToolResult:
        columns = self._columns.get(table_fqn.upper())
        if columns is None:
            return ToolResult(status="failed", summary="Unknown table", error_code="table_not_found")
        return ToolResult(status="succeeded", summary="Contract", data={
            "table": table_fqn, "columns": columns,
            "column_contracts": [{"name": name, "type": "NUMBER" if name.endswith("ID") else "VARCHAR"}
                                 for name in columns],
        })

    @staticmethod
    def _type_family(value: str) -> str:
        return "number" if value.upper().startswith("NUMBER") else "text"


def _join_runtime(workbench: _JoinContractWorkbench) -> DeepAgentsRuntime:
    runtime = DeepAgentsRuntime(
        model=_model(), migration_graph=build_migration_graph(DefaultWorkflowHandlers()),
        budget=ExecutionBudget(model_limit=5, tool_limit=20), workbench=workbench,
    )
    runtime._active_invocation = RuntimeInvocation(
        run_id="join-run", thread_id="join-run", prompt="Map households", effort=EffortLevel.MEDIUM,
        workflow_input={**_workflow_input(), "intent": "NEW_MIGRATION_TASK",
                        "authorized_schemas": ["DB.SRC", "DB.TGT"]},
    )
    runtime._registry._plan_validator = lambda plan: (
        setattr(runtime._registry, "_validated_supervisor_plan", dict(plan)) or {"status": "succeeded"}
    )
    return runtime


_FAMILY_PLAN = {"source_preparation": {
    "driving_source": "DB.SRC.CONTACT_FAMILIES", "supporting_sources": ["DB.SRC.CONTACTS"],
    "target_table": "DB.TGT.HOUSEHOLD", "relationships": [],
}}
_BRIDGE_RULE = ("CONTACT_FAMILIES.ID = CONTACT_FAMILY_MEMBERS.FAMILY_ID; "
                "CONTACT_FAMILY_MEMBERS.CONTACT_ID = CONTACTS.ID")


def test_confirmed_join_rule_through_a_catalog_bridge_table_validates_the_plan() -> None:
    workbench = _JoinContractWorkbench()
    runtime = _join_runtime(workbench)
    registry = runtime._registry
    registry._prepared_plan_candidate = dict(_FAMILY_PLAN)
    # The bridge was verified via inspect_table_contract during research but is
    # neither the driving nor a supporting source of the prepared plan.
    registry._catalog_candidates.update(
        {"DB.SRC.CONTACT_FAMILIES", "DB.SRC.CONTACTS", "DB.SRC.CONTACT_FAMILY_MEMBERS"})

    result = workbench.resolve_join_clarifications({}, [{"rule": _BRIDGE_RULE}])

    assert result["status"] == "succeeded"
    source = result["supervisor_plan"]["source_preparation"]
    assert "DB.SRC.CONTACT_FAMILY_MEMBERS" in source["supporting_sources"]
    assert {(item["left_table"], item["right_table"]) for item in source["relationships"]} == {
        ("DB.SRC.CONTACT_FAMILIES", "DB.SRC.CONTACT_FAMILY_MEMBERS"),
        ("DB.SRC.CONTACT_FAMILY_MEMBERS", "DB.SRC.CONTACTS"),
    }


def test_join_answer_after_restart_restores_the_checkpointed_plan_candidate() -> None:
    workbench = _JoinContractWorkbench()
    runtime = _join_runtime(workbench)
    # A fresh worker process has an empty registry; the interrupted state holds
    # the server-stored candidate and the verified catalog tables.
    assert runtime._registry.prepared_plan_candidate is None
    state = {"research_clarification": {
        "target_table": "DB.TGT.HOUSEHOLD",
        "prepared_plan_candidate": dict(_FAMILY_PLAN),
        "catalog_candidates": ["DB.SRC.CONTACT_FAMILIES", "DB.SRC.CONTACTS",
                               "DB.SRC.CONTACT_FAMILY_MEMBERS"],
    }}

    result = workbench.resolve_join_clarifications(state, [{"rule": _BRIDGE_RULE}])

    assert result["status"] == "succeeded"
    assert result["supervisor_plan"]["source_preparation"]["driving_source"] == "DB.SRC.CONTACT_FAMILIES"


def test_restored_candidate_outside_the_authorized_schemas_is_not_trusted() -> None:
    workbench = _JoinContractWorkbench()
    runtime = _join_runtime(workbench)
    state = {"research_clarification": {
        "prepared_plan_candidate": {"source_preparation": {
            "driving_source": "DB.OTHER.CONTACT_FAMILIES", "supporting_sources": ["DB.SRC.CONTACTS"]}},
        "catalog_candidates": ["DB.OTHER.CONTACT_FAMILIES", "DB.SRC.CONTACTS"],
    }}

    result = workbench.resolve_join_clarifications(state, [{"rule": "CONTACT_FAMILIES.ID = CONTACTS.ID"}])

    assert result["status"] == "needs_input"
    assert runtime._registry.prepared_plan_candidate is None


def test_excluded_source_is_removed_with_its_joins_ctes_and_gaps() -> None:
    from unittest.mock import Mock

    driver, kept, dropped = "DB.SRC.CONTACTS", "DB.SRC.ADDRESSES", "DB.SRC.MAPPER_ACR_MASTER"
    registry = CapabilityRegistry.__new__(CapabilityRegistry)
    registry._prepared_plan_candidate = {"source_preparation": {
        "driving_source": driver, "supporting_sources": [kept, dropped],
        "relationships": [{"left_table": kept, "right_table": driver,
                           "conditions": [{"left_column": "CONTACT_ID", "right_column": "ID"}]}],
        "selected_columns_by_table": {driver: ["ID"], dropped: ["CONTACT_ID"]},
        "source_rationale": {driver: "driver", dropped: "precedent"},
        "derived_sources": [{"name": "ACR", "sql": "SELECT 1", "base_source_tables": [dropped]}],
        "unresolved_items": [f"Current relationship evidence has no join path to {driver}: {dropped}"],
    }}
    registry._validated_supervisor_plan = None
    registry._catalog_candidates = {driver, kept, dropped}
    registry._workbench = Mock()
    captured = []
    registry._plan_validator = lambda plan: (captured.append(plan) or {"status": "succeeded"})
    assert registry.apply_reviewed_join_path([], excluded=[dropped, driver])["status"] == "succeeded"
    staged = captured[0]["source_preparation"]
    assert staged["supporting_sources"] == [kept] and staged["driving_source"] == driver
    assert staged["excluded_sources"] == [dropped]
    assert dropped not in staged["selected_columns_by_table"] and dropped not in staged["source_rationale"]
    assert staged["derived_sources"] == [] and staged["unresolved_items"] == []
    assert len(staged["relationships"]) == 1
    # With joins resolved by the host, remaining gaps are presented, not blocking.
    assert captured[0]["auto_map"]["allow_partial_coverage"] is True


def test_verified_recommended_joins_are_applied_without_asking_and_only_the_rest_is_asked() -> None:
    driver = "DB.SRC.CONTACTS"
    confident, ambiguous = "DB.SRC.MEMBERS", "DB.SRC.ACTIVITIES"
    received: list[list[dict[str, Any]]] = []
    recorded: list[str] = []

    def join(target: str, column: str) -> dict[str, Any]:
        return {"left_table": target, "right_table": driver,
                "conditions": [{"left_column": column, "right_column": "ID"}]}

    class Resolver(DefaultWorkflowHandlers):
        def auto_apply_verified_joins(self) -> bool:
            return True

        def record_auto_resolved_join(self, _state, question, option) -> None:
            recorded.append(f"{question['target']}:{option['confidence']}")

        def resolve_source_clarification(self, _state: dict[str, Any], _selected: str) -> dict[str, Any]:
            return {"status": "needs_input", "join_questions": [
                {"target": confident, "driver": driver, "options": [
                    {"id": "p1", "label": "Recommended", "recommended": True, "confidence": 0.99,
                     "joins": [join(confident, "CONTACT_ID")]}]},
                {"target": ambiguous, "driver": driver, "options": [
                    {"id": "a1", "label": "Route A", "confidence": 0.62, "joins": [join(ambiguous, "OWNER_ID")]},
                    {"id": "a2", "label": "Route B", "confidence": 0.58, "joins": [join(ambiguous, "CONTACT_ID")]}]},
            ]}

        def validate_join_candidate(self, _joins: list[dict[str, Any]]) -> dict[str, Any]:
            return {"status": "succeeded"}

        def resolve_join_clarifications(self, _state: dict[str, Any], answers: list[dict[str, Any]]) -> dict[str, Any]:
            received.extend([answer] for answer in answers)
            return {"status": "needs_input", "summary": "More evidence needed"}

    graph = build_migration_graph(Resolver(), checkpointer=InMemorySaver())
    config = {"configurable": {"thread_id": "auto-apply-verified-joins"}}
    initial = graph.invoke({**_workflow_input(), "run_mode": "plan",
        "authorized_target_scope": ["DB.TGT.HOUSEHOLD"], "target_candidates": ["DB.TGT.HOUSEHOLD"],
        "research_clarification": {"target_table": "DB.TGT.HOUSEHOLD", "question": "Which driver?",
            "choices": [{"choice_id": "driver", "label": driver, "selection_payload": {"selected_value": driver}}]},
        "supervisor_plan": {"source_preparation": {"driving_source": driver, "target_table": "DB.TGT.HOUSEHOLD"}}},
        config=config)
    source = initial["__interrupt__"][0].value
    asked = graph.invoke(Command(resume=source["choices"][0]["selection_payload"]), config=config)
    question = asked["__interrupt__"][0].value
    # Only the ambiguous join is a question, numbered among the asked ones.
    assert question["question"].startswith("Join path 1 of 1:") and ambiguous in question["question"]
    assert question["recommended_choice_id"] is None
    assert [choice.get("confidence") for choice in question["choices"][:2]] == [0.62, 0.58]
    graph.invoke(Command(resume=question["choices"][0]["selection_payload"]), config=config)
    answers = [item[0] for item in received]
    assert answers[0] == {"joins": [join(confident, "CONTACT_ID")], "auto": True}
    assert answers[1]["joins"][0]["conditions"][0]["left_column"] == "OWNER_ID" and not answers[1].get("auto")
    assert recorded and set(recorded) == {f"{confident}:0.99"}


def test_without_auto_apply_recommended_joins_are_confirmed_in_one_checkpoint() -> None:
    driver = "DB.SRC.CONTACTS"
    first, second, split = "DB.SRC.MEMBERS", "DB.SRC.PROFILES", "DB.SRC.ACTIVITIES"
    received: list[dict[str, Any]] = []

    def join(target: str, column: str) -> dict[str, Any]:
        return {"left_table": target, "right_table": driver,
                "conditions": [{"left_column": column, "right_column": "ID"}]}

    class Resolver(DefaultWorkflowHandlers):
        def auto_apply_verified_joins(self) -> bool:
            return False

        def resolve_source_clarification(self, _state: dict[str, Any], _selected: str) -> dict[str, Any]:
            return {"status": "needs_input", "join_questions": [
                {"target": first, "driver": driver, "options": [
                    {"id": "m", "label": "Recommended (99%)", "recommended": True, "confidence": 0.99,
                     "joins": [join(first, "CONTACT_ID")]}]},
                {"target": second, "driver": driver, "options": [
                    {"id": "p", "label": "Recommended (97%)", "recommended": True, "confidence": 0.97,
                     "joins": [join(second, "CONTACT_ID")]}]},
                {"target": split, "driver": driver, "options": [
                    {"id": "a1", "label": "Route A", "confidence": 0.55, "joins": [join(split, "OWNER_ID")]},
                    {"id": "a2", "label": "Route B", "confidence": 0.52, "joins": [join(split, "CONTACT_ID")]}]},
            ]}

        def validate_join_candidate(self, _joins: list[dict[str, Any]]) -> dict[str, Any]:
            return {"status": "succeeded"}

        def resolve_join_clarifications(self, _state: dict[str, Any], answers: list[dict[str, Any]]) -> dict[str, Any]:
            received.extend(answers)
            return {"status": "needs_input", "summary": "More evidence needed"}

    graph = build_migration_graph(Resolver(), checkpointer=InMemorySaver())
    config = {"configurable": {"thread_id": "batch-recommended-joins"}}
    initial = graph.invoke({**_workflow_input(), "run_mode": "plan",
        "authorized_target_scope": ["DB.TGT.HOUSEHOLD"], "target_candidates": ["DB.TGT.HOUSEHOLD"],
        "research_clarification": {"target_table": "DB.TGT.HOUSEHOLD", "question": "Which driver?",
            "choices": [{"choice_id": "driver", "label": driver, "selection_payload": {"selected_value": driver}}]},
        "supervisor_plan": {"source_preparation": {"driving_source": driver, "target_table": "DB.TGT.HOUSEHOLD"}}},
        config=config)
    source = initial["__interrupt__"][0].value
    batch = graph.invoke(Command(resume=source["choices"][0]["selection_payload"]), config=config)["__interrupt__"][0].value
    assert batch["category"] == "source_join_path_batch"
    assert "MEMBERS" in batch["question"] and "PROFILES" in batch["question"] and "ACTIVITIES" not in batch["question"]
    single = graph.invoke(Command(resume=batch["choices"][0]["selection_payload"]), config=config)["__interrupt__"][0].value
    # Only the split decision remains, numbered among the questions still asked.
    assert single["category"] == "source_join_path" and single["question"].startswith("Join path 1 of 1:")
    assert split in single["question"]
    graph.invoke(Command(resume=single["choices"][1]["selection_payload"]), config=config)
    assert [answer["joins"][0]["left_table"] for answer in received] == [first, second, split]
    assert not any(answer.get("auto") for answer in received)


def test_a_join_the_user_confirmed_before_is_reused_instead_of_asked() -> None:
    driver, lookup = "DB.SRC.CONTACTS", "DB.SRC.COUNTRY_CODES"
    received: list[dict[str, Any]] = []
    reused: list[str] = []
    remembered_join = {"left_table": driver, "right_table": lookup,
                       "conditions": [{"left_column": "COUNTRY", "right_column": "CODE"}],
                       "normalized_lookup_alternative": "ALIAS", "literal_filters": []}

    class Resolver(DefaultWorkflowHandlers):
        def auto_apply_verified_joins(self) -> bool:
            return True

        def remembered_join_paths(self, _state, targets, plan_tables):
            assert driver in plan_tables and lookup in targets
            return {lookup: {"joins": [remembered_join], "evidence_ids": ["learning:c1"]}}

        def record_remembered_join(self, _state, target, _path) -> None:
            reused.append(target)

        def resolve_source_clarification(self, _state: dict[str, Any], _selected: str) -> dict[str, Any]:
            return {"status": "needs_input", "join_questions": [
                {"target": lookup, "driver": driver, "options": [], "no_path_reason": "a code lookup"}]}

        def validate_join_candidate(self, _joins: list[dict[str, Any]]) -> dict[str, Any]:
            return {"status": "succeeded"}

        def resolve_join_clarifications(self, _state: dict[str, Any], answers: list[dict[str, Any]]) -> dict[str, Any]:
            received.extend(answers)
            return {"status": "needs_input", "summary": "done"}

    graph = build_migration_graph(Resolver(), checkpointer=InMemorySaver())
    config = {"configurable": {"thread_id": "remembered-join"}}
    initial = graph.invoke({**_workflow_input(), "run_mode": "plan",
        "authorized_target_scope": ["DB.TGT.HOUSEHOLD"], "target_candidates": ["DB.TGT.HOUSEHOLD"],
        "research_clarification": {"target_table": "DB.TGT.HOUSEHOLD", "question": "Which driver?",
            "choices": [{"choice_id": "driver", "label": driver, "selection_payload": {"selected_value": driver}}]},
        "supervisor_plan": {"source_preparation": {"driving_source": driver, "target_table": "DB.TGT.HOUSEHOLD"}}},
        config=config)
    after = graph.invoke(Command(resume=initial["__interrupt__"][0].value["choices"][0]["selection_payload"]), config=config)
    # No join question: the earlier confirmation answered it.
    assert not any(item.value.get("category") == "source_join_path" for item in after.get("__interrupt__") or [])
    assert received == [{"joins": [remembered_join], "auto": True}]
    assert reused == [lookup]


def test_a_plan_waiting_only_on_join_paths_goes_straight_to_the_join_checkpoint() -> None:
    from app.agent_runtime.deepagents_runtime import _only_join_paths_open

    ready = {"plan_candidate": {"source_preparation": {"driving_source": "DB.S.CONTACTS",
                                                        "supporting_sources": ["DB.S.ADDRESSES"]}},
             "unresolved": ["Current relationship evidence has no join path to DB.S.CONTACTS: DB.S.ADDRESSES"]}
    assert _only_join_paths_open(ready)
    # No sources chosen yet: the model still has research to do.
    assert not _only_join_paths_open({**ready, "plan_candidate": {"source_preparation": {}}})
    # Other gaps only: nothing for the join checkpoint to settle.
    assert not _only_join_paths_open({**ready, "unresolved": ["Target column X has no verified current source"]})
