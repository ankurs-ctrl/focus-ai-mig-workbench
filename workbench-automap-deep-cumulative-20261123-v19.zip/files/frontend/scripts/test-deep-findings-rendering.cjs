const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
const file = path.resolve(__dirname, '../src/features/ai-agent/deep-agent-panel.tsx');
test('page and sidebar findings share formatted review components instead of a JSON pane', () => {
  const source = ts.createSourceFile(file, fs.readFileSync(file, 'utf8'), ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
  let review;
  function walk(node) {
    if (ts.isJsxAttribute(node) && node.name.getText(source) === 'reviewContent') review = node;
    ts.forEachChild(node, walk);
  }
  walk(source);
  assert.ok(review);
  const content = review.getText(source);
  assert.match(content, /AgentReviewTable/);
  assert.match(content, /AgentReviewList/);
  assert.doesNotMatch(content, /JSON\.stringify|component="pre"/);
});
test('working plan and research do not depend on a formal approval artifact or special heading', () => {
  const source = fs.readFileSync(file, 'utf8');
  assert.match(source, /displayedPlan = planDocument \?\? \(workingPlanTodos\.length/);
  assert.match(source, /MigrationPlanRows event=\{workingPlanEvent\}/);
  assert.doesNotMatch(source.slice(source.indexOf('const researchReport ='), source.indexOf('const workingPlanEvent =')), /message\.content\.includes/);
  assert.match(source, /row\.mapping_key \|\| row\.sttm_id/);
});
