import type { DerivedSource } from "../types/sttm.types";

/** Keep dependencies durable without selecting them into the outer query. */
export function selectedDerivedClosure(sources: DerivedSource[]): DerivedSource[] {
  const byId = new Map(sources.map((source) => [source.id, source]));
  const selected = new Map<string, DerivedSource>();
  const visiting = new Set<string>();
  const visit = (source: DerivedSource) => {
    if (selected.has(source.id)) return;
    if (visiting.has(source.id)) throw new Error(`Cyclic CTE dependency: ${source.sourceName}`);
    visiting.add(source.id);
    for (const id of source.parentDerivedSourceIds ?? source.derivedSourceIds ?? []) {
      const parent = byId.get(id);
      if (!parent) throw new Error(`Missing CTE dependency for ${source.sourceName}: ${id}`);
      visit(parent);
    }
    visiting.delete(source.id);
    selected.set(source.id, source);
  };
  sources.filter((source) => source.isSelected).forEach(visit);
  return Array.from(selected.values());
}

export function workspaceDerivedSources(sources: DerivedSource[]) {
  return selectedDerivedClosure(sources).map(source => ({
    id: source.id, name: source.sourceName, is_selected: Boolean(source.isSelected),
    sql_text: source.sqlText, table_ids: source.tableIds ?? [],
    base_source_tables: source.baseSourceTables ?? [],
    parent_derived_source_ids: source.parentDerivedSourceIds ?? source.derivedSourceIds ?? [],
    definition_sql: source.definitionSql, query_scope: source.queryScope ?? {},
    output_columns: source.outputColumns ?? [], column_semantics: source.columnSemantics ?? [],
    semantic_projection: source.semanticProjection ?? {}, semantic_quality: source.semanticQuality,
    purpose: source.purpose, business_description: source.businessDescription,
    grain: source.grain, keys: source.keys ?? [],
    selected_columns_by_table: source.selectedColumnsByTable ?? {}, filters: source.filters ?? [],
  }));
}