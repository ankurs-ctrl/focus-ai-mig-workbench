"""Conversation-scoped knowledge the migration agent has already verified.

Every claim of a durable run used to start from empty caches: contracts were
re-described, catalog candidates forgotten and evidence packages rebuilt on
each resume. ``RunKnowledge`` keeps what a run has verified for the whole
conversation (or run, when there is no conversation) and persists it through
an injected writer. Nothing stored is trusted blindly:

* a stored table contract is used in a new claim only after its column
  signature matched the live catalog (one set-based query for all the tables a
  step needs), unless it was confirmed within the recheck window;
* every derived item records the contract fingerprints it was built from and
  is discarded as soon as one of them changes or disappears;
* every item expires after the configured TTL, after which it is re-read.

The store is thread-safe; concurrent mapping partitions share one instance.
"""
from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable

from app.agent_tools.contract_reader import contract_fingerprint, normalize_fqn

CONTRACT = "contract"
CATALOG_CANDIDATE = "catalog_candidate"
TOOL_RESULT = "tool_result"
DECISION = "decision"
# Data verification of a join candidate and polymorphic type values.
RELATIONSHIP = "relationship"
KINDS = frozenset({CONTRACT, CATALOG_CANDIDATE, TOOL_RESULT, DECISION, RELATIONSHIP})

SignatureReader = Callable[[list[str]], dict[str, str]]


def knowledge_scope(run_id: str, conversation_id: str | None) -> str:
    return f"conversation:{conversation_id}" if conversation_id else f"run:{run_id}"


@dataclass
class KnowledgeItem:
    kind: str
    key: str
    value: dict[str, Any]
    fingerprint: str = ""
    depends_on: dict[str, str] = field(default_factory=dict)
    provenance: dict[str, Any] = field(default_factory=dict)
    run_id: str = ""
    recorded_at: float = 0.0
    # Last time a contract's signature was confirmed against the live catalog.
    confirmed_at: float = 0.0

    def to_row(self) -> dict[str, Any]:
        return {
            "kind": self.kind, "key": self.key, "fingerprint": self.fingerprint,
            "payload": {"value": self.value, "depends_on": self.depends_on,
                        "provenance": self.provenance, "run_id": self.run_id,
                        "recorded_at": self.recorded_at, "confirmed_at": self.confirmed_at},
        }

    @classmethod
    def from_row(cls, row: dict[str, Any]) -> "KnowledgeItem | None":
        payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
        kind, key = str(row.get("kind") or ""), str(row.get("key") or "")
        value = payload.get("value")
        if kind not in KINDS or not key or not isinstance(value, dict):
            return None
        recorded_at = float(payload.get("recorded_at") or 0.0)
        return cls(
            kind=kind, key=key, value=value, fingerprint=str(row.get("fingerprint") or ""),
            depends_on={str(k): str(v) for k, v in dict(payload.get("depends_on") or {}).items()},
            provenance=dict(payload.get("provenance") or {}),
            run_id=str(payload.get("run_id") or ""),
            recorded_at=recorded_at,
            confirmed_at=float(payload.get("confirmed_at") or recorded_at),
        )


class RunKnowledge:
    def __init__(
        self,
        *,
        scope: str,
        access_scope: str,
        run_id: str,
        ttl_seconds: float,
        recheck_seconds: float = 0.0,
        writer: Callable[[list[dict[str, Any]]], None] | None = None,
        clock: Callable[[], float] = time.time,
    ) -> None:
        self.scope = scope
        self.access_scope = access_scope
        self.run_id = run_id
        self._ttl = float(ttl_seconds)
        self._recheck = max(0.0, float(recheck_seconds))
        self._writer = writer
        self._clock = clock
        self._lock = threading.RLock()
        self._items: dict[tuple[str, str], KnowledgeItem] = {}
        self._signatures: SignatureReader | None = None
        # Contracts usable in this claim: read or confirmed since it started.
        self._verified: set[str] = set()
        self._dirty: dict[tuple[str, str], KnowledgeItem | None] = {}
        self.metrics = {"hydrated": 0, "hits": 0, "misses": 0, "invalidated": 0,
                        "contracts_confirmed": 0, "contracts_confirmed_without_query": 0,
                        "contracts_changed": 0, "contracts_unavailable": 0, "signature_queries": 0}

    # ---- hydration and persistence -------------------------------------------------
    def hydrate(self, rows: Iterable[dict[str, Any]]) -> int:
        """Load stored rows; contracts stay unverified until confirmed."""
        loaded = 0
        with self._lock:
            for row in rows:
                item = KnowledgeItem.from_row(row)
                if item is None:
                    continue
                self._items[(item.kind, item.key)] = item
                loaded += 1
            self.metrics["hydrated"] += loaded
        return loaded

    def set_writer(self, writer: Callable[[list[dict[str, Any]]], None] | None) -> None:
        with self._lock:
            self._writer = writer

    def set_signature_reader(self, reader: SignatureReader | None) -> None:
        """Install the batched live-catalog signature check for stored contracts."""
        with self._lock:
            self._signatures = reader

    def drain(self) -> list[dict[str, Any]]:
        """Return pending upserts (``payload``) and deletions (``payload: None``)."""
        with self._lock:
            pending, self._dirty = self._dirty, {}
        return [
            item.to_row() if item is not None else {"kind": kind, "key": key, "fingerprint": "", "payload": None}
            for (kind, key), item in pending.items()
        ]

    def flush(self) -> None:
        with self._lock:
            writer = self._writer
            if writer is None or not self._dirty:
                return
        writer(self.drain())

    def _mark(self, kind: str, key: str, item: KnowledgeItem | None) -> None:
        self._dirty[(kind, key)] = item

    def _drop(self, kind: str, key: str) -> None:
        self._items.pop((kind, key), None)
        if kind == CONTRACT:
            self._verified.discard(key)
        self._mark(kind, key, None)

    def _expired(self, item: KnowledgeItem) -> bool:
        return self._clock() - item.recorded_at > self._ttl

    # ---- contracts ------------------------------------------------------------------
    def stored_contract_keys(self) -> list[str]:
        with self._lock:
            return sorted(key for kind, key in self._items if kind == CONTRACT)

    def contract(self, fqn: str) -> dict[str, Any] | None:
        """A contract read or confirmed against the live catalog in this claim."""
        key = normalize_fqn(fqn)
        with self._lock:
            item = self._items.get((CONTRACT, key))
            if item is None or key not in self._verified:
                self.metrics["misses"] += 1
                return None
            self.metrics["hits"] += 1
            return item.value

    def contract_fingerprint(self, fqn: str) -> str | None:
        key = normalize_fqn(fqn)
        with self._lock:
            item = self._items.get((CONTRACT, key))
            return item.fingerprint if item is not None and key in self._verified else None

    def ensure_verified(self, tables: Iterable[str], *, reader: SignatureReader | None = None) -> dict[str, list[str]]:
        """Confirm stored contracts for ``tables`` before they are used.

        Contracts confirmed within the recheck window are trusted as is; the
        rest are checked with one batched signature query through ``reader``
        (default: the installed one). Changed or no longer visible contracts
        are dropped (the caller re-reads them) with every item derived from them.
        """
        now = self._clock()
        summary: dict[str, list[str]] = {"confirmed": [], "changed": [], "unavailable": []}
        with self._lock:
            pending: list[str] = []
            for key in sorted({normalize_fqn(table) for table in tables}):
                item = self._items.get((CONTRACT, key))
                if item is None or key in self._verified:
                    continue
                if self._expired(item):
                    self._drop(CONTRACT, key)
                    self._invalidate_dependents({key})
                    continue
                if self._recheck > 0 and now - item.confirmed_at <= self._recheck:
                    self._verified.add(key)
                    self.metrics["contracts_confirmed_without_query"] += 1
                    summary["confirmed"].append(key)
                    continue
                pending.append(key)
            reader = reader or self._signatures
        if not pending or reader is None:
            return summary
        current = {normalize_fqn(key): value for key, value in reader(pending).items()}
        with self._lock:
            self.metrics["signature_queries"] += 1
            for key in pending:
                item = self._items.get((CONTRACT, key))
                if item is None:
                    continue
                if key not in current:
                    self._drop(CONTRACT, key)
                    self._invalidate_dependents({key})
                    self.metrics["contracts_unavailable"] += 1
                    summary["unavailable"].append(key)
                elif current[key] != item.fingerprint:
                    self._drop(CONTRACT, key)
                    self._invalidate_dependents({key})
                    self.metrics["contracts_changed"] += 1
                    summary["changed"].append(key)
                else:
                    item.confirmed_at = now
                    self._verified.add(key)
                    self._mark(CONTRACT, key, item)
                    self.metrics["contracts_confirmed"] += 1
                    summary["confirmed"].append(key)
        self.flush()
        return summary

    def record_contracts(self, contracts: dict[str, dict[str, Any]], *, source: str) -> list[str]:
        """Store freshly read contracts; returns keys whose fingerprint changed."""
        changed: list[str] = []
        now = self._clock()
        with self._lock:
            for fqn, contract in contracts.items():
                key = normalize_fqn(fqn)
                fingerprint = contract_fingerprint(contract)
                previous = self._items.get((CONTRACT, key))
                if previous is not None and previous.fingerprint != fingerprint:
                    changed.append(key)
                self._verified.add(key)
                item = KnowledgeItem(kind=CONTRACT, key=key, value=contract, fingerprint=fingerprint,
                                     provenance={"source": source}, run_id=self.run_id,
                                     recorded_at=now, confirmed_at=now)
                self._items[(CONTRACT, key)] = item
                self._mark(CONTRACT, key, item)
            if changed:
                self.metrics["contracts_changed"] += len(changed)
                self._invalidate_dependents(set(changed))
        self.flush()
        return changed

    def _invalidate_dependents(self, tables: set[str]) -> None:
        for (kind, key), item in list(self._items.items()):
            if kind != CONTRACT and tables & set(item.depends_on):
                self._drop(kind, key)
                self.metrics["invalidated"] += 1

    # ---- derived items --------------------------------------------------------------
    def dependencies(self, kind: str, key: str) -> list[str]:
        with self._lock:
            item = self._items.get((kind, key))
            return sorted(item.depends_on) if item is not None else []

    def _valid(self, item: KnowledgeItem) -> bool:
        if self._expired(item):
            return False
        for table, fingerprint in item.depends_on.items():
            current = self._items.get((CONTRACT, table))
            if current is None or table not in self._verified or current.fingerprint != fingerprint:
                return False
        return True

    def get(self, kind: str, key: str) -> dict[str, Any] | None:
        """A derived item, only if all its contract dependencies are verified and unchanged."""
        with self._lock:
            item = self._items.get((kind, key))
            if item is None:
                self.metrics["misses"] += 1
                return None
            if not self._valid(item):
                if self._expired(item) or any(
                    (CONTRACT, table) not in self._items for table in item.depends_on
                ):
                    self._drop(kind, key)
                    self.metrics["invalidated"] += 1
                self.metrics["misses"] += 1
                return None
            self.metrics["hits"] += 1
            return item.value

    def values(self, kind: str) -> list[tuple[str, dict[str, Any]]]:
        with self._lock:
            keys = [key for item_kind, key in self._items if item_kind == kind]
        return [(key, value) for key in keys if (value := self.get(kind, key)) is not None]

    def put(self, kind: str, key: str, value: dict[str, Any], *,
            depends_on_tables: Iterable[str] = (), provenance: dict[str, Any] | None = None) -> None:
        self.put_many(kind, [(key, value, depends_on_tables)], provenance=provenance)

    def put_many(self, kind: str, entries: Iterable[tuple[str, dict[str, Any], Iterable[str]]], *,
                 provenance: dict[str, Any] | None = None) -> None:
        """Record several derived items with one persistence flush."""
        if kind not in KINDS or kind == CONTRACT:
            raise ValueError(f"Unsupported knowledge kind: {kind}")
        now = self._clock()
        with self._lock:
            for key, value, depends_on_tables in entries:
                depends_on = {}
                for table in depends_on_tables:
                    normalized = normalize_fqn(table)
                    fingerprint = self.contract_fingerprint(normalized)
                    if fingerprint:
                        depends_on[normalized] = fingerprint
                existing = self._items.get((kind, key))
                if (existing is not None and existing.value == value and existing.depends_on == depends_on
                        and not self._expired(existing)):
                    continue
                item = KnowledgeItem(kind=kind, key=key, value=value, depends_on=depends_on,
                                     provenance=dict(provenance or {}), run_id=self.run_id, recorded_at=now)
                self._items[(kind, key)] = item
                self._mark(kind, key, item)
        self.flush()

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            counts: dict[str, int] = {}
            for kind, _ in self._items:
                counts[kind] = counts.get(kind, 0) + 1
            return {"scope": self.scope, "items": counts, "verified_contracts": len(self._verified),
                    **self.metrics}
