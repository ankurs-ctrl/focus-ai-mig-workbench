"""WS6: tiered review table, scoped follow-up child runs and lineage-owned drafts."""
from __future__ import annotations

import threading
from types import SimpleNamespace

import pytest

from app.agent_runs.review_tiers import (
    TIER_BLOCKER, TIER_CONFIDENCE, TIER_PLANNING, build_review_table, decision_key, tier_of,
)


def _firm_value_item(target: str, review_item_id: str) -> dict:
    return {"category": "mapping_candidate_review", "target_table": f"DB.T.{target}", "review_item_id": review_item_id,
            "safe_summary": f"{target}.FIRM_ID needs the firm id.", "status": "OPEN",
            "details": {"target_column": "FIRM_ID", "firm_value_name": "FIRMID"}}


def test_tiers_follow_the_plan_and_the_category() -> None:
    blocker = {"category": "source_preparation", "blocking": True}
    assert tier_of(blocker, has_plan=True) == TIER_BLOCKER
    assert tier_of(blocker, has_plan=False) == TIER_BLOCKER
    assert tier_of(_firm_value_item("CALLS", "r1"), has_plan=True) == TIER_PLANNING
    # Without a plan nothing is asked up front; it all goes to the table.
    assert tier_of(_firm_value_item("CALLS", "r1"), has_plan=False) == TIER_CONFIDENCE
    assert tier_of({"category": "mapping_tests"}, has_plan=True) == TIER_CONFIDENCE


def test_the_same_firm_value_question_across_targets_is_one_row() -> None:
    items = [_firm_value_item(name, f"r{i}") for i, name in enumerate(["CALLS", "BIZ_ACCOUNTS", "HOUSEHOLD"])]
    assert len({decision_key(item, item["target_table"].rsplit(".", 1)[-1]) for item in items}) == 1
    table = build_review_table([], items, has_plan=True)
    planning = [row for row in table["rows"] if row["tier"] == TIER_PLANNING]
    assert len(planning) == 1
    assert planning[0]["targets"] == ["CALLS", "BIZ_ACCOUNTS", "HOUSEHOLD"]
    assert planning[0]["review_item_ids"] == ["r0", "r1", "r2"]
    assert table["summary"]["planning_questions"] == 1


def test_column_rows_become_confidence_rows_sorted_by_impact_then_confidence() -> None:
    results = [{"target_table": "DB.T.CALLS", "status": "READY_FOR_REVIEW", "target_columns": ["CALL_ID", "NOTES", "OWNER"],
                "sql_validation": {"compile_valid": True, "preview_valid": True}, "mapping_rows": [
        {"target_column": "CALL_ID", "source_columns": ["S.ID"], "confidence": 0.95, "status": "draft"},
        {"target_column": "NOTES", "expression": "TRIM(S.NOTE)", "confidence": 0.55, "status": "draft",
         "mapping_classification": "derived", "confidence_reason": "One precedent only"},
        {"target_column": "OWNER", "confidence": 0, "status": "unresolved"},
    ]}, {"target_table": "DB.T.HOUSEHOLD", "status": "NEEDS_REVIEW", "mapping_rows": []}]
    blocker = {"category": "sql_repair_review", "blocking": True, "target_table": "DB.T.HOUSEHOLD",
               "safe_summary": "HOUSEHOLD SQL could not be repaired."}
    table = build_review_table(results, [blocker], has_plan=True, accept_threshold=0.8)
    rows = table["rows"]
    assert rows[0]["tier"] == TIER_BLOCKER
    assert rows[1]["column"] == "OWNER" and rows[1]["status"] == "UNRESOLVED"
    by_column = {row["column"]: row for row in rows if row.get("column")}
    assert by_column["NOTES"]["current_choice"] == "TRIM(S.NOTE)" and by_column["NOTES"]["why"] == "One precedent only"
    assert by_column["CALL_ID"]["accept_eligible"] and not by_column["NOTES"]["accept_eligible"]
    assert table["summary"] == {"targets_ready": 0, "targets": 2, "planning_questions": 0, "blockers": 1,
                                "decisions_to_confirm": 3, "checks_failed": 0, "accept_eligible": 1,
                                "actionable": 3, "informational": 1}
    assert by_column["CALL_ID"]["auto_approve_eligible"] is True


def test_batched_low_confidence_finding_replaces_duplicate_column_rows() -> None:
    result = {
        "mapping_key": "calls",
        "mapping_name": "CALLS",
        "target_table": "DB.T.CALLS",
        "sttm_id": "s1",
        "target_columns": ["SUBJECT", "COMMENTS"],
        "mapping_rows": [
            {"target_column": "SUBJECT", "source_columns": ["S.SUBJECT"], "confidence": 0.55, "status": "draft"},
            {"target_column": "COMMENTS", "source_columns": ["S.COMMENTS"], "confidence": 0.45, "status": "draft"},
        ],
        "sql_validation": {"compile_valid": True, "preview_valid": True},
    }
    batch = {
        "category": "mapping_candidate_review",
        "mapping_key": "calls",
        "mapping_name": "CALLS",
        "target_table": "DB.T.CALLS",
        "sttm_id": "s1",
        "safe_summary": "Confirm two low-confidence columns together.",
        "details": {"target_columns": ["SUBJECT", "COMMENTS"]},
    }

    table = build_review_table([result], [batch], has_plan=True, accept_threshold=0.75)

    assert [(row["column"], row["kind"]) for row in table["rows"]] == [
        ("2 uncorroborated mappings", "mapping_group"),
    ]
    assert table["rows"][0]["current_choice"] == "SUBJECT, COMMENTS"
    assert table["summary"]["actionable"] == 1


def test_validated_high_confidence_finding_becomes_one_audit_row() -> None:
    result = {
        "mapping_key": "calls",
        "mapping_name": "CALLS",
        "target_table": "DB.T.CALLS",
        "sttm_id": "s1",
        "target_columns": ["SUBJECT"],
        "mapping_rows": [
            {"target_column": "SUBJECT", "source_columns": ["S.SUBJECT"], "confidence": 0.9, "status": "draft"},
        ],
        "sql_validation": {"compile_valid": True, "preview_valid": True},
    }
    finding = {
        "category": "mapping_candidate_review",
        "mapping_key": "calls",
        "mapping_name": "CALLS",
        "target_table": "DB.T.CALLS",
        "sttm_id": "s1",
        "safe_summary": "SUBJECT is strongly corroborated.",
        "details": {"target_column": "SUBJECT", "confidence": 0.9},
    }

    table = build_review_table([result], [finding], has_plan=True, accept_threshold=0.75)

    assert len(table["rows"]) == 1
    assert table["rows"][0]["category"] == "column_mapping"
    assert table["rows"][0]["auto_approve_eligible"] is True
    assert table["summary"]["actionable"] == 0


def _handlers(snapshot_rows, draft_run_id="parent-run"):
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers

    handler = object.__new__(WorkbenchWorkflowHandlers)
    handler._domain_lock = threading.RLock()
    handler._projects = SimpleNamespace(get_sttm_detail=lambda _sttm_id: SimpleNamespace(
        sttm=SimpleNamespace(metadata={"migration_run_id": draft_run_id}),
        latest_snapshot={"mapping_rows": snapshot_rows}))
    handler._describe_table = lambda _table: {"columns": ["CALL_ID", "NOTES", "OWNER"]}
    handler._repository = SimpleNamespace(list_dag_nodes=lambda _run_id: [])
    return handler


def _state(target_columns, parent="parent-run"):
    return {"run_id": "child-run", "parent_run_id": parent, "run_lineage": ["child-run", parent] if parent else ["child-run"],
            "project_id": "p1", "approved_plan_hash": "h",
            "manifest": [{"mapping_key": "calls", "target_table": "DB.T.CALLS", "sttm_id": "s1"}],
            "migration_plan": {"mapping_specs": [{"mapping_key": "calls", "auto_map": {"target_columns": target_columns}}]}}


_GRID_ROWS = [
    {"target_column": "CALL_ID", "source_columns": ["S.ID"], "status": "MAPPED", "review_status": "draft",
     "mapping_mode": "source", "rule": "Direct", "transformation_classification": "direct"},
    {"target_column": "NOTES", "expression": "TRIM(S.NOTE)", "status": "MAPPED", "review_status": "draft"},
    {"target_column": "OWNER", "status": "UNMAPPED", "review_status": "unresolved"},
]


def test_a_scoped_follow_up_keeps_parent_rows_and_maps_only_the_named_columns() -> None:
    handler = _handlers(_GRID_ROWS)
    partitions = handler.build_partitions(_state(["OWNER"]))
    by_id = {partition.partition_id: partition for partition in partitions}
    carried = by_id["calls:map:carried"]
    assert carried.state.value == "COMPLETED" and carried.columns == ["CALL_ID", "NOTES"]
    assert [row["status"] for row in carried.result["mapping_rows"]] == ["draft", "draft"]
    assert carried.result["mapped_target_columns"] == ["CALL_ID", "NOTES"]
    mapped = [p for p in partitions if p.stage == "map" and p.partition_id != "calls:map:carried"]
    assert [column for p in mapped for column in p.columns] == ["OWNER"]
    assert "calls:map:carried" in by_id["calls:compile"].waits_for
    from app.migration_workflow.scheduler import merge_column_partitions
    carried_only = merge_column_partitions([carried])
    assert [row["target_column"] for row in carried_only] == ["CALL_ID", "NOTES"]


@pytest.mark.parametrize("target_columns,parent,draft_run", [
    (["CALL_ID", "NOTES", "OWNER"], "parent-run", "parent-run"),  # full scope: re-map everything
    ([], "parent-run", "parent-run"),                            # no column scope
    (["OWNER"], "", "parent-run"),                               # not a follow-up
    (["OWNER"], "parent-run", "someone-elses-run"),              # draft outside the lineage
])
def test_no_rows_are_carried_outside_a_scoped_owned_follow_up(target_columns, parent, draft_run) -> None:
    partitions = _handlers(_GRID_ROWS, draft_run_id=draft_run).build_partitions(_state(target_columns, parent))
    assert not any(p.partition_id.endswith(":carried") for p in partitions)
    assert sorted(c for p in partitions if p.stage == "map" for c in p.columns) == ["CALL_ID", "NOTES", "OWNER"]


def test_a_column_missing_from_the_parent_draft_is_re_mapped() -> None:
    partitions = _handlers(_GRID_ROWS[:1]).build_partitions(_state(["OWNER"]))
    carried = next(p for p in partitions if p.partition_id.endswith(":carried"))
    assert carried.columns == ["CALL_ID"]
    assert sorted(c for p in partitions if p.stage == "map" and p is not carried for c in p.columns) == ["NOTES", "OWNER"]


def _run(run_id, parent=None, user="u1"):
    return SimpleNamespace(run_id=run_id, request=SimpleNamespace(parent_run_id=parent),
                           actor=SimpleNamespace(user_id=user, tenant_id="t"))


def test_lineage_stops_at_a_run_owned_by_someone_else() -> None:
    from app.agent_runs.service import AgentRunService

    runs = {"r2": _run("r2", "r1"), "r1": _run("r1", "r0", user="other"), "r0": _run("r0")}
    service = object.__new__(AgentRunService)
    service.repository = SimpleNamespace(get_run=lambda run_id: runs.get(run_id))
    assert service._run_lineage(_run("r3", "r2")) == ["r3", "r2"]
    runs["r1"] = _run("r1", "r0")
    assert service._run_lineage(_run("r3", "r2")) == ["r3", "r2", "r1", "r0"]


def test_the_draft_writer_accepts_the_lineage_and_rejects_other_runs(monkeypatch) -> None:
    import app.agent_runs.review_apply as review_apply

    detail = SimpleNamespace(sttm=SimpleNamespace(metadata={"migration_run_id": "parent-run"}, project_id="p1"),
                             latest_snapshot={"mapping_rows": []})
    saved = []

    class _Projects:
        def __init__(self, **_kwargs):
            pass

        def get_sttm_detail(self, _sttm_id):
            return detail

        def list_project_attributes(self, _project_id):
            return []

        def autosave_sttm(self, sttm_id, request, user_id):
            saved.append(sttm_id)
            return SimpleNamespace(snapshot_id="snap")

    monkeypatch.setattr("app.core.project_service.ProjectService", _Projects)
    monkeypatch.setattr(review_apply, "apply_review_choice", lambda snapshot, *_a, **_k: snapshot)
    write = review_apply.make_draft_writer(session=None, settings=None)
    kwargs = dict(sttm_id="s1", target_column="OWNER", candidate={"source_columns": ["S.OWNER"]},
                  actor=SimpleNamespace(user_id="u1"))
    with pytest.raises(PermissionError):
        write(run=SimpleNamespace(run_id="child-run"), **kwargs)
    assert write(run=SimpleNamespace(run_id="child-run"), lineage=["child-run", "parent-run"], **kwargs)["sttm_id"] == "s1"
    assert saved == ["s1"]


def test_review_table_auto_approves_validated_high_confidence_rows() -> None:
    from app.agent_runs.models import AgentActor, MappingDagNode, RunCreateRequest
    from app.agent_runs.repository import InMemoryAgentRunRepository
    from app.agent_runs.service import AgentRunService, RunAuthorizationError

    repository = InMemoryAgentRunRepository()
    service = AgentRunService(repository)
    owner = AgentActor(user_id="u1", tenant_id="t", effective_role="R")
    run = service.create_run(RunCreateRequest(prompt="Map CALLS"), owner)
    repository.save_dag_node(MappingDagNode(
        node_id="n1", run_id=run.run_id, mapping_key="calls:compile", mapping_name="CALLS", plan_hash="h",
        partition_payload={"result": {"target_table": "DB.T.CALLS", "status": "READY_FOR_REVIEW", "sttm_id": "s1",
                                      "mapping_rows": [
                                          {"target_column": "CALL_ID", "source_columns": ["S.ID"], "confidence": 0.95,
                                           "status": "draft"},
                                          {"target_column": "SUBJECT", "source_columns": ["S.SUBJECT"], "confidence": 0.55,
                                           "status": "draft"},
                                          {"target_column": "OWNER", "confidence": 0, "status": "unresolved"}],
                                      "target_columns": ["CALL_ID", "SUBJECT", "OWNER"],
                                      "sql_validation": {"compile_valid": True, "preview_valid": True},
                                      "review_items": []}}))
    table = service.review_table(run.run_id, owner)
    rows = {row["column"]: row for row in table["rows"]}
    assert table["summary"]["accept_eligible"] == 0
    assert table["summary"]["auto_approved"] == 1
    assert rows["CALL_ID"]["status"] == "AUTO_APPROVED"
    result = service.accept_review_rows(run.run_id, [rows["CALL_ID"]["row_id"], rows["SUBJECT"]["row_id"],
                                                     rows["OWNER"]["row_id"]], owner)
    assert result["accepted"] == []
    assert result["skipped"] == [rows["CALL_ID"]["row_id"], rows["SUBJECT"]["row_id"], rows["OWNER"]["row_id"]]
    after = {row["column"]: row for row in service.review_table(run.run_id, owner)["rows"]}
    assert after["CALL_ID"]["status"] == "AUTO_APPROVED" and after["OWNER"]["status"] == "UNRESOLVED"
    with pytest.raises(RunAuthorizationError):
        service.review_table(run.run_id, AgentActor(user_id="u2", tenant_id="t", effective_role="R"))


def test_review_items_with_the_same_column_on_different_targets_are_preserved() -> None:
    from app.agent_runs.models import AgentActor, AgentReviewItem, MappingDagNode, RunCreateRequest
    from app.agent_runs.repository import InMemoryAgentRunRepository
    from app.agent_runs.service import AgentRunService

    repository = InMemoryAgentRunRepository()
    service = AgentRunService(repository)
    owner = AgentActor(user_id="u1", tenant_id="t", effective_role="R")
    run = service.create_run(RunCreateRequest(prompt="Map targets"), owner)
    for target, sttm_id in (("CALLS", "s1"), ("TASKS", "s2")):
        finding = {"category": "mapping_candidate_review", "safe_summary": f"{target}.OWNERID needs review",
                   "details": {"target_column": "OWNERID", "candidates": []}}
        repository.save_review_item(AgentReviewItem(
            review_item_id=f"r-{target}", run_id=run.run_id, sttm_id=sttm_id,
            category="mapping_candidate_review", safe_summary=finding["safe_summary"],
            subject_keys=["OWNERID"],
        ))
        repository.save_dag_node(MappingDagNode(
            node_id=f"n-{target}", run_id=run.run_id, mapping_key=f"{target.lower()}:compile",
            mapping_name=target, target_table=f"DB.T.{target}", sttm_id=sttm_id, plan_hash="h",
            partition_payload={"result": {"target_table": f"DB.T.{target}", "sttm_id": sttm_id,
                                           "mapping_rows": [], "review_items": [finding]}},
        ))

    items = service._review_items_for_run(run.run_id)
    assert {(item.sttm_id, item.subject_keys[0]) for item in items} == {("s1", "OWNERID"), ("s2", "OWNERID")}


def test_mapping_choices_use_structured_confidence_not_label_text() -> None:
    from app.agent_runs.service import AgentRunService

    [choice, unresolved] = AgentRunService._mapping_review_choices([
        {"source_columns": ["S.ID"], "confidence": 0.82, "reason": "Verified current contract"},
    ])
    assert choice.label == "S.ID"
    assert choice.confidence == 0.82
    assert unresolved.confidence is None


def test_summary_requires_nonempty_complete_rows_and_uses_manifest_target_count() -> None:
    results = [{"target_table": "DB.T.BIZ_CONTACTS", "status": "NEEDS_REVIEW", "mapping_rows": [],
                "target_columns": ["ID"], "sql_validation": {"compile_valid": True, "preview_valid": True}},
               {"target_table": "DB.T.CALLS", "status": "NEEDS_REVIEW", "mapping_rows": [],
                "sql_validation": {"compile_valid": False}}]
    notes = [{"category": "population_rule_review", "target_table": "DB.T.BIZ_CONTACTS", "review_item_id": "r1",
              "safe_summary": "BIZ_CONTACTS: CONTACTS flags deleted records; only live ones are loaded."},
             {"category": "population_rule_review", "review_item_id": "r2",
              "safe_summary": "PERSONACCOUNT: CONTACTS flags deleted records; only live ones are loaded."}]
    table = build_review_table(results, notes, has_plan=True, target_count=8)
    assert table["summary"]["targets_ready"] == 0 and table["summary"]["targets"] == 8
    planning = [row for row in table["rows"] if row["tier"] == TIER_PLANNING]
    assert len(planning) == 1 and planning[0]["targets"] == ["BIZ_CONTACTS", "PERSONACCOUNT"]


def test_summary_counts_a_complete_validated_target_once() -> None:
    rows = [{"target_column": "ID", "source_columns": ["S.ID"], "status": "draft", "confidence": 0.9}]
    results = [
        {"target_table": "DB.T.CALLS", "status": "READY_FOR_REVIEW", "target_columns": ["ID"],
         "mapping_rows": rows, "sql_validation": {"compile_valid": True, "preview_valid": True}},
        {"target_table": "DB.T.CALLS", "status": "READY_FOR_REVIEW", "target_columns": ["ID"],
         "mapping_rows": rows, "sql_validation": {"compile_valid": True, "preview_valid": True}},
    ]
    table = build_review_table(results, [], has_plan=True, target_count=1)
    assert table["summary"]["targets_ready"] == 1
    assert table["summary"]["targets"] == 1
