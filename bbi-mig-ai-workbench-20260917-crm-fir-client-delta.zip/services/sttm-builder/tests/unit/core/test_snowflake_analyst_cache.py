import pytest

from app.core import snowflake_analyst as module
from app.core.exceptions import SnowflakeAgentError
from app.core.snowflake_analyst import SnowflakeAnalystClient


class _Response:
    status_code = 200
    text = "ok"

    def json(self):
        return {
            "request_id": "request-1",
            "message": {
                "content": [
                    {"type": "text", "text": "Ready"},
                    {"type": "sql", "statement": "SELECT 1"},
                ]
            },
        }


class _HttpClient:
    def __init__(self):
        self.calls = 0

    def post(self, *_args, **_kwargs):
        self.calls += 1
        return _Response()


def test_identical_analyst_requests_reuse_authorization_scoped_cache(monkeypatch) -> None:
    http = _HttpClient()
    monkeypatch.setattr(module, "_shared_http_client", lambda _base_url: http)
    module._ANALYST_CACHE.clear()
    module._ANALYST_IN_FLIGHT.clear()
    module._ANALYST_FAILURES.clear()
    client = SnowflakeAnalystClient(
        "delegated-token",
        host="account.snowflakecomputing.com",
        role="MIGRATION_ROLE",
        warehouse="AGENT_WH",
    )

    first = client.ask(question="Build household CTE", semantic_model_yaml="name: bundle")
    second = client.ask(question="Build household CTE", semantic_model_yaml="name: bundle")

    assert http.calls == 1
    assert first.response_metadata["cache_source"] == "fresh"
    assert second.response_metadata["cache_source"] == "memory"
    assert second.sql == "SELECT 1"


def test_analyst_cache_is_scoped_to_delegated_credential(monkeypatch) -> None:
    http = _HttpClient()
    monkeypatch.setattr(module, "_shared_http_client", lambda _base_url: http)
    module._ANALYST_CACHE.clear()
    module._ANALYST_IN_FLIGHT.clear()
    module._ANALYST_FAILURES.clear()
    first = SnowflakeAnalystClient("token-a", host="account.snowflakecomputing.com")
    second = SnowflakeAnalystClient("token-b", host="account.snowflakecomputing.com")

    first.ask(question="Question", semantic_model_yaml="name: bundle")
    second.ask(question="Question", semantic_model_yaml="name: bundle")

    assert http.calls == 2


def test_deterministic_analyst_failure_is_not_retried(monkeypatch) -> None:
    class _BadRequest(_Response):
        status_code = 400
        text = "invalid semantic relationship"

    class _BadClient(_HttpClient):
        def post(self, *_args, **_kwargs):
            self.calls += 1
            return _BadRequest()

    http = _BadClient()
    monkeypatch.setattr(module, "_shared_http_client", lambda _base_url: http)
    module._ANALYST_CACHE.clear()
    module._ANALYST_IN_FLIGHT.clear()
    module._ANALYST_FAILURES.clear()
    client = SnowflakeAnalystClient("token", host="account.snowflakecomputing.com")

    with pytest.raises(SnowflakeAgentError, match="invalid semantic relationship"):
        client.ask(question="Question", semantic_model_yaml="name: invalid")
    with pytest.raises(SnowflakeAgentError, match="invalid semantic relationship"):
        client.ask(question="Question", semantic_model_yaml="name: invalid")

    assert http.calls == 1
