# Validation — confidence and custom-rule generation

## Confirmed defects corrected

- The internal model-envelope conversion omitted request metadata, including the new draft-policy marker. Private context planning could therefore retain legacy quote-review and binding behavior even on newly deployed code. The new rules-v2 protocol explicitly carries its backend-owned marker into private planning.
- The source-response normalizer dropped rule_intent/decision_basis and the transformation normalizer dropped candidate identity. Those boundaries now preserve the necessary handoff fields; model output cannot manufacture backend admission or completion receipts.
- Custom routing depended on classification labels and source-column presence. New runs route actual custom intent/expressions, including Firm-Value-only expressions, while direct and Value assignments skip the specialist.
- Missing/malformed model confidence survived as unknown. Agents now have strict confidence instructions and response examples; backend evidence scoring supplies a fallback and preserves model attribution. Frontend revalidation preserves that estimate and recomputes caps from the uncapped base.
- JSON null was indistinguishable from an absent constant even when the target explicitly specified SQL NULL. New source-output normalization converts it only with explicit target/FIR support; ordinary missing constants remain missing.
- Final candidate selection could lose per-target route/completion metadata, and equivalent Value ID normalization could invalidate an unchanged rule receipt. Receipts now preserve canonical Value identity and include the current graph/Values/intent context.

## Local checks

- Broad core run: 3,933 passed, 31 skipped, two failures involving legacy test request fixtures without metadata. The compatibility guard was corrected and those modules passed in subsequent focused runs. This is not described as a clean rerun of the entire core suite.
- Combined worker/handoff/scoring/FIR/runtime/durable/publication/real SQL-upload regression: 358 passed.
- Final follow-up routing/transformation/compatibility selection: 136 passed.
- Additional focused runs cover partial specialist results followed by a failed repair, exact candidate identity, unchanged-rule reuse, changed Firm Values, direct/Value/constant routes, missing and malformed confidence, model score zero, intentional NULL, new-policy admission and legacy compatibility.
- Frontend candidate suite: 79 passed. Mapping/status/navigation: 44 passed, including calculated confidence after failed and successful revalidation. SQL-upload workflow assertions passed.
- TypeScript, agent-spec manifest and whitespace checks passed. No dependency lockfiles or environment files changed.

## Native Snowflake acceptance

NATIVE-ACCEPTANCE.json contains the real guarded test-account result:

- Five targets: direct ID, FIR-based column-plus-Firm-Value expression, direct Firm Value, Value-only CASE, and intentional SQL NULL.
- All returned output rows matched the expected fixture values.
- Every target had positive numeric confidence: ID 0.95, DISPLAY_NAME 0.90, FIRM_VALUE 0.95, VALUE_CASE 0.70, OWNERNAME 0.79.
- The persisted controlled FIR recipe was cited by DISPLAY_NAME (`accept_exact_precedent`). It is a validated-mapping fixture, not a client publication or a fabricated client learning.
- Both custom targets completed in one actual transformation-model submission. Three actual model submissions occurred overall. Direct/Value/NULL targets bypassed the specialist.
- No execution slots remained occupied, legacy quarantine fixture records were preserved, and the scratch schema was cleaned up.
- Measured model/execution interval: 277.61 seconds. This establishes behavior within the existing allowance; it does not establish low latency in the client environment.

Earlier mixed-test attempts exposed an incomplete test Value authorization flag and an identity-only test message conflicting with custom target contracts. A subsequent attempt returned correct SQL values but failed NULL confidence/route assertions; those defects were corrected before the passing run. Passing output was not inferred from deployment readiness.

## Limits

No client UAT deployment, existing mapping changes, environment changes, account setting changes or client FIR backfill were performed. The specific client job was not accessible. Live publish-to-reuse and SPCS/browser acceptance remain unverified; publication and SQL-upload regressions use the real local parser/importer/compiler/validator with controlled SQL transport. Confidence estimates are policy scores, not calibrated probabilities or business approval. Provider/model failures may still leave explicitly deferred drafts. Performance should be measured on client target inventories after deployment.
