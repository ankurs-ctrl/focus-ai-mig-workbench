'use client';

import Link from 'next/link';
import React, { useCallback, useState } from 'react';
import ReactMarkdown, { type Components } from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { AiaBox, AiaIconButton } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import { SqlHighlight } from '@/components/sql';
import { formatSqlForDisplay } from '@/components/sql/format-sql';
import { CheckIcon, ContentCopyRoundedIcon, WrapTextRoundedIcon } from '@/utils/icons';

/**
 * GitHub-flavoured markdown for assistant answers (react-markdown + remark-gfm).
 *
 * Raw HTML in model output is never rendered (no rehype-raw), and react-markdown's
 * default URL transform drops unsafe schemes such as javascript:. SQL fences use the
 * workbench SQL highlighter with a copy button; an unterminated fence renders as code,
 * which keeps a streaming answer stable until the closing fence arrives.
 */

const MONO = 'var(--font-mono, ui-monospace, SFMono-Regular, Menlo, monospace)';

function textOf(node: React.ReactNode): string {
  if (typeof node === 'string' || typeof node === 'number') return String(node);
  if (Array.isArray(node)) return node.map(textOf).join('');
  if (React.isValidElement<{ children?: React.ReactNode }>(node)) return textOf(node.props.children);
  return '';
}

function CodeBlock({ code: sourceCode, language }: { code: string; language: string }) {
  const [copied, setCopied] = useState(false);
  const [wrapped, setWrapped] = useState(false);
  const isSql =
    /^(sql|snowflake|snowsql)$/i.test(language) ||
    (!language && /^\s*(select|with|insert|update|merge|create)\b/i.test(sourceCode));
  const code = isSql ? formatSqlForDisplay(sourceCode) : sourceCode;
  const copy = useCallback(() => {
    if (typeof navigator === 'undefined' || !navigator.clipboard) return;
    void navigator.clipboard.writeText(code).then(() => {
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1500);
    });
  }, [code]);
  return (
    <AiaBox sx={{ borderRadius: 1.5, overflow: 'hidden', border: '1px solid #1e293b', bgcolor: '#0f172a', minWidth: 0 }}>
      <AiaBox sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', px: 1.25, py: 0.25, bgcolor: '#111827', borderBottom: '1px solid #1e293b' }}>
        <AiaText sx={{ fontSize: 11, color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
          {isSql ? 'sql' : language || 'code'}
        </AiaText>
        <AiaBox sx={{ display: 'flex', alignItems: 'center', gap: 0.25 }}>
          <AiaIconButton
            size="small"
            aria-label={wrapped ? 'Disable wrapping' : 'Wrap long lines'}
            onClick={() => setWrapped((value) => !value)}
            sx={{ color: wrapped ? '#60a5fa' : '#cbd5e1', p: 0.5 }}
          >
            <WrapTextRoundedIcon sx={{ fontSize: 15 }} />
          </AiaIconButton>
          <AiaIconButton size="small" aria-label={copied ? 'Copied' : 'Copy code'} onClick={copy} sx={{ color: '#cbd5e1', p: 0.5 }}>
            {copied ? <CheckIcon sx={{ fontSize: 15 }} /> : <ContentCopyRoundedIcon sx={{ fontSize: 15 }} />}
          </AiaIconButton>
        </AiaBox>
      </AiaBox>
      <AiaBox
        component="pre"
        sx={{
          m: 0,
          px: 1.5,
          py: 1.25,
          fontSize: 12,
          lineHeight: 1.6,
          overflowX: wrapped ? 'hidden' : 'auto',
          whiteSpace: wrapped ? 'pre-wrap' : 'pre',
          wordBreak: wrapped ? 'break-word' : 'normal',
          color: '#e5e7eb',
          fontFamily: MONO,
        }}
      >
        <code>{isSql ? <SqlHighlight text={code} /> : code}</code>
      </AiaBox>
    </AiaBox>
  );
}

const cellSx = { px: 1, py: 0.75, borderBottom: '1px solid #e2e8f0', color: '#334155', verticalAlign: 'top' } as const;

const TableWrapContext = React.createContext(false);

function TableBlock({ children }: { children: React.ReactNode }) {
  const [wrapped, setWrapped] = useState(false);
  return (
    <AiaBox sx={{ display: 'grid', gap: 0.25, minWidth: 0 }}>
      <AiaBox sx={{ display: 'flex', justifyContent: 'flex-end' }}>
        <AiaIconButton
          size="small"
          aria-label={wrapped ? 'Disable wrapping' : 'Wrap table to fit'}
          onClick={() => setWrapped((value) => !value)}
          sx={{ color: wrapped ? '#1d4ed8' : '#94a3b8', p: 0.25 }}
        >
          <WrapTextRoundedIcon sx={{ fontSize: 15 }} />
        </AiaIconButton>
      </AiaBox>
      <AiaBox sx={{ overflowX: wrapped ? 'hidden' : 'auto', maxWidth: '100%', border: '1px solid #e2e8f0', borderRadius: 1.5 }}>
        <TableWrapContext.Provider value={wrapped}>
          <AiaBox
            component="table"
            sx={{ width: '100%', borderCollapse: 'collapse', fontSize: 13, tableLayout: wrapped ? 'fixed' : 'auto' }}
          >
            {children}
          </AiaBox>
        </TableWrapContext.Provider>
      </AiaBox>
    </AiaBox>
  );
}

function TableHeaderCell({ children, style }: { children?: React.ReactNode; style?: React.CSSProperties }) {
  const wrapped = React.useContext(TableWrapContext);
  return (
    <AiaBox
      component="th"
      sx={{
        ...cellSx,
        textAlign: style?.textAlign ?? 'left',
        borderBottom: '1px solid #cbd5e1',
        fontWeight: 800,
        color: '#0f172a',
        whiteSpace: wrapped ? 'normal' : 'nowrap',
        wordBreak: wrapped ? 'break-word' : 'normal',
      }}
    >
      {children}
    </AiaBox>
  );
}

function TableDataCell({ children, style }: { children?: React.ReactNode; style?: React.CSSProperties }) {
  const wrapped = React.useContext(TableWrapContext);
  return (
    <AiaBox
      component="td"
      sx={{
        ...cellSx,
        textAlign: style?.textAlign ?? 'left',
        whiteSpace: wrapped ? 'normal' : 'nowrap',
        wordBreak: wrapped ? 'break-word' : 'normal',
      }}
    >
      {children}
    </AiaBox>
  );
}

const COMPONENTS: Components = {
  h1: ({ children }) => <AiaText component="h3" sx={{ m: 0, fontSize: 19, lineHeight: 1.3, fontWeight: 800, color: '#0f172a' }}>{children}</AiaText>,
  h2: ({ children }) => <AiaText component="h4" sx={{ mt: 1, mb: 0, pb: 0.75, borderBottom: '1px solid #e2e8f0', fontSize: 16, lineHeight: 1.35, fontWeight: 800, color: '#0f172a' }}>{children}</AiaText>,
  h3: ({ children }) => <AiaText component="h5" sx={{ m: 0, fontSize: 13, lineHeight: 1.4, letterSpacing: '0.045em', textTransform: 'uppercase', fontWeight: 800, color: '#0f172a' }}>{children}</AiaText>,
  h4: ({ children }) => <AiaText component="h6" sx={{ m: 0, fontSize: 13.5, fontWeight: 800, color: '#0f172a' }}>{children}</AiaText>,
  p: ({ children }) => (
    <AiaText component="p" sx={{ m: 0, minWidth: 0, fontSize: 13.5, lineHeight: 1.7, color: '#334155', overflowWrap: 'anywhere', wordBreak: 'break-word' }}>
      {children}
    </AiaText>
  ),
  em: ({ children }) => <AiaBox component="em" sx={{ fontStyle: 'italic', color: '#475569' }}>{children}</AiaBox>,
  strong: ({ children }) => <AiaBox component="strong" sx={{ fontWeight: 800, color: '#0f172a' }}>{children}</AiaBox>,
  // The default URL transform blanks unsafe schemes; show those as plain text.
  a: ({ href, children }) =>
    href && /^\/sttm\/builder\/[^/?#]+\/mapping\?/.test(href) ? (
      <Link href={href} onClick={() => {
        const params = new URL(href, window.location.origin).searchParams;
        window.dispatchEvent(new CustomEvent('sttm:review-row', {detail:{mappingId:params.get('reviewRow'),section:params.get('reviewSection')}}));
      }} style={{color:'#1d4ed8',textDecoration:'underline'}}>{children}</Link>
    ) : href ? (
      <AiaBox component="a" href={href} target="_blank" rel="noopener noreferrer" sx={{ color: '#1d4ed8', textDecoration: 'underline' }}>
        {children}
      </AiaBox>
    ) : (
      <>{children}</>
    ),
  ul: ({ children }) => <AiaBox component="ul" sx={{ pl: 2.5, my: 0, display: 'grid', gap: 0.55, listStyleType: 'disc', color: '#334155', '& ::marker': { color: 'var(--aia-button-color)' } }}>{children}</AiaBox>,
  ol: ({ children, start }) => (
    <AiaBox component="ol" start={start} sx={{ pl: 2.75, my: 0, display: 'grid', gap: 0.55, listStyleType: 'decimal', color: '#334155', '& ::marker': { color: 'var(--aia-button-color)', fontWeight: 700 } }}>{children}</AiaBox>
  ),
  li: ({ children }) => <AiaBox component="li" sx={{ pl: 0.25, fontSize: 13.5, lineHeight: 1.65, '& > p': { my: 0 } }}>{children}</AiaBox>,
  blockquote: ({ children }) => (
    <AiaBox component="blockquote" sx={{ m: 0, px: 1.5, py: 1, borderLeft: '3px solid var(--aia-button-color)', borderRadius: '0 8px 8px 0', bgcolor: '#f8fafc', color: '#475569', display: 'grid', gap: 0.75 }}>
      {children}
    </AiaBox>
  ),
  hr: () => <AiaBox component="hr" sx={{ border: 0, borderTop: '1px solid #e2e8f0', my: 0.5, width: '100%' }} />,
  table: ({ children }) => <TableBlock>{children}</TableBlock>,
  thead: ({ children }) => <AiaBox component="thead" sx={{ bgcolor: '#f8fafc' }}>{children}</AiaBox>,
  th: TableHeaderCell,
  td: TableDataCell,
  // Fenced blocks arrive as <pre><code class="language-x">; inline code has no <pre>.
  pre: ({ children }) => {
    const child = React.Children.toArray(children)[0];
    const className = React.isValidElement<{ className?: string }>(child) ? child.props.className ?? '' : '';
    const language = /language-([\w+-]+)/.exec(className)?.[1] ?? '';
    return <CodeBlock code={textOf(children).replace(/\n$/, '')} language={language} />;
  },
  code: ({ children }) => (
    <AiaBox component="code" sx={{ px: 0.5, py: 0.1, borderRadius: 0.75, bgcolor: '#eef2f7', color: '#0f172a', fontSize: '0.92em', fontFamily: MONO }}>
      {children}
    </AiaBox>
  ),
};

const REMARK_PLUGINS = [remarkGfm];

export function AssistantMarkdown({ content }: { content: string }) {
  return (
    <AiaBox sx={{ display: 'grid', gap: 1.25, minWidth: 0, maxWidth: '100%', overflowX: 'hidden', overflowWrap: 'anywhere', wordBreak: 'break-word' }}>
      <ReactMarkdown remarkPlugins={REMARK_PLUGINS} components={COMPONENTS}>
        {content.trim()}
      </ReactMarkdown>
    </AiaBox>
  );
}
