"""Firm values in agent mappings.

A firm value (project value, ``TBL_PROJECT_ATTRIBUTES``) is a named constant
that belongs to one project: the transaction firm's CRM ID, a record type, a
legacy ID prefix. Mapping rows bind to one instead of a source column, either
as the whole column (``mapping_mode`` ``attribute`` with ``attribute_name``) or
inside a rule (``$LegacyHHcPrefix || CONTACTS.ID``).

Earlier mappings record those bindings, and they are how the agent learns
which target columns take a firm value and in what shape:

* ``value``    the column is the firm value itself;
* ``prefix``   the firm value is prepended to a source identifier;
* ``fallback`` the firm value fills in when the source is empty;
* ``rule``     any other rule that uses it (passed to the specialists only).

Values differ per firm, so a value is never copied from another project on
the agent's own authority: a value the current project holds is used; one the
user states (request or attachment) is created; otherwise the reviewer picks
one of the known values or types their own.
"""
from __future__ import annotations

import re
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Iterable

from app.agent_runs.value_bindings import valid_typed_project_value

_TOKEN = re.compile(r"\$([A-Za-z_][A-Za-z0-9_]*)")
_WHOLE = re.compile(r"\s*\$([A-Za-z_][A-Za-z0-9_]*)\s*")
_PREFIX = re.compile(r"\s*\$([A-Za-z_][A-Za-z0-9_]*)\s*\|\|\s*(.+?)\s*", re.S)
_FALLBACK = re.compile(r"\s*(?:COALESCE|IFNULL|NVL)\s*\(\s*(.+?)\s*,\s*\$([A-Za-z_][A-Za-z0-9_]*)\s*\)\s*", re.I | re.S)
# Imported values sometimes carry a pasted script (``...'; SET X = ...``).
_SCRIPT_FRAGMENT = re.compile(r"(?i)(?:';|\bSET\s+[A-Za-z_]+\s*=|--|/\*)")
_MAX_VALUE_LENGTH = 255


def norm(value: Any) -> str:
    """Letters and digits only, upper case: ``Transaction_Firm__c`` -> ``TRANSACTIONFIRMC``."""
    return re.sub(r"[^A-Z0-9]", "", str(value or "").upper())


def names_in(expression: str | None) -> list[str]:
    """Firm value names a rule references, in order of first use."""
    seen: list[str] = []
    for name in _TOKEN.findall(str(expression or "")):
        if name not in seen:
            seen.append(name)
    return seen


def usable_value(value: Any, data_type: str | None) -> bool:
    """A stored value that can be offered or compiled as it is."""
    text = str(value if value is not None else "").strip()
    if not text or len(text) > _MAX_VALUE_LENGTH or _SCRIPT_FRAGMENT.search(text):
        return False
    return valid_typed_project_value(text, data_type) or text.upper() == "NULL"


@dataclass(frozen=True)
class Usage:
    """One earlier mapping row that binds a target column to a firm value."""
    target_column: str
    name: str
    shape: str
    project_id: str
    project_name: str
    sttm_id: str
    published: bool


def usages_from_rows(rows: Iterable[dict[str, Any]]) -> list[Usage]:
    """Classify earlier rows (``ProjectService.firm_value_usages``) by shape."""
    usages: list[Usage] = []
    for row in rows:
        column = str(row.get("TARGET_COLUMN") or "")
        mode = str(row.get("MAPPING_MODE") or "").lower()
        expression = str(row.get("EXPRESSION") or "")
        constant = str(row.get("CONSTANT_VALUE") or "")
        name, shape = None, None
        if mode == "attribute" and row.get("ATTRIBUTE_NAME"):
            name, shape = str(row["ATTRIBUTE_NAME"]), "value"
        elif (match := _WHOLE.fullmatch(expression) or _WHOLE.fullmatch(constant)):
            name, shape = match.group(1), "value"
        elif (match := _PREFIX.fullmatch(expression)) and not names_in(match.group(2)):
            name, shape = match.group(1), "prefix"
        elif (match := _FALLBACK.fullmatch(expression)) and not names_in(match.group(1)):
            name, shape = match.group(2), "fallback"
        elif len(found := names_in(expression)) == 1:
            name, shape = found[0], "rule"
        if not column or not name:
            continue
        usages.append(Usage(
            target_column=column, name=name, shape=shape, project_id=str(row.get("PROJECT_ID") or ""),
            project_name=str(row.get("PROJECT_NAME") or ""), sttm_id=str(row.get("STTM_ID") or ""),
            published=str(row.get("STATUS") or "").upper() in {"PUBLISHED", "COMPLETE"},
        ))
    return usages


@dataclass
class Choice:
    """The firm value earlier mappings bind a target column to."""
    target_column: str
    name: str
    shape: str
    support: int
    sttm_ids: list[str] = field(default_factory=list)
    projects: list[str] = field(default_factory=list)
    origin: str = "mappings"

    @property
    def reason(self) -> str:
        if self.origin == "catalog":
            return (f"The firm-value catalogue sets {self.target_column} "
                    f"{_SHAPE_TEXT[self.shape]} firm value {self.name}.")
        where = ", ".join(self.projects[:3]) or "earlier projects"
        return (f"{self.support} earlier mapping(s) ({where}) set {self.target_column} "
                f"{_SHAPE_TEXT[self.shape]} firm value {self.name}.")

    @property
    def evidence_ids(self) -> list[str]:
        return [f"sttm_precedent:{value}" for value in self.sttm_ids[:5]]


_SHAPE_TEXT = {
    "value": "to",
    "prefix": "to a source ID prefixed with",
    "fallback": "to its source, falling back to",
    "rule": "with a rule that uses",
}


def choose(target_columns: Iterable[str], usages: Iterable[Usage], current_names: Iterable[str], *,
           min_support: int = 1) -> dict[str, Choice]:
    """The best-supported firm value for each target column earlier mappings bind.

    A name the current project already holds ranks first; then the number of
    distinct earlier mappings, then how many of them are published.
    """
    held = {norm(name) for name in current_names}
    by_column: dict[str, list[Usage]] = defaultdict(list)
    for usage in usages:
        by_column[norm(usage.target_column)].append(usage)
    choices: dict[str, Choice] = {}
    for column in target_columns:
        grouped: dict[tuple[str, str], list[Usage]] = defaultdict(list)
        for usage in by_column.get(norm(column), []):
            grouped[(norm(usage.name), usage.shape)].append(usage)
        ranked = []
        for (key, shape), items in grouped.items():
            sttms = sorted({item.sttm_id for item in items}, reverse=True)
            if len(sttms) < min_support:
                continue
            spelling = max({item.name for item in items}, key=lambda value: sum(i.name == value for i in items))
            ranked.append(((key in held, len(sttms), sum(item.published for item in items), shape == "value"),
                           Choice(target_column=column, name=spelling, shape=shape, support=len(sttms), sttm_ids=sttms,
                                  projects=sorted({item.project_name for item in items if item.project_name}))))
        if ranked:
            choices[column] = max(ranked, key=lambda item: item[0])[1]
    return choices


def known_values(values: Iterable[dict[str, Any]], name: str, *, exclude_project: str | None = None,
                 limit: int = 3) -> list[dict[str, Any]]:
    """Distinct values other projects hold for a firm value name, most used first."""
    seen: dict[str, dict[str, Any]] = {}
    for item in values:
        if norm(item.get("ATTRIBUTE_NAME")) != norm(name) or str(item.get("PROJECT_ID")) == str(exclude_project or ""):
            continue
        value, data_type = item.get("ATTRIBUTE_VALUE"), item.get("ATTRIBUTE_TYPE")
        if not usable_value(value, data_type):
            continue
        entry = seen.setdefault(str(value).strip(), {
            "name": str(item.get("ATTRIBUTE_NAME")), "type": str(data_type or "VARCHAR"), "value": str(value).strip(),
            "source_project_id": str(item.get("PROJECT_ID")), "source_project_name": str(item.get("PROJECT_NAME") or ""),
            "source_attribute_id": str(item.get("ATTRIBUTE_ID") or ""), "projects": [],
        })
        entry["projects"].append(str(item.get("PROJECT_NAME") or item.get("PROJECT_ID")))
    return sorted(seen.values(), key=lambda entry: -len(entry["projects"]))[:limit]


def binding(firm_value: dict[str, Any]) -> dict[str, Any]:
    """The value binding the mapping page sends for a project's firm value."""
    return {
        "binding_id": f"project-attribute:{firm_value.get('attribute_id') or firm_value['name']}",
        "value": f"${firm_value['name']}",
        "resolved_value": firm_value.get("value"),
        "data_type": firm_value.get("type") or None,
        "attribute_name": firm_value["name"],
        "is_placeholder": True,
        "allow_project_specific_value": True,
        "resolution_status": "project_attribute",
        "provenance": "current_project_attribute",
    }


def source_expression(row: dict[str, Any]) -> str | None:
    """The current rule of a source-mapped row, or its single source column."""
    expression = str(row.get("expression") or "").strip()
    if expression:
        return expression
    sources = [str(value) for value in row.get("source_columns") or [] if str(value).strip()]
    return sources[0] if len(sources) == 1 else None


def _sql_string_literal_value(expression: str) -> str | None:
    match = re.fullmatch(r"\s*'((?:''|[^'])*)'\s*", expression, re.S)
    return match.group(1).replace("''", "'") if match else None


def _replace_matching_prefix_literal(expression: str, value: Any, placeholder: str) -> str | None:
    match = re.match(r"\s*'((?:''|[^'])*)'\s*\|\|\s*", expression, re.S)
    if not match:
        return None
    literal = match.group(1).replace("''", "'")
    prefix = str(value)
    if not literal.startswith(prefix):
        return None
    suffix = literal[len(prefix):]
    suffix_sql = "'" + suffix.replace("'", "''") + "' || " if suffix else ""
    return placeholder + " || " + suffix_sql + expression[match.end():]


def apply(row: dict[str, Any], choice: Choice, firm_value: dict[str, Any], *, confidence: float,
          override_source: bool) -> dict[str, Any] | None:
    """Bind ``row`` to ``firm_value`` in the chosen shape; the row it replaced, or None.

    ``value`` makes the row a grid firm-value row (``attribute`` mode with the
    resolved value, as the grid saves it). ``prefix`` and ``fallback`` wrap the
    row's current source rule and need one. A row the user's own notes decided
    is never changed, and a source guess is replaced only when
    ``override_source`` allows it.
    """
    if row.get("attachment_evidence") or names_in(row.get("expression")):
        return None
    before = {key: row.get(key) for key in (
        "source_columns", "source_dependencies", "expression", "status", "confidence", "confidence_reason",
        "mapping_classification", "mapping_mode", "constant_value", "attribute_name")}
    mapped = row.get("status") == "draft" and bool(row.get("source_columns") or row.get("expression"))
    common = {
        "status": "draft", "confidence": max(float(row.get("confidence") or 0), confidence),
        "confidence_reason": choice.reason, "missing_dependencies": [],
        "evidence_ids": sorted({*[str(value) for value in row.get("evidence_ids") or []], *choice.evidence_ids}),
        "firm_values": [firm_value["name"]],
    }
    if choice.shape == "value":
        if mapped and not override_source:
            return None
        row.update({**common, "mapping_mode": "attribute", "attribute_name": firm_value["name"],
                    "constant_value": firm_value.get("value"), "source_columns": [], "source_dependencies": [],
                    "expression": None, "mapping_classification": "constant"})
        return before if mapped else None
    current = source_expression(row) if mapped else None
    if current is None or choice.shape not in {"prefix", "fallback"}:
        return None
    name = f"${firm_value['name']}"
    if _sql_string_literal_value(current) == str(firm_value.get("value")):
        row.update({**common, "mapping_mode": "attribute", "attribute_name": firm_value["name"],
                    "constant_value": firm_value.get("value"), "source_columns": [], "source_dependencies": [],
                    "expression": None, "mapping_classification": "constant"})
        return before
    if choice.shape == "prefix":
        wrapped = _replace_matching_prefix_literal(current, firm_value.get("value"), name) or f"{name} || {current}"
    else:
        wrapped = f"COALESCE({current}, {name})"
    row.update({**common, "expression": wrapped, "mapping_classification": "derived",
                "source_dependencies": list(row.get("source_dependencies") or row.get("source_columns") or [])})
    return before


def hints(choices: dict[str, Choice], held: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    """What the mapping specialists are told: each firm value, its value and where it is used."""
    used: dict[str, list[str]] = defaultdict(list)
    for choice in choices.values():
        used[norm(choice.name)].append(f"{choice.target_column} ({choice.shape})")
    return [
        {"placeholder": f"${item['name']}", "name": item["name"], "type": item.get("type"),
         "value": item.get("value"), "used_for": used.get(key, [])}
        for key, item in sorted(held.items())
    ]
