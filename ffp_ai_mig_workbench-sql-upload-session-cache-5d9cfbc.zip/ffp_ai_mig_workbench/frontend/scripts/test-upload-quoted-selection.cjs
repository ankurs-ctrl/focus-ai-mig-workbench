const fs=require('fs'),path=require('path'),ts=require('typescript'),Module=require('module'),assert=require('node:assert/strict');
function load(name){const file=path.resolve(__dirname,'../src',name);const m=new Module(file,module);m.require=name=>name.startsWith('@/')?load(name.slice(2)+'.ts'):require(name);m._compile(ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText,file);return m.exports;}
const {resolveSelectedSourceTables}=load('features/sttm/shared/sttm-selection-utils.ts');
const row=(id,qn)=>({tableId:id,qualifiedName:qn,isSelected:true});
for(const [one,two] of [['D.S."Country"','D.S."COUNTRY"'],['D.S."a.b"','D.S."A.B"'],['D.S."a""b"','D.S."A""B"']]){
 const sources=[row('sql-instance:first',one),row('sql-instance:second',one),row(two,two)];
 assert.equal(resolveSelectedSourceTables({sources,sourceDatabases:[]}).length,3);
}
assert.equal(resolveSelectedSourceTables({sources:[row('d.s.t','d.s.t'),row('D.S.T','D.S.T')],sourceDatabases:[]}).length,1);
console.log('Quoted case, embedded dots and escaped quotes remain distinct; unquoted names canonicalize.');
const {sqlTableReference}=load('features/sttm/shared/sql-identifiers.ts');
assert.deepEqual(sqlTableReference('"D.b".S."a""b"'),{database:'"D.b"',schema:'S',table:'"a""b"'});
const {restoreImportedPhysicalInstances}=load('features/sttm/shared/imported-physical-instances.ts');
const id='sql-instance:test:physical:outer:%22mail%22';
const reopened=restoreImportedPhysicalInstances([row('other','D.S."COUNTRY"')],[{kind:'PHYSICAL_TABLE',relation_id:id,alias:'"mail"',table:{database:'D',schema:'S',table:'"Country"'}}]);
assert.equal(reopened.filter(item=>item.isSelected).length,2);
assert.equal(reopened.find(item=>item.tableId===id).qualifiedName,'D.S."Country"');
// Execute the exact deduplication used by openSttmFromBackend, not a replacement helper.
const sliceFile=path.resolve(__dirname,'../src/features/sttm/store/sttm-builder-slice.ts');
const ast=ts.createSourceFile(sliceFile,fs.readFileSync(sliceFile,'utf8'),ts.ScriptTarget.Latest,true);
let rawSources;function scan(n){if(ts.isVariableDeclaration(n)&&n.name.getText(ast)==='rawSources')rawSources=n.initializer.getText(ast);ts.forEachChild(n,scan)}scan(ast);assert.ok(rawSources);
const compiled=new Module(sliceFile,module);compiled._compile(ts.transpileModule(`module.exports=(rawSourceCandidates,derivedInputSources,sqlIdentifierKey)=>(${rawSources});`,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText,sliceFile);
const {sqlIdentifierKey}=load('features/sttm/shared/sql-identifiers.ts');
assert.equal(compiled.exports([{database:'D',schema:'S',table:'"Country"'},{database:'D',schema:'S',table:'"country"'}],[],sqlIdentifierKey).length,2);
assert.equal(compiled.exports([{database:'d',schema:'s',table:'t'},{database:'D',schema:'S',table:'T'}],[],sqlIdentifierKey).length,1);
