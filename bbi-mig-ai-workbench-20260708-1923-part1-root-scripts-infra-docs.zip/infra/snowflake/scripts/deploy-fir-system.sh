#!/usr/bin/env bash
# Deploy AGT_FIR_SYSTEM DDL to Snowflake.
#
# Reads credentials from services/sttm-builder/.env.local (names only, values never printed).
# Placeholders are substituted at deploy time — no secrets in SQL files.
#
# Usage:
#   ./infra/snowflake/scripts/deploy-fir-system.sh [--dry-run] [--skip-tasks] [--skip-grants]
#
# Options:
#   --dry-run      Print rendered SQL to stdout instead of executing
#   --skip-tasks   Skip task creation and RESUME (useful on first deploy — resume manually)
#   --skip-grants  Skip grants (useful if running as non-privileged role during testing)

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FIR_DIR="${SCRIPT_DIR}/../fir_system"
ENV_FILE="${SCRIPT_DIR}/../../../services/sttm-builder/.env.local"

# ── Parse args ─────────────────────────────────────────────────────────────────
DRY_RUN=false
SKIP_TASKS=false
SKIP_GRANTS=false

for arg in "$@"; do
  case "${arg}" in
    --dry-run)     DRY_RUN=true ;;
    --skip-tasks)  SKIP_TASKS=true ;;
    --skip-grants) SKIP_GRANTS=true ;;
    *) echo "ERROR: unknown option '${arg}'" >&2; exit 1 ;;
  esac
done

# ── Load credentials ────────────────────────────────────────────────────────────
if [[ ! -f "${ENV_FILE}" ]]; then
  echo "ERROR: credentials file not found: ${ENV_FILE}" >&2
  echo "       Expected services/sttm-builder/.env.local at project root." >&2
  exit 1
fi

set -a
# shellcheck disable=SC1090
source "${ENV_FILE}"
set +a

# Confirm required vars are present (names only — never print values)
REQUIRED_VARS=(
  SNOWFLAKE_ACCOUNT
  SNOWFLAKE_USER
  SNOWFLAKE_PASSWORD
  SNOWFLAKE_ROLE
  SNOWFLAKE_WAREHOUSE
  SNOWFLAKE_DATABASE
  SNOWFLAKE_SCHEMA
)
for var in "${REQUIRED_VARS[@]}"; do
  if [[ -z "${!var:-}" ]]; then
    echo "ERROR: ${var} is not set in ${ENV_FILE}" >&2
    exit 1
  fi
done

echo "Credentials loaded from: ${ENV_FILE}"
echo "Vars confirmed present (values not shown): ${REQUIRED_VARS[*]}"
echo ""

# ── Derived placeholders ────────────────────────────────────────────────────────
NS="${SNOWFLAKE_DATABASE}.${SNOWFLAKE_SCHEMA}"
export STTM_METADATA_NAMESPACE="${NS}"
export WAREHOUSE_NAME="${SNOWFLAKE_WAREHOUSE}"
export SERVICE_OWNER_ROLE="${SNOWFLAKE_ROLE}"
export DATABASE_NAME="${SNOWFLAKE_DATABASE}"

echo "Placeholder substitutions:"
echo "  __STTM_METADATA_NAMESPACE__ → ${NS}"
echo "  __WAREHOUSE_NAME__          → ${SNOWFLAKE_WAREHOUSE}"
echo "  __SERVICE_OWNER_ROLE__      → ${SNOWFLAKE_ROLE}"
echo "  __DATABASE__                → ${SNOWFLAKE_DATABASE}"
echo ""

# ── Dependency check ────────────────────────────────────────────────────────────
if ! command -v snowsql &>/dev/null; then
  echo "ERROR: snowsql not found. Install SnowSQL and ensure it is on PATH." >&2
  exit 1
fi

# ── Render + run ────────────────────────────────────────────────────────────────
render() {
  # Substitute __PLACEHOLDER__ tokens with env var values
  local file="$1"
  sed \
    -e "s|__STTM_METADATA_NAMESPACE__|${NS}|g" \
    -e "s|__WAREHOUSE_NAME__|${SNOWFLAKE_WAREHOUSE}|g" \
    -e "s|__SERVICE_OWNER_ROLE__|${SNOWFLAKE_ROLE}|g" \
    -e "s|__DATABASE__|${SNOWFLAKE_DATABASE}|g" \
    "${file}"
}

run_sql_file() {
  local label="$1"
  local file="$2"

  local rendered
  rendered="$(render "${file}")"

  if [[ "${DRY_RUN}" == "true" ]]; then
    echo "──── [DRY RUN] ${label} ────────────────────────────────────────"
    echo "${rendered}"
    echo ""
    return
  fi

  # Write rendered SQL to a temp file so SnowSQL uses -f (file mode).
  # -q (inline query) cannot handle $$-delimited procedure bodies.
  local tmpfile
  tmpfile="$(mktemp /tmp/fir_deploy_XXXXXX.sql)"
  trap 'rm -f "${tmpfile}"' RETURN
  printf '%s' "${rendered}" > "${tmpfile}"

  echo "→ ${label}"
  SNOWSQL_PWD="${SNOWFLAKE_PASSWORD}" snowsql \
    -a "${SNOWFLAKE_ACCOUNT}" \
    -u "${SNOWFLAKE_USER}" \
    -r "${SNOWFLAKE_ROLE}" \
    -w "${SNOWFLAKE_WAREHOUSE}" \
    -d "${SNOWFLAKE_DATABASE}" \
    -s "${SNOWFLAKE_SCHEMA}" \
    -o friendly=false \
    -o header=false \
    -o output_format=plain \
    -f "${tmpfile}"
  echo "  ✓ done"
  echo ""
}

# ── Deployment sequence ─────────────────────────────────────────────────────────
echo "=========================================="
echo " AGT_FIR_SYSTEM — Local Deployment"
echo " Stage: LOCAL"
echo "=========================================="
echo ""

# 1. Tables
echo "[ 1/7 ] Tables"
run_sql_file "TBL_AGENT_FIR_360"              "${FIR_DIR}/tables/tbl_agent_fir_360.sql"
run_sql_file "TBL_SEMANTIC_VIEW_VERSIONS"      "${FIR_DIR}/tables/tbl_semantic_view_versions.sql"
run_sql_file "TBL_FIR_AGENT_RECOMMENDATIONS"   "${FIR_DIR}/tables/tbl_fir_agent_recommendations.sql"

# 2. Streams
echo "[ 2/7 ] Streams"
run_sql_file "FIR Streams" "${FIR_DIR}/streams/fir_streams.sql"

# 3. Procedures
echo "[ 3/7 ] Stored Procedures"
run_sql_file "SP_FIR_COLLECT_FEEDBACK"            "${FIR_DIR}/procedures/sp-fir-collect-feedback.sql"
run_sql_file "SP_FIR_GENERATE_INFERENCES"         "${FIR_DIR}/procedures/sp-fir-generate-inferences.sql"
run_sql_file "SP_FIR_CREATE_SEMANTIC_VERSION"     "${FIR_DIR}/procedures/sp-fir-create-semantic-version.sql"
run_sql_file "SP_FIR_GENERATE_RECOMMENDATIONS"    "${FIR_DIR}/procedures/sp-fir-generate-recommendations.sql"
run_sql_file "SP_FIR_APPLY_CONFIDENCE_DECAY"      "${FIR_DIR}/procedures/sp-fir-apply-confidence-decay.sql"
run_sql_file "SP_FIR_GET_AGENT_RECOMMENDATIONS"   "${FIR_DIR}/procedures/sp-fir-get-agent-recommendations.sql"
run_sql_file "SP_FIR_ORCHESTRATE_BATCH"           "${FIR_DIR}/procedures/sp-fir-orchestrate-batch.sql"
run_sql_file "SP_FIR_CONSOLIDATE_SEMANTIC_VERSIONS" "${FIR_DIR}/procedures/sp-fir-consolidate-semantic-versions.sql"
run_sql_file "SP_FIR_READ_DOCUMENTS"              "${FIR_DIR}/procedures/sp-fir-read-documents.sql"
run_sql_file "SP_FIR_READ_PENDING_RECORDS"        "${FIR_DIR}/procedures/sp-fir-read-pending-records.sql"
run_sql_file "SP_FIR_STORE_INFERENCE"             "${FIR_DIR}/procedures/sp-fir-store-inference.sql"
run_sql_file "SP_FIR_STORE_RECOMMENDATION"        "${FIR_DIR}/procedures/sp-fir-store-recommendation.sql"
run_sql_file "SP_FIR_STORE_QA_PAIR"              "${FIR_DIR}/procedures/sp-fir-store-qa-pair.sql"
run_sql_file "SP_FIR_INVOKE_AGENT"                "${FIR_DIR}/procedures/sp-fir-invoke-agent.sql"

# 4. Cortex Search Services
echo "[ 4/7 ] Cortex Search Services"
run_sql_file "FIR Cortex Search Services" "${FIR_DIR}/cortex_search/fir_search_services.sql"

# 5. Agent (requires Python with snowflake-connector)
echo "[ 5/7 ] Agent (AGT_FIR_SYSTEM)"
VENV_PYTHON="${SCRIPT_DIR}/../../../services/sttm-builder/.venv/bin/python"
DEPLOY_AGENT_SCRIPT="${SCRIPT_DIR}/../../../scripts/deploy_fir_agent.py"
if [[ -f "${VENV_PYTHON}" && -f "${DEPLOY_AGENT_SCRIPT}" ]]; then
  if [[ "${DRY_RUN}" == "true" ]]; then
    echo "  [DRY RUN] Would deploy AGT_FIR_SYSTEM via ${DEPLOY_AGENT_SCRIPT}"
  else
    "${VENV_PYTHON}" "${DEPLOY_AGENT_SCRIPT}" --skip-procedures --env-file "${ENV_FILE}"
    echo "  ✓ AGT_FIR_SYSTEM deployed"
  fi
else
  echo "  ⚠ Skipped: Python venv or deploy script not found."
  echo "    Run manually: python scripts/deploy_fir_agent.py --skip-procedures"
fi
echo ""

# 6. Tasks
if [[ "${SKIP_TASKS}" == "false" ]]; then
  echo "[ 6/7 ] Tasks"
  run_sql_file "FIR Tasks" "${FIR_DIR}/tasks/fir_tasks.sql"

  echo ""
  echo "NOTE: Tasks are created in SUSPENDED state."
  echo "      Resume manually when ready:"
  echo "        ALTER TASK ${NS}.TSK_FIR_PROCESS_BATCH RESUME;"
  echo "        ALTER TASK ${NS}.TSK_FIR_CONFIDENCE_DECAY RESUME;"
  echo "        ALTER TASK ${NS}.TSK_FIR_SEMANTIC_CONSOLIDATION RESUME;"
  echo ""
else
  echo "[ 6/7 ] Tasks — SKIPPED (--skip-tasks)"
fi

# 7. Grants
if [[ "${SKIP_GRANTS}" == "false" ]]; then
  echo "[ 7/7 ] Grants"
  run_sql_file "FIR Grants" "${FIR_DIR}/grants/fir_grants.sql"
else
  echo "[ 7/7 ] Grants — SKIPPED (--skip-grants)"
fi

# ── Verification hint ───────────────────────────────────────────────────────────
if [[ "${DRY_RUN}" == "false" ]]; then
  echo "=========================================="
  echo " Deployment complete. Verify with:"
  echo "=========================================="
  echo ""
  echo "  SHOW TABLES    LIKE 'TBL_%FIR%'  IN SCHEMA ${NS};"
  echo "  SHOW STREAMS   LIKE 'STM_FIR_%'  IN SCHEMA ${NS};"
  echo "  SHOW PROCEDURES LIKE 'SP_FIR_%'  IN SCHEMA ${NS};"
  echo "  SHOW TASKS     LIKE 'TSK_FIR_%'  IN SCHEMA ${NS};"
  echo ""
  echo "  Manual test:"
  echo "    CALL ${NS}.SP_FIR_ORCHESTRATE_BATCH(OBJECT_CONSTRUCT("
  echo "      'task_type', 'manual',"
  echo "      'batch_size', 10,"
  echo "      'processing_options', OBJECT_CONSTRUCT("
  echo "        'collect_feedback', TRUE,"
  echo "        'generate_inferences', TRUE,"
  echo "        'create_semantic_versions', FALSE,"
  echo "        'generate_recommendations', TRUE,"
  echo "        'apply_decay', FALSE"
  echo "      )"
  echo "    ));"
fi
