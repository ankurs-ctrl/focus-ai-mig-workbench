"""Synchronize instructions while preserving live tools and runtime settings."""

import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import subprocess

import yaml


def verify_live_export(path: Path, expected: dict) -> None:
    """Verify the complete LIVE spec from an untruncated SHOW VERSIONS export."""
    export = json.loads(path.read_text(encoding="utf-8"))
    rows = [row if isinstance(row, dict) else dict(zip(export["columns"], row))
            for row in export["rows"]]
    live = [row for row in rows if row.get("spec_file_path", "").lower().endswith("/versions/live/")]
    if len(live) != 1 or json.loads(live[0]["agent_spec"]) != expected:
        raise ValueError("Saved LIVE spec differs from the complete approved specification")


def run_cli(cli: str, root: Path, *arguments: str) -> dict:
    completed = subprocess.run(
        [cli, "agent-studio", *arguments], cwd=root, capture_output=True,
        text=True, encoding="utf-8", timeout=180, check=False,
    )
    if completed.returncode:
        raise RuntimeError(completed.stderr or completed.stdout)
    output = completed.stdout
    result = json.loads(output[output.index("{"):])
    if not result.get("success"):
        raise RuntimeError(json.dumps(result))
    return result


def include_evidence_tool(original, template, *, namespace, warehouse):
    """Add only the named read-only evidence tool; retain every other setting."""
    result = deepcopy(original)
    tool = next(deepcopy(item) for item in template.get('tools', [])
                if item.get('tool_spec', {}).get('name') == 'ReadAutoMapEvidence')
    resources = result.setdefault('tool_resources', {})
    tools = result.setdefault('tools', [])
    matches = [item for item in tools if item.get('tool_spec', {}).get('name') == 'ReadAutoMapEvidence']
    resource = deepcopy(template['tool_resources']['ReadAutoMapEvidence'])
    resource['identifier'] = namespace + '.SP_AUTOMAP_READ_EVIDENCE'
    resource['execution_environment']['warehouse'] = warehouse
    if matches:
        if len(matches) != 1 or resources.get('ReadAutoMapEvidence', {}).get('identifier') != resource['identifier']:
            raise ValueError('Existing evidence tool differs from the selected namespace; review its binding')
        return result
    tools.append(tool)
    resources['ReadAutoMapEvidence'] = resource
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cli", required=True)
    parser.add_argument("--connection", required=True)
    parser.add_argument("--namespace", required=True)
    parser.add_argument("--output-dir", type=Path, help="New local directory for this reviewable read-only preparation")
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--include-evidence-tool", action="store_true", help="Add ReadAutoMapEvidence while preserving existing tools/resources")
    parser.add_argument("--warehouse", help="Existing approved warehouse for the optional evidence procedure")
    parser.add_argument("--allow-runtime-changes", action="store_true", help="Include reviewed template model and orchestration budget changes")
    parser.add_argument("--agents", nargs="+", choices=["AGT_SOURCE_MAPPING", "AGT_STTM_BUILDER", "AGT_TRANSFORMATION_RULE", "AGT_FIR_SYSTEM"])
    parser.add_argument("--publish", action="store_true", help="Publish an already-saved approved spec after exact LIVE export verification")
    parser.add_argument("--live-versions-export", type=Path)
    parser.add_argument("--prepared-spec", type=Path)
    args = parser.parse_args()
    if args.include_evidence_tool and not args.warehouse:
        parser.error("--include-evidence-tool requires --warehouse")
    if args.apply and not args.agents:
        parser.error("--apply requires explicitly selected --agents")
    root = Path(__file__).resolve().parents[1]
    if args.publish:
        if args.apply or not args.agents or len(args.agents) != 1 or not args.live_versions_export or not args.prepared_spec:
            parser.error("Publish separately with one --agents, --prepared-spec and --live-versions-export; no --apply")
        expected = yaml.safe_load(args.prepared_spec.read_text(encoding="utf-8"))
        verify_live_export(args.live_versions_export, expected)
        fqn = f"{args.namespace}.{args.agents[0]}"
        published = run_cli(args.cli, root, "agent-publish", "--fqn", fqn, "--connection", args.connection)
        actual = yaml.safe_load(run_cli(args.cli, root, "agent-read", "--fqn", fqn,
                                       "--connection", args.connection)["yaml_content"])
        if actual != expected:
            raise RuntimeError(f"Published default does not match approved spec: {fqn}")
        print(json.dumps({"agent": fqn, "publish": published, "default_verified": True,
                          "spec_sha256": hashlib.sha256(json.dumps(actual, sort_keys=True).encode()).hexdigest()}), flush=True)
        return
    artifacts = args.output_dir or root / ".dev-cache" / "agent-spec-sync"
    if args.output_dir and (not artifacts.is_absolute() or artifacts.exists()):
        parser.error("--output-dir must be a new absolute directory")
    artifacts.mkdir(parents=True, exist_ok=True)
    inventory = []
    for name, template_name in (
        ("AGT_SOURCE_MAPPING", "agent_spec_source_mapping.yaml"),
        ("AGT_STTM_BUILDER", "agent_spec_sttm_builder.yaml"),
        ("AGT_TRANSFORMATION_RULE", "agent_spec_transformation_rule.yaml"),
        ("AGT_FIR_SYSTEM", "agent_spec_fir_system.yaml"),
    ):
        if args.agents and name not in args.agents:
            continue
        fqn = f"{args.namespace}.{name}"
        read = run_cli(args.cli, root, "agent-read", "--fqn", fqn,
                       "--connection", args.connection)
        original = yaml.safe_load(read["yaml_content"])
        backup = artifacts / f"{name}.before.yaml"
        if not backup.exists():
            backup.write_text(read["yaml_content"], encoding="utf-8")
        template = yaml.safe_load(
            (root / "infra" / "snowflake" / "agents" / template_name)
            .read_text(encoding="utf-8")
        )
        merged = {**original, "instructions": {
            **original.get("instructions", {}), **template["instructions"],
        }}
        if args.allow_runtime_changes:
            for field in ("models", "orchestration"):
                if field in template:
                    merged[field] = template[field]
        if args.include_evidence_tool and name in {"AGT_SOURCE_MAPPING", "AGT_TRANSFORMATION_RULE"}:
            merged = include_evidence_tool(merged, template, namespace=args.namespace, warehouse=args.warehouse)
        permitted_tool_fields = {"tools", "tool_resources"} if args.include_evidence_tool else set()
        runtime_diff = {field: {"before": original.get(field), "after": merged.get(field)}
                        for field in ("models", "orchestration") if original.get(field) != merged.get(field)}
        for field, value in original.items():
            if field != "instructions" and field not in runtime_diff and field not in permitted_tool_fields and merged[field] != value:
                raise RuntimeError(f"Unexpected change to {field}")
        content = yaml.safe_dump(merged, allow_unicode=True, sort_keys=False)
        prepared = artifacts / f"{name}.prepared.yaml"
        prepared.write_text(content, encoding="utf-8")
        inventory.append({"agent": fqn, "runtime_diff": runtime_diff, "before_sha256": hashlib.sha256(json.dumps(original, sort_keys=True).encode()).hexdigest(),
                          "prepared_sha256": hashlib.sha256(json.dumps(merged, sort_keys=True).encode()).hexdigest(),
                          "changes": [f"instructions.{key}" for key, value in merged["instructions"].items()
                                      if value != original.get("instructions", {}).get(key)],
                          "models": merged.get("models"), "orchestration": merged.get("orchestration"),
                          "tools": [tool["tool_spec"]["name"] for tool in original.get("tools", [])],
                          "approval_required": True})
        print(json.dumps({"agent": fqn, "instruction_chars": {
            key: len(value) for key, value in merged["instructions"].items()
            if isinstance(value, str)
        }, "preserved_fields": sorted(set(original) - {"instructions"}),
            "tools": [tool["tool_spec"]["name"]
                      for tool in original.get("tools", [])]}), flush=True)
        if not args.apply:
            continue
        workspace_file = root / "cortex_project" / f"{name}.reconciliation.agent.yaml"
        if workspace_file.exists():
            raise RuntimeError(f"Refusing to overwrite existing workspace spec: {workspace_file.name}")
        # Windows limits process command lines to 32K UTF-16 characters. Register
        # the complete spec's non-instruction fields, then serialize its full
        # instruction body to that tracked file before any Snowflake save.
        registration = yaml.safe_dump(
            {**merged, "instructions": {}}, sort_keys=False
        )
        run_cli(args.cli, root, "agent-write", "--yaml-content", registration,
                "--source-object", fqn, "--file-path", workspace_file.name)
        workspace_file.write_text(content, encoding="utf-8")
        if yaml.safe_load(workspace_file.read_text(encoding="utf-8")) != merged:
            raise RuntimeError("Workspace round-trip mismatch")
        saved = run_cli(args.cli, root, "agent-save", "--file-path",
                        str(workspace_file), "--fqn", fqn,
                        "--connection", args.connection)
        print(json.dumps({"agent": fqn, "save": saved}), flush=True)
        verified = run_cli(args.cli, root, "agent-read", "--fqn", fqn,
                           "--connection", args.connection)
        actual = yaml.safe_load(verified["yaml_content"])
        if actual != merged:
            if actual != original:
                raise RuntimeError(f"Unexpected default change while saving LIVE: {fqn}")
            print(json.dumps({"agent": fqn, "status": "saved_live_default_unchanged",
                              "next": "Verify SHOW VERSIONS full LIVE spec before separate approved publication"}), flush=True)
        else:
            print(json.dumps({"agent": fqn, "default_verified": True}), flush=True)
    (artifacts / "review.json").write_text(json.dumps(inventory, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()