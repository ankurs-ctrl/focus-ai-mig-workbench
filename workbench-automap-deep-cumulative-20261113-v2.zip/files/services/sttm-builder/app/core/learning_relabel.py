"""Re-key stored learnings onto the fixed target schema (reversible).

Learnings written before the target schema was fixed name their target the
old way (``SCH_EVERNEST_HH_TARGET.EVERNEST_HH_SF_IMPORT``, or nothing at all
for SQL uploaded without a target) and their columns the script's way
(``xxOGStateCode``). Retrieval keys on the canonical target column, so those
learnings were never found. This module plans the re-key; the caller writes
new rows and retires the old ones (SUPERSEDED_BY), never updating in place.
"""
from __future__ import annotations

import hashlib
import json
import re
from dataclasses import asdict, dataclass
from typing import Any, Iterable

from app.core.learning_scope import (
    SCOPE_PROJECT,
    canonical_column,
    canonical_target,
    derive_scope,
    infer_target_from_columns,
    source_schemas,
    target_role,
    vendor_family,
)


@dataclass
class PatternRelabel:
    pattern_id: str
    asset_id: str | None
    old_target: str
    new_target: str | None
    old_column: str
    new_column: str | None
    old_scope: str
    new_scope: str
    vendor: str | None
    action: str  # relabel | skip
    reason: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def _stable_hash(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), default=str).encode()).hexdigest()


def _payload(row: dict[str, Any]) -> dict[str, Any]:
    value = row.get("PATTERN_PAYLOAD")
    if isinstance(value, str):
        value = json.loads(value)
    return value if isinstance(value, dict) else {}


def plan_pattern_relabels(
    rows: Iterable[dict[str, Any]], contracts: dict[str, list[str]], settings: Any = None,
) -> list[PatternRelabel]:
    """One decision per active pattern row (``TBL_FIR_TARGET_MAPPING_PATTERNS`` columns)."""
    rows = list(rows)
    known = list(contracts)
    columns_by_asset: dict[str, list[str]] = {}
    for row in rows:
        asset = str((_payload(row).get("provenance") or {}).get("asset_id") or "")
        if asset and not str(row.get("TARGET_TABLE") or "").strip():
            columns_by_asset.setdefault(asset, []).append(str(row.get("TARGET_COLUMN") or ""))
    inferred = {
        asset: infer_target_from_columns(columns, contracts)
        for asset, columns in columns_by_asset.items()
    }
    plans: list[PatternRelabel] = []
    for row in rows:
        payload = _payload(row)
        contract = payload.get("target_contract") or {}
        profile = payload.get("source_system_profile") or {}
        recipe = payload.get("mapping_recipe") or {}
        provenance = payload.get("provenance") or {}
        asset = str(provenance.get("asset_id") or "") or None
        old_target = str(row.get("TARGET_TABLE") or "").strip()
        old_column = str(row.get("TARGET_COLUMN") or contract.get("target_column") or "")
        old_scope = str(row.get("SCOPE") or payload.get("scope") or "client")
        reason = ""
        new_target = canonical_target(old_target, settings, known_tables=known) if old_target else None
        if new_target:
            reason = "fixed target" if new_target == old_target.upper() else f"alias of {old_target}"
        elif not old_target and asset and inferred.get(asset, (None, 0))[0]:
            table, share = inferred[asset]
            new_target = canonical_target(table, settings, known_tables=known)
            reason = f"inferred from the upload's columns ({share:.0%} of them exist in {table})"
        vendor = vendor_family(profile.get("source_tables") or [], settings, declared=profile.get("vendor_family"))
        if old_scope == SCOPE_PROJECT:
            new_scope = SCOPE_PROJECT
        else:
            new_scope = derive_scope(
                recipe, evidence_class=provenance.get("evidence_class"),
                has_project_literal=bool(recipe.get("has_project_specific_literal")),
            )
        leaf = str(new_target or "").split(".")[-1]
        new_column = canonical_column(old_column, contracts.get(leaf, [])) if new_target else None
        if not new_target:
            plans.append(PatternRelabel(
                str(row.get("PATTERN_ID")), asset, old_target, None, old_column, None, old_scope, old_scope,
                vendor, "skip", "no fixed target for this learning"))
            continue
        if not new_column:
            plans.append(PatternRelabel(
                str(row.get("PATTERN_ID")), asset, old_target, new_target, old_column, None, old_scope, new_scope,
                vendor, "skip", f"{old_column} is not a column of {leaf}"))
            continue
        unchanged = (new_target == old_target.upper() and new_column == old_column
                     and new_scope == old_scope and contract.get("canonical_target") == new_target)
        plans.append(PatternRelabel(
            str(row.get("PATTERN_ID")), asset, old_target, new_target, old_column, new_column, old_scope, new_scope,
            vendor, "skip" if unchanged else "relabel", "already canonical" if unchanged else reason or "scope"))
    return plans


def relabeled_pattern(payload: dict[str, Any], plan: PatternRelabel, *, settings: Any = None) -> dict[str, Any]:
    """The replacement pattern payload for a ``relabel`` decision (new id and content hash)."""
    contract = dict(payload.get("target_contract") or {})
    profile = dict(payload.get("source_system_profile") or {})
    contract.update({
        "original_target_fqn": contract.get("target_fqn") or plan.old_target or None,
        "original_target_column": plan.old_column,
        "target_fqn": plan.new_target,
        "canonical_target": plan.new_target,
        "target_role": target_role(plan.new_target),
        "target_column": plan.new_column,
    })
    profile["vendor_family"] = plan.vendor
    profile["source_schemas"] = source_schemas(profile.get("source_tables") or [])
    content_hash = _stable_hash({
        "target_table": plan.new_target,
        "target_column": plan.new_column,
        "recipe": payload.get("mapping_recipe"),
        "project_scope": payload.get("project_id") if plan.new_scope == SCOPE_PROJECT else None,
    })
    subject = f"target_column:{plan.new_target}.{plan.new_column}"
    return {
        **payload,
        "pattern_id": f"tmp_{content_hash[:24]}",
        "subject_key": subject,
        "scope": plan.new_scope,
        "target_contract": contract,
        "source_system_profile": profile,
        "content_hash": content_hash,
        "superseded_by": None,
        "provenance": {**(payload.get("provenance") or {}), "relabeled_from": plan.pattern_id,
                       "relabel_reason": plan.reason},
    }


_SUBJECT = re.compile(r"^(target_column|mapping_row:[^:]+):(.+)\.([^.]+)$")


def relabeled_subject_key(subject_key: str, contracts: dict[str, list[str]], settings: Any = None) -> str | None:
    """``target_column:DB.SCHEMA.TABLE.COL`` on the fixed target, or None when it has no fixed target."""
    match = _SUBJECT.match(str(subject_key or ""))
    if not match:
        return None
    prefix, table, column = match.groups()
    new_target = canonical_target(table, settings, known_tables=list(contracts))
    if not new_target:
        return None
    new_column = canonical_column(column, contracts.get(new_target.split(".")[-1], []))
    if not new_column:
        return None
    key = f"{prefix}:{new_target}.{new_column}"
    return None if key == subject_key else key


def summarize_plans(plans: list[PatternRelabel]) -> dict[str, Any]:
    """Counts by action and old -> new target, for the dry-run report."""
    moves: dict[str, int] = {}
    skips: dict[str, int] = {}
    scopes: dict[str, int] = {}
    for plan in plans:
        if plan.action == "relabel":
            key = f"{plan.old_target or '<no target>'} -> {plan.new_target}"
            moves[key] = moves.get(key, 0) + 1
            scopes[plan.new_scope] = scopes.get(plan.new_scope, 0) + 1
        else:
            reason = "column not in the fixed target" if " is not a column of " in plan.reason else plan.reason
            skips[reason] = skips.get(reason, 0) + 1
    return {"relabel": sum(moves.values()), "skip": sum(skips.values()), "moves": moves,
            "new_scopes": scopes, "skip_reasons": skips}
