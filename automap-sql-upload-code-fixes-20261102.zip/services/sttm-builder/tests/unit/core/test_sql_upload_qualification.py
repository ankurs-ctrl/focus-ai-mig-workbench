from __future__ import annotations

from types import SimpleNamespace
from typing import Any

import pytest

from app.core.sql_upload_qualification import qualify_upload_references, resolve_reference


class _Result:
    def __init__(self, rows: list[dict[str, Any]]) -> None:
        self._rows = rows

    def collect(self, statement_params: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        assert statement_params and statement_params["STATEMENT_TIMEOUT_IN_SECONDS"] >= 1
        return self._rows


class _Session:
    def __init__(
        self,
        *,
        project_metadata: dict[str, Any] | None = None,
        project_tables: list[dict[str, Any]] | None = None,
        info_schema: dict[str, list[dict[str, Any]]] | None = None,
        current_database: str = "",
    ) -> None:
        self.project_metadata = project_metadata or {}
        self.project_tables = project_tables or []
        self.info_schema = info_schema or {}
        self.current_database = current_database
        self.calls: list[tuple[str, list[Any]]] = []

    def sql(self, query: str, params: list[Any]) -> _Result:
        self.calls.append((query, params))
        if query == "DESCRIBE TABLE IDENTIFIER(?)":
            return _Result([{"name": "ID", "type": "NUMBER"}])
        if "PROJECT_METADATA" in query:
            return _Result([{"PROJECT_METADATA": self.project_metadata}])
        if "SELECT DISTINCT s.DATABASE_NAME" in query:
            return _Result(self.project_tables)
        if "INFORMATION_SCHEMA" in query:
            database = params[0].split(".", 1)[0].strip('"')
            names = set(params[1:])
            return _Result(
                [row for row in self.info_schema.get(database, []) if row["TABLE_NAME"] in names]
            )
        if "CURRENT_DATABASE" in query:
            return _Result([{"DB": self.current_database}])
        if "WITH requested" in query:
            return _Result([])
        raise AssertionError(query)


SETTINGS = SimpleNamespace(
    qualify_metadata_object_name=lambda name: f"META.SCH.{name}",
    snowflake_sttm_sources_table="TBL_STTM_SOURCES",
    snowflake_sttm_table="TBL_STTM",
    resolved_semantic_views_table="META.SCH.TABLE_REGISTRY",
    resolved_semantic_native_views_table="META.SCH.NATIVE_REGISTRY",
)


def _info(database: str, schema: str, table: str) -> dict[str, str]:
    return {"TABLE_CATALOG": database, "TABLE_SCHEMA": schema, "TABLE_NAME": table}


def test_fully_qualified_names_use_only_exact_lookup() -> None:
    session = _Session()
    references = qualify_upload_references(
        session,
        SETTINGS,
        project_id="p1",
        references=[("DB.S.T", "source")],
    )

    assert references[0]["resolved_fqn"] == "DB.S.T"
    assert references[0]["resolution_method"] == "exact_fqn"
    assert session.calls == [("DESCRIBE TABLE IDENTIFIER(?)", ["DB.S.T"])]


def test_known_workspace_tables_qualify_partial_names_first() -> None:
    session = _Session(info_schema={"OTHER": [_info("OTHER", "RAW", "ACCOUNTS")]})
    references = qualify_upload_references(
        session,
        SETTINGS,
        project_id="p1",
        references=[("accounts", "source"), ("RAW.owners", "source")],
        known_tables=["DB1.RAW.ACCOUNTS", "DB1.RAW.OWNERS"],
    )

    assert [item["resolved_fqn"] for item in references] == [
        "DB1.RAW.ACCOUNTS",
        "DB1.RAW.OWNERS",
    ]
    assert not any("INFORMATION_SCHEMA" in query for query, _ in session.calls)


def test_scoped_information_schema_lookup_uses_use_context_database() -> None:
    session = _Session(
        info_schema={"DB1": [_info("DB1", "RAW", "ACCOUNTS"), _info("DB1", "STAGE", "ACCOUNTS")]}
    )
    references = qualify_upload_references(
        session,
        SETTINGS,
        project_id="p1",
        references=[("ACCOUNTS", "source")],
        use_context={"database": "DB1", "schema": "RAW"},
    )

    assert references[0]["resolution_status"] == "resolved"
    assert references[0]["resolved_fqn"] == "DB1.RAW.ACCOUNTS"
    assert session.calls == [("DESCRIBE TABLE IDENTIFIER(?)", ["DB1.RAW.ACCOUNTS"])]


def test_project_defaults_and_project_tables_are_used() -> None:
    session = _Session(
        project_metadata={"source_database": "SRC", "source_schema": "CRM"},
        project_tables=[{"DATABASE_NAME": "SRC", "SCHEMA_NAME": "CRM", "TABLE_NAME": "CONTACTS"}],
        info_schema={"SRC": [_info("SRC", "CRM", "NOTES"), _info("SRC", "OLD", "NOTES")]},
    )
    references = qualify_upload_references(
        session,
        SETTINGS,
        project_id="p1",
        references=[("CONTACTS", "source"), ("NOTES", "source")],
    )

    assert [item["resolved_fqn"] for item in references] == ["SRC.CRM.CONTACTS", "SRC.CRM.NOTES"]
    assert references[0]["resolution_method"] == "project_known_table"


def test_ambiguous_names_return_candidates_without_guessing() -> None:
    session = _Session(
        current_database="DB",
        info_schema={"DB": [_info("DB", "A", "T"), _info("DB", "B", "T")]},
    )
    references = qualify_upload_references(
        session,
        SETTINGS,
        project_id="p1",
        references=[("T", "source")],
    )

    assert references[0]["resolution_status"] == "ambiguous"
    assert references[0]["resolved_fqn"] is None
    assert references[0]["candidate_fqns"] == ["DB.A.T", "DB.B.T"]


def test_two_part_name_prefers_document_database() -> None:
    catalog = [
        {"DATABASE_NAME": "X", "SCHEMA_NAME": "S", "TABLE_NAME": "T", "FQN": "X.S.T"},
        {"DATABASE_NAME": "Y", "SCHEMA_NAME": "S", "TABLE_NAME": "T", "FQN": "Y.S.T"},
    ]
    result = resolve_reference("S.T", catalog, preferred=[("", ""), ("Y", "")])

    assert result["resolved_fqn"] == "Y.S.T"


def test_failed_lookups_leave_names_unknown() -> None:
    class _FailingSession(_Session):
        def sql(self, query: str, params: list[Any]) -> _Result:
            raise RuntimeError("no access")

    references = qualify_upload_references(
        _FailingSession(),
        SETTINGS,
        project_id="p1",
        references=[("T", "source")],
    )

    assert references[0]["resolution_status"] == "lookup_failed"
    assert references[0]["semantic_status"] == "lookup_failed"
    assert references[0]["metadata_warnings"]
    assert references[0]["raw_identifier"] == "T"


@pytest.mark.parametrize("failed_scope", ["PROJECT_METADATA", "SELECT DISTINCT", "CURRENT_DATABASE", "INFORMATION_SCHEMA"])
@pytest.mark.parametrize("failure", ["statement timed out", "metadata unavailable"])
def test_unqualified_lookup_errors_reach_route_diagnostics(failed_scope, failure):
    from app.routers.upload import _qualified_upload_references

    class FailingSession(_Session):
        def sql(self, query, params):
            if failed_scope in query:
                raise RuntimeError(failure)
            return super().sql(query, params)

    result = _qualified_upload_references(
        FailingSession(current_database="DB"), SETTINGS, project_id="p1",
        references=[("T", "source")], use_context={}, known_tables=[],
    )[0]
    assert result["resolution_status"] == "lookup_failed"
    assert result["catalog_status"] == "lookup_failed"
    assert result["semantic_status"] == "lookup_failed"
    assert result["classification"] == "lookup_failed"
    assert result["resolved_fqn"] is None
    assert result["metadata_warnings"][0]["status"] == "unknown"
    assert result["metadata_warnings"][0]["reason"] == (
        "timeout" if failure == "statement timed out" else "lookup_failed"
    )


def test_successful_empty_qualification_is_still_unresolved():
    result = qualify_upload_references(
        _Session(current_database="DB"), SETTINGS, project_id="p1", references=[("T", "source")],
    )[0]
    assert result["resolution_status"] == "unresolved"
    assert not result.get("metadata_warnings")


FTPITT_SQL = """
SELECT a.ID, c.ID AS CONTACT_ID, h.ID AS HOUSEHOLD_ID, o.ID AS OWNER_ID, n.ID AS NOTE_ID
FROM FTPITT.RAW.CLIENTS a
LEFT JOIN FTPITT.RAW.CONTACTS c ON a.ID = c.CLIENT_ID
LEFT JOIN FTPITT.RAW.HOUSEHOLDS h ON a.ID = h.CLIENT_ID
LEFT JOIN FTPITT.RAW.OWNERS o ON a.ID = o.CLIENT_ID
LEFT JOIN FTPITT.RAW.NOTES n ON a.ID = n.CLIENT_ID
LEFT JOIN ACCOUNTS accounts ON a.ID = accounts.CLIENT_ID
"""


@pytest.mark.parametrize("hint", ["known", "use", "none"])
def test_ftpitt_five_fqns_precede_unqualified_discovery_and_keep_positive_evidence(monkeypatch, hint):
    from app.core.sql_parser import parse_sql_document
    from app.core.upload_reference_status import identifier_parts
    from app.routers.upload import _qualified_upload_references

    class Caller(_Session):
        def sql(self, query, params):
            if "INFORMATION_SCHEMA" in query:
                self.calls.append((query, params))
                assert params[0] == '"FTPITT".INFORMATION_SCHEMA.TABLES'
                assert params[1:] == ["ACCOUNTS"]
                assert sum(call[0].startswith("DESCRIBE") for call in self.calls) == 5
                raise RuntimeError("statement timed out")
            return super().sql(query, params)

    session = Caller()
    parsed = parse_sql_document(FTPITT_SQL)
    assert len(parsed.source_tables) == 6
    result = _qualified_upload_references(
        session, SETTINGS, project_id="ftpitt", references=[(name, "source") for name in parsed.source_tables],
        use_context={"database": "FTPITT", "schema": "RAW"} if hint == "use" else {},
        known_tables=["FTPITT.RAW.ACCOUNTS"] if hint == "known" else [],
    )
    exact = [item for item in result if len(identifier_parts(item["raw_identifier"])) == 3]
    assert len(exact) == 5
    assert all(item["catalog_status"] == "available" and item["resolution_status"] == "resolved" for item in exact)
    assert all(query == "DESCRIBE TABLE IDENTIFIER(?)" for query, _ in session.calls[:5])
    account = next(item for item in result if item["raw_identifier"] == "ACCOUNTS")
    if hint == "none":
        assert account["resolution_status"] == "lookup_failed"
        assert account["resolved_fqn"] is None
        assert any("INFORMATION_SCHEMA" in query for query, _ in session.calls)
    else:
        assert account["catalog_status"] == "available"
        assert account["resolved_fqn"] == "FTPITT.RAW.ACCOUNTS"
        assert len(session.calls) == 8  # Six describes plus two semantic registries.
        assert not any("INFORMATION_SCHEMA" in query or "PROJECT_METADATA" in query for query, _ in session.calls)
    assert len(session.calls) <= 8


def test_discovery_is_limited_to_four_relevant_databases():
    from app.routers.upload import _qualified_upload_references
    session = _Session()
    result = _qualified_upload_references(
        session, SETTINGS, project_id="p1", references=[("T", "source")], use_context={},
        known_tables=[f"DB{index}.S.UNRELATED" for index in range(10)],
    )[0]
    lookups = [params[0] for query, params in session.calls if "INFORMATION_SCHEMA" in query]
    assert lookups == [f'"DB{index}".INFORMATION_SCHEMA.TABLES' for index in range(4)]
    assert len(session.calls) == 6
    assert result["resolution_status"] == "lookup_failed"
    assert any(warning["reason"] == "database_limit" for warning in result["metadata_warnings"])


def test_denied_relevant_database_does_not_stop_next_database():
    from app.routers.upload import _qualified_upload_references
    class Caller(_Session):
        def sql(self, query, params):
            if "INFORMATION_SCHEMA" in query and params[0] == '"DENIED".INFORMATION_SCHEMA.TABLES':
                self.calls.append((query, params))
                raise RuntimeError("access denied")
            return super().sql(query, params)
    session = Caller(info_schema={"OK": [_info("OK", "RAW", "T")]})
    result = _qualified_upload_references(session, SETTINGS, project_id="p1", references=[("T", "source")],
                                         use_context={}, known_tables=["DENIED.S.X", "OK.S.X"])[0]
    assert result["resolved_fqn"] == "OK.RAW.T"
    assert result["catalog_status"] == "available"
    assert result["resolution_status"] == "resolved"
    assert len(session.calls) == 6


def test_route_deadline_is_not_reset_between_qualification_and_inspection(monkeypatch):
    import app.core.upload_reference_status as status
    from app.routers.upload import _qualified_upload_references
    now = [0.0]
    monkeypatch.setattr(status.time, "monotonic", lambda: now[0])
    class Caller(_Session):
        def sql(self, query, params):
            if query.startswith("DESCRIBE"):
                now[0] += 1
            return super().sql(query, params)
    session = Caller()
    result = _qualified_upload_references(session, SETTINGS, project_id="p1",
                                         references=[(f"DB.S.T{index}", "source") for index in range(9)],
                                         use_context={}, known_tables=[])
    assert len(session.calls) == 5
    assert all(item["catalog_status"] == "available" for item in result[:5])
    assert all(item["catalog_status"] == "lookup_failed" for item in result[5:])
    assert all(item["semantic_status"] == "lookup_failed" for item in result)


def test_late_reference_cap_does_not_erase_already_verified_fqns():
    from app.routers.upload import _qualified_upload_references
    session = _Session()
    result = _qualified_upload_references(session, SETTINGS, project_id="p1",
                                         references=[(f"DB.S.T{index:04}", "source") for index in reversed(range(210))],
                                         use_context={}, known_tables=[])
    assert len(session.calls) == 8
    assert all(item["catalog_status"] == "available" for item in result[:6])
    assert all(item["catalog_status"] == "lookup_failed" for item in result[6:])


def test_qualifier_inspector_share_one_caller_cache_for_duplicate_roles():
    from app.routers.upload import _qualified_upload_references
    session = _Session()
    result = _qualified_upload_references(
        session, SETTINGS, project_id="p1",
        references=[("DB.S.T", "source"), ("db.s.t", "target"), ("T", "source")],
        use_context={}, known_tables=["DB.S.T"],
    )
    assert [item["catalog_status"] for item in result] == ["available"] * 3
    assert [params for query, params in session.calls if query.startswith("DESCRIBE")] == [["DB.S.T"]]
    assert len(session.calls) == 3
    # A new request does not inherit the previous request's evidence.
    _qualified_upload_references(session, SETTINGS, project_id="p1", references=[("DB.S.T", "source")],
                                 use_context={}, known_tables=[])
    assert len(session.calls) == 6


def test_known_quoted_identity_survives_hint_parse_and_inspection():
    from app.routers.upload import _parse_known_tables, _qualified_upload_references, _table_ref_from_fqn
    import json
    fqn = '"Ft.Pitt"."Raw Data"."a.b"'
    hints = _parse_known_tables(json.dumps([fqn]))
    assert hints == [fqn]
    session = _Session()
    result = _qualified_upload_references(session, SETTINGS, project_id="p1",
                                         references=[('"a.b"', "source")], use_context={}, known_tables=hints)[0]
    assert result["resolved_fqn"] == fqn
    assert result["catalog_status"] == "available"
    assert session.calls[0] == ("DESCRIBE TABLE IDENTIFIER(?)", [fqn])
    table = _table_ref_from_fqn(fqn)
    assert (table.database, table.schema, table.table) == ("Ft.Pitt", "Raw Data", "a.b")


def test_unexpected_inspection_failure_keeps_verified_exact_evidence(monkeypatch):
    from app.routers import upload
    monkeypatch.setattr(upload, "inspect_upload_references", lambda *args, **kwargs: (_ for _ in ()).throw(RuntimeError("broken registry")))
    result = upload._qualified_upload_references(_Session(), SETTINGS, project_id="p1",
                                                references=[("DB.S.T", "source")], use_context={}, known_tables=[])[0]
    assert result["catalog_status"] == "available"
    assert result["resolution_status"] == "resolved"
    assert result["semantic_status"] == "lookup_failed"
    assert result["metadata_warnings"][0]["scope"] == "semantic"


def test_discovery_positive_evidence_is_reused_without_extra_describe():
    from app.routers.upload import _qualified_upload_references
    session = _Session(current_database="DB", info_schema={"DB": [_info("DB", "RAW", "T")]})
    result = _qualified_upload_references(session, SETTINGS, project_id="p1", references=[("T", "source")],
                                         use_context={}, known_tables=[])[0]
    assert result["resolved_fqn"] == "DB.RAW.T"
    assert result["catalog_status"] == "available"
    assert not any(query.startswith("DESCRIBE") for query, _ in session.calls)
    assert len(session.calls) == 6


def test_known_tables_with_wrong_schema_do_not_suppress_relevant_discovery():
    session = _Session(info_schema={"DB": [_info("DB", "RIGHT", "T")]})
    result = qualify_upload_references(session, SETTINGS, project_id="p1", references=[("RIGHT.T", "source")],
                                       known_tables=["DB.WRONG.T"])[0]
    assert result["resolved_fqn"] == "DB.RIGHT.T"
    assert any("INFORMATION_SCHEMA" in query for query, _ in session.calls)
