# R12 client AVD deployment

This is a cumulative overlay from the R7 baseline. It contains R8 through R12,
so it can also be extracted over the currently deployed R11 workspace.

R12 fixes:

- saved mappings retry backend hydration instead of leaving target columns empty;
- caller-rights semantic refresh no longer attempts request-time CREATE/ALTER DDL;
- oversized agent artifacts use a bounded inline fallback instead of repeatedly
  attempting an unavailable Snowflake stage;
- SQL upload explanations and SQL repair use `AI_COMPLETE` with legacy
  `SNOWFLAKE.CORTEX.COMPLETE` compatibility and deterministic fallback;
- normal deployment scripts do not add or attempt any new privilege grants.

## Deploy

1. Back up the client workspace and keep the existing
   `infra/snowflake/env/client.env` file.
2. Extract the ZIP at the repository root.
3. No new R12 tables or migrations are required. If R11 was already
   bootstrapped successfully, do not rerun metadata bootstrap for R12.
4. Rebuild and deploy the services. Do not use `-SkipBuild`, because R12 changes
   frontend and Python application code.

   ```powershell
   .\scripts\deploy_spcs_client_snow_safe.ps1 -EnvFile ".\infra\snowflake\env\client.env"
   ```

5. Wait for the services to become healthy and hard-refresh the browser.

The deploy command uses the same privilege behavior as before R12. It does not
attempt caller, stage, or Cortex grants.

## Expected fallback behavior

- A missing caller DDL privilege does not block semantic context preparation.
- Caller-mode artifact payloads up to 1 MiB remain inline. Larger payloads retain
  metadata without blocking Auto-map.
- If direct Cortex completion is unavailable to the UI caller, SQL upload still
  succeeds and displays deterministic structure-based wording.
- A procedure that can call Cortex remains independent of the direct UI caller
  path; wiring that procedure requires its exact name and parameter contract.

## Smoke test

1. Open an existing mapping and confirm target columns and mappings load.
2. Return to Selection, then reopen Mapping and confirm hydration still works.
3. Run Auto-map and confirm a missing artifact-stage grant does not cause repeated
   delays or fail the mapping job.
4. Upload a SQL file and confirm deterministic results always appear. If direct
   Cortex is available to the caller, confirm the richer explanation appears.
5. Confirm no grant statements are attempted during deployment.
