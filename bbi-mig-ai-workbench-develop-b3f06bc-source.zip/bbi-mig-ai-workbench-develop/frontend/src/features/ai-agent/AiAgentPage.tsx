"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import {
  AiaBox,
  AiaIconButton,
  AiaResizeHandle,
  AiaTooltip,
} from "@/components/ui";
import { AiaText } from "@/components/ui/aia-text";
import AIAgentPanel from "@/features/ai-agent/ai-agent-panel";
import { AiAgentEmptyState } from "@/features/ai-agent/ai-agent-empty-state";
import {
  AiAgentProjectTree,
  GENERAL_PROJECT_VALUE,
} from "@/features/ai-agent/ai-agent-project-tree";
import { AiAgentPageComposer } from "@/features/ai-agent/ai-agent-page-composer";
import { AiAgentProjectBrowseView } from "@/features/ai-agent/ai-agent-project-browse-view";
import { AI_AGENT_PAGE_CONTENT_MAX_WIDTH } from "@/features/ai-agent/ai-chat-layout-constants";
import { useAiChatLayout } from "@/features/ai-agent/ai-chat-layout-context";
import {
  loadAgentSessionsByProjectId,
  persistChatSessions,
  type StoredChatSession,
} from "@/features/ai-agent/ai-chat-session-utils";
import {
  useAiAgentSendApi,
} from "@/features/ai-agent/use-ai-agent-send";
import { AiAgentSendBridgeProvider } from "@/features/ai-agent/ai-agent-send-bridge";
import NewProjectModal from "@/features/projects/new-project-modal";
import { PROJECT_COLOR_OPTIONS } from "@/features/projects/project-color-options";
import type { ProjectItem } from "@/features/projects/projects-data";
import { useSttmBuilderContext } from "@/features/sttm/context/sttm-builder-context";
import {
  createProjectFromTemplate,
  listProjects,
  type ProjectRecord,
} from "@/services/projectService";
import {
  EditNoteRoundedIcon,
  KeyboardDoubleArrowLeftRoundedIcon,
  KeyboardDoubleArrowRightRoundedIcon,
} from "@/utils/icons";

const HISTORY_SIDEBAR_DEFAULT_WIDTH = 300;
const HISTORY_SIDEBAR_MIN_WIDTH = 220;
const HISTORY_SIDEBAR_MAX_WIDTH = 480;
const HISTORY_SIDEBAR_COLLAPSED_WIDTH = 70;
const HISTORY_SIDEBAR_WIDTH_STORAGE_KEY = "ai-agent-project-sidebar-width";
const HISTORY_SIDEBAR_COLLAPSED_STORAGE_KEY = "ai-agent-project-sidebar-collapsed";

const sidebarToggleButtonSx = {
  width: 32,
  height: 32,
  p: 0,
  color: "#64748B",
  border: "1px solid #DBE2EA",
  borderRadius: "50%",
  backgroundColor: "#FFFFFF",
  "&:hover": {
    backgroundColor: "#F8FAFC",
  },
} as const;

function loadHistorySidebarWidth() {
  if (typeof window === "undefined") return HISTORY_SIDEBAR_DEFAULT_WIDTH;
  try {
    const raw = window.localStorage.getItem(HISTORY_SIDEBAR_WIDTH_STORAGE_KEY);
    if (!raw) return HISTORY_SIDEBAR_DEFAULT_WIDTH;
    const parsed = Number(raw);
    if (!Number.isFinite(parsed)) return HISTORY_SIDEBAR_DEFAULT_WIDTH;
    return Math.min(
      HISTORY_SIDEBAR_MAX_WIDTH,
      Math.max(HISTORY_SIDEBAR_MIN_WIDTH, parsed),
    );
  } catch {
    return HISTORY_SIDEBAR_DEFAULT_WIDTH;
  }
}

function loadHistorySidebarCollapsed() {
  if (typeof window === "undefined") return false;
  try {
    return window.localStorage.getItem(HISTORY_SIDEBAR_COLLAPSED_STORAGE_KEY) === "1";
  } catch {
    return false;
  }
}

function hasUserChatMessages(messages: Array<{ role: string }>) {
  return messages.some((message) => message.role === "user");
}

function AiAgentPageContent() {
  const router = useRouter();
  const {
    sessions,
    activeSessionId,
    agentPageProjectId,
    setAgentPageProjectId,
    handleNewChat,
    handleSelectSession,
    renameSession,
    deleteSession,
  } = useAiChatLayout();
  const {
    chatMessages,
    activeProjectId,
    activeProjectName,
    setActiveProjectIdentity,
    session,
  } = useSttmBuilderContext();
  const { send, isLoading } = useAiAgentSendApi();

  const [projects, setProjects] = useState<ProjectRecord[]>([]);
  const [sessionsByProjectId, setSessionsByProjectId] = useState<
    Record<string, StoredChatSession[]>
  >({});
  const [sidebarWidth, setSidebarWidth] = useState(HISTORY_SIDEBAR_DEFAULT_WIDTH);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [isResizingSidebar, setIsResizingSidebar] = useState(false);
  const [draft, setDraft] = useState("");
  const [isNewProjectOpen, setIsNewProjectOpen] = useState(false);
  const [browsingProjectId, setBrowsingProjectId] = useState<string | null>(null);
  const pendingSessionRef = useRef<StoredChatSession | null>(null);
  const priorProjectRef = useRef<{
    projectId: string | null;
    projectName: string | null;
  } | null>(null);

  const refreshProjectSessions = (projectRows: ProjectRecord[]) => {
    setSessionsByProjectId(
      loadAgentSessionsByProjectId(
        session?.user_id != null ? String(session.user_id) : null,
        projectRows.map((project) => project.project_id),
      ),
    );
  };

  useEffect(() => {
    setSidebarWidth(loadHistorySidebarWidth());
    setSidebarCollapsed(loadHistorySidebarCollapsed());
  }, []);

  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      window.localStorage.setItem(
        HISTORY_SIDEBAR_WIDTH_STORAGE_KEY,
        String(sidebarWidth),
      );
    } catch {
      // Ignore storage write failures (private mode / quota).
    }
  }, [sidebarWidth]);

  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      window.localStorage.setItem(
        HISTORY_SIDEBAR_COLLAPSED_STORAGE_KEY,
        sidebarCollapsed ? "1" : "0",
      );
    } catch {
      // Ignore storage write failures (private mode / quota).
    }
  }, [sidebarCollapsed]);

  useEffect(() => {
    let cancelled = false;
    listProjects()
      .then((rows) => {
        if (cancelled) return;
        setProjects(rows);
        refreshProjectSessions(rows);
      })
      .catch(() => {
        if (cancelled) return;
        setProjects([]);
        refreshProjectSessions([]);
      });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps -- load once on mount; session user identity is stable for the page visit
  }, [session?.user_id]);

  const beginSidebarResize = useCallback(
    (event: React.MouseEvent<HTMLDivElement>) => {
      if (sidebarCollapsed) return;
      event.preventDefault();
      const startX = event.clientX;
      const startWidth = sidebarWidth;
      setIsResizingSidebar(true);

      const onMove = (moveEvent: MouseEvent) => {
        const next = Math.min(
          HISTORY_SIDEBAR_MAX_WIDTH,
          Math.max(
            HISTORY_SIDEBAR_MIN_WIDTH,
            startWidth + (moveEvent.clientX - startX),
          ),
        );
        setSidebarWidth(next);
      };

      const onUp = () => {
        setIsResizingSidebar(false);
        window.removeEventListener("mousemove", onMove);
        window.removeEventListener("mouseup", onUp);
      };

      window.addEventListener("mousemove", onMove);
      window.addEventListener("mouseup", onUp);
    },
    [sidebarCollapsed, sidebarWidth],
  );

  useEffect(() => {
    priorProjectRef.current = {
      projectId: activeProjectId,
      projectName: activeProjectName,
    };
    setAgentPageProjectId(GENERAL_PROJECT_VALUE);
    setActiveProjectIdentity({ projectId: null, projectName: null });
    return () => {
      setAgentPageProjectId(null);
      const prior = priorProjectRef.current;
      setActiveProjectIdentity({
        projectId: prior?.projectId ?? null,
        projectName: prior?.projectName ?? null,
      });
    };
    // Mount/unmount only: capture prior identity once, then clear agent override on leave.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [setAgentPageProjectId, setActiveProjectIdentity]);

  // Keep the selected project's branch in sync with live session list from layout context.
  useEffect(() => {
    const projectKey = agentPageProjectId ?? GENERAL_PROJECT_VALUE;
    setSessionsByProjectId((current) => ({
      ...current,
      [projectKey]: sessions,
    }));
  }, [agentPageProjectId, sessions]);

  // After switching project for a history click, select the pending session once scope reloads.
  useEffect(() => {
    const pending = pendingSessionRef.current;
    if (!pending) return;
    const match = sessions.find((item) => item.id === pending.id);
    if (!match) return;
    pendingSessionRef.current = null;
    handleSelectSession(match);
  }, [sessions, handleSelectSession]);

  const projectOptions = useMemo(
    () => [
      { label: "General", value: GENERAL_PROJECT_VALUE },
      ...projects.map((project) => ({
        label: project.project_name || project.project_id,
        value: project.project_id,
      })),
    ],
    [projects],
  );

  const selectedProjectId = agentPageProjectId ?? GENERAL_PROJECT_VALUE;
  const showEmptyState = !browsingProjectId && !hasUserChatMessages(chatMessages);
  const browsingProjectLabel =
    projectOptions.find((option) => option.value === browsingProjectId)?.label ?? "Project";
  const browsingProjectChats = useMemo(() => {
    if (!browsingProjectId) return [];
    return [...(sessionsByProjectId[browsingProjectId] ?? [])].sort(
      (a, b) => b.updatedAt - a.updatedAt,
    );
  }, [browsingProjectId, sessionsByProjectId]);

  const applyProjectSelection = (nextProjectId: string) => {
    const option = projectOptions.find((item) => item.value === nextProjectId);
    setAgentPageProjectId(nextProjectId);
    if (nextProjectId === GENERAL_PROJECT_VALUE) {
      setActiveProjectIdentity({ projectId: null, projectName: null });
    } else {
      setActiveProjectIdentity({
        projectId: nextProjectId,
        projectName: option?.label ?? null,
      });
    }
  };

  const handleSend = () => {
    if (send(draft)) {
      setBrowsingProjectId(null);
      setDraft("");
    }
  };

  const handleSendFromBrowse = () => {
    if (!browsingProjectId) return;
    const message = draft;
    if (!message.trim()) return;
    pendingSessionRef.current = null;
    if (browsingProjectId !== selectedProjectId) {
      applyProjectSelection(browsingProjectId);
    }
    setBrowsingProjectId(null);
    handleNewChat();
    if (send(message)) {
      setDraft("");
    }
  };

  const handleUseProject = (nextProjectId: string) => {
    if (!nextProjectId) return;
    pendingSessionRef.current = null;
    setBrowsingProjectId(null);
    if (nextProjectId !== selectedProjectId) {
      applyProjectSelection(nextProjectId);
      setDraft("");
    }
  };

  const handleViewProjectChats = (projectId: string) => {
    if (!projectId) return;
    pendingSessionRef.current = null;
    if (projectId !== selectedProjectId) {
      applyProjectSelection(projectId);
    }
    setBrowsingProjectId(projectId);
    setDraft("");
  };

  const handleNewChatUnderProject = (projectId: string) => {
    pendingSessionRef.current = null;
    setBrowsingProjectId(null);
    if (projectId !== selectedProjectId) {
      applyProjectSelection(projectId);
    }
    handleNewChat();
    setDraft("");
  };

  const handleSelectSessionUnderProject = (
    projectId: string,
    chatSession: StoredChatSession,
  ) => {
    setBrowsingProjectId(null);
    if (projectId === selectedProjectId) {
      handleSelectSession(chatSession);
      return;
    }
    pendingSessionRef.current = chatSession;
    applyProjectSelection(projectId);
  };

  const agentSessionScope = (projectId: string) =>
    `${session?.user_id != null ? String(session.user_id) : "anonymous"}::${projectId}::agent`;

  const handleRenameBrowseSession = (chatSession: StoredChatSession, title: string) => {
    if (!browsingProjectId) return;
    const nextTitle = title.trim();
    if (!nextTitle) return;

    if (browsingProjectId === selectedProjectId) {
      renameSession(chatSession.id, nextTitle);
      return;
    }

    setSessionsByProjectId((current) => {
      const list = current[browsingProjectId] ?? [];
      const next = list.map((item) =>
        item.id === chatSession.id
          ? { ...item, title: nextTitle, updatedAt: Date.now() }
          : item,
      );
      persistChatSessions(agentSessionScope(browsingProjectId), next);
      return { ...current, [browsingProjectId]: next };
    });
  };

  const handleDeleteBrowseSession = (chatSession: StoredChatSession) => {
    if (!browsingProjectId) return;

    if (browsingProjectId === selectedProjectId) {
      deleteSession(chatSession.id);
      return;
    }

    setSessionsByProjectId((current) => {
      const list = current[browsingProjectId] ?? [];
      const next = list.filter((item) => item.id !== chatSession.id);
      persistChatSessions(agentSessionScope(browsingProjectId), next);
      return { ...current, [browsingProjectId]: next };
    });
  };

  const handleCreateProject = async (project: ProjectItem) => {
    const color = PROJECT_COLOR_OPTIONS.find((option) => option.color === project.themeColor);
    try {
      const result = await createProjectFromTemplate({
        project_name: project.name,
        description: project.description,
        theme_color_id: color?.id,
        domain: project.domain,
        intended_outcome: project.intendedOutcome,
        business_process: project.businessProcess,
        owner: project.owner,
        linked_project_ids: project.linkedProjectIds,
        template_id: project.projectTemplateId || "CRM_MIGRATION",
        source_system_key: project.sourceSystemKey || "OTHER",
        bootstrap_mode: project.bootstrapMode || "AUTO",
        idempotency_key: project.bootstrapIdempotencyKey || `project-${Date.now()}`,
      });
      setProjects((current) => [result.project, ...current]);
      setSessionsByProjectId((current) => ({
        ...current,
        [result.project.project_id]: [],
      }));
      setIsNewProjectOpen(false);
      handleNewChatUnderProject(result.project.project_id);
    } catch (error) {
      if (process.env.NODE_ENV === "development") {
        console.warn("Project creation failed from AI Agent page.", error);
      }
    }
  };

  const displaySidebarWidth = sidebarCollapsed
    ? HISTORY_SIDEBAR_COLLAPSED_WIDTH
    : sidebarWidth;

  return (
    <AiaBox
      sx={{
        flex: 1,
        minHeight: 0,
        height: "100%",
        display: "flex",
        overflow: "hidden",
        backgroundColor: "#FFFFFF",
      }}
    >
      <AiaBox
        component="aside"
        aria-label="AI Agent projects and chats"
        sx={{
          width: displaySidebarWidth,
          minWidth: displaySidebarWidth,
          height: "100%",
          display: "flex",
          flexDirection: "column",
          borderRight: "1px solid #E8ECF4",
          backgroundColor: "#FAFBFC",
          overflow: "hidden",
          flexShrink: 0,
          transition: isResizingSidebar ? "none" : "width 160ms ease, min-width 160ms ease",
        }}
      >
        {sidebarCollapsed ? (
          <>
            <AiaBox
              sx={{
                flex: 1,
                minHeight: 0,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                pt: 2,
                gap: 1.5,
              }}
            >
              <AiaTooltip title="New chat" placement="right" arrow>
                <AiaIconButton
                  aria-label="New chat"
                  onClick={() => handleNewChatUnderProject(selectedProjectId)}
                  sx={{
                    width: 36,
                    height: 36,
                    color: "#64748B",
                    border: "1px solid #E2E8F0",
                    borderRadius: "50%",
                    backgroundColor: "#FFFFFF",
                    "&:hover": { backgroundColor: "#F8FAFC" },
                  }}
                >
                  <EditNoteRoundedIcon sx={{ fontSize: 18 }} />
                </AiaIconButton>
              </AiaTooltip>
            </AiaBox>
            <AiaBox
              sx={{
                py: 1,
                display: "flex",
                justifyContent: "center",
                width: "100%",
                flexShrink: 0,
                borderTop: "1px solid #EEF2F7",
                backgroundColor: "#FAFBFC",
              }}
            >
              <AiaTooltip title="Expand sidebar" placement="right" arrow>
                <AiaIconButton
                  aria-label="Expand sidebar"
                  onClick={() => setSidebarCollapsed(false)}
                  sx={sidebarToggleButtonSx}
                >
                  <KeyboardDoubleArrowRightRoundedIcon sx={{ fontSize: 18 }} />
                </AiaIconButton>
              </AiaTooltip>
            </AiaBox>
          </>
        ) : (
          <>
            <AiaBox sx={{ px: 1.5, pt: 2, pb: 1, flexShrink: 0 }}>
              <AiaBox
                component="button"
                type="button"
                onClick={() => {
                  handleNewChatUnderProject(selectedProjectId);
                }}
                sx={{
                  width: "100%",
                  display: "flex",
                  alignItems: "center",
                  gap: 1,
                  border: "none",
                  background: "transparent",
                  cursor: "pointer",
                  textAlign: "left",
                  borderRadius: "8px",
                  px: 0,
                  py: 0.85,
                  color: "#475569",
                  "&:hover": { backgroundColor: "#F3F4F6" },
                }}
              >
                <EditNoteRoundedIcon sx={{ fontSize: 18, color: "#64748B", flexShrink: 0 }} />
                <AiaText sx={{ fontSize: 13.5, fontWeight: 550, color: "#475569" }}>
                  New chat
                </AiaText>
              </AiaBox>
            </AiaBox>

            <AiAgentProjectTree
              projects={projects}
              sessionsByProjectId={sessionsByProjectId}
              selectedProjectId={selectedProjectId}
              activeSessionId={activeSessionId}
              onViewProjectChats={handleViewProjectChats}
              onSelectSession={handleSelectSessionUnderProject}
              onNewProject={() => setIsNewProjectOpen(true)}
              onNewChat={() => handleNewChatUnderProject(selectedProjectId)}
              onEditProject={(projectId) => {
                router.push(`/projects/${encodeURIComponent(projectId)}`);
              }}
            />

            <AiaBox
              sx={{
                px: 1.5,
                py: 1,
                display: "flex",
                justifyContent: "flex-start",
                width: "100%",
                flexShrink: 0,
                borderTop: "1px solid #EEF2F7",
                backgroundColor: "#FAFBFC",
              }}
            >
              <AiaIconButton
                aria-label="Collapse sidebar"
                onClick={() => setSidebarCollapsed(true)}
                sx={sidebarToggleButtonSx}
              >
                <KeyboardDoubleArrowLeftRoundedIcon sx={{ fontSize: 18 }} />
              </AiaIconButton>
            </AiaBox>
          </>
        )}
      </AiaBox>

      {!sidebarCollapsed ? (
        <AiaResizeHandle
          direction="horizontal"
          onMouseDown={beginSidebarResize}
          sx={{ alignSelf: "stretch", height: "100%", width: 6, minWidth: 6, flexShrink: 0 }}
        />
      ) : null}

      <AiaBox
        sx={{
          flex: 1,
          minWidth: 0,
          minHeight: 0,
          display: "flex",
          flexDirection: "column",
          backgroundColor: "#FFFFFF",
        }}
      >
        <AiaBox
          sx={{
            flex: 1,
            minHeight: 0,
            display: "flex",
            flexDirection: "column",
            position: "relative",
          }}
        >
          {browsingProjectId ? (
            <AiAgentProjectBrowseView
              projectId={browsingProjectId}
              projectLabel={browsingProjectLabel}
              sessions={browsingProjectChats}
              activeSessionId={activeSessionId}
              isUsingProject={browsingProjectId === selectedProjectId}
              canEditProject={browsingProjectId !== GENERAL_PROJECT_VALUE}
              composer={
                <AiAgentPageComposer
                  value={draft}
                  onChange={setDraft}
                  onSend={handleSendFromBrowse}
                  loading={isLoading}
                  placement="centered"
                  contentMaxWidth="100%"
                  placeholder={`Ask or build in ${browsingProjectLabel}...`}
                />
              }
              onSelectSession={(chatSession) =>
                handleSelectSessionUnderProject(browsingProjectId, chatSession)
              }
              onUseProject={() => handleUseProject(browsingProjectId)}
              onRenameSession={handleRenameBrowseSession}
              onDeleteSession={handleDeleteBrowseSession}
              onEditProject={
                browsingProjectId === GENERAL_PROJECT_VALUE
                  ? undefined
                  : () => router.push(`/projects/${encodeURIComponent(browsingProjectId)}`)
              }
            />
          ) : (
            <>
              <AiaBox
                sx={{
                  flex: 1,
                  minHeight: 0,
                  display: "flex",
                  flexDirection: "column",
                  width: "100%",
                  maxWidth: AI_AGENT_PAGE_CONTENT_MAX_WIDTH,
                  mx: "auto",
                  ...(showEmptyState
                    ? {
                        position: "absolute",
                        inset: 0,
                        opacity: 0,
                        pointerEvents: "none",
                      }
                    : {}),
                }}
              >
                <AIAgentPanel
                  variant="sidebar"
                  expanded
                  hideComposer
                  draft={draft}
                  onDraftChange={setDraft}
                />
              </AiaBox>
              {showEmptyState ? (
                <AiAgentEmptyState
                  userName={session?.display_name || session?.email || null}
                  onSelectPrompt={setDraft}
                >
                  <AiAgentPageComposer
                    value={draft}
                    onChange={setDraft}
                    onSend={handleSend}
                    loading={isLoading}
                    placement="centered"
                  />
                </AiAgentEmptyState>
              ) : null}
            </>
          )}
        </AiaBox>

        {!browsingProjectId && !showEmptyState ? (
          <AiAgentPageComposer
            value={draft}
            onChange={setDraft}
            onSend={handleSend}
            loading={isLoading}
          />
        ) : null}
      </AiaBox>

      <NewProjectModal
        open={isNewProjectOpen}
        onClose={() => setIsNewProjectOpen(false)}
        onCreate={handleCreateProject}
      />
    </AiaBox>
  );
}

export default function AiAgentPage() {
  return (
    <AiAgentSendBridgeProvider>
      <AiAgentPageContent />
    </AiAgentSendBridgeProvider>
  );
}
