import type { ProjectAttributeRecord } from '@/services/projectService';

const NUMERIC_FIRM_VALUE_TYPES = new Set(['INT', 'BIGINT', 'NUMBER', 'DECIMAL', 'FLOAT', 'DOUBLE']);

/**
 * SQL literal for a firm value, inserted when it is clicked: numbers as-is, booleans as
 * TRUE/FALSE, everything else single-quoted (with embedded quotes escaped).
 */
export function firmValueLiteral(value: string | null | undefined, type: string | null | undefined) {
  const raw = String(value ?? '').trim();
  const baseType = String(type ?? '').trim().toUpperCase().split('(')[0];
  if (NUMERIC_FIRM_VALUE_TYPES.has(baseType) && raw !== '' && Number.isFinite(Number(raw))) {
    return raw;
  }
  if (baseType === 'BOOLEAN' && /^(true|false)$/i.test(raw)) {
    return raw.toUpperCase();
  }
  return `'${String(value ?? '').replace(/'/g, "''")}'`;
}

/** Matches the literal as a whole token, capturing the preceding character. */
export function firmValueLiteralPattern(literal: string, flags = '') {
  const escaped = literal.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return new RegExp(`(^|[^A-Za-z0-9_.'])${escaped}(?![A-Za-z0-9_.'])`, flags);
}

/**
 * Names to show for a saved rule.
 * A remembered selection wins. A rule saved before that only has the value, so every
 * name that stores that value still matches.
 */
export function firmValueNamesForMapping(
  expression: string | null | undefined,
  firmValues: ProjectAttributeRecord[],
  selectedNames?: string[] | null,
): string[] {
  if (selectedNames == null) {
    return firmValueNamesInExpression(expression, firmValues);
  }
  const chosen = new Set(
    selectedNames.map((name) => name.trim().toUpperCase()).filter(Boolean),
  );
  return firmValues
    .filter((attribute) => chosen.has(attribute.attribute_name.trim().toUpperCase()))
    .filter((attribute) =>
      sqlUsesFirmValuePlaceholder(expression, attribute.attribute_name)
      || firmValueLiteralPattern(
        firmValueLiteral(attribute.attribute_value, attribute.attribute_type),
      ).test(expression ?? ''),
    )
    .map((attribute) => attribute.attribute_name);
}

function escapeRegExp(value: string) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/** `$ABC` written into SQL when that firm value is ticked. */
export function firmValuePlaceholder(name: string) {
  return `$${String(name ?? '').trim().replace(/^\$/, '')}`;
}

/** `$ABC` as a SQL token, not inside a longer name. */
export function firmValuePlaceholderPattern(name: string, flags = '') {
  const token = escapeRegExp(name.trim().replace(/^\$/, ''));
  return new RegExp(`(^|[^A-Za-z0-9_$])\\$${token}(?![A-Za-z0-9_$])`, flags);
}

export function sqlUsesFirmValuePlaceholder(sql: string | null | undefined, name: string) {
  if (!sql?.trim() || !name.trim()) return false;
  return firmValuePlaceholderPattern(name, 'i').test(sql);
}

/** Rewrite `$ABC` to `$ABC_NEW`. Leaves a bare number `100` alone. */
export function rewriteFirmValuePlaceholder(
  sql: string,
  previousName: string,
  nextName: string,
) {
  const fromName = previousName.trim().replace(/^\$/, '');
  const toName = nextName.trim().replace(/^\$/, '');
  if (!sql || !fromName || !toName) return sql;
  return sql.replace(firmValuePlaceholderPattern(fromName, 'gi'), `$1$${toName}`);
}

function namesEqual(left: string | null | undefined, right: string | null | undefined) {
  return (left ?? '').trim().toUpperCase() === (right ?? '').trim().toUpperCase();
}

export function followFirmValueNames(
  names: string[] | null | undefined,
  previousName: string,
  nextName: string,
): string[] | null | undefined {
  if (names == null) return names;
  const fromName = previousName.trim();
  const toName = nextName.trim();
  if (!fromName || !toName) return names;
  return names.map((name) => (namesEqual(name, fromName) ? toName : name));
}

/**
 * Follow a known firm-value edit in saved SQL.
 * `$ABC` always follows. The number `100` follows only when this row remembered ABC.
 */
export function followFirmValueInSql(
  sql: string | null | undefined,
  note: {
    previousName: string;
    nextName: string;
    previousValue?: string;
    nextValue?: string;
    previousType?: string | null;
    nextType?: string | null;
  },
  selectedNames?: string[] | null,
): string | null | undefined {
  if (sql == null) return sql;
  let next = rewriteFirmValuePlaceholder(sql, note.previousName, note.nextName);
  const remembered = (selectedNames ?? []).some((name) =>
    namesEqual(name, note.previousName) || namesEqual(name, note.nextName),
  );
  if (remembered && note.previousValue != null && note.nextValue != null) {
    const previousLiteral = firmValueLiteral(note.previousValue, note.previousType);
    const nextLiteral = firmValueLiteral(note.nextValue, note.nextType);
    if (previousLiteral !== nextLiteral) {
      next = next.replace(firmValueLiteralPattern(previousLiteral, 'g'), `$1${nextLiteral}`);
    }
  }
  return next;
}

/** Names of the firm values whose literal appears in a pre-processing expression. */
export function firmValueNamesInExpression(
  expression: string | null | undefined,
  firmValues: ProjectAttributeRecord[],
): string[] {
  if (!expression?.trim() || !firmValues.length) return [];
  const seen = new Set<string>();
  const names: string[] = [];
  for (const attribute of firmValues) {
    const key = attribute.attribute_name.trim().toUpperCase();
    if (seen.has(key)) continue;
    const usesPlaceholder = sqlUsesFirmValuePlaceholder(expression, attribute.attribute_name);
    const usesLiteral = firmValueLiteralPattern(
      firmValueLiteral(attribute.attribute_value, attribute.attribute_type),
    ).test(expression);
    if (!usesPlaceholder && !usesLiteral) continue;
    seen.add(key);
    names.push(attribute.attribute_name);
  }
  return names;
}
