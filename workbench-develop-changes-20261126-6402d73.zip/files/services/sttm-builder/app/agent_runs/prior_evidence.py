"""Carry verified, caller-owned run evidence into a new conversation turn."""
from typing import Any
from app.agent_tools.contract_reader import normalize_fqn
from app.agent_tools.catalog_discovery import authorized_scope, identifier_parts

_PRIOR_EVIDENCE_EVENT_TYPES = frozenset({"tool.completed", "tool.reused", "workspace.synced", "run.ready_for_review"})


def _prior_run_evidence(events: list[Any], *, limit: int = 16) -> list[dict[str, Any]]:
    """Carry sanitized durable evidence into a follow-up without replaying tools."""
    evidence: list[dict[str, Any]] = []
    verified_tables: set[str] = set()

    def collect_tables(value: Any, key: str = "") -> None:
        if isinstance(value, dict):
            for child_key, child in value.items():
                collect_tables(child, str(child_key).casefold())
        elif isinstance(value, list):
            for child in value:
                collect_tables(child, key)
        elif key in {"table", "table_fqn", "source_table", "target_table", "candidates"}:
            candidate = normalize_fqn(value)
            if len(identifier_parts(candidate)) == 3:
                verified_tables.add(candidate)

    for event in events:
        if event.event_type not in _PRIOR_EVIDENCE_EVENT_TYPES:
            continue
        data = dict(event.data or {})
        if str(event.status or "").lower() in {"succeeded", "completed", "ready_for_review"}:
            collect_tables(data.get("result_preview"))
        evidence.append({
            "event_type": event.event_type,
            "capability": data.get("label") or data.get("tool") or event.safe_summary,
            "sanitized_input": data.get("sanitized_input") or {},
            "result_preview": data.get("result_preview"),
            "evidence_refs": list(data.get("evidence_refs") or []),
            "artifact_refs": list(event.artifact_refs or []),
        })
    retained = evidence[-limit:]
    if verified_tables:
        retained.append({
            "event_type": "verified.catalog_scope",
            "capability": "Server-verified catalog scope from the preceding run",
            "result_preview": {"candidates": sorted(verified_tables)},
            "sanitized_input": {}, "evidence_refs": [], "artifact_refs": [],
        })
    return retained


def summarize_related_plans(
    artifacts: list[dict[str, Any]], target: str, context: dict[str, Any],
    *, internal_tables: set[tuple[str, ...]],
) -> list[dict[str, Any]]:
    """Project saved plans into design leads without copying their executable content."""
    results = []

    def eligible(table: str) -> bool:
        parts = tuple(identifier_parts(table))
        return (
            len(parts) == 3 and table != target and parts not in internal_tables
            and authorized_scope(table, context)
        )

    def identifier(value: Any) -> str:
        return normalize_fqn(value) if len(identifier_parts(value)) == 1 else ""

    for artifact in artifacts[:3]:
        design = artifact.get("source_preparation")
        if not isinstance(design, dict):
            continue
        driver = normalize_fqn(design.get("driving_source"))
        sources = list(dict.fromkeys([
            driver, *(normalize_fqn(value) for value in design.get("supporting_sources") or []),
        ]))
        if len(sources) > 8 or not all(eligible(table) for table in sources):
            continue
        joins = []
        for relationship in (design.get("relationships") or [])[:12]:
            if not isinstance(relationship, dict):
                continue
            left, right = (normalize_fqn(relationship.get(f"{side}_table")) for side in ("left", "right"))
            if left not in sources or right not in sources:
                continue
            conditions = []
            for condition in relationship.get("conditions") or []:
                if not isinstance(condition, dict):
                    break
                left_column, right_column = (identifier(condition.get(f"{side}_column")) for side in ("left", "right"))
                operator = condition.get("operator") or "="
                if not left_column or not right_column or operator not in ("=", "!=", "<>", "<", "<=", ">", ">="):
                    break
                conditions.append({"left_column": left_column, "right_column": right_column, "operator": operator})
            join_type = str(relationship.get("join_type") or "").upper()
            if 0 < len(conditions) <= 8 and len(conditions) == len(relationship["conditions"]):
                joins.append({
                    "left_table": left, "right_table": right, "conditions": conditions,
                    "join_type": join_type if join_type in {"INNER", "LEFT", "RIGHT", "FULL"} else None,
                })
        results.append({
            "run_id": artifact.get("run_id"),
            "project_id": artifact.get("project_id"),
            "plan_id": artifact.get("plan_id"),
            "revision": artifact.get("revision"),
            "status": artifact.get("status"),
            "target_table": target,
            "driving_source": driver,
            "supporting_sources": sources[1:],
            "join_candidates": joins,
            "cte_names": [
                name for item in (design.get("derived_sources") or [])[:8]
                if isinstance(item, dict) and (name := identifier(item.get("name")))
            ],
        })
    return results
