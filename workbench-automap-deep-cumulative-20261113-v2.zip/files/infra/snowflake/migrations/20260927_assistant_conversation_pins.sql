-- Chat organization metadata. Project assignment and title already exist.
ALTER TABLE IF EXISTS TBL_ASSISTANT_CONVERSATIONS
  ADD COLUMN IF NOT EXISTS PINNED BOOLEAN DEFAULT FALSE;
