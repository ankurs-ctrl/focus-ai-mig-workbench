"""Durable acceptance, caller isolation and stale-generation publication."""
import copy
import json
import threading
from concurrent.futures import ThreadPoolExecutor
from types import SimpleNamespace
import pytest
from app.core.sql_upload_jobs import SqlUploadJobs, fingerprint
from app.core.config import Settings

class Database:
    def __init__(self):
        self.rows=[]
        self.lock=threading.RLock()

class Session:
    def __init__(self, db, caller='alice', role='WORKBENCH'):
        self.db=db; self.caller=caller; self.role=role; self.statements=[]
    def sql(self, query, params=None):
        params=params or []
        self.statements.append(query)
        def collect(**kwargs):
            if query=='BEGIN TRANSACTION': self.db.lock.acquire(); return []
            if query in {'COMMIT','ROLLBACK'}: self.db.lock.release(); return []
            if "REQUEST_ID='__admission_lock__'" in query: return [{'updated':1}]
            mine=[row for row in self.db.rows if row['REQUESTED_BY']==self.caller and row['REQUESTED_ROLE']==self.role]
            if query.startswith('SELECT *'):
                return [copy.deepcopy(row) for row in mine if row['REQUEST_ID']==params[0] and row['PROJECT_ID']==params[1]]
            if query.startswith('SELECT REQUEST_ID'):
                return [{'REQUEST_ID':row['REQUEST_ID']} for row in reversed(mine)
                    if row['PROJECT_ID']==params[0] and row['CONTENT_IDENTITY']==params[1]
                    and row['STATUS'] in {'queued','running','preview_ready','completed'}
                    and not row['REQUEST_PAYLOAD'].get('reuse_request_id')][:1]
            if query.startswith('MERGE'):
                request,project,identity,version,processing_id,payload=params
                self.db.rows.append(dict(REQUEST_ID=request,PROJECT_ID=project,CONTENT_IDENTITY=identity,
                    PROCESSOR_VERSION=version,PROCESSING_ID=processing_id,REQUESTED_BY=self.caller,REQUESTED_ROLE=self.role,
                    REQUEST_PAYLOAD=json.loads(payload),STATUS='queued',GENERATION=0))
                return [{'inserted':1}]
            if "SET STATUS='running'" in query:
                token,request,project=params
                matches=[row for row in mine if row['REQUEST_ID']==request and row['PROJECT_ID']==project
                    and (row['STATUS']=='queued' or row.get('expired'))]
                for row in matches: row.update(STATUS='running',LEASE_TOKEN=token,GENERATION=row['GENERATION']+1,expired=False)
                return [{'updated':len(matches)}]
            if 'SET STATUS=?, STAGE=?' in query:
                status,stage,result,error,request,project,generation,token=params
                matches=[row for row in mine if row['REQUEST_ID']==request and row['PROJECT_ID']==project
                    and row['GENERATION']==generation and row['LEASE_TOKEN']==token
                    and not row.get('expired') and row['STATUS'] in {'running','preview_ready'}]
                for row in matches:
                    row.update(STATUS=status,STAGE=stage,ERROR_CODE=error)
                    if result is not None: row['RESULT_PAYLOAD']=json.loads(result)
                return [{'updated':len(matches)}]
            raise AssertionError(query)
        return SimpleNamespace(collect=collect)

def service(db=None, caller='alice', role='WORKBENCH'):
    return SqlUploadJobs(Session(db or Database(),caller,role), Settings())

def accept(jobs, request='request-123456789', project='501', options=None):
    return jobs.accept(request_id=request,project_id=project,
        identity=fingerprint(b'SELECT 1',project, options or {}),payload={'sql_text':'SELECT 1'})

def test_fingerprint_binds_content_project_processor_and_options(monkeypatch):
    import app.core.sql_upload_jobs as module
    base=fingerprint(b'SELECT 1','501',{})
    assert base==fingerprint(b'SELECT 1','501',{})
    assert base!=fingerprint(b'SELECT 2','501',{})
    assert base!=fingerprint(b'SELECT 1','502',{})
    assert base!=fingerprint(b'SELECT 1','501',{'target':'D.S.T'})
    monkeypatch.setattr(module,'PROCESSOR_VERSION','new-processor')
    assert base!=fingerprint(b'SELECT 1','501',{})

def test_concurrent_identical_uploads_admit_one_logical_processor():
    db=Database()
    def submit(i): return accept(service(db),f'request-{i:016d}')
    with ThreadPoolExecutor(max_workers=6) as pool: rows=list(pool.map(submit,range(6)))
    roots=[row for row in rows if not row['REQUEST_PAYLOAD'].get('reuse_request_id')]
    assert len(roots)==1
    assert all(row['REQUEST_PAYLOAD'].get('reuse_request_id',row['REQUEST_ID'])==roots[0]['REQUEST_ID'] for row in rows)
    assert service(db).claim(roots[0]['REQUEST_ID'],'501')
    assert service(db).claim(roots[0]['REQUEST_ID'],'501') is None

def test_disconnect_and_restart_retrieve_saved_preview_without_new_post():
    db=Database(); first=service(db); row=accept(first)
    claimed=first.claim(row['REQUEST_ID'],'501')
    first.save(claimed,status='preview_ready',result={'asset_id':'asset','parsed_summary':{'ctes':[1]}})
    restarted=service(db)
    restored=restarted.get(row['REQUEST_ID'],'501')
    assert restored['RESULT_PAYLOAD']['parsed_summary']['ctes']==[1]
    assert len(db.rows)==1
    assert restarted.claim(row['REQUEST_ID'],'501') is None  # do not replay a live worker

def test_wrong_project_caller_and_role_cannot_retrieve_upload():
    db=Database(); jobs=service(db); row=accept(jobs)
    assert jobs.get(row['REQUEST_ID'],'502') is None
    assert service(db,'bob').get(row['REQUEST_ID'],'501') is None
    assert service(db,role='OTHER').get(row['REQUEST_ID'],'501') is None
    assert service(db,'bob').claim(row['REQUEST_ID'],'501') is None

def test_failed_generation_is_preserved_and_explicit_reupload_gets_fresh_run():
    jobs=service(); old=accept(jobs); claimed=jobs.claim(old['REQUEST_ID'],'501')
    jobs.save(claimed,status='failed',error='learning_failed',result={'asset_id':'saved'})
    new=accept(jobs,'request-fresh123456')
    assert 'reuse_request_id' not in new['REQUEST_PAYLOAD']
    assert jobs.get(old['REQUEST_ID'],'501')['ERROR_CODE']=='learning_failed'
    assert jobs.get(old['REQUEST_ID'],'501')['RESULT_PAYLOAD']=={'asset_id':'saved'}
    assert jobs.claim(old['REQUEST_ID'],'501') is None

def test_compatible_completed_work_reuses_result_and_changed_context_does_not():
    jobs=service(); row=accept(jobs); claimed=jobs.claim(row['REQUEST_ID'],'501')
    jobs.save(claimed,status='completed',result={'asset_id':'saved'})
    alias=accept(jobs,'request-complete123')
    assert alias['REQUEST_PAYLOAD']['reuse_request_id']==row['REQUEST_ID']
    changed=accept(jobs,'request-changed1234',options={'target':'D.S.OTHER'})
    assert 'reuse_request_id' not in changed['REQUEST_PAYLOAD']

def test_stale_worker_cannot_publish_after_recovery_generation_claim():
    jobs=service(); row=accept(jobs); old=jobs.claim(row['REQUEST_ID'],'501')
    jobs.session.db.rows[0]['expired']=True
    new=jobs.claim(row['REQUEST_ID'],'501')
    assert new['GENERATION']==old['GENERATION']+1
    with pytest.raises(RuntimeError,match='stale delivery rejected'):
        jobs.save(old,status='completed',result={'wrong':'late'})
    jobs.save(new,status='completed',result={'correct':'current'})
    assert jobs.get(row['REQUEST_ID'],'501')['RESULT_PAYLOAD']=={'correct':'current'}

def test_identity_reuse_with_different_options_is_rejected():
    jobs=service(); accept(jobs)
    with pytest.raises(ValueError,match='different content or options'): accept(jobs,options={'target':'other'})


def test_durable_route_accepts_before_parse_learning_or_metadata_work(monkeypatch):
    import asyncio
    from io import BytesIO
    from unittest.mock import Mock
    from fastapi import BackgroundTasks, UploadFile
    from app.routers import upload
    db=Database(); session=Session(db)
    forbidden=Mock(side_effect=AssertionError('Foreground must only durably accept'))
    monkeypatch.setattr(upload,'_prepare_sql_upload',forbidden)
    tasks=BackgroundTasks()
    response=asyncio.run(upload.upload_sql(background_tasks=tasks,
        client=SimpleNamespace(session=session), settings=Settings(), semantic_service=Mock(),project_service=Mock(),
        file=UploadFile(filename='test.sql',file=BytesIO(b'SELECT 1')),project_id='501',upload_request_id='request-route12345',
        mode='auto_populate',source_table_hints='',target_table_hint='',workspace_context='',import_behavior='preview',
        sttm_id='',expected_target_table='',logical_target_key='',source_system_key='',known_tables='',session_lease=Mock()))
    assert response.status_code==202
    assert json.loads(response.body)['status']=='queued'
    assert len(db.rows)==1 and db.rows[0]['REQUEST_PAYLOAD']['sql_text']=='SELECT 1'
    forbidden.assert_not_called()
    assert len(tasks.tasks)==1
    assert session.statements[-1]=='COMMIT'


@pytest.mark.parametrize('fail_background',[False,True],ids=['ready','enrichment-fails'])
def test_worker_releases_prepare_lease_before_background_and_preserves_preview(monkeypatch,fail_background):
    from contextlib import contextmanager
    from app.routers import upload
    db=Database(); jobs=service(db); row=accept(jobs)
    db.rows[0]['REQUEST_PAYLOAD']={'sql_text':'SELECT 1','filename':'fixture.sql','options':{}}
    leases=[]
    @contextmanager
    def lease():
        assert not leases, 'A pool of size one must not require nested leases'
        leases.append(1)
        try: yield SimpleNamespace(session=Session(db))
        finally: leases.pop()
    observed=[]
    def background():
        with lease():
            observed.append(service(db).get(row['REQUEST_ID'],'501')['RESULT_PAYLOAD'])
            if fail_background: raise RuntimeError('background failed')
        return {'verification_status':'ready','learning_job_id':'new-job','learning_status':'queued','failures':[]}
    def prepare(**kwargs):
        assert kwargs['processing_generation']==row['PROCESSING_ID']
        kwargs['background_tasks'].add_task(background)
        return {'asset_id':'saved','learning_coverage':{}}
    monkeypatch.setattr(upload,'_prepare_sql_upload',prepare)
    upload._resume_sql_upload_job(session_lease=lease,settings=Settings(),request_id=row['REQUEST_ID'],project_id='501')
    saved=service(db).get(row['REQUEST_ID'],'501')
    assert observed[0]['asset_id']=='saved'  # Persisted before optional work starts.
    assert saved['RESULT_PAYLOAD']['asset_id']=='saved'
    assert saved['STATUS']==('failed' if fail_background else 'completed')
    assert not leases


def test_verification_continuation_reuses_learning_generation(monkeypatch):
    from contextlib import contextmanager
    from app.routers import upload
    db=Database(); jobs=service(db); row=accept(jobs)
    db.rows[0]['REQUEST_PAYLOAD']={'sql_text':'SELECT 1','filename':'fixture.sql','options':{}}
    @contextmanager
    def lease(): yield SimpleNamespace(session=Session(db))
    generations=[]
    def prepare(**kwargs):
        generations.append(kwargs['processing_generation'])
        kwargs['background_tasks'].add_task(lambda:{'verification_status':'incomplete' if len(generations)==1 else 'ready',
            'learning_job_id':'same-job','learning_status':'queued','failures':[]})
        return {'asset_id':'saved','learning_coverage':{}}
    monkeypatch.setattr(upload,'_prepare_sql_upload',prepare)
    for _ in range(2):
        upload._resume_sql_upload_job(session_lease=lease,settings=Settings(),request_id=row['REQUEST_ID'],project_id='501')
    saved=service(db).get(row['REQUEST_ID'],'501')
    assert saved['STATUS']=='completed'
    assert saved['RESULT_PAYLOAD']['learning_job_id']=='same-job'
    assert generations==[row['PROCESSING_ID']]*2


def test_learning_action_waits_for_this_upload_job_instead_of_reusing_old_failure(monkeypatch):
    import asyncio
    from fastapi import BackgroundTasks,HTTPException
    from unittest.mock import Mock
    from app.routers import upload
    jobs=Mock(); jobs.get.return_value={'RESULT_PAYLOAD':{'asset_id':'asset','learning_job_id':None}}
    monkeypatch.setattr(upload,'SqlUploadJobs',Mock(return_value=jobs))
    patterns=Mock(side_effect=AssertionError('Do not choose the latest failed asset job'))
    monkeypatch.setattr(upload,'TargetMappingPatternService',patterns)
    with pytest.raises(HTTPException) as error:
        asyncio.run(upload.trigger_learning(background_tasks=BackgroundTasks(),client=Mock(),agent_client=Mock(),
            settings=Settings(),asset_id='asset',project_id='501',approved_project_values='',upload_request_id='request-123456789'))
    assert error.value.status_code==409
    patterns.assert_not_called()


def test_learning_action_uses_exact_current_job_and_independent_lease(monkeypatch):
    import asyncio
    from fastapi import BackgroundTasks
    from unittest.mock import Mock
    from app.schema.fir_patterns import FIRLearningJobResponse
    from app.routers import upload
    jobs=Mock(); jobs.get.return_value={'RESULT_PAYLOAD':{'asset_id':'asset','learning_job_id':'new-job'}}
    monkeypatch.setattr(upload,'SqlUploadJobs',Mock(return_value=jobs))
    patterns=Mock(); patterns.get_job.return_value=FIRLearningJobResponse(learning_job_id='new-job',
        asset_id='asset',project_id='501',status='running')
    monkeypatch.setattr(upload,'TargetMappingPatternService',Mock(return_value=patterns))
    monkeypatch.setattr(upload,'enqueue_fir_document_event',Mock())
    client=Mock();client.session.sql.return_value.collect.return_value=[{'SQL_ASSET_ID':'asset','ATTRIBUTES':{}}]
    tasks=BackgroundTasks();lease=Mock()
    result=asyncio.run(upload.trigger_learning(background_tasks=tasks,client=client,agent_client=Mock(),
        settings=SimpleNamespace(fir_durable_jobs_v2=True),asset_id='asset',project_id='501',approved_project_values='',
        upload_request_id='request-123456789',session_lease=lease))
    assert result['learning_job_id']=='new-job'
    patterns.get_latest_job_for_asset.assert_not_called()
    assert tasks.tasks[0].func is upload._drain_fir_learning_on_lease
    assert tasks.tasks[0].kwargs['session_lease'] is lease


def test_same_browser_identity_across_callers_has_distinct_server_processing_identity():
    db=Database()
    alice=accept(service(db,'alice'))
    bob=accept(service(db,'bob'),options={'target':'different-context'})
    assert alice['REQUEST_ID']==bob['REQUEST_ID']
    assert alice['PROCESSING_ID']!=bob['PROCESSING_ID']


def test_processor_change_does_not_present_old_completed_work_as_current(monkeypatch):
    import app.core.sql_upload_jobs as module
    jobs=service(); row=accept(jobs); claimed=jobs.claim(row['REQUEST_ID'],'501')
    jobs.save(claimed,status='completed',result={'asset_id':'old-result'})
    saved=jobs.get(row['REQUEST_ID'],'501')
    monkeypatch.setattr(module,'PROCESSOR_VERSION','new-processor')
    public=jobs.public(saved)
    assert public['status']=='needs_reupload' and public['result'] is None
    assert saved['RESULT_PAYLOAD']['asset_id']=='old-result'
    newer=accept(jobs,'request-upgrade123')
    assert newer['PROCESSOR_VERSION']=='new-processor'
    assert 'reuse_request_id' not in newer['REQUEST_PAYLOAD']
