"""Bounded, snapshot-local candidate scans; no mapping decisions or integration.

The trusted caller supplies scope, explicit target IDs, a backend, and admission.
Admission MUST return a context manager yielding exactly True after acquiring a
real permit; denial, acquisition failure, or a missing adapter fails closed. It
must honor request.check_active()/remaining_seconds() while waiting. The permit
stays held until the backend exits, even when the coordinator has timed out.
There is deliberately no default semaphore or distributed-admission substitute.

The backend receives the registry's checked message unchanged and must make at
most ONE agent call, without hidden retries. For prepared scan contexts, message
is the serialized normalized Agent messages array: deserialize it as messages,
never wrap it in another user message or append prompt content. Transport
timeout/cancellation and response-size limits must also be enforced there. Python cannot kill a running
thread: a stopped scan returns immutable coverage without waiting for such calls,
but those threads can outlive the scan (and delay interpreter shutdown).

The registry builder must include the scan instructions, target context and output
contract in its complete checked message. Request metadata is not permission to
append unbudgeted prompt text. A stable, thread-safe builder/backend/admission and
an authenticated caller scope are integration prerequisites, not supplied here.
Source eligibility requires checked records with kind="source_column" and a
body object containing eligible=true; generic registries have no allow-all fallback.
"""
from __future__ import annotations

from collections.abc import Callable
from concurrent.futures import FIRST_COMPLETED, Future, ThreadPoolExecutor, wait
from contextlib import AbstractContextManager
from dataclasses import dataclass, field
from enum import Enum
import hashlib
import json
import math
from threading import Event
import time
from typing import TypeAlias

from app.core.automap_shards import MessageBudget, ShardRegistry, SnapshotScope


class ScanStatus(str, Enum):
    SUCCEEDED = "succeeded"
    CANCELED = "canceled"
    TIMED_OUT = "timed_out"
    CALL_BUDGET_EXHAUSTED = "call_budget_exhausted"
    READ_FAILED = "read_failed"
    DISPATCH_FAILED = "dispatch_failed"
    ADMISSION_FAILED = "admission_failed"
    BACKEND_FAILED = "backend_failed"
    INVALID_RESPONSE = "invalid_response"
    OUTPUT_BUDGET_EXCEEDED = "output_budget_exceeded"


class CandidateRole(str, Enum):
    SOURCE = "source"
    JOIN = "join"
    FILTER = "filter"
    GRAIN = "grain"
    TRANSFORMATION = "transformation"
    RECIPE = "recipe"
    CONSTRAINT = "constraint"


@dataclass(frozen=True)
class ScanCandidate:
    record_id: str
    role: CandidateRole
    evidence_refs: tuple[str, ...]


@dataclass(frozen=True)
class TargetCandidates:
    target_id: str
    candidates: tuple[ScanCandidate, ...]


@dataclass(frozen=True)
class ShardScanResult:
    scope: SnapshotScope
    generation: str
    shard_id: str
    target_ids: tuple[str, ...]
    status: ScanStatus
    targets: tuple[TargetCandidates, ...] = ()
    error_code: str | None = None
    # True means a slot was consumed, not proof that a network call began.
    call_reserved: bool = False


@dataclass(frozen=True)
class ScanWarning:
    """Scoped source IDs and counts only; never excluded or exception bodies."""

    error_code: str
    group_id: str | None
    table_id: str | None
    shard_id: str | None
    scope_hash: str
    record_count: int
    char_count: int
    byte_count: int
    affected_target_ids: tuple[str, ...]

    @property
    def source_id(self) -> str:
        return self.group_id if self.group_id is not None else self.shard_id


@dataclass(frozen=True)
class ScanCoverage:
    expected_shards: int
    succeeded_shards: int
    plan_complete: bool
    excluded_group_count: int
    excluded_record_count: int
    incomplete_target_ids: tuple[str, ...]
    warnings: tuple[ScanWarning, ...]

    @property
    def complete_coverage(self) -> bool:
        return self.plan_complete and self.succeeded_shards == self.expected_shards

    @property
    def blocked_group_ids(self) -> tuple[str, ...]:
        return tuple(warning.group_id for warning in self.warnings if warning.group_id is not None)

    @property
    def blocked_table_ids(self) -> tuple[str, ...]:
        return tuple(warning.table_id for warning in self.warnings if warning.table_id is not None)


@dataclass(frozen=True)
class ScanResult:
    scope: SnapshotScope
    generation: str
    target_ids: tuple[str, ...]
    shards: tuple[ShardScanResult, ...]
    reserved_calls: int
    # Legacy envelopes without a registry manifest cannot claim completeness.
    coverage: ScanCoverage | None = None

    @property
    def complete(self) -> bool:
        """Full plan and successful scans; never global no-match/mapping authority."""
        return (self.coverage is not None and self.coverage.complete_coverage
                and len(self.shards) == self.coverage.expected_shards
                and all(result.status == ScanStatus.SUCCEEDED for result in self.shards))

    @property
    def warnings(self) -> tuple[ScanWarning, ...]:
        return self.coverage.warnings if self.coverage is not None else ()


def summarize_scan_coverage(*, registry: ShardRegistry, target_ids: tuple[str, ...],
                            shards: tuple[ShardScanResult, ...], expected_shards: int) -> ScanCoverage:
    """Derive metadata AFTER the caller checks exact directory/shard membership.

    The reducer independently repeats that check; this summary is not authority.
    Without a proven dependency partition, all targets are potentially affected.
    """
    targets = tuple(sorted(target_ids))
    warnings = [ScanWarning(item.error_code, item.group_id,
                item.group_id.removeprefix("table:") if item.group_id.startswith("table:") else None,
                None, item.scope_hash, item.record_count, item.char_count, item.byte_count, targets)
                for item in registry.excluded_groups]
    for shard in sorted(shards, key=lambda item: item.shard_id):
        if shard.status != ScanStatus.SUCCEEDED:
            identity = json.dumps([registry.scope.owner_id, registry.scope.snapshot_id,
                                   registry.generation, shard.shard_id, shard.status.value], separators=(",", ":"))
            warnings.append(ScanWarning(shard.status.value, None, None, shard.shard_id,
                hashlib.sha256(identity.encode("utf-8")).hexdigest(), 0, 0, 0, targets))
    succeeded = sum(shard.status == ScanStatus.SUCCEEDED for shard in shards)
    complete = registry.complete_coverage and succeeded == expected_shards
    return ScanCoverage(expected_shards, succeeded, registry.complete_coverage,
                        len(registry.excluded_groups), sum(item.record_count for item in registry.excluded_groups),
                        () if complete else targets, tuple(warnings))


class ScanStopReason(str, Enum):
    DEADLINE = "deadline_expired"
    CANCELED = "canceled"
    INTERNAL_STOP = "internal_stop"


class ScanStopped(RuntimeError):
    def __init__(self, status: ScanStatus, *, reason: ScanStopReason | None = None):
        self.status = status
        self.reason = reason or (ScanStopReason.CANCELED if status == ScanStatus.CANCELED else ScanStopReason.DEADLINE)
        super().__init__(status.value)


class RuntimePhase(str, Enum):
    SNAPSHOT_WRITE = "snapshot_write"
    SNAPSHOT_READBACK = "snapshot_readback"
    REQUEST_WRITE = "request_write"
    REQUEST_READBACK = "request_readback"
    ADMISSION_WAIT = "admission_wait"
    PERMIT_RENEWAL = "permit_renewal"
    LIFECYCLE_BIND = "lifecycle_bind"
    THREAD_CREATE = "thread_create"
    THREAD_PERSIST = "thread_persist"
    MODEL_RUN = "model_run"
    ADMISSION_CLEANUP = "admission_cleanup"
    RESPONSE_WRITE = "response_write"
    RESPONSE_READBACK = "response_readback"
    FINAL_CHECK = "final_check"


@dataclass
class RuntimeCallTrace:
    """Local fixed-vocabulary observations, never permit/completion authority."""

    phase: RuntimePhase = RuntimePhase.SNAPSHOT_WRITE
    failure_phase: RuntimePhase | None = None
    started: float = field(default_factory=time.monotonic)
    phase_started: float = field(default_factory=time.monotonic)
    phase_seconds: dict[str, float] = field(default_factory=dict)
    thread_post_attempts: int = 0
    model_post_attempts: int = 0
    terminal_responses: int = 0
    archived_responses: int = 0
    capacity_wait_seconds: float = 0.0

    def enter(self, phase: RuntimePhase) -> None:
        if type(phase) is not RuntimePhase:
            raise ValueError("Invalid runtime phase")
        now = time.monotonic()
        self.phase_seconds[self.phase.value] = self.phase_seconds.get(self.phase.value, 0.0) + max(0.0, now - self.phase_started)
        self.phase, self.phase_started = phase, now

    def snapshot(self) -> dict:
        now = time.monotonic()
        timings = dict(self.phase_seconds)
        timings[self.phase.value] = timings.get(self.phase.value, 0.0) + max(0.0, now - self.phase_started)
        return {"runtime_phase": (self.failure_phase or self.phase).value, "runtime_attempts": 1,
                "runtime_seconds": round(max(0.0, now - self.started), 6),
                "phase_seconds": {key: round(value, 6) for key, value in timings.items()},
                "thread_post_attempts": self.thread_post_attempts,
                "model_post_attempts": self.model_post_attempts,
                "terminal_responses": self.terminal_responses,
                "archived_responses": self.archived_responses}


@dataclass(frozen=True)
class ScanRequest:
    scope: SnapshotScope
    generation: str
    shard_id: str
    target_ids: tuple[str, ...]
    record_ids: tuple[str, ...]
    message: str
    output_budget: MessageBudget
    deadline: float
    _cancel: Event = field(repr=False, compare=False)
    _stop: Event = field(repr=False, compare=False)
    # Empty is fail-closed for standalone callers; scan_registry derives this from cards.
    eligible_source_record_ids: tuple[str, ...] = ()
    runtime_trace: RuntimeCallTrace | None = field(default=None, repr=False, compare=False)
    request_archive_ref: str | None = field(default=None, repr=False, compare=False)

    capacity_wait_limit_seconds: float = 0.0

    @property
    def effective_deadline(self):
        credit = self.runtime_trace.capacity_wait_seconds if self.runtime_trace is not None else 0
        return self.deadline + credit

    def remaining_seconds(self) -> float:
        return max(0.0, self.effective_deadline - time.monotonic())

    def check_active(self) -> None:
        if self._cancel.is_set():
            raise ScanStopped(ScanStatus.CANCELED)
        if self.remaining_seconds() <= 0:
            raise ScanStopped(ScanStatus.TIMED_OUT)
        if self._stop.is_set():
            raise ScanStopped(ScanStatus.TIMED_OUT, reason=ScanStopReason.INTERNAL_STOP)


ScanBackend: TypeAlias = Callable[[ScanRequest], str]
ScanAdmission: TypeAlias = Callable[[ScanRequest], AbstractContextManager[bool]]


class ScanTransportReason(str, Enum):
    """Closed diagnostic vocabulary; no provider text, headers, or bodies."""

    HTTP_CONNECT_TIMEOUT = "scan_transport_http_connect_timeout"
    HTTP_READ_TIMEOUT = "scan_transport_http_read_timeout"
    HTTP_WRITE_TIMEOUT = "scan_transport_http_write_timeout"
    HTTP_POOL_TIMEOUT = "scan_transport_http_pool_timeout"
    HTTP_CONNECT_ERROR = "scan_transport_http_connect_error"
    HTTP_READ_ERROR = "scan_transport_http_read_error"
    HTTP_WRITE_ERROR = "scan_transport_http_write_error"
    HTTP_CLOSE_ERROR = "scan_transport_http_close_error"
    HTTP_LOCAL_PROTOCOL_ERROR = "scan_transport_http_local_protocol_error"
    HTTP_REMOTE_PROTOCOL_ERROR = "scan_transport_http_remote_protocol_error"
    HTTP_PROXY_ERROR = "scan_transport_http_proxy_error"
    HTTP_UNSUPPORTED_PROTOCOL = "scan_transport_http_unsupported_protocol"
    HTTP_DECODING_ERROR = "scan_transport_http_decoding_error"
    HTTP_TOO_MANY_REDIRECTS = "scan_transport_http_too_many_redirects"
    HTTP_STATUS_ERROR = "scan_transport_http_status_error"
    HTTP_ERROR = "scan_transport_http_error"
    UNSUPPORTED_CONTENT_ENCODING = "scan_transport_unsupported_content_encoding"
    UNEXPECTED_HTTP_STATUS = "scan_transport_unexpected_http_status"
    MALFORMED_JSON = "scan_transport_malformed_json"
    UNKNOWN_STATUS = "scan_transport_unknown_status"


class ScanBackendError(RuntimeError):
    """Explicit diagnostic carrier, not evidence of remote completion.

    Defined here so transport can opt in without a scan-to-transport import.
    Existing errors without a reason retain their class-name diagnostic.
    """

    def __init__(self, message: str, *, reason: ScanTransportReason | None = None):
        if reason is not None and type(reason) is not ScanTransportReason:
            raise TypeError("Scan reason must be a ScanTransportReason")
        self.reason = reason
        super().__init__(message)


class InvalidScanResponse(ValueError):
    """The entire response is rejected; no partial candidates are retained."""


class ScanOutputBudgetError(InvalidScanResponse):
    """Raw output exceeds its hard character or UTF-8 byte limit."""


def _keys(value: object, expected: set[str]) -> dict:
    if type(value) is not dict or set(value) != expected:
        raise InvalidScanResponse("Unexpected response fields")
    return value


def _unique_object(pairs: list[tuple[str, object]]) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise InvalidScanResponse("Duplicate JSON field")
        result[key] = value
    return result


def _identities(values: object, *, nonempty: bool = True) -> tuple[str, ...]:
    if type(values) not in (list, tuple) or (nonempty and not values):
        raise ValueError("IDs must be an explicit nonempty list or tuple")
    if any(type(value) is not str or not value.strip() for value in values):
        raise ValueError("IDs must be nonempty strings")
    for value in values:
        value.encode("utf-8")
    if len(set(values)) != len(values):
        raise ValueError("Duplicate IDs")
    return tuple(sorted(values))


def eligible_source_record_ids(records: list[dict]) -> tuple[str, ...]:
    """Select only explicitly eligible source cards from checked shard metadata."""
    return tuple(record["record_id"] for record in records
                 if record.get("kind") == "source_column"
                 and isinstance(record.get("body"), dict)
                 and record["body"].get("eligible") is True)


def validate_scan_response(raw: str, *, request: ScanRequest,
                           output_budget: MessageBudget) -> tuple[TargetCandidates, ...]:
    """Strict JSON: {generation, shard_id, targets: [{target_id, candidates}]}.

    Each candidate has ONLY record_id, role and nonempty evidence_refs (exact
    record IDs in this shard). Each requested target appears exactly once. Empty
    candidate lists are shard-local observations, not final no-match decisions.
    Claimed owners, record bodies, mappings, foreign IDs and duplicate identities
    are rejected. SOURCE additionally requires explicit checked source eligibility.
    Candidate identity is (record_id, role), allowing distinct roles.
    """
    if type(raw) is not str:
        raise InvalidScanResponse("Backend must return raw JSON text")
    if len(raw) > output_budget.max_chars:
        raise ScanOutputBudgetError("Output character budget exceeded")
    if len(raw.encode("utf-8")) > output_budget.max_bytes:
        raise ScanOutputBudgetError("Output byte budget exceeded")

    def reject_constant(value: str) -> None:
        raise InvalidScanResponse("Nonfinite JSON number")

    body = _keys(json.loads(raw, object_pairs_hook=_unique_object,
                            parse_constant=reject_constant), {"generation", "shard_id", "targets"})
    if body["generation"] != request.generation or body["shard_id"] != request.shard_id:
        raise InvalidScanResponse("Foreign shard or stale generation")
    if type(body["targets"]) is not list:
        raise InvalidScanResponse("targets must be a structured list")
    allowed_records = set(request.record_ids)
    allowed_sources = set(request.eligible_source_record_ids)
    allowed_targets = set(request.target_ids)
    targets = {}
    for target in body["targets"]:
        target = _keys(target, {"target_id", "candidates"})
        target_id = target["target_id"]
        if type(target_id) is not str or target_id not in allowed_targets or target_id in targets:
            raise InvalidScanResponse("Foreign or duplicate target")
        if type(target["candidates"]) is not list:
            raise InvalidScanResponse("candidates must be a structured list")
        candidates = {}
        for candidate in target["candidates"]:
            candidate = _keys(candidate, {"record_id", "role", "evidence_refs"})
            record_id = candidate["record_id"]
            if type(record_id) is not str or record_id not in allowed_records:
                raise InvalidScanResponse("Foreign record")
            role = CandidateRole(candidate["role"])
            if role == CandidateRole.SOURCE and record_id not in allowed_sources:
                raise InvalidScanResponse("Record is not an eligible source column")
            if type(candidate["evidence_refs"]) is not list:
                raise InvalidScanResponse("evidence_refs must be a structured list")
            refs = _identities(candidate["evidence_refs"])
            if set(refs) - allowed_records:
                raise InvalidScanResponse("Foreign evidence reference")
            identity = (record_id, role.value)
            if identity in candidates:
                raise InvalidScanResponse("Duplicate candidate identity")
            candidates[identity] = ScanCandidate(record_id, role, refs)
        targets[target_id] = TargetCandidates(target_id, tuple(candidates[key] for key in sorted(candidates)))
    if set(targets) != allowed_targets:
        raise InvalidScanResponse("Requested target omitted")
    return tuple(targets[key] for key in sorted(targets))


def scan_registry(*, registry: ShardRegistry, scope: SnapshotScope,
                  target_ids: tuple[str, ...] | list[str], backend: ScanBackend,
                  admission: ScanAdmission, max_workers: int, max_calls: int,
                  total_seconds: float, output_budget: MessageBudget,
                  cancellation: Event | None = None) -> ScanResult:
    """Scan each registered shard once with at most max_workers pending futures.

    Budget is aggregate per invocation: deterministically reserve at most max_calls
    in directory order, including failed admission attempts; no retries/refunds.
    Output limits apply per raw shard response (aggregate <= max_calls * limits).
    Directory descriptors are retained for complete failure coverage, not record
    bodies. Preflight and exact rendering are synchronous: their elapsed time
    counts toward the deadline, but a blocked trusted builder cannot be interrupted.
    Results are immutable and ordered by registry directory, independent
    of completion order. Unsubmitted work gets explicit cancellation/deadline/budget
    coverage. Preflight scope/directory/configuration errors raise before any call.
    """
    started = time.monotonic()
    if not isinstance(registry, ShardRegistry) or not isinstance(scope, SnapshotScope):
        raise TypeError("registry and trusted scope must be typed")
    if not callable(backend) or not callable(admission):
        raise TypeError("backend and explicit admission factory are required")
    for name, value in (("max_workers", max_workers), ("max_calls", max_calls)):
        if type(value) is not int or value < (1 if name == "max_workers" else 0):
            raise ValueError(f"Invalid {name}")
    if type(total_seconds) not in (int, float) or not math.isfinite(total_seconds) or total_seconds <= 0:
        raise ValueError("total_seconds must be positive and finite")
    if not isinstance(output_budget, MessageBudget):
        raise TypeError("output_budget must be a MessageBudget")
    if cancellation is not None and not isinstance(cancellation, Event):
        raise TypeError("cancellation must be a threading.Event")
    targets = _identities(target_ids)
    cancel = cancellation if cancellation is not None else Event()
    stop = Event()
    deadline = started + total_seconds
    shard_ids = []
    cursor = None
    while True:
        page = registry.directory(scope=scope, cursor=cursor, max_entries=128).payload
        shard_ids.extend(entry["shard_id"] for entry in page["entries"])
        cursor = page["next_cursor"]
        if cursor is None:
            if (page["complete"] is not True or page["total_shards"] != len(shard_ids)
                    or len(set(shard_ids)) != len(shard_ids)):
                raise ValueError("Directory coverage mismatch")
            break

    def stopped() -> ScanStatus | None:
        if cancel.is_set():
            return ScanStatus.CANCELED
        if time.monotonic() >= deadline:
            return ScanStatus.TIMED_OUT
        return None

    def result(shard_id: str, status: ScanStatus, *, reserved: bool = False,
               candidates: tuple[TargetCandidates, ...] = (), error: str | None = None) -> ShardScanResult:
        return ShardScanResult(scope, registry.generation, shard_id, targets, status, candidates, error, reserved)

    def worker(request: ScanRequest) -> ShardScanResult:
        outcome = None
        try:
            request.check_active()
            with admission(request) as granted:
                if granted is not True:
                    raise PermissionError("Admission must explicitly yield True")
                request.check_active()
                phase = ScanStatus.BACKEND_FAILED
                try:
                    raw = backend(request)
                    request.check_active()
                    phase = ScanStatus.INVALID_RESPONSE
                    candidates = validate_scan_response(raw, request=request, output_budget=output_budget)
                    request.check_active()
                    outcome = result(request.shard_id, ScanStatus.SUCCEEDED,
                                     reserved=True, candidates=candidates)
                except ScanStopped:
                    raise
                except ScanOutputBudgetError:
                    outcome = result(request.shard_id, ScanStatus.OUTPUT_BUDGET_EXCEEDED,
                                     reserved=True, error="output_budget_exceeded")
                except ScanBackendError as exc:
                    # Recheck the closed enum at the persistence boundary, even
                    # if a subclass bypassed initialization or mutated reason.
                    reason = getattr(exc, "reason", None)
                    error = reason.value if type(reason) is ScanTransportReason else type(exc).__name__
                    outcome = result(request.shard_id, phase, reserved=True, error=error)
                except Exception as exc:
                    outcome = result(request.shard_id, phase, reserved=True, error=type(exc).__name__)
            request.check_active()
            # An admission context may suppress an exception; absence of an
            # explicit validated outcome is still failure, never an empty match.
            return outcome or result(request.shard_id, ScanStatus.ADMISSION_FAILED,
                                     reserved=True, error="suppressed_failure")
        except ScanStopped as exc:
            return result(request.shard_id, exc.status, reserved=True, error=exc.status.value)
        except Exception as exc:
            # Do not persist exception text, which may contain sensitive payloads.
            return result(request.shard_id, ScanStatus.ADMISSION_FAILED,
                          reserved=True, error=type(exc).__name__)

    completed: dict[str, ShardScanResult] = {}
    pending: dict[Future, str] = {}
    reserved_calls = 0
    next_index = 0
    executor = ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="automap-scan")
    try:
        while next_index < len(shard_ids) or pending:
            terminal = stopped()
            if terminal is not None:
                break
            while next_index < len(shard_ids) and len(pending) < max_workers:
                if stopped() is not None:
                    break
                shard_id = shard_ids[next_index]
                next_index += 1
                if reserved_calls >= max_calls:
                    completed[shard_id] = result(shard_id, ScanStatus.CALL_BUDGET_EXHAUSTED,
                                                  error="call_budget_exhausted")
                    continue
                try:
                    message = registry.read_shard(scope=scope, shard_id=shard_id)
                except Exception as exc:
                    completed[shard_id] = result(shard_id, ScanStatus.READ_FAILED, error=type(exc).__name__)
                    continue
                terminal = stopped()
                if terminal is not None:
                    completed[shard_id] = result(shard_id, terminal, error=terminal.value)
                    break
                records = message.payload["records"]
                request = ScanRequest(scope, registry.generation, shard_id, targets,
                                      tuple(record["record_id"] for record in records),
                                      message.text, output_budget, deadline, cancel, stop,
                                      eligible_source_record_ids=eligible_source_record_ids(records))
                reserved_calls += 1
                try:
                    pending[executor.submit(worker, request)] = shard_id
                except Exception as exc:
                    completed[shard_id] = result(shard_id, ScanStatus.DISPATCH_FAILED,
                                                  reserved=True, error=type(exc).__name__)
            if not pending:
                continue
            done, _ = wait(pending, timeout=min(0.02, max(0.0, deadline - time.monotonic())),
                           return_when=FIRST_COMPLETED)
            for future in done:
                shard_id = pending.pop(future)
                completed[shard_id] = future.result()
        terminal = stopped()
        if terminal is not None:
            stop.set()
            for future, shard_id in pending.items():
                # Keep outcomes fully completed before the cutoff, but never
                # let a late worker mutate this returned snapshot of coverage.
                if future.done() and not future.cancelled():
                    completed[shard_id] = future.result()
                else:
                    future.cancel()
                    completed[shard_id] = result(shard_id, terminal, reserved=True, error=terminal.value)
            for shard_id in shard_ids[next_index:]:
                completed[shard_id] = result(shard_id, terminal, error=terminal.value)
        shards = tuple(completed[shard_id] for shard_id in shard_ids)
        coverage = summarize_scan_coverage(registry=registry, target_ids=targets,
                                           shards=shards, expected_shards=len(shard_ids))
        return ScanResult(scope, registry.generation, targets, shards, reserved_calls, coverage)
    finally:
        stop.set()
        executor.shutdown(wait=False, cancel_futures=True)
