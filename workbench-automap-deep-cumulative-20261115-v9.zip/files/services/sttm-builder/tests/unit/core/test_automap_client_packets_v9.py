"""Sanitized incident shape: 37 targets, six sources, seven graph nodes.

These are regression fixtures, not reconstructed client packets or live timings.
"""
from copy import deepcopy
import json
import time

import pytest

from app.core.automap_input_budget import wire_text
from app.core.sttm_builder import STTMBuilderService
from tests.unit.core.test_automap_admission_v6 import wide_value
from tests.unit.core.test_automap_fast_batch import prepared_request, service, FinalAgent
from tests.unit.core.test_automap_fast_context import add_table


def client_shape(*, populated):
    value = wide_value(37)
    value['meta'].update(automap_generation_policy='draft-v3', automap_rules_policy='rules-v2', automap_packet_policy='frozen-packets-v1')
    for index in range(5):
        add_table(value, 'LOOKUP_' + str(index), columns=3, connected=True)
    graph = value['context']['relation_graph']
    for edge in graph['edges']:
        edge['conditions'][0]['left_column'] = 'FIELD_000'
    graph['nodes'].append({'relation_id':'cte_current', 'alias':'cte_current', 'kind':'CTE',
        'sql_text':'SELECT a.FIELD_000 FROM D.S.ACCOUNTS a',
        'output_columns':[{'name':'FIELD_000','data_type':'TEXT'}],
        'parent_relation_ids':['a']})
    sql = 'WITH cte_current AS (SELECT FIELD_000 FROM D.S.ACCOUNTS) SELECT FIELD_000 FROM cte_current'
    value['context']['workspace_context'].update(mapping_sql=sql, raw_mapping_sql=sql,
        mapping_rows=[{'id': 'NAME'+str(i), 'target_column': 'NAME'+str(i),
            **({'source_columns':['a.FIELD_000'], 'rule':'Direct', 'manually_saved':True} if populated else {})} for i in range(37)])
    value['context']['learning_context'] = {'mapping_precedents':[{'project_id':'2','precedent_sttm_id':'old',
        'mappings':[{'target_column':'NAME'+str(i), 'source_columns':['a.FIELD_000'],
            'rule':'Direct', 'description':('Historical target meaning and rationale. ' * 72)} for i in range(37)]}]}
    for item in value['data']['attributes']:
        item['target_description'] = 'Direct current a.FIELD_000. Historical context is guidance; return numeric confidence.'
    return value


@pytest.mark.parametrize('populated',[False,True])
def test_client_shaped_groups_have_bounded_renders_and_exact_frozen_messages(monkeypatch,populated):
    from app.core.automap_fast_context import FastContextPlan
    value = client_shape(populated=populated)
    assert len(value['context']['source_tables']) == 6
    assert len(value['context']['relation_graph']['nodes']) == 7
    assert len(value['context']['semantic_context'][0]['semantic_model']['attributes']) == 600
    assert len(json.dumps(value['context']['learning_context'])) >= 103000
    req = prepared_request(value)
    builder = service(FinalAgent())
    builder._settings = builder._settings.model_copy(update={'agent_outbound_message_max_chars':180000,
        'agent_outbound_message_max_bytes':180000})
    counts = {}
    original = FastContextPlan._render
    def observed(self,*args,**kwargs):
        counts[self] = counts.get(self,0)+1
        return original(self,*args,**kwargs)
    monkeypatch.setattr(FastContextPlan,'_render',observed)
    started = time.perf_counter()
    receipts=[]
    for start in range(0,37,8):
        batch=req.model_copy(update={'data':req.data.model_copy(update={'attributes':req.data.attributes[start:start+8]})})
        projection=STTMBuilderService.project_agent_payload(batch,builder._settings)
        assert projection.frozen_packet is not None, projection.diagnostics
        receipt=projection.frozen_packet
        text=wire_text(receipt['messages'])
        assert receipt['final_chars'] == len(text) <= 180000
        assert receipt['final_bytes'] == len(text.encode('utf-8')) <= 180000
        assert not projection.diagnostics['fast_preflight']['requires_target_subdivision']
        receipts.append(receipt)
    elapsed=time.perf_counter()-started
    assert max(counts.values()) <= 4
    assert elapsed < 10, {'warm_packing_seconds':elapsed,'renders':list(counts.values())}
    assert sum(len(json.loads(r['messages'][0]['content'][0]['text'])['data']['attributes']) for r in receipts)==37


@pytest.mark.parametrize('populated',[False,True])
def test_regeneration_captures_baselines_without_compiling_obsolete_definitions(monkeypatch,populated):
    from app.core.automap_deterministic import regeneration_targets
    from app.core.mapping_sql import MappingSqlService
    value=client_shape(populated=populated)
    req=prepared_request(value)
    def forbidden(*args,**kwargs):
        raise AssertionError('Fresh regeneration must not compile old definitions')
    monkeypatch.setattr(MappingSqlService,'compile',forbidden)
    resolution=regeneration_targets(req)
    assert len(resolution.pending_attributes)==37
    assert all(item.mapping is None and not item.compiler_valid for item in resolution.targets)
    assert [row.model_dump() for row in resolution.baseline_rows]==[row.model_dump() for row in req.context.workspace_context.mapping_rows]
    assert resolution.mapping_sql==req.context.workspace_context.mapping_sql
