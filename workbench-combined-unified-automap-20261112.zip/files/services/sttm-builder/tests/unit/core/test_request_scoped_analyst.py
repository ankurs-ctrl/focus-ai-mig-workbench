from copy import deepcopy
from types import SimpleNamespace
from concurrent.futures import ThreadPoolExecutor

import httpx
import pytest
import yaml

from app.core.exceptions import SnowflakeAgentError
from app.core.semantic_context import SemanticContextService
from app.core.snowflake_agent import SnowflakeAgentClient


def spec():
    return {
        "models": {"orchestration": "claude-haiku-4-5"},
        "instructions": {"orchestration": "Preserve project constraints", "response": "Return JSON"},
        "tools": [
            {"tool_spec": {"type": "cortex_search", "name": "Search"}},
            {"tool_spec": {"type": "generic", "name": "Specialist"}},
            {"tool_spec": {"type": "cortex_analyst_text_to_sql", "name": "OldAnalyst"}},
        ],
        "tool_resources": {"Search": {"search_service": "D.S.SEARCH"},
                           "Specialist": {"type": "procedure", "identifier": "D.S.SP"},
                           "OldAnalyst": {"semantic_view": "D.S.OLD"}},
    }


def test_parallel_bindings_never_mutate_source_or_each_other():
    source = spec()
    original = deepcopy(source)
    with ThreadPoolExecutor(4) as pool:
        configs = list(pool.map(lambda index: SnowflakeAgentClient.with_bundle_analyst(
            source, semantic_view=f"D.S.BUNDLE_{index}", warehouse="WH",
        ), range(20)))
    assert source == original
    for index, config in enumerate(configs):
        assert config["tool_resources"]["CurrentBundleAnalyst"]["semantic_view"] == f"D.S.BUNDLE_{index}"
        assert "OldAnalyst" not in config["tool_resources"]
        assert config["tool_resources"]["Search"] == original["tool_resources"]["Search"]
        assert config["tool_resources"]["Specialist"] == original["tool_resources"]["Specialist"]
        assert config["models"] == original["models"]
        assert config["instructions"]["response"] == "Return JSON"
    configs[0]["tool_resources"]["Search"].clear()
    assert configs[1]["tool_resources"]["Search"]


def test_transport_uses_objectless_endpoint_and_preserves_caller(monkeypatch):
    calls = []
    def handle(request):
        import json
        calls.append((str(request.url), json.loads(request.content), request.headers))
        return httpx.Response(200, json={"role": "assistant", "content": [{"type": "text", "text": "ok"}]})
    monkeypatch.setattr("app.core.snowflake_agent._shared_http_client", lambda _: httpx.Client(transport=httpx.MockTransport(handle)))
    client = SnowflakeAgentClient("token", host="example.snowflakecomputing.com", role="CALLER", warehouse="WH")
    config = SnowflakeAgentClient.with_bundle_analyst(spec(), semantic_view="D.S.B", warehouse="WH")
    assert client.run_detailed([{"role": "user", "content": "hello"}], run_config=config)[0] == "ok"
    url, body, headers = calls[0]
    assert url.endswith("/api/v2/cortex/agent:run")
    assert body["tool_resources"]["CurrentBundleAnalyst"]["semantic_view"] == "D.S.B"
    assert headers["X-Snowflake-Role"] == "CALLER"
    assert "thread_id" not in body
    for extra in ({"agent": "D.S.A"}, {"thread_id": "123"}, {"parent_message_id": 0}):
        with pytest.raises(SnowflakeAgentError):
            client.run_detailed([], run_config=config, **extra)
    with pytest.raises(SnowflakeAgentError):
        client.run_detailed([], run_config={**config, "messages": []})
    assert len(calls) == 1


def test_stream_transport_and_no_replay_after_partial_output(monkeypatch):
    calls = []
    class BrokenStream(httpx.SyncByteStream):
        def __iter__(self):
            yield b'event: response.text.delta\ndata: {"text":"partial"}\n\n'
            raise httpx.ReadTimeout("interrupted")
    def handle(request):
        calls.append(str(request.url))
        return httpx.Response(200, stream=BrokenStream())
    monkeypatch.setattr("app.core.snowflake_agent._shared_http_client", lambda _: httpx.Client(transport=httpx.MockTransport(handle)))
    client = SnowflakeAgentClient("token", host="example.snowflakecomputing.com")
    config = SnowflakeAgentClient.with_bundle_analyst(spec(), semantic_view="D.S.B", warehouse="WH")
    events = client.stream_events([], run_config=config)
    assert next(events) == ("response.text.delta", {"text": "partial"})
    with pytest.raises(SnowflakeAgentError):
        next(events)
    assert calls == ["https://example.snowflakecomputing.com/api/v2/cortex/agent:run"]


def test_enabled_builder_checks_governance_and_uses_exact_prepared_bundle():
    from app.core.sttm_builder import STTMBuilderService
    from app.schema.sttm_builder import STTMBuilderEnvelopeRequest
    instance = object.__new__(STTMBuilderService)
    instance._settings = SimpleNamespace(agent_request_scoped_analyst_v1=True,
        agent_bundle_view_schema="D.S", snowflake_warehouse="WH")
    log = []
    instance._model_guard = SimpleNamespace(assert_model_target_allowed=lambda **kwargs: log.append("guard"))
    instance._agent = SimpleNamespace(get_specification=lambda name: (log.append(name), spec())[1])
    instance._resolved_agent_name = lambda req: "D.S.BUILDER"
    def materialize(**kwargs):
        log.append(kwargs)
        return "D.S.BUNDLE"
    instance._semantic_context_service = SimpleNamespace(materialize_analyst_bundle_view=materialize)
    request = STTMBuilderEnvelopeRequest.model_validate({"contract_version": "1.0", "operation": "sttm.chat",
        "context": {"semantic_bundle_id": "current"}, "data": {"intent": "CHAT", "message": "data"}})
    config = instance._request_scoped_analyst_config(request, SimpleNamespace(bundle_hash="exact"), None)
    assert log == ["guard", "D.S.BUILDER", {"bundle_id": "current", "bundle_hash": "exact", "schema_fqn": "D.S"}]
    assert config["tool_resources"]["CurrentBundleAnalyst"]["semantic_view"] == "D.S.BUNDLE"
    instance._refresh_semantic_context_for_explicit_resolve = lambda req: (req, SimpleNamespace(bundle_hash=""))
    with pytest.raises(SnowflakeAgentError, match="hash"):
        instance._request_scoped_analyst_config(request, SimpleNamespace(bundle_hash=""), None)


def service(existing=False):
    calls = []
    class Session:
        def sql(self, query, params=None):
            calls.append((query, params))
            rows = []
            if existing and query.startswith("SHOW"):
                rows = [{"name": query.split("'")[1]}]
            return SimpleNamespace(collect=lambda: rows)
    instance = object.__new__(SemanticContextService)
    instance._access_fingerprint = "a" * 64
    instance._session = Session()
    instance.get_bundle = lambda **_: {"bundle_hash": "hash", "semantic_model_yaml": yaml.safe_dump({
        "name": "inline", "tables": [{"name": "test", "base_table": {"database": "D", "schema": "S", "table": "T"},
        "dimensions": [{"name": "id", "expr": "ID", "data_type": "NUMBER"}]}],
    })}
    return instance, calls


def test_materialization_binds_yaml_and_validates_before_create():
    instance, calls = service()
    name = instance.materialize_analyst_bundle_view(bundle_id="bundle", bundle_hash="hash", schema_fqn="D.S")
    assert name.startswith("D.S.SV_STTM_")
    assert "TRUE" in calls[0][0]
    assert calls[1][0].startswith("SHOW SEMANTIC VIEWS")
    assert "FALSE" in calls[2][0]
    assert calls[0][1] == calls[2][1]
    assert yaml.safe_load(calls[0][1][1])["name"] == name.split(".")[-1]
    assert not any("AGENT" in query or "GRANT" in query for query, _ in calls)


def test_existing_view_is_not_replaced_and_stale_bundle_fails_closed():
    instance, calls = service(existing=True)
    instance.materialize_analyst_bundle_view(bundle_id="bundle", bundle_hash="hash", schema_fqn="D.S")
    assert len(calls) == 2
    calls.clear()
    with pytest.raises(ValueError, match="changed"):
        instance.materialize_analyst_bundle_view(bundle_id="bundle", bundle_hash="stale", schema_fqn="D.S")
    with pytest.raises(ValueError, match="DATABASE.SCHEMA"):
        instance.materialize_analyst_bundle_view(bundle_id="bundle", bundle_hash="hash", schema_fqn="D.S; DROP DATABASE D")
    assert not calls


def test_failed_validation_never_creates_view():
    instance, calls = service()
    instance._session.sql = lambda *args, **kwargs: (_ for _ in ()).throw(RuntimeError("invalid YAML"))
    with pytest.raises(RuntimeError, match="invalid YAML"):
        instance.materialize_analyst_bundle_view(bundle_id="bundle", bundle_hash="hash", schema_fqn="D.S")
    assert not calls


@pytest.mark.parametrize("enabled", [True, False])
@pytest.mark.parametrize("asset_count", [1, 2])
def test_missing_semantics_runs_builder_without_analyst_or_materialization(enabled, asset_count):
    from app.core.sttm_builder import STTMBuilderService
    from app.schema.sttm_builder import STTMBuilderEnvelopeRequest, STTMBuilderResponse
    from unittest.mock import Mock
    instance = object.__new__(STTMBuilderService)
    instance._settings = SimpleNamespace(agent_request_scoped_analyst_v1=enabled)
    instance._resolved_agent_name = lambda req: "D.S.BUILDER"
    original = spec()
    instance._agent = SimpleNamespace(get_specification=Mock(return_value=original))
    instance._model_guard = SimpleNamespace(assert_model_target_allowed=Mock(side_effect=AssertionError("Analyst guard must not run")))
    instance._semantic_context_service = SimpleNamespace(materialize_analyst_bundle_view=Mock(side_effect=AssertionError("Must not materialize partial YAML")))
    items = [{"table": {"database": "D", "schema": "S", "table": name},
        "semantic_model": {"semantic_status": "native_yaml_missing", "attributes": []}} for name in ["SOURCE", "TARGET"][:asset_count]]
    request = STTMBuilderEnvelopeRequest.model_validate({"operation": "sttm.chat", "data": {"intent": "CHAT", "message": "Recommend a CTE using available history"},
        "context": {"semantic_context": items}})
    before = deepcopy(original)
    config = instance._request_scoped_analyst_config(request, None, None)
    assert original == before
    assert [tool["tool_spec"]["name"] for tool in config["tools"]] == ["Search", "Specialist"]
    assert "OldAnalyst" not in config["tool_resources"]
    assert "historical guidance" in config["instructions"]["orchestration"]
    response = STTMBuilderResponse.from_invocation(request, thread_id=None, parent_message_id=None,
        agent=None, result=None, status="completed", message="Use the supported current bindings and published pattern.")
    answer = instance._execute_requested_analyst_delegation(request, response, semantic_refresh=None, decision=None)
    assert answer.data.message.startswith("Use the supported")
    assert answer.data.message.endswith("review assumptions against current bindings.")
    assert len(answer.meta["semantic_evidence_coverage"]["missing_assets"]) == asset_count
    assert answer.warnings[-1].code == "SEMANTIC_EVIDENCE_GAP"
    assert instance._with_semantic_gap_notice(request, answer).data.message == answer.data.message
    assert not instance._needs_analyst_derived_fallback(request, answer)
    instance._agent.get_specification.assert_called_once_with("D.S.BUILDER")


def test_semantic_gap_never_swallows_caller_agent_permission_error():
    from app.core.sttm_builder import STTMBuilderService
    from app.schema.sttm_builder import STTMBuilderEnvelopeRequest
    from unittest.mock import Mock
    instance = object.__new__(STTMBuilderService)
    instance._agent = SimpleNamespace(get_specification=Mock(side_effect=SnowflakeAgentError("Caller cannot read agent")))
    instance._resolved_agent_name = lambda req: "D.S.BUILDER"
    request = STTMBuilderEnvelopeRequest.model_validate({"operation": "sttm.chat", "data": {"intent": "CHAT"},
        "context": {"semantic_context": [{"table": {"database": "D", "schema": "S", "table": "T"},
            "semantic_model": {"semantic_status": "native_yaml_missing"}}]}})
    with pytest.raises(SnowflakeAgentError, match="Caller cannot read"):
        instance._request_scoped_analyst_config(request, None, None)


def test_without_analyst_accepts_tool_free_deployed_specs():
    config = SnowflakeAgentClient.without_analyst({"models": {"orchestration": "claude-haiku-4-5"}})
    assert config["tools"] == [] and config["tool_resources"] == {}
