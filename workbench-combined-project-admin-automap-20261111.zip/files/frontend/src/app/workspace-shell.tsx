"use client";

import type { ReactNode } from "react";
import { usePathname } from "next/navigation";
import AppHeader from "@/features/layout/app-header";
import AppShellGate from "@/features/layout/app-shell-gate";
import SessionGate from "@/features/layout/session-gate";
import WorkspaceProviders from "./workspace-providers";

const HEADER_HIDDEN_PATHS = new Set(["/home", "/landing"]);

export default function WorkspaceShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const normalizedPath = (pathname || "/").replace(/\/+$/, "") || "/";
  const showHeader = !HEADER_HIDDEN_PATHS.has(normalizedPath);

  const shell = (
    <div className="flex h-screen flex-col overflow-hidden">
      {showHeader ? <AppHeader /> : null}
      <div className="flex min-h-0 flex-1 flex-col overflow-hidden">
        <AppShellGate>
          {showHeader ? <SessionGate>{children}</SessionGate> : children}
        </AppShellGate>
      </div>
    </div>
  );

  return (
    <WorkspaceProviders>
      {/* Render navigation immediately. Identity bootstrap only coordinates
          scoped page reads; it must not replace the app with a session screen. */}
      {shell}
    </WorkspaceProviders>
  );
}
