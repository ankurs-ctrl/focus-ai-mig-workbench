'use client';
import { AiaBox } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';

import { Fragment, useCallback, useEffect, useMemo, useRef, useState } from 'react';

import { SqlHighlight } from './sql-highlight';
import {
  SQL_EDITOR_COLORS,
  SQL_EDITOR_METRICS,
  SQL_EDITOR_SCROLL_SX,
  SQL_HIGHLIGHT_DEBOUNCE_MS,
  SQL_LINE_NUMBER_COLOR,
  SQL_MONO_FONT,
} from './sql-styles';
import { tokenizeSql, type SqlToken } from './sql-tokenizer';

type SqlEditorSurfaceProps = {
  value: string;
  onChange?: (next: string) => void;
  readOnly?: boolean;
  placeholder?: string;
  emptyText?: string;
  showLineNumbers?: boolean;
  compact?: boolean;
  onSelectionChange?: (start: number, end: number) => void;
  editorRef?: React.RefObject<HTMLTextAreaElement | null>;
  completionCandidates?: string[];
};

const editorTextSx = {
  fontFamily: SQL_MONO_FONT,
  fontSize: SQL_EDITOR_METRICS.fontSize,
  lineHeight: SQL_EDITOR_METRICS.lineHeight,
  px: SQL_EDITOR_METRICS.paddingX,
  py: SQL_EDITOR_METRICS.paddingY,
  whiteSpace: 'pre-wrap',
  wordBreak: 'break-word',
} as const;

const editorTextNoWrapSx = {
  ...editorTextSx,
  whiteSpace: 'pre',
  wordBreak: 'normal',
} as const;

function splitTokensByLine(tokens: SqlToken[]): SqlToken[][] {
  const lines: SqlToken[][] = [[]];
  for (const token of tokens) {
    const parts = token.value.split('\n');
    parts.forEach((part, index) => {
      if (index > 0) lines.push([]);
      if (part) lines[lines.length - 1].push({ type: token.type, value: part });
    });
  }
  return lines;
}

export function SqlEditorSurface({
  value,
  onChange,
  readOnly = false,
  placeholder = '-- Write SQL here',
  emptyText = '-- No SQL to display',
  showLineNumbers = true,
  compact = false,
  onSelectionChange,
  editorRef,
  completionCandidates = [],
}: SqlEditorSurfaceProps) {
  const overlayRef = useRef<HTMLDivElement | null>(null);
  const lineNumbersRef = useRef<HTMLDivElement | null>(null);
  const internalEditorRef = useRef<HTMLTextAreaElement | null>(null);
  const textareaRef = editorRef ?? internalEditorRef;

  const [highlightText, setHighlightText] = useState(value);
  const [selection, setSelection] = useState({ start: value.length, end: value.length });

  useEffect(() => {
    if (readOnly) return;

    const timeout = window.setTimeout(
      () => setHighlightText(value),
      SQL_HIGHLIGHT_DEBOUNCE_MS,
    );
    return () => window.clearTimeout(timeout);
  }, [readOnly, value]);

  const visibleHighlightText = readOnly ? value : highlightText;
  const highlightTokens = useMemo(
    () => (visibleHighlightText ? tokenizeSql(visibleHighlightText) : []),
    [visibleHighlightText],
  );

  const lineCount = useMemo(() => Math.max(1, value.split('\n').length), [value]);
  const highlightLines = useMemo(
    () => (readOnly && showLineNumbers ? splitTokensByLine(highlightTokens) : []),
    [highlightTokens, readOnly, showLineNumbers],
  );
  const textSx = showLineNumbers ? editorTextNoWrapSx : editorTextSx;

  const completion = useMemo(() => {
    if (readOnly || selection.start !== selection.end || !completionCandidates.length) return null;
    const beforeCaret = value.slice(0, selection.start);
    const prefixMatch = beforeCaret.match(/[A-Za-z0-9_$."]+$/);
    const prefix = prefixMatch?.[0] ?? '';
    if (!prefix || prefix.endsWith('.')) return null;
    const normalizedPrefix = prefix.replace(/^"/, '').toLowerCase();
    const candidate = [...new Set(completionCandidates)]
      .filter((item) => item.toLowerCase().startsWith(normalizedPrefix))
      .filter((item) => item.toLowerCase() !== normalizedPrefix)
      .sort((left, right) => left.length - right.length || left.localeCompare(right))[0];
    if (!candidate) return null;
    const suffix = candidate.slice(normalizedPrefix.length);
    if (!suffix) return null;
    return {
      candidate,
      prefixStart: selection.start - prefix.length,
      suffix,
    };
  }, [completionCandidates, readOnly, selection, value]);

  const updateSelection = useCallback(
    (start: number, end: number) => {
      setSelection({ start, end });
      onSelectionChange?.(start, end);
    },
    [onSelectionChange],
  );

  const syncScroll = useCallback((scrollTop: number, scrollLeft: number) => {
    if (overlayRef.current) {
      overlayRef.current.style.transform = `translate(-${scrollLeft}px, -${scrollTop}px)`;
    }
    if (lineNumbersRef.current) {
      lineNumbersRef.current.style.transform = `translateY(-${scrollTop}px)`;
    }
  }, []);

  if (readOnly) {
    const readOnlyPaddingX = compact ? 1.5 : 3;
    const readOnlyPaddingY = compact ? 1.35 : 2;
    const readOnlyFontSize = compact ? '13.25px' : SQL_EDITOR_METRICS.fontSize;
    const readOnlyLineHeight = compact ? 1.72 : 1.65;

    return (
      <AiaBox
        sx={{
          flex: 1,
          minHeight: 0,
          px: readOnlyPaddingX,
          pt: 0,
          pb: readOnlyPaddingY,
          bgcolor: 'transparent',
          ...SQL_EDITOR_SCROLL_SX,
        }}
      >
        {value.trim() && showLineNumbers ? (
    
          <AiaBox
            component="pre"
            sx={{
              m: 0,
              display: 'grid',
              gridTemplateColumns: 'max-content minmax(0, 1fr)',
              fontFamily: SQL_MONO_FONT,
              fontSize: readOnlyFontSize,
              color: '#cbd5e1',
              lineHeight: readOnlyLineHeight,
            }}
          >
            {highlightLines.map((lineTokens, index) => (
              <Fragment key={index}>
                <AiaBox
                  component="span"
                  aria-hidden
                  sx={{
                    pr: 1.25,
                    mr: 1.5,
                    textAlign: 'right',
                    color: SQL_LINE_NUMBER_COLOR,
                    borderRight: `1px solid ${SQL_EDITOR_COLORS.border}`,
                    userSelect: 'none',
                  }}
                >
                  {index + 1}
                </AiaBox>
                <AiaBox
                  component="span"
                  sx={{ minWidth: 0, whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}
                >
                  <SqlHighlight
                    text={lineTokens.map((token) => token.value).join('')}
                    tokens={lineTokens}
                  />
                </AiaBox>
              </Fragment>
            ))}
          </AiaBox>
        ) : value.trim() ? (
          <AiaBox
            component="pre"
            sx={{
              m: 0,
              fontFamily: SQL_MONO_FONT,
              fontSize: readOnlyFontSize,
              color: '#cbd5e1',
              whiteSpace: 'pre-wrap',
              wordBreak: 'break-word',
              lineHeight: readOnlyLineHeight,
            }}
          >
            <SqlHighlight text={value} tokens={highlightTokens} />
          </AiaBox>
        ) : (
          <AiaText
            sx={{
              fontFamily: SQL_MONO_FONT,
              fontSize: compact ? readOnlyFontSize : '0.78rem',
              color: SQL_EDITOR_COLORS.muted,
              fontStyle: 'italic',
              lineHeight: readOnlyLineHeight,
            }}
          >
            {emptyText}
          </AiaText>
        )}
      </AiaBox>
    );
  }

  return (
    <AiaBox
      sx={{
        display: 'flex',
        flex: 1,
        minHeight: 0,
        minWidth: 0,
        overflow: 'hidden',
        bgcolor: SQL_EDITOR_COLORS.panelBg,
      }}
    >
      {showLineNumbers ? (
        <AiaBox
          sx={{
            minWidth: SQL_EDITOR_METRICS.lineNumberWidth,
            flexShrink: 0,
            alignSelf: 'stretch',
            borderRight: `1px solid ${SQL_EDITOR_COLORS.border}`,
            overflow: 'hidden',
            position: 'relative',
          }}
        >
          <AiaBox
            ref={lineNumbersRef}
            sx={{
              py: SQL_EDITOR_METRICS.paddingY,
              px: 1,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'flex-end',
              fontFamily: SQL_MONO_FONT,
              fontSize: SQL_EDITOR_METRICS.fontSize,
              lineHeight: SQL_EDITOR_METRICS.lineHeight,
              color: SQL_LINE_NUMBER_COLOR,
              pointerEvents: 'none',
              userSelect: 'none',
              willChange: 'transform',
            }}
          >
            {Array.from({ length: lineCount }, (_, index) => (
              <AiaBox key={index + 1}>{index + 1}</AiaBox>
            ))}
          </AiaBox>
        </AiaBox>
      ) : null}

      <AiaBox sx={{ position: 'relative', flex: 1, minWidth: 0, minHeight: 0 }}>
        <AiaBox
          aria-hidden
          sx={{
            position: 'absolute',
            inset: 0,
            overflow: 'hidden',
            pointerEvents: 'none',
            color: SQL_EDITOR_COLORS.text,
          }}
        >
          <AiaBox
            ref={overlayRef}
            sx={{ ...textSx, willChange: 'transform' }}
          >
            {visibleHighlightText ? (
              completion ? (
                <>
                  <SqlHighlight
                    text={value.slice(0, selection.start)}
                    tokens={tokenizeSql(value.slice(0, selection.start))}
                  />
                  <AiaBox
                    component="span"
                    sx={{ color: '#64748b', opacity: 0.72 }}
                  >
                    {completion.suffix}
                  </AiaBox>
                  <SqlHighlight
                    text={value.slice(selection.start)}
                    tokens={tokenizeSql(value.slice(selection.start))}
                  />
                </>
              ) : (
                <SqlHighlight text={visibleHighlightText} tokens={highlightTokens} />
              )
            ) : null}
          </AiaBox>
        </AiaBox>

        <AiaBox
          component="textarea"
          ref={textareaRef}
          value={value}
          wrap={showLineNumbers ? 'off' : undefined}
          onChange={(event) => {
            onChange?.(event.target.value);
            updateSelection(event.currentTarget.selectionStart, event.currentTarget.selectionEnd);
          }}
          onSelect={(event) => {
            updateSelection(
              event.currentTarget.selectionStart,
              event.currentTarget.selectionEnd,
            );
          }}
          onKeyDown={(event) => {
            if (event.key !== 'Tab' || !completion || !onChange) return;
            event.preventDefault();
            const nextValue = `${value.slice(0, completion.prefixStart)}${completion.candidate}${value.slice(selection.end)}`;
            const nextCaret = completion.prefixStart + completion.candidate.length;
            onChange(nextValue);
            updateSelection(nextCaret, nextCaret);
            requestAnimationFrame(() => {
              textareaRef.current?.focus();
              textareaRef.current?.setSelectionRange(nextCaret, nextCaret);
            });
          }}
          onScroll={(event) => {
            syncScroll(event.currentTarget.scrollTop, event.currentTarget.scrollLeft);
          }}
          placeholder={placeholder}
          spellCheck={false}
          sx={{
            position: 'absolute',
            inset: 0,
            width: '100%',
            height: '100%',
            resize: 'none',
            border: 'none',
            bgcolor: 'transparent',
            color: 'transparent',
            caretColor: SQL_EDITOR_COLORS.text,
            WebkitTextFillColor: 'transparent',
            outline: 'none',
            boxSizing: 'border-box',
            ...textSx,
            ...SQL_EDITOR_SCROLL_SX,
            '&::placeholder': {
              color: SQL_EDITOR_COLORS.placeholder,
              WebkitTextFillColor: SQL_EDITOR_COLORS.placeholder,
            },
            '&::selection': {
              bgcolor: SQL_EDITOR_COLORS.selection,
              WebkitTextFillColor: 'transparent',
            },
          }}
        />
      </AiaBox>
    </AiaBox>
  );
}
