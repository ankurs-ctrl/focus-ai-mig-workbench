# Client V8 findings corrected in V9

V9 is a cumulative delta from the user-confirmed V5.1 / client commit `49c6a576def79e5bb02aa8326502a90d680b9477`, not just a patch to V8. It includes the prior V6–V8 protections. No changes have been pushed or deployed here. No shared Snowflake agent definition, env file, credential, database migration, deadline, permit-pool setting or output limit was changed.

## 1. Null bindings during SQL-upload preparation

Production preparation can generate lineage cards with `binding: null`. In particular, a selected derived-source node can resolve both its graph relation and a separate cached semantic relation via `derived_source_id`. The cached metadata has no outer graph binding; treating it as a binding dictionary caused the reported `.get` exception.

Typed node reads now require a real binding dictionary with the exact node relation identity before pinning a card. Unbound lineage and target metadata are skipped for that typed binding read. They remain in the frozen archive and applicable metadata; they are not promoted into selectable columns. A missing binding is never replaced with the selected node's binding or inferred from a display name. Regression fixtures generate these cards through production preparation, with 1/10/37 targets, a 600-column parent and varied cached outputs. Hidden cached and parent fields remain unselectable.

This is a synthetic reproduction of the observed cause, not a replay of mapping 3001's approximately 996k-character archived request. Subsequent client-specific SQL/proof issues can only be assessed by that client's acceptance run.

## 2. Normal agent responses rejected by the block-review contract

The original block tests mostly supplied the custom minimal response template. The client's live agent used the application's normal version-1 envelope and nested `data.agent`. The old validator rejected that valid transport form before reaching quote validation.

V9 supports two explicit forms: the legacy direct review envelope and the normal v1 agent envelope. It type-checks the normal `contract_version`, `request_id`, `operation`, inert warnings, empty context and documented inactive data fields. The source agent may appear at root, under data, or identically in both places. Explicit completion is required. The prompt now supplies a normal v1 request/response example with `sttm.auto_map`, `AUTO_MAP` and nested `AGT_SOURCE_MAPPING`.

The allowlist remains. Conflicting agents/status/results, nested or root delegation/actions, nonempty returned context/actions, artifacts, explicit errors, unknown fields, duplicate JSON keys, nonfinite values, incorrect block IDs, fabricated quotes and extra fact fields remain rejected. Facts contain only literal `quote` strings and may be empty when no excerpt is relevant. No prose or model observation becomes verified evidence. A completed malformed response gets one bounded format correction carrying a safe specific validator reason; uncertain transport calls are not blindly replayed. Required block failures retain that safe reason in the unresolved outcome. No raw SQL or semantic text is added to logs.

Tests cover normal and legacy positives, negative envelopes, the real guarded runtime, actual specialist dispatch/SQL validation and a 37-target parent/four-worker freeze/restore/wire/governance path. Fake model responses prove protocol execution and preservation, not business correctness.

## 3. Key-profile elimination confused with mapping eligibility

Evidence references now retain their semantic field path, record/relation ownership and purpose. The block reader receives that ownership and instructions distinguishing key-candidate elimination for nulls/uniqueness from mapping eligibility.

Known diagnostic child fields such as `pk_detection.eliminated_candidates` and their `key_contract` equivalent remain exact, addressable optional blocks. They do not gate every source or target before a decision. Confirmed keys, key notes, grain, business rules, joins, CTE output contracts and mandatory learning remain required evidence; whole `pk_detection`/`key_contract` bodies are not indiscriminately exempted. The global renderer preserves individual typed records when optional diagnostic children are present. Required-only globals retain their shared exact aggregate capsule, avoiding repeated framing and futile per-column packing across a large target set. Aggregate ownership is recorded as a required global record set; its original record IDs and relation context remain in the exact JSON.

The archive retains the original complete profile. The graph exposes purpose and required/unread coverage separately. An agent needing a particular diagnostic can return the existing unresolved-result schema plus `meta.evidence_requests` with the current snapshot, target, verified `source_refs`, and optional `evidence_roots`. The backend verifies root ownership before promoting that read into required work, reviews it through the same guarded runtime, then calls the decision agent again. Unknown roots/bindings cannot authorize reads. Identical text occurring in a mandatory business constraint remains required even if a profiling occurrence is optional. Nothing claims optional unread blocks were examined.

## 4. Reevaluation downgraded saved mapping status

The backend now exposes `reevaluate` and `had_baseline` separately from its pending decision status in both partial and final diagnostics. The frontend recognizes explicit reevaluation from those diagnostics or the immutable active-run selection and settles the untouched row back to its run-start status. Pending replacement work is not a validation result for the existing definition.

Mapped source, empty-string constant and project-attribute definitions stay mapped. An originally unmapped definition stays unmapped; this fix does not certify it. The separate non-reevaluation path can still mark an unproven baseline unresolved. V8's original-revision fencing, stale-proposal rejection, manual-edit protection and nonapplicable unresolved replacement checks remain intact.

The already affected client mapping 3101 is not silently marked mapped by this package: its persisted status may already be unmapped. Restore/validate its known original definition through the normal client workflow, or use a fresh controlled copy. Nonempty text alone must not be used to certify historical rows.

## 5. Completion summary and discoverability

The completion notice counts actually applied new mappings, queued new proposals, queued replacement proposals, retained original definitions and unresolved targets separately. Queue counts come from this run's actual reducer state, not `mapped_count == 0`. Retained and replacement counts may overlap intentionally: a saved definition can remain intact while its replacement awaits review. Results for older runs or unchecked targets are excluded. Manual edits made during the run are not counted as newly applied Auto-map mappings.

Both the persistent mapping notice and completion toast offer a Review proposals action. It switches the assistant to chat and opens it; a replacement is still applied only through existing explicit acceptance and freshness checks. Review notices do not auto-dismiss as success. Backend review text remains available in the AI Summary.

## 6. Single Auto-map button

The selection sidebar has one Auto-map execution button and explains its scope. No checked rows means all targets are processed, with existing definitions retained by default; checked rows mean exactly those targets, and checked existing definitions are reevaluated as reviewable replacements. The additional Retry unresolved and Reevaluate all execution buttons are removed from this sidebar. Internal explicit retry/reevaluation contracts remain supported for compatibility and regression coverage; they are not extra visible execution buttons here. No unchecked target is automatically changed.

## Additional packing regression checks

During the broader V9 review, keeping every global record individually framed caused repeated unsuccessful per-column packing on the existing 35-target Ft. Pitt fixture. Required-only global evidence now retains the original exact aggregate packing; typed optional diagnostic children remain separate. A regression bounds the number of complete-message packing attempts on that production-SQL fixture. The original fixture's local call time is recorded in TEST_RESULTS.md; it is not a live-model latency measurement. Small globals remain inline when they occupy at most one quarter of the configured allowance, even if large optional candidates require finer child blocks. The exact final message is still measured against both caps; no evidence is truncated. Failed optional admission attempts restore their enabled/threshold configuration together with the original bindings. They cannot force unrelated small mandatory context into unnecessary review calls. The existing single-decision isolation test remains unchanged and passes.

The existing lossless text interner also used an unanchored regular expression that repeatedly rescanned long delimiter-free suffixes. It now finds delimiters in one pass while retaining every comma, semicolon, newline, space and tab. Reassembly tests include long ASCII/Unicode suffixes, quotes, SQL literals and repeated join text. No SQL parsing or rewriting is introduced by text factoring.

The older unread-source regression originally selected a column from a separate preparation, which could differ from the actual worker packet after governance/canonicalization. Its model fixture now chooses the unread real binding from the first actual outbound inventory and verifies that it becomes selectable only on the second decision. The application validation was not relaxed to satisfy the test.

## Why the prior verification missed this

The previous tests did not jointly cover the normal live agent wrapper, cached derived-source semantics producing null bindings, and a pending backend reevaluation diagnostic on a mapped frontend row. V9 adds those concrete production paths instead of accepting the custom template alone as integration proof. Full offline regression remains distinct from live client acceptance, real model reasoning and actual Snowflake compilation.
