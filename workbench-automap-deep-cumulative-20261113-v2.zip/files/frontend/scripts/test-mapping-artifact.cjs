// Run with node; use the project's installed TypeScript compiler, no test dependency.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
const Module = require('node:module');

const filename = path.resolve(__dirname, '../src/features/sttm/mapping/mapping-sql-artifact.ts');
const compiled = ts.transpileModule(fs.readFileSync(filename, 'utf8'), {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 },
});
const loaded = new Module(filename, module);
const pureCache = new Map();
function loadPure(file) {
  if(pureCache.has(file))return pureCache.get(file).exports;
  const instance=new Module(file,module);pureCache.set(file,instance);
  instance.require=name=>{
    if(name.startsWith('@/')||name.startsWith('.')) {
      let target=name.startsWith('@/')?path.resolve(__dirname,'../src',name.slice(2)):path.resolve(path.dirname(file),name);
      if(!path.extname(target))target+='.ts';return loadPure(target);
    }
    return require(name);
  };
  instance._compile(ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText,file);
  return instance.exports;
}
loaded.require = name=>name.startsWith('.')?loadPure(path.resolve(path.dirname(filename),name+'.ts')):require(name);
loaded._compile(compiled.outputText, filename);
const { selectMappingSqlArtifact, buildMappingCompilerContextHash, normalizeCompilerContextHash, savedCompilerSemanticContext } = loaded.exports;
const base = { relationGraph: {}, mappings: [], targetTable: 'CRM.HOUSEHOLD', projectId: 'firm-a', firmValues: [{ name: 'FirmID', value: 'A' }] };
const currentCompilerHash = buildMappingCompilerContextHash(base);
assert.match(currentCompilerHash, /^sha256:[0-9a-f]{64}$/);
assert.equal(buildMappingCompilerContextHash({ ...base, semanticContext: "x".repeat(74_000) }).length, 71);
const legacySerialized = JSON.stringify({ compilerContractVersion: "physical-column-case-v2",
  projectId: "firm-a", semanticContext: [] });
assert.equal(normalizeCompilerContextHash(legacySerialized),
  `sha256:${require('node:crypto').createHash('sha256').update(legacySerialized).digest('hex')}`);
const legacyCompilerInput = { ...base, compilerContractVersion: "physical-column-case-v1" };
assert.equal(selectMappingSqlArtifact({compiledSql:'SELECT a.BillFrequency', compiledPreviewSql:'SELECT a.BillFrequency',
  compiledReady:true, compiledContextHash:JSON.stringify(legacyCompilerInput), currentContextHash:currentCompilerHash,
  fallbackSql:'draft', fallbackPreviewSql:'draft', allowFallback:false}).source, 'generated');
assert.notEqual(buildMappingCompilerContextHash(base), buildMappingCompilerContextHash({ ...base, projectId: 'firm-b' }));
assert.notEqual(buildMappingCompilerContextHash(base), buildMappingCompilerContextHash({ ...base, firmValues: [{ name: 'FirmID', value: 'B' }] }));
const input = { compiledSql: "INSERT INTO CRM.HOUSEHOLD SELECT 'A'", compiledPreviewSql: "SELECT 'A'", compiledScriptSql: "SET FirmID = 'A';\nSELECT $FirmID;", compiledContextHash: currentCompilerHash, currentContextHash: currentCompilerHash, compiledReady: true, fallbackSql: 'draft', fallbackPreviewSql: 'draft' };
const artifact = selectMappingSqlArtifact(input);
assert.equal(artifact.scriptSql, input.compiledScriptSql);
assert.equal(artifact.previewSql, "SELECT 'A'");
assert.equal(artifact.generatedSql, input.compiledSql);
assert.equal(selectMappingSqlArtifact({ ...input, compiledReady: false }).ready, false);
assert.equal(selectMappingSqlArtifact({ ...input, currentContextHash: 'changed' }).scriptSql, 'draft');
assert.equal(selectMappingSqlArtifact({ ...input, currentContextHash: 'changed', allowFallback:false }).scriptSql, '');
assert.equal(selectMappingSqlArtifact({ ...input, allowFallback:false }).source, 'compiled');
assert.equal(selectMappingSqlArtifact({fallbackSql:'unsafe draft',fallbackPreviewSql:'unsafe draft',
  authoredSql:'SELECT 1',authoredIsCurrent:true,allowFallback:false}).source, 'authored');
assert.equal(selectMappingSqlArtifact({ ...input, currentContextHash: 'changed', authoredIsCurrent: true,
  authoredSql: input.compiledSql, authoredPreviewSql: input.compiledPreviewSql }).source, 'generated');
assert.notEqual(buildMappingCompilerContextHash(base), buildMappingCompilerContextHash({ ...base, semanticContext: { grain: 'household' } }));
console.log('Mapping SQL artifact regressions passed.');
const semantics = [{ table: { database: 'DB', schema: 'SRC', table: 'CONTACTS' }, semantic_model: { grain: 'contact' } }];
const savedHash = buildMappingCompilerContextHash({ ...base, semanticContext: semantics });
assert.deepEqual(savedCompilerSemanticContext(savedHash, 'firm-a', semantics, 'firm-a'), semantics);
assert.equal(savedCompilerSemanticContext(savedHash, 'firm-b', semantics, 'firm-a'), null);
assert.equal(savedCompilerSemanticContext('invalid', 'firm-a'), null);
assert.equal(savedCompilerSemanticContext(JSON.stringify({ projectId: 'firm-a', semanticContext: [{}] }), 'firm-a'), null);
assert.deepEqual(savedCompilerSemanticContext(JSON.stringify({ projectId: 'firm-a', semanticContext: semantics }), 'firm-a'), semantics);
assert.equal(buildMappingCompilerContextHash({ ...base, semanticContext: savedCompilerSemanticContext(savedHash, 'firm-a', semantics, 'firm-a') }), savedHash);
console.log('Saved semantic inputs survive reopen without weakening currency checks.');
const multiSource = { status: 'MAPPED', targetColumn: 'STREET', sourceColumns: ['a.STREET', 'a.UNIT'],
  expression: "CONCAT(a.STREET, a.UNIT)", sourceColumn: 'a.STREET' };
assert.equal(buildMappingCompilerContextHash({ ...base, mappings: [multiSource] }),
  buildMappingCompilerContextHash({ ...base, mappings: [{ ...multiSource, sourceColumn: 'a.STREET, a.UNIT' }] }));

// Exercise the actual rejection reducer without loading the UI/API dependency tree.
const sliceFile = path.resolve(__dirname, '../src/features/sttm/store/sttm-builder-slice.ts');
const source = ts.createSourceFile(sliceFile, fs.readFileSync(sliceFile, 'utf8'), ts.ScriptTarget.Latest, true);
const predicateFunctions = new Set(['snapshotTableFqn', 'normalizeSnapshotRelationships',
  'normalizedRelationshipSignature', 'deduplicateRelationships']);
const predicateModule = new Module(sliceFile, module);
predicateModule._compile(ts.transpileModule(source.statements
  .filter(node => ts.isFunctionDeclaration(node) && predicateFunctions.has(node.name?.text))
  .map(node => node.getText(source)).join('\n') + '\nmodule.exports = {normalizeSnapshotRelationships,deduplicateRelationships};', {
    compilerOptions: {module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020},
  }).outputText, sliceFile);
const restoredPredicate = predicateModule.exports.normalizeSnapshotRelationships([{
  edge_id:'edge-preserved',left_relation_id:'D.S.A',right_relation_id:'D.S.B',join_type:'LEFT',conditions:[],
  additional_predicate:'a.ID = b.ID OR b.ID IS NULL',
}]);
assert.equal(restoredPredicate[0].sqlPredicate,'a.ID = b.ID OR b.ID IS NULL');
assert.equal(restoredPredicate[0].id,'edge-preserved');
assert.equal(predicateModule.exports.deduplicateRelationships([
  restoredPredicate[0],{...restoredPredicate[0],sqlPredicate:'a.ID = b.ID AND b.ID IS NOT NULL'},
]).length,2);
console.log('Snapshot reopen and deduplication retain full join predicates.');
const authoredFile = path.resolve(__dirname, '../src/features/sttm/mapping/authored-sql-key.ts');
const authoredModule = new Module(authoredFile,module);
authoredModule._compile(ts.transpileModule(fs.readFileSync(authoredFile,'utf8'), {
  compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020},
}).outputText,authoredFile);
const authoredState = {sources:[],derivedSources:[],relationships:restoredPredicate,mappings:[]};
const authoredKey = authoredModule.exports.computeAuthoredSqlSemanticKey(authoredState);
assert.notEqual(authoredKey, authoredModule.exports.computeAuthoredSqlSemanticKey({...authoredState,
  relationships:[{...restoredPredicate[0],sqlPredicate:'a.ID = b.ID'}]}));
assert.notEqual(authoredKey, authoredModule.exports.computeAuthoredSqlSemanticKey({...authoredState,
  sourceQueryModifiers:{limit:'LIMIT 2'}}));
console.log('Full predicates and query modifiers invalidate authored SQL currency.');
const placeholder = {id:'catalog-1',targetColumn:'UNUSED',targetType:'VARCHAR',sourceColumn:null,sourceType:null,
  expression:null,rule:'Select...',status:'UNMAPPED',nlRule:null,loadOrder:null,description:null,
  confidenceScore:null,confidenceReason:null,candidateSourceColumns:[],unmatchedReason:null,aiSuggestedRule:null,aiSuggestedRuleType:null};
assert.equal(authoredModule.exports.computeAuthoredSqlSemanticKey({...authoredState,mappings:[placeholder]}),authoredKey,
  'untouched catalog placeholder must not invalidate uploaded SQL');
for(const change of [{expression:'a.ID'},{sourceColumn:'a.ID'},{sourceColumns:['a.ID']},{constantValue:''},
  {mappingMode:'constant'},{mappingMode:'attribute',attributeName:'Firm'},{rule:'Custom'},{nlRule:'Use ID'},
  {status:'MAPPED'},{manuallySaved:true},{description:'intent'},{sourceDependencies:['D.S.A']},
  {unmatchedReason:'review required'},{valueBindingIds:['value:one']}]) {
  assert.notEqual(authoredModule.exports.computeAuthoredSqlSemanticKey({...authoredState,mappings:[{...placeholder,...change}]}),authoredKey,
    `meaningful unmapped intent must remain keyed: ${JSON.stringify(change)}`);
}
const mappedState={...authoredState,mappings:[{...placeholder,targetColumn:'ID',status:'MAPPED',sourceColumns:['a.ID'],rule:'Direct'}]};
const mappedKey=authoredModule.exports.computeAuthoredSqlSemanticKey(mappedState);
for(const change of [{targetColumn:'OTHER'},{targetType:'NUMBER'},{sourceColumns:['a.OTHER']},{expression:'TRIM(a.ID)'},
  {mappingMode:'attribute',attributeName:'Other'},{mappingMode:'constant',constantValue:'changed'}]) {
  assert.notEqual(authoredModule.exports.computeAuthoredSqlSemanticKey({...mappedState,mappings:[{...mappedState.mappings[0],...change}]}),mappedKey);
}
console.log('Only empty placeholders are excluded; real mapping, type, constant, attribute and transform changes invalidate.');
assert.equal(authoredModule.exports.authoredSqlIsCurrent('SELECT 1','ask1:1b3dc9ff:4o',authoredState),false);
assert.equal(authoredModule.exports.authoredSqlIsCurrent('SELECT 1','ask1:1b3dc9ff:4o',{...authoredState,mappings:[placeholder]}),false);
assert.equal(authoredModule.exports.authoredSqlIsCurrent('SELECT 1','ask1:1b3dc9ff:4o',mappedState),false);
assert.notEqual(authoredModule.exports.computeAuthoredSqlSemanticKey({...mappedState,targets:[{isSelected:true,qualifiedName:'D.T.ONE'}]}),
  authoredModule.exports.computeAuthoredSqlSemanticKey({...mappedState,targets:[{isSelected:true,qualifiedName:'D.T.TWO'}]}));
console.log('Legacy lossy keys remain recoverable but cannot certify current SQL.');
const providerFile = path.resolve(__dirname, '../src/features/sttm/context/sttm-builder-context.tsx');
const providerSource = ts.createSourceFile(providerFile,fs.readFileSync(providerFile,'utf8'),ts.ScriptTarget.Latest,true);
let hydrationCleanup;
function findHydrationCleanup(node) {
  if (ts.isReturnStatement(node) && node.expression && ts.isArrowFunction(node.expression)
    && node.expression.getText(providerSource).includes('window.clearTimeout(selectionMetadataTimerRef.current)')) {
    hydrationCleanup=node.expression.getText(providerSource);
  }
  ts.forEachChild(node,findHydrationCleanup);
}
findHydrationCleanup(providerSource);
assert.ok(hydrationCleanup);
const cleanupModule=new Module(providerFile,module);
cleanupModule._compile(ts.transpileModule(`module.exports=(selectionMetadataTimerRef,attributeHydrationSignatureRef,window)=>(${hydrationCleanup})();`,{
  compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020},
}).outputText,providerFile);
const timerRef={current:42}, signatureRef={current:'unfetched-selection'};
cleanupModule.exports(timerRef,signatureRef,{clearTimeout:id=>assert.equal(id,42)});
assert.equal(timerRef.current,null);
assert.equal(signatureRef.current,null);
console.log('Cancelled column-catalog debounce can be retried on the next render.');
const cteFile=path.resolve(__dirname,'../src/features/sttm/source-target/add-derived-modal.tsx');
const cteSource=ts.createSourceFile(cteFile,fs.readFileSync(cteFile,'utf8'),ts.ScriptTarget.Latest,true);
let previewEffect, previewDependencies;
function findPreviewEffect(node) {
  if(ts.isCallExpression(node) && node.expression.getText(cteSource)==='useEffect'
    && node.arguments[0]?.getText(cteSource).includes('validatedSql.current === effectiveSqlExpression')) {
    previewEffect=node.arguments[0].getText(cteSource);
    previewDependencies=node.arguments[1].getText(cteSource);
  }
  ts.forEachChild(node,findPreviewEffect);
}
findPreviewEffect(cteSource);
assert.equal(previewDependencies,'[effectiveSqlExpression, isOpen]');
const previewModule=new Module(cteFile,module);
previewModule._compile(ts.transpileModule(`module.exports=({isOpen,effectiveSqlExpression,validatedSql,setPreviewColumnsState,setPreviewRowsState,setValidationState})=>(${previewEffect})();`,{
 compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020},
}).outputText,cteFile);
let changedMessages=0;
const effectInput={isOpen:true,effectiveSqlExpression:'SELECT 2',validatedSql:{current:null},
 setPreviewColumnsState:()=>{},setPreviewRowsState:()=>{},setValidationState:()=>changedMessages++};
previewModule.exports(effectInput);
assert.equal(changedMessages,0);
effectInput.validatedSql.current='SELECT 1';
previewModule.exports(effectInput);
assert.equal(changedMessages,1);
assert.equal(effectInput.validatedSql.current,null);
console.log('CTE Apply status is not overwritten by equivalent hydration state; real SQL changes invalidate preview.');
let rejectionReducer;
let fulfilledReducer;
function visit(node) {
  if (ts.isCallExpression(node) && node.arguments[0]?.getText(source) === 'runAutoMap.rejected') {
    rejectionReducer = node.arguments[1].getText(source);
  }
  if (ts.isCallExpression(node) && node.arguments[0]?.getText(source) === 'runAutoMap.fulfilled') {
    fulfilledReducer = node.arguments[1].getText(source);
  }
  ts.forEachChild(node, visit);
}
visit(source);
assert.ok(rejectionReducer);
const lifecycleNames = new Set(['isCurrentAutoMapRun', 'restoreAutoMapStatus', 'autoMapRowIsEdited', 'autoMapInputSignature']);
const lifecycleSource = source.statements.filter(node => ts.isFunctionDeclaration(node)
  && lifecycleNames.has(node.name?.text)).map(node => node.getText(source)).join('\n');
const runState = () => ({activeSttmId:'sttm', activeProjectId:'project', pendingManualEditSnapshots:{},
  autoMapRun:{requestId:'run', sttmId:'sttm', projectId:'project', expectedInputs:{}, baseline:{}}});
const reducerModule = new Module(sliceFile, module);
reducerModule.require=name=>name.startsWith('@/')?loadPure(path.resolve(__dirname,'../src',name.slice(2)+'.ts')):require(name);
reducerModule._compile(ts.transpileModule(`import {rowMappingStatus} from "@/features/sttm/shared/row-validation-state";
import {selectionValidationSignature} from "@/features/sttm/shared/validation-context";
${lifecycleSource}\nmodule.exports = ${rejectionReducer}`, {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 },
}).outputText, sliceFile);
const failedState = { ...runState(), mappingLoading: true, autoMapProcessingIds: ['pending'], autoMapStatusMessage: 'Working',
  mappings: [{ id: 'pending', status: 'PROCESSING' }, { id: 'done', status: 'MAPPED', confidenceScore: 0.9 }], errorState: {} };
reducerModule.exports(failedState, { meta:{requestId:'run'}, payload: 'Context preparation failed' });
assert.equal(failedState.mappingLoading, false);
assert.deepEqual(failedState.autoMapProcessingIds, []);
assert.equal(failedState.mappings[0].status, 'UNMAPPED');
assert.equal(failedState.mappings[1].status, 'MAPPED');
assert.equal(failedState.errorState.autoMap, 'Context preparation failed');
console.log('Auto-map rejection state regression passed.');

const fulfilledModule = new Module(sliceFile, module);
fulfilledModule.require=reducerModule.require;
fulfilledModule._compile(ts.transpileModule(`import {rowMappingStatus} from "@/features/sttm/shared/row-validation-state";
import {selectionValidationSignature} from "@/features/sttm/shared/validation-context";
${lifecycleSource}\nmodule.exports = ${fulfilledReducer}`, {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 },
}).outputText, sliceFile);
const completedState = { ...runState(), mappingLoading: true, autoMapProcessingIds: ['review'],
  mappings: [{ id: 'review', status: 'PROCESSING' }, { id: 'done', status: 'MAPPED' }] };
fulfilledModule.exports(completedState, { meta:{requestId:'run'}, payload: null });
assert.equal(completedState.mappings[0].status, 'UNMAPPED');
assert.equal(completedState.mappings[1].status, 'MAPPED');
console.log('Completed Auto-map does not leave review rows processing.');

const functionNames = new Set(['isStructuredSqlExpression', 'applyMappingSuggestion']);
const functionSources = source.statements.filter(node => ts.isFunctionDeclaration(node) && functionNames.has(node.name?.text)).map(node => node.getText(source));
const suggestionModule = new Module(sliceFile, module);
suggestionModule.require=reducerModule.require;
suggestionModule._compile(ts.transpileModule(`import {rowMappingStatus} from "@/features/sttm/shared/row-validation-state";\n${functionSources.join('\n')}\nmodule.exports = applyMappingSuggestion;`, {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 },
}).outputText, sliceFile);
const directRow = {};
suggestionModule.exports(directRow, { sourceAttributes: ['a.CITY'], confidenceScore: 0.9,
  preprocessingRuleType: 'Direct', preprocessingRule: 'Use source city directly.' });
assert.equal(directRow.expression, null);
assert.equal(directRow.rule, 'Direct');
const transformedRow = {};
suggestionModule.exports(transformedRow, { sourceAttributes: ['a.CITY'], confidenceScore: 0.9,
  preprocessingRuleType: 'Custom', preprocessingRule: 'TRIM(a.CITY)' });
assert.equal(transformedRow.expression, 'TRIM(a.CITY)');
console.log('Direct mapping prose is not executable SQL.');

// Execute the real compiler-request row projection: persisted AI IDs cannot
// override the binding identity owned by the current graph's mapping row.
const pageFile = path.resolve(__dirname, '../src/app/sttm/builder/new/mapping/page.tsx');
const pageSource = ts.createSourceFile(pageFile, fs.readFileSync(pageFile, 'utf8'), ts.ScriptTarget.Latest, true);
let statusPanelSource;
function findStatusPanel(node) {
  if (ts.isJsxAttribute(node) && node.name.getText(pageSource) === 'statusPanel') statusPanelSource = node.getText(pageSource);
  ts.forEachChild(node, findStatusPanel);
}
findStatusPanel(pageSource);
assert.ok(statusPanelSource.includes("cteDraft.status === 'complete' ? 'info' : 'warning'"));
assert.ok(statusPanelSource.includes("fontSize: '0.8rem'"));
assert.ok(statusPanelSource.includes('component="details"'));
assert.ok(statusPanelSource.includes('Review draft issues'));
assert.ok(!pageSource.text.includes('<AiaBox role="status" sx={{px: 2, py: 1'));
console.log('Draft notices use the shared compact status panel with expandable issues.');
let projectCompilerRow;
function visitCompilerRow(node) {
  if (ts.isCallExpression(node) && node.expression.getText(pageSource).startsWith('activeMappings.map')
      && node.arguments[0]?.getText(pageSource).includes('target_column: mapping.targetColumn')) {
    projectCompilerRow = node.arguments[0].getText(pageSource);
  }
  ts.forEachChild(node, visitCompilerRow);
}
visitCompilerRow(pageSource);
assert.ok(projectCompilerRow);
const rowModule = new Module(pageFile, module);
rowModule._compile(ts.transpileModule(`module.exports = ${projectCompilerRow}`, {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 },
}).outputText, pageFile);
for (const mode of ['attribute', 'constant']) {
  const row = rowModule.exports({ id: 'parent', mappingMode: mode, sourceColumns: [],
    sourceDependencies: [], valueBindingIds: ['project-attribute:stale-model-id'] });
  assert.deepEqual(row.value_binding_ids, ['value:parent']);
}
console.log('Compiler request uses current row-owned value bindings.');

// Review may obtain a temporary Analyst model, but cannot mutate the prepared
// semantics and thereby invalidate the just-compiled SET artifact.
let validateFunction;
function visitValidation(node) {
  if (ts.isVariableDeclaration(node) && node.name.getText(pageSource) === 'handleValidateSql') {
    validateFunction = node.initializer;
  }
  ts.forEachChild(node, visitValidation);
}
visitValidation(pageSource);
assert.ok(validateFunction);
const validationCalls = [];
function collectCalls(node) {
  if (ts.isCallExpression(node)) validationCalls.push(node.expression.getText(pageSource));
  ts.forEachChild(node, collectCalls);
}
collectCalls(validateFunction);
assert.ok(validationCalls.includes('dbService.refreshSemanticContext'));
assert.ok(!validationCalls.includes('applySemanticRefresh'));
console.log('SQL review preserves compiled artifact semantic currency.');

let restoredSourceColumn;
function visitRestoredColumn(node) {
  if (ts.isPropertyAssignment(node) && node.name.getText(source) === 'sourceColumn'
      && node.initializer.getText(source).includes('sourceColumns.join')) {
    restoredSourceColumn = node.initializer.getText(source);
  }
  ts.forEachChild(node, visitRestoredColumn);
}
visitRestoredColumn(source);
assert.ok(restoredSourceColumn);
const restoredModule = new Module(sliceFile, module);
restoredModule._compile(`module.exports = sourceColumns => (${restoredSourceColumn});`, sliceFile);
assert.equal(restoredModule.exports(['contacts.FIRST_NAME', 'contacts.LAST_NAME']),
  'contacts.FIRST_NAME, contacts.LAST_NAME');
assert.equal(restoredModule.exports([]), null);
console.log('Reopened multi-source mappings preserve their compiler input.');

const aliasFile = path.resolve(__dirname, '../src/features/sttm/mapping/relation-alias.ts');
const aliasModule = new Module(aliasFile, module);
aliasModule._compile(ts.transpileModule(fs.readFileSync(aliasFile, 'utf8'), {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 },
}).outputText, aliasFile);
const { relationAliasFor, buildRelationDisplayAliases, formatRelationDisplayText, splitSourceDisplayLabel } = aliasModule.exports;
const identity = 'agent_cte_0fa187a74c142419bb96';
const alias = relationAliasFor(identity, 'addresses_one_per_contacts');
const nodes = [{ identity, alias, displaySeed: 'addresses_one_per_contacts' }];
const labels = buildRelationDisplayAliases(nodes);
assert.equal(formatRelationDisplayText(`${alias}.CITY`, labels), 'addresses_one_per_contacts.CITY');
assert.equal(formatRelationDisplayText(`${identity}.CITY`, labels), 'addresses_one_per_contacts.CITY');
assert.equal(formatRelationDisplayText(`COALESCE(${alias}.CITY, '${alias}.CITY')`, labels),
  `COALESCE(addresses_one_per_contacts.CITY, '${alias}.CITY')`);
assert.equal(formatRelationDisplayText(`-- ${alias}.CITY\n${alias}.CITY`, labels),
  `-- ${alias}.CITY\naddresses_one_per_contacts.CITY`);
assert.equal(nodes[0].alias, alias);
assert.equal(formatRelationDisplayText(`Prepared source ${alias}.`, labels), 'Prepared source addresses_one_per_contacts.');
assert.deepEqual(splitSourceDisplayLabel(formatRelationDisplayText(`${alias}.CITY`, labels)),
  { column: 'CITY', relation: 'addresses_one_per_contacts' });
assert.deepEqual(splitSourceDisplayLabel('DB.SRC.ADDRESSES.CITY'), { column: 'CITY', relation: 'DB.SRC.ADDRESSES' });
assert.deepEqual(splitSourceDisplayLabel('Value'), { column: 'Value', relation: '' });
const duplicateLabels = buildRelationDisplayAliases([...nodes, { identity: 'another',
  alias: relationAliasFor('another', 'addresses_one_per_contacts'), displaySeed: 'addresses_one_per_contacts' }]);
assert.equal(duplicateLabels.get(alias.toUpperCase()), 'addresses_one_per_contacts_1');
assert.equal(duplicateLabels.get(relationAliasFor('another', 'addresses_one_per_contacts').toUpperCase()),
  'addresses_one_per_contacts_2');
assert.equal(buildRelationDisplayAliases([{ ...nodes[0], alias: 'custom_alias_123456' }]).size, 0);
const previewValue = pageSource.statements.find(node => ts.isFunctionDeclaration(node) && node.name?.text === 'stringifyPreviewValue');
const valueModule = new Module(pageFile, module);
valueModule._compile(ts.transpileModule(`${previewValue.getText(pageSource)}\nmodule.exports=stringifyPreviewValue;`, {
  compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 },
}).outputText, pageFile);
assert.equal(valueModule.exports(null), 'NULL');
assert.equal(valueModule.exports(undefined), 'Not sampled');
assert.equal(valueModule.exports(''), '(empty)');
assert.equal(valueModule.exports(0), '0');
assert.equal(valueModule.exports(false), 'false');
console.log('Preview aliases are display-only; missing, null and empty values remain distinct.');

let automaticCompileEffect;
function visitAutomaticCompile(node) {
  if (ts.isCallExpression(node) && node.expression.getText(pageSource) === 'useEffect'
      && node.arguments[0]?.getText(pageSource).includes('lastAutomaticCompileHash.current')) {
    automaticCompileEffect = node.arguments[0].getText(pageSource);
  }
  ts.forEachChild(node, visitAutomaticCompile);
}
visitAutomaticCompile(pageSource);
assert.ok(automaticCompileEffect);
const autoCompileModule = new Module(pageFile, module);
autoCompileModule._compile(ts.transpileModule(`module.exports = (state) => {
  const { autoCompile, mappingLoading, currentSqlArtifact, isCompilingSql, savedWorkspaceHydrating,
    isLoadingProjectAttributes, pendingManualEditSnapshots,
    reviewLoading, draftCount, lastAutomaticCompileHash, compilerContextHash, compileCurrentMappingSql, window } = state;
  return (${automaticCompileEffect})();
};`, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText, pageFile);
let pendingCompile;
let automaticCalls = 0;
const autoState = { autoCompile: true, mappingLoading: true, savedWorkspaceHydrating:false, isLoadingProjectAttributes:false,
  pendingManualEditSnapshots:{},
  currentSqlArtifact: { source: 'generated' }, activeTab: 'mapping', isCompilingSql: false,
  reviewLoading: false, draftCount: 2, lastAutomaticCompileHash: { current: null }, compilerContextHash: 'first',
  compileCurrentMappingSql: () => { automaticCalls += 1; },
  window: { setTimeout: callback => { pendingCompile = callback; return 1; }, clearTimeout: () => { pendingCompile = null; } } };
autoCompileModule.exports(autoState);
assert.equal(pendingCompile, undefined);
autoState.mappingLoading = false;
const cleanup = autoCompileModule.exports(autoState);
cleanup();
assert.equal(pendingCompile, null);
autoState.compilerContextHash = 'settled';
autoCompileModule.exports(autoState);
pendingCompile();
assert.equal(automaticCalls, 1);
assert.equal(autoCompileModule.exports(autoState), undefined);
autoState.compilerContextHash = 'new-firm-values';
autoCompileModule.exports(autoState);
pendingCompile();
assert.equal(automaticCalls, 2);
autoState.currentSqlArtifact.source = 'compiled';
assert.equal(autoCompileModule.exports(autoState), undefined);
autoState.currentSqlArtifact.source = 'generated';
autoState.compilerContextHash = 'reopened-draft';
autoState.activeTab = 'sql-preview';
autoCompileModule.exports(autoState);
pendingCompile();
assert.equal(automaticCalls, 3);
autoState.compilerContextHash='manual-edit';
autoState.activeTab='mapping';
autoState.pendingManualEditSnapshots={row:{status:'MAPPED'}};
assert.equal(autoCompileModule.exports(autoState), undefined);
autoState.pendingManualEditSnapshots={};
autoCompileModule.exports(autoState);
pendingCompile();
assert.equal(automaticCalls, 4);
autoState.compilerContextHash='hydrating';
autoState.savedWorkspaceHydrating=true;
assert.equal(autoCompileModule.exports(autoState), undefined);
autoState.savedWorkspaceHydrating=false;
autoState.isLoadingProjectAttributes=true;
assert.equal(autoCompileModule.exports(autoState), undefined);
autoState.isLoadingProjectAttributes=false;
autoCompileModule.exports(autoState);
pendingCompile();
assert.equal(automaticCalls, 5);
autoState.autoCompile = false;
autoState.compilerContextHash = 'off-edits';
assert.equal(autoCompileModule.exports(autoState), undefined);
assert.equal(automaticCalls, 5);
autoState.autoCompile = true;
autoCompileModule.exports(autoState);
pendingCompile();
assert.equal(automaticCalls, 6);
const failedDraft = {...multiSource, status:'VALIDATION_FAILED', rule:'Custom', expression:null};
assert.notEqual(buildMappingCompilerContextHash({...base,mappings:[failedDraft]}),
  buildMappingCompilerContextHash({...base,mappings:[{...failedDraft,attributeName:'Changed'}]}));
// Execute the actual control expression: zero validated rows with drafts remain recoverable.
let compileDisabled, generationFunction, submitFunction;
function collectTask5(node) {
 if(ts.isJsxAttribute(node)&&node.name.getText(pageSource)==='compileDisabled')compileDisabled=node.initializer.expression.getText(pageSource);
 if(ts.isVariableDeclaration(node)&&node.name.getText(pageSource)==='compileCurrentMappingSql')generationFunction=node.initializer.getText(pageSource);
 ts.forEachChild(node,collectTask5);
}
collectTask5(pageSource);
const controls=new Module(pageFile,module);
controls._compile(ts.transpileModule(`module.exports=({reviewLoading=false,pendingManualEditSnapshots={},draftCount=1,compilerRelationGraph={nodes:[{}]},isMappingSqlValidated=false,currentSqlArtifact={source:'generated'}}={})=>(${compileDisabled});`,{
 compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText,pageFile);
assert.equal(controls.exports(),false);
assert.equal(controls.exports({draftCount:0}),true);
assert.equal(controls.exports({pendingManualEditSnapshots:{row:{}}}),true);
assert.ok(generationFunction.includes('validate_with_explain: false'));
assert.ok(!generationFunction.includes('validatedRows:'));
const headerFile=path.resolve(__dirname,'../src/features/layout/app-header.tsx');
const headerSource=ts.createSourceFile(headerFile,fs.readFileSync(headerFile,'utf8'),ts.ScriptTarget.Latest,true);
function collectSubmit(node){if(ts.isVariableDeclaration(node)&&node.name.getText(headerSource)==='handlePublishMapping')submitFunction=node.initializer.getText(headerSource);ts.forEachChild(node,collectSubmit);}
collectSubmit(headerSource);
const submission=new Module(headerFile,module);
submission._compile(ts.transpileModule(`module.exports=async (isCurrentValidation)=>{let blocked=false;const store={getState:()=>({sttmBuilder:{pendingManualEditSnapshots:{edited:{}}}})};const isPublishing=false;const setPublishBlockedOpen=()=>{blocked=true};const setIsPublishing=()=>{throw new Error('must not create or publish')};await (${submitFunction})({publishMode:'version'});return blocked;};`,{
 compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText,headerFile);
require('node:test')('open modal submission rechecks live pending edits before side effects',async()=>{
 assert.equal(await submission.exports(()=>false),true);
});
let editSqlHandler;
function collectEditSql(node){if(ts.isJsxAttribute(node)&&node.name.getText(pageSource)==='onEditableSqlChange')editSqlHandler=node.initializer.expression.getText(pageSource);ts.forEachChild(node,collectEditSql);}
collectEditSql(pageSource);
const editSqlModule=new Module(pageFile,module);
editSqlModule._compile(ts.transpileModule(`module.exports=({sqlEditRevision,setEditableSql,dispatch,setSqlValidatedSignature})=>(${editSqlHandler});`,{
 compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText,pageFile);
const revision={current:0};let validationMarker='old',edited;
editSqlModule.exports({sqlEditRevision:revision,setEditableSql:sql=>edited=sql,dispatch:action=>validationMarker=action,
 setSqlValidatedSignature:signature=>signature})('SELECT unsaved');
assert.equal(revision.current,1);assert.equal(validationMarker,null);assert.equal(edited,'SELECT unsaved');
const asyncValidation=new Module(pageFile,module);
asyncValidation._compile(ts.transpileModule(`module.exports=(env)=>{const {
 validationRequestSignature,mappingSqlRequestPayload,reviewContextSignature,compilerContextHash,
 reviewErrorRef,setReviewError,setActiveTab,setReviewLoading,setPreviewError,setValidatedPreviewData,
 setReviewResult,setReviewBannerDismissed,setApprovedVariant,setReviewStage,refreshAssistantSignals,
 resolveReviewSemanticContext,dbService,latestCompileContext,lastValidatedReviewContextRef,
 setReviewSelectionVariant,setApprovedPreviewSql,setMappingPreviewSql,setMappingSqlVariant,setReviewDialogOpen
 }=env;return (${validateFunction.getText(pageSource)});};`,{
 compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText,pageFile);
require('node:test')('actual delayed SQL review cannot certify an edited SQL or pending-edit revision',async()=>{
 for(const reason of ['SQL edit','pending edit','Values changed']) {
  let revision='old',resolveReview;const results=[];const noop=()=>{};
  const env={validationRequestSignature:()=>revision,mappingSqlRequestPayload:{mappings:[{}]},reviewContextSignature:'old',compilerContextHash:'same-graph',
   reviewErrorRef:{current:null},latestCompileContext:{current:'same-graph'},lastValidatedReviewContextRef:{current:null},
   resolveReviewSemanticContext:async payload=>({payload}),dbService:{reviewMappingSql:()=>new Promise(resolve=>resolveReview=resolve)},
   setReviewResult:value=>results.push(value)};
  for(const key of ['setReviewError','setActiveTab','setReviewLoading','setPreviewError','setValidatedPreviewData','setReviewBannerDismissed','setApprovedVariant','setReviewStage','refreshAssistantSignals','setReviewSelectionVariant','setApprovedPreviewSql','setMappingPreviewSql','setMappingSqlVariant','setReviewDialogOpen'])env[key]=noop;
  const pending=asyncValidation.exports(env)();await new Promise(resolve=>setImmediate(resolve));revision=reason;
  resolveReview({execution_ready:true,original_preview_sql:'SELECT 1',original_generated_sql:'SELECT 1'});
  assert.equal(await pending,null);assert.deepEqual(results,[null]);assert.equal(env.lastValidatedReviewContextRef.current,null);
 }
});
console.log('Draft validation controls, proof-free generation and submission freshness regressions passed.');
// Execute actual page approval/Sync/compile functions with mocked API boundaries.
function pageFunction(name) {
  let result;
  function visit(node) {
    if (ts.isVariableDeclaration(node) && node.name.getText(pageSource) === name) {
      result = ts.isCallExpression(node.initializer) ? node.initializer.arguments[0] : node.initializer;
    }
    ts.forEachChild(node, visit);
  }
  visit(pageSource);
  assert.ok(result, name);
  const compiled = ts.transpileModule(`module.exports=(env)=>{with(env){return (${result.getText(pageSource)});}}`, {
    compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020},
  }).outputText;
  const instance = new Module(pageFile,module);
  instance._compile(compiled,pageFile);
  return instance.exports;
}
const approveReviewedSql = pageFunction('handleApproveReviewedSql');
const synchronizeSql = pageFunction('handleReviewSqlChanges');
const compileAndValidate = pageFunction('handleCompileAndValidate');
function reviewEnvironment() {
  const calls=[];
  const state={pendingManualEditSnapshots:{},mappings:[{id:'name',expression:'COALESCE(a.NAME, a.NAME)'}]};
  const env={calls,state,reviewResult:{original_preview_sql:'SELECT COALESCE(a.NAME, a.NAME) AS NAME FROM D.S.A a',
    original_generated_sql:'INSERT INTO D.S.T (NAME) SELECT COALESCE(a.NAME, a.NAME) AS NAME FROM D.S.A a',
    optimized_preview_sql:'SELECT a.NAME AS NAME FROM D.S.A a',optimized_generated_sql:'INSERT INTO D.S.T (NAME) SELECT a.NAME AS NAME FROM D.S.A a',
    execution_ready:true,requires_approval:true},isMappingSqlValidated:true,editableSql:'original-script',
    currentSqlArtifact:{scriptSql:'original-script'},sqlEditRevision:{current:0},compilerContextHash:'context',
    store:{getState:()=>({sttmBuilder:state})},setSqlValidatedSignature:value=>({signature:value}),
    dispatch:action=>calls.push(['dispatch',action]),recordCurrentSqlValidation:()=>calls.push(['certify']),
    setSqlEditRequestId:update=>calls.push(['open-editor',update(0)]),
    setEditableSql:value=>{env.editableSql=value;calls.push(['editor',value]);}};
  for(const key of ['setReviewDialogOpen','setReviewBannerDismissed','setApprovedVariant','setReviewSelectionVariant','setValidatedPreviewData',
    'setActiveTab','setReviewStage','setApprovedPreviewSql','setMappingSql','setMappingPreviewSql','setMappingSqlVariant',
    'setCompiledMappingResult','setPreviewError','setSqlFailureNotice','setSqlParseResult','setSqlParseDialogOpen','setSqlParseLoading']) {
    env[key]=value=>calls.push([key,value]);
  }
  return env;
}
require('node:test')('optimized approval stages Sync without certification or silently changing mapping definitions',async()=>{
  const env=reviewEnvironment(), before=JSON.stringify(env.state);
  await approveReviewedSql(env)('optimized');
  assert.equal(env.editableSql,env.reviewResult.optimized_preview_sql);
  assert.equal(env.sqlEditRevision.current,1);
  assert.deepEqual(env.calls.find(([name])=>name==='open-editor'),['open-editor',1]);
  assert.deepEqual(env.calls.find(([name])=>name==='dispatch'),['dispatch',{signature:null}]);
  assert.equal(JSON.stringify(env.state),before);
  assert.ok(!env.calls.some(([name])=>['certify','setCompiledMappingResult','setMappingSql','setMappingPreviewSql'].includes(name)));
  assert.match(env.calls.find(([name])=>name==='setReviewStage')[1],/Sync.*Compile & Validate/);
  const withValues=reviewEnvironment();withValues.reviewResult.optimized_script_sql="SET Firm='x'; SELECT $Firm AS NAME";
  await approveReviewedSql(withValues)('optimized');
  assert.equal(withValues.editableSql,withValues.reviewResult.optimized_script_sql);
});
require('node:test')('review selection preserves pending manual/SQL edits and normal original selection',async()=>{
  for(const kind of ['mapping','sql','stale']) {
    const env=reviewEnvironment();
    if(kind==='mapping')env.state.pendingManualEditSnapshots.name={};
    if(kind==='sql')env.editableSql='manual SQL';
    if(kind==='stale')env.isMappingSqlValidated=false;
    await approveReviewedSql(env)('optimized');
    assert.ok(!env.calls.some(([name])=>['certify','editor','setCompiledMappingResult','setMappingSql'].includes(name)));
  }
  const env=reviewEnvironment();await approveReviewedSql(env)('original');
  assert.ok(env.calls.some(([name])=>name==='certify'));
  assert.equal(env.calls.find(([name])=>name==='setMappingSql')[1],env.reviewResult.original_generated_sql);
});
function syncEnvironment() {
  const env=reviewEnvironment();
  Object.assign(env,{activeProjectId:'p',knownSqlTables:[],selectedSourceTables:[],selectedTargetQualifiedName:'D.S.T',
    mappedMappings:[],relationshipPayload:[],sourceFilterSql:'',mappingSqlRequestPayload:{},
    validationRequestSignature:()=>String(env.sqlEditRevision.current),
    qualifiedNameToTableRef:()=>null,parseSourceColumns:()=>[],buildEditedInsertSql:sql=>sql,
    dbService:{parseMappingSql:async()=>({valid:true,preview_sql:'SELECT a.NAME AS NAME FROM D.S.A a',parsed_workspace:{}})},
    applyParsedSqlResult:(_result,commit)=>{if(commit){env.state.mappings=[{id:'name',expression:'a.NAME'}];env.calls.push(['synchronized']);}
      return {parsedMappings:[{targetColumn:'NAME',sourceColumns:['a.NAME'],expression:'a.NAME'}]};},
    handleValidateSql:async()=>({execution_ready:true}),reviewErrorRef:{current:null}});
  return env;
}
require('node:test')('Sync clears proof; actual compile and validation certify the synchronized definitions',async()=>{
  const env=syncEnvironment();
  assert.equal(await synchronizeSql(env)(),true);
  assert.ok(env.calls.some(([name])=>name==='synchronized'));
  assert.ok(!env.calls.some(([name])=>name==='certify'));
  assert.deepEqual(env.state.mappings,[{id:'name',expression:'a.NAME'}]);
  Object.assign(env,{mappings:env.state.mappings,hasMappingDefinition:()=>true,rowDefinitionSignature:row=>row.expression,
    selectionValidationSignature:()=> 'synced-context',compilerErrorRef:{current:null},
    compileCurrentMappingSql:async()=>({ready:true,generated_sql:'INSERT INTO D.S.T (NAME) SELECT a.NAME AS NAME FROM D.S.A a',
      preview_sql:'SELECT a.NAME AS NAME FROM D.S.A a'})});
  await compileAndValidate(env)();
  assert.ok(env.calls.some(([name])=>name==='certify'));
  const proof=env.calls.find(([name])=>name==='setCompiledMappingResult')[1];
  assert.equal(proof.explainValidated,true);
  assert.deepEqual(proof.validatedRows,[{id:'name',definitionSignature:'a.NAME'}]);
});
require('node:test')('unsupported Sync, failed validation and delayed edits cannot mutate or certify mappings',async()=>{
  for(const kind of ['parse','review','pending','delayed']) {
    const env=syncEnvironment(),before=JSON.stringify(env.state.mappings);
    if(kind==='parse')env.dbService.parseMappingSql=async()=>({valid:false});
    if(kind==='review')env.handleValidateSql=async()=>({execution_ready:false});
    if(kind==='pending')env.state.pendingManualEditSnapshots.name={};
    if(kind==='delayed')env.dbService.parseMappingSql=async()=>{env.sqlEditRevision.current++;return {valid:true,parsed_workspace:{}};};
    assert.equal(await synchronizeSql(env)(),false,kind);
    assert.equal(JSON.stringify(env.state.mappings),before);
    assert.ok(!env.calls.some(([name])=>['certify','synchronized'].includes(name)),kind);
  }
});
const previewComponentFile=path.resolve(__dirname,'../src/components/sql/sql-preview/mapping-sql-preview.tsx');
const previewComponentSource=ts.createSourceFile(previewComponentFile,fs.readFileSync(previewComponentFile,'utf8'),ts.ScriptTarget.Latest,true);
let requestedEditorEffect;
function findRequestedEditorEffect(node) {
  if(ts.isCallExpression(node)&&node.expression.getText(previewComponentSource)==='useEffect'
    &&node.arguments[0]?.getText(previewComponentSource).includes('editRequestId'))requestedEditorEffect=node.arguments[0].getText(previewComponentSource);
  ts.forEachChild(node,findRequestedEditorEffect);
}
findRequestedEditorEffect(previewComponentSource);
const requestedEditorModule=new Module(previewComponentFile,module);
requestedEditorModule._compile(ts.transpileModule(`module.exports=(editRequestId,setEditing)=>(${requestedEditorEffect})();`,{
  compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText,previewComponentFile);
let requestedEditing=false;
requestedEditorModule.exports(0,value=>requestedEditing=value);assert.equal(requestedEditing,false);
requestedEditorModule.exports(1,value=>requestedEditing=value);assert.equal(requestedEditing,true);
console.log('Optimized selection opens the existing editable SQL and Sync controls.');
console.log('Auto-compile OFF never sends a request; ON compiles the latest edits once.');
console.log('Automatic compile synchronizes saved manual edits and settled Auto-map inputs, avoids loops, and waits for hydration/firm Values.');
const {formatDiagnosticDisplayText} = aliasModule.exports;
assert.equal(formatDiagnosticDisplayText(`invalid identifier '${alias}.CITY'`, labels),
  "invalid identifier 'addresses_one_per_contacts.CITY'");
assert.equal(formatDiagnosticDisplayText(`invalid identifier "${alias}.CITY"`, labels),
  'invalid identifier addresses_one_per_contacts.CITY');
assert.equal(formatDiagnosticDisplayText('invalid identifier ACTUAL_USER_COLUMN', labels),
  'invalid identifier ACTUAL_USER_COLUMN');

const {buildRelationDiagnosticAliases} = aliasModule.exports;
const importedDiagnostics = buildRelationDiagnosticAliases([
  {identity:'sql-instance:outer:0', alias:'accounts_80ydxi', displaySeed:'ACCOUNTS'},
]);
assert.equal(formatDiagnosticDisplayText("SQL compilation error: invalid identifier 'ACCOUNTS_80YDXI.ADDRESS1_LINE1'", importedDiagnostics),
  "SQL compilation error: invalid identifier 'ACCOUNTS.ADDRESS1_LINE1'");
const twoAccounts=buildRelationDiagnosticAliases([
  {identity:'first',alias:'first_hash',displaySeed:'ACCOUNTS'},
  {identity:'second',alias:'second_hash',displaySeed:'ACCOUNTS'},
]);
assert.equal(twoAccounts.get('FIRST_HASH'),'ACCOUNTS (1)');
assert.equal(twoAccounts.get('SECOND_HASH'),'ACCOUNTS (2)');
