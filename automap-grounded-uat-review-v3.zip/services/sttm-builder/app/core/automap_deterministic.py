"""Offline, current-definition preservation for a parent Auto-map partition.

This is not inference, execution approval, or proof of business correctness.
Keep ``baseline_rows`` and ``mapping_sql`` intact when merging a partition. A
SQL-owned mapping must travel with its full query; the scalar mapping alone
does not encode its CTEs, joins, filters, grain, or population. Pending entries
are not permission to overwrite an existing definition.
"""
from __future__ import annotations

from collections import Counter
from copy import deepcopy
from dataclasses import dataclass
from typing import Any, Literal, Sequence

from sqlglot import exp, parse
from sqlglot.errors import ErrorLevel, SqlglotError
from sqlglot.optimizer.normalize_identifiers import normalize_identifiers
from sqlglot.tokens import TokenType
from sqlglot import Dialect

from app.core.mapping_contracts import valid_attribute_expression
from app.core.mapping_sql import MappingSqlService
from app.core.query_scope_contract import query_scope_contract
from app.schema.mapping_sql import MappingSqlCompileRequest, MappingSqlMappingItem
from app.schema.sttm_builder import (
    AttributeMapping, RelationGraphContext, RelationNode, SourceMappingResult,
    STTMBuilderEnvelopeRequest, TargetAttributeItem,
)
from app.schema.workspace_context import WorkspaceMappingRow


@dataclass(frozen=True)
class AuthoredDiagnostic:
    code: str
    message: str
    target_attribute: str | None = None


@dataclass(frozen=True)
class AuthoredTargetResolution:
    attribute: TargetAttributeItem
    status: Literal["definition_preserved", "pending"]
    origin: Literal["authored_sql", "current_rule", "none"]
    mapping: AttributeMapping | None
    baseline_rows: tuple[WorkspaceMappingRow, ...]
    definition_sql: str | None
    requires_authored_query: bool
    compiler_valid: bool
    execution_status: Literal["blocked", "not_validated"]
    required_relation_ids: tuple[str, ...]
    unresolved_values: tuple[str, ...]
    diagnostics: tuple[AuthoredDiagnostic, ...]


@dataclass(frozen=True)
class AuthoredTargetsResolution:
    targets: tuple[AuthoredTargetResolution, ...]
    pending_attributes: tuple[TargetAttributeItem, ...]
    baseline_rows: tuple[WorkspaceMappingRow, ...]
    mapping_sql: str | None
    raw_mapping_sql: str | None
    diagnostics: tuple[AuthoredDiagnostic, ...]

    @property
    def source_mapping_results(self) -> dict[str, SourceMappingResult]:
        """Preservation metadata, not replacement frontend rows or standalone SQL.

        Keep the baseline and authored query. In particular a source-free Custom
        scalar is not a frontend constant/value roundtrip contract.
        """
        grouped: dict[str, dict[str, AttributeMapping]] = {}
        for target in self.targets:
            if target.mapping is not None:
                table = target.attribute.target_table.qualified_name
                grouped.setdefault(table, {})[target.attribute.target_attribute] = target.mapping.model_copy(deep=True)
        return {table: SourceMappingResult(mappings=mappings) for table, mappings in grouped.items()}


class _Unproven(ValueError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


def _one(sql: str) -> exp.Expression:
    try:
        statements = parse(sql, read="snowflake", error_level=ErrorLevel.RAISE)
    except (SqlglotError, ValueError) as exc:
        raise _Unproven("invalid_sql", "SQL did not parse completely.") from exc
    if len(statements) != 1 or statements[0] is None:
        raise _Unproven("invalid_sql", "Exactly one complete SQL statement is required.")
    return statements[0]


def _key(identifier: exp.Expression) -> str:
    if not isinstance(identifier, exp.Identifier):
        raise _Unproven("invalid_identifier", "An explicit SQL identifier is required.")
    return identifier.name if identifier.args.get("quoted") else identifier.name.upper()


def _parts(text: str) -> tuple[str, ...]:
    column = _one(text)
    if not isinstance(column, exp.Column) or column.is_star:
        raise _Unproven("invalid_identifier", "A column or relation identifier is required.")
    return tuple(_key(part) for part in column.parts)


def _identifier(text: str) -> exp.Identifier:
    column = _one(text)
    if not isinstance(column, exp.Column) or len(column.parts) != 1 or column.is_star:
        raise _Unproven("invalid_identifier", "One unqualified identifier is required.")
    return column.this.copy()


def _equivalent(left: exp.Expression, right: exp.Expression) -> bool:
    return normalize_identifiers(left.copy(), dialect="snowflake") == normalize_identifiers(right.copy(), dialect="snowflake")


def _scalar(text: str) -> exp.Expression:
    tree = _one(text)
    if not valid_attribute_expression(text) or isinstance(tree, exp.Alias) or any(
        isinstance(node, (exp.Query, exp.DDL, exp.DML, exp.Command, exp.Star)) for node in tree.walk()
    ):
        raise _Unproven("unrepresentable_expression", "The current rule is not one complete scalar expression.")
    return tree


def _projection_texts(sql: str, query: exp.Select) -> list[str]:
    """Token offsets retain literal/function spelling instead of re-rendering it."""
    tokens = Dialect.get_or_raise("snowflake").tokenize(sql)
    depth = 0
    start: int | None = None
    fragments: list[str] = []
    terminators = {TokenType.FROM, TokenType.WHERE, TokenType.GROUP_BY, TokenType.HAVING,
                   TokenType.QUALIFY, TokenType.ORDER_BY, TokenType.LIMIT, TokenType.OFFSET,
                   TokenType.SEMICOLON}
    for index, token in enumerate(tokens):
        if start is None:
            if depth == 0 and token.token_type == TokenType.SELECT:
                start = token.end + 1
                following = tokens[index + 1] if index + 1 < len(tokens) else None
                distinct = query.args.get("distinct")
                if distinct is not None:
                    if distinct.args.get("on") or following is None or following.token_type != TokenType.DISTINCT:
                        raise _Unproven("unsupported_projection", "Only plain DISTINCT has a proven projection boundary.")
                    # Skip the modifier in scalar text only. The complete query
                    # remains mandatory: DISTINCT belongs to the full row grain.
                    start = following.end + 1
                    following = tokens[index + 2] if index + 2 < len(tokens) else None
                if following is not None and following.token_type == TokenType.TOP:
                    raise _Unproven("unsupported_projection", "TOP projection extraction requires explicit review.")
            elif token.token_type == TokenType.L_PAREN:
                depth += 1
            elif token.token_type == TokenType.R_PAREN:
                depth -= 1
            continue
        if depth == 0 and (token.token_type in terminators or token.token_type == TokenType.COMMA):
            fragments.append(sql[start:token.start].strip())
            start = token.end + 1
            if token.token_type != TokenType.COMMA:
                break
        elif token.token_type in {TokenType.L_PAREN, TokenType.L_BRACKET, TokenType.L_BRACE}:
            depth += 1
        elif token.token_type in {TokenType.R_PAREN, TokenType.R_BRACKET, TokenType.R_BRACE}:
            depth -= 1
    else:
        if start is not None:
            fragments.append(sql[start:].strip())
    if len(fragments) != len(query.expressions):
        raise _Unproven("unsupported_projection", "Projection text cannot be bound without changing the full query.")
    result = []
    for fragment, item in zip(fragments, query.expressions):
        probe = _one("SELECT " + fragment)
        if not isinstance(probe, exp.Select) or len(probe.expressions) != 1 or not _equivalent(probe.expressions[0], item):
            raise _Unproven("unsupported_projection", "Projection text and parsed projection disagree.")
        if isinstance(item, exp.Alias):
            local = Dialect.get_or_raise("snowflake").tokenize(fragment)
            end = local[-2].start if local[-2].token_type == TokenType.ALIAS else local[-1].start
            fragment = fragment[:end].rstrip()
        result.append(fragment)
    return result


def _output_keys(node: RelationNode) -> set[str]:
    # Catalog output names are exact spellings, not case-insensitive suggestions.
    names = set()
    for output in node.output_columns:
        name = output.get("name") or output.get("column_name")
        if name:
            sql_name = output.get("sql_name") if node.kind != "PHYSICAL_TABLE" else None
            text = str(sql_name or name)
            names.add(_key(_identifier(text)) if sql_name or text.startswith('"') else text)
    return names


def _query_output_identifiers(query: exp.Expression) -> list[exp.Identifier]:
    """UNION names come from the left arm, but every arm must be scalar/positional."""
    if isinstance(query, exp.Union):
        if any(query.args.get(key) for key in ("by_name", "on", "side", "kind")):
            raise _Unproven("unsupported_query", "Only positional UNION definitions are supported.")
        left = _query_output_identifiers(query.this)
        right = _query_output_identifiers(query.expression)
        if len(left) != len(right):
            raise _Unproven("unknown_cte_output", "UNION arms have different output widths.")
        return left
    if not isinstance(query, exp.Select):
        raise _Unproven("unsupported_query", "A derived output must be a SELECT or positional UNION.")
    identifiers = []
    for item in query.expressions:
        identifier = item.args.get("alias") if isinstance(item, exp.Alias) else item.this if isinstance(item, exp.Column) else None
        if not isinstance(identifier, exp.Identifier):
            raise _Unproven("unknown_cte_output", "Derived outputs need explicit scalar names.")
        _scalar((item.this if isinstance(item, exp.Alias) else item).sql(dialect="snowflake"))
        identifiers.append(identifier)
    if len({_key(identifier) for identifier in identifiers}) != len(identifiers):
        raise _Unproven("unknown_cte_output", "Derived output aliases are ambiguous.")
    return identifiers


def _bind_output_contract(node: RelationNode, identifiers: list[exp.Identifier]) -> None:
    # The UI keeps the parser's display spelling plus an optional SQL spelling.
    # Validate that association against the saved AST; never casefold quoted names.
    for output in node.output_columns:
        name = str(output.get("name") or output.get("column_name") or "")
        matches = [identifier for identifier in identifiers if name in {identifier.name, _key(identifier), identifier.sql(dialect="snowflake")}]
        if len(matches) != 1:
            raise _Unproven("unknown_cte_output", "Declared derived outputs disagree with the current SQL definition.")
        identifier = matches[0]
        if output.get("sql_name") and _key(_identifier(str(output["sql_name"]))) != _key(identifier):
            raise _Unproven("unknown_cte_output", "Derived SQL output spelling conflicts with its definition.")
        output["sql_name"] = identifier.sql(dialect="snowflake")


class _Bindings:
    def __init__(self, graph: RelationGraphContext):
        self.graph = graph
        self.validated_definitions: dict[str, set[str]] = {}
        self.validating_definitions: set[str] = set()
        self.nodes = {node.relation_id: node for node in graph.nodes}
        if len({node.relation_id.upper() for node in graph.nodes}) != len(graph.nodes):
            raise _Unproven("invalid_graph", "Relation IDs are not unique.")
        aliases = [_key(_identifier(node.alias)) for node in graph.nodes]
        if len(set(aliases)) != len(aliases):
            raise _Unproven("invalid_graph", "Relation aliases are not unique.")
        self.aliases = dict(zip(aliases, graph.nodes))
        for edge in graph.edges:
            if edge.left_relation_id not in self.nodes or edge.right_relation_id not in self.nodes:
                raise _Unproven("invalid_graph", "A join refers to an unknown relation.")
        if len({binding.binding_id for binding in graph.value_bindings}) != len(graph.value_bindings):
            raise _Unproven("invalid_value_binding", "Value binding IDs are not unique.")

    def physical(self, parts: tuple[str, ...], alias: str | None = None) -> RelationNode:
        matches = [node for node in self.graph.nodes if node.table is not None
                   and _parts(node.table.qualified_name)[-len(parts):] == parts]
        if not matches and len(parts) == 1:
            # A CTE body hydrated from the current authored SQL refers to its
            # compiler alias, which is an outer graph node rather than a
            # physical catalog table. The hash is checked again below.
            matches = [node for node in self.graph.nodes if node.kind != "PHYSICAL_TABLE"
                       and node.dependency_hash and _key(_identifier(node.alias)) == parts[0]]
        if len(matches) > 1 and alias is not None:
            matches = [node for node in matches if _key(_identifier(node.alias)) == alias]
        if len(matches) != 1:
            raise _Unproven("unknown_relation", "A SQL relation is absent or ambiguous in the current graph.")
        return matches[0]

    def column(self, column: exp.Column, aliases: dict[str, RelationNode] | None = None) -> tuple[RelationNode, str]:
        aliases = self.aliases if aliases is None else aliases
        if not isinstance(column, exp.Column) or column.is_star:
            raise _Unproven("unrepresentable_expression", "Wildcard bindings are not scalar mappings.")
        key = _key(column.this)
        if column.db or column.catalog:
            node = self.physical(tuple(_key(part) for part in column.parts[:-1]))
            if node.relation_id not in {candidate.relation_id for candidate in aliases.values()}:
                raise _Unproven("unknown_relation", "A column references a relation outside this query scope.")
        elif column.table:
            node = aliases.get(_key(column.args["table"]))
            if node is None:
                raise _Unproven("unknown_alias", "A column qualifier is not bound in the current scope.")
        else:
            if any(not _output_keys(candidate) for candidate in aliases.values()):
                raise _Unproven("unknown_column", "Unqualified ownership needs complete output contracts.")
            matches = [candidate for candidate in aliases.values() if key in _output_keys(candidate)]
            if len(matches) != 1:
                raise _Unproven("unknown_column", "An unqualified column is absent or ambiguous.")
            node = matches[0]
        if key not in _output_keys(node):
            raise _Unproven("unknown_column", "A column is not proven by its current output contract.")
        return node, f"{node.alias}.{column.this.sql(dialect='snowflake')}"

    def expression(self, tree: exp.Expression, aliases: dict[str, RelationNode] | None = None) -> tuple[list[str], exp.Expression]:
        compiled = tree.copy()
        references = []
        for column in (node for node in compiled.walk(bfs=False) if isinstance(node, exp.Column)):
            node, reference = self.column(column, aliases)
            references.append(reference)
            column.set("catalog", None)
            column.set("db", None)
            column.set("table", _identifier(node.alias))
        return list(dict.fromkeys(references)), compiled


@dataclass
class _AuthoredQuery:
    projections: dict[str, tuple[str, exp.Expression]]
    aliases: dict[str, RelationNode]
    required_ids: set[str]
    tree: exp.Query


def _authored_query(sql: str, bindings: _Bindings, target_table: str | None, *, definition: bool = False) -> _AuthoredQuery:
    statement = _one(sql)
    query = statement
    if isinstance(statement, exp.Insert):
        destination = statement.this.this if isinstance(statement.this, exp.Schema) else statement.this
        if not isinstance(destination, exp.Table) or not target_table or tuple(_key(part) for part in destination.parts) != _parts(target_table):
            raise _Unproven("target_mismatch", "INSERT destination does not match the current target table.")
        query = statement.expression
    if (not isinstance(query, exp.Select) and not (definition and isinstance(query, exp.Union))) or any(
        isinstance(node, (exp.DDL, exp.DML, exp.Command)) or isinstance(node, exp.SetOperation) and not isinstance(node, exp.Union)
        for node in query.walk()
    ):
        raise _Unproven("unsupported_query", "Only a complete SELECT (optionally INSERT SELECT) is supported.")
    for union in query.find_all(exp.Union):
        _query_output_identifiers(union)
    if any(cte.args.get("recursive") for cte in query.find_all(exp.With)):
        raise _Unproven("unsupported_query", "Recursive query definitions require review.")
    if any(alias.args.get("columns") for alias in query.find_all(exp.TableAlias)):
        raise _Unproven("unsupported_query", "Positional relation column aliases require review.")
    if any(join.args.get("using") or join.args.get("method") for join in query.find_all(exp.Join)):
        raise _Unproven("unsupported_query", "USING/NATURAL join output coalescence requires review.")
    try:
        contract = query_scope_contract(query, "statement:0")
    except (SqlglotError, ValueError, KeyError) as exc:
        raise _Unproven("invalid_scope", "The full query scope cannot be resolved.") from exc
    scopes = {scope["scope_id"]: scope for scope in contract["scopes"]}
    root = next((scope for scope in scopes.values() if scope["parent_scope_id"] is None), None)
    if root is None:
        raise _Unproven("invalid_scope", "The full query has no root scope.")
    required: set[str] = set()
    root_aliases: dict[str, RelationNode] = {}
    for scope in scopes.values():
        scope_aliases: dict[str, RelationNode] = {}
        for relation in scope["relations"]:
            alias_key = relation["alias"] if relation["alias_quoted"] else relation["alias"].upper()
            source_id = relation["source_scope_id"]
            if source_id is None:
                parts = tuple(part["name"] if part["quoted"] else part["name"].upper() for part in relation["identifier_parts"])
                if not parts:
                    raise _Unproven("unknown_relation", "Table functions and implicit relations require review.")
                node = bindings.physical(parts, alias_key)
                required.add(node.relation_id)
            else:
                source = scopes[source_id]
                identifiers = _query_output_identifiers(_one(source["definition_sql"]))
                names = [_key(identifier) for identifier in identifiers]
                if scope is root and not definition:
                    bodies = [source["definition_sql"]]
                    bodies.extend(item["executable_sql"] for item in contract["ctes_by_node"].values()
                                  if item["scope_id"] == source_id and item["executable_sql"])
                    candidates = [candidate for candidate in bindings.graph.nodes
                                  if candidate.kind != "PHYSICAL_TABLE" and candidate.sql_text
                                  and any(_equivalent(_one(candidate.sql_text), _one(body)) for body in bodies)]
                    query_with = query.args.get("with") or query.args.get("with_")
                    if not candidates and query_with is not None:
                        for candidate in bindings.graph.nodes:
                            if candidate.kind != "CTE" or not candidate.sql_text:
                                continue
                            wrapper = _one(candidate.sql_text)
                            wrapper_with = wrapper.args.get("with") or wrapper.args.get("with_")
                            if (isinstance(wrapper, exp.Select) and wrapper_with is not None
                                    and _equivalent(wrapper_with, query_with)
                                    and _key(_identifier(candidate.alias)) == _key(_identifier(source.get("name_sql") or source.get("name")))):
                                candidates.append(candidate)
                    if not candidates:
                        from app.core.automap_retrieval import digest
                        source_key = _key(_identifier(source.get("name_sql") or source.get("name") or relation["alias"]))
                        if any(candidate.original_cte_name
                               and _key(_identifier(candidate.original_cte_name)) == source_key
                               and not set(candidate.parent_relation_ids) <= set(bindings.nodes)
                               for candidate in bindings.graph.nodes):
                            raise _Unproven("invalid_graph", "A derived relation has a missing declared parent.")
                        candidates = [candidate for candidate in bindings.graph.nodes
                            if candidate.kind != "PHYSICAL_TABLE" and candidate.original_cte_name
                            and _key(_identifier(candidate.original_cte_name)) == source_key
                            and candidate.dependency_hash == digest({
                                "sql": candidate.sql_text, "parents": candidate.parent_relation_ids,
                                "authored_sql": digest(sql)})]
                    if len(candidates) > 1:
                        candidates = [candidate for candidate in candidates if _key(_identifier(candidate.alias)) == alias_key]
                    if len(candidates) != 1:
                        raise _Unproven("unknown_cte", "The SQL-owned CTE does not match exactly one current graph definition.")
                    _bind_output_contract(candidates[0], identifiers)
                    node = candidates[0].model_copy(deep=True)
                    node.output_columns = [{"name": name} for name in names]
                    required.add(node.relation_id)
                else:
                    # Lexical CTE outputs are scoped facts, not new graph nodes.
                    node = RelationNode(relation_id=source_id, alias=relation["alias_sql"], kind="CTE",
                                        output_columns=[{"name": name} for name in names])
            if node.relation_id in {existing.relation_id for existing in scope_aliases.values()}:
                raise _Unproven("ambiguous_relation_instance", "Distinct SQL relation instances cannot collapse to one current graph binding.")
            scope_aliases[alias_key] = node
        for reference in scope["referenced_columns"]:
            bindings.column(_one(reference["sql"]), scope_aliases)
        if scope is root:
            root_aliases = scope_aliases
    if definition and len(query.expressions) == 1 and isinstance(query.expressions[0], exp.Star):
        star = query.expressions[0]
        if any(star.args.values()) or len(root_aliases) != 1:
            raise _Unproven("unknown_cte_output", "A saved wildcard needs one complete, unmodified output contract.")
        owner = next(iter(root_aliases.values()))
        outputs = _output_keys(owner)
        if not outputs:
            raise _Unproven("unknown_cte_output", "A saved wildcard has no known output contract.")
        projections = {name: (exp.column(name, quoted=True).sql(dialect="snowflake"), exp.column(name, quoted=True)) for name in sorted(outputs)}
        return _AuthoredQuery(projections, root_aliases, required, query)
    if definition and isinstance(query, exp.Union):
        identifiers = _query_output_identifiers(query)
        projections = {_key(identifier): (identifier.sql(dialect="snowflake"), exp.Column(this=identifier.copy())) for identifier in identifiers}
        return _AuthoredQuery(projections, root_aliases, required, query)
    texts = _projection_texts(sql, query)
    projections = {}
    for item, text in zip(query.expressions, texts):
        identifier = item.args.get("alias") if isinstance(item, exp.Alias) else item.this if isinstance(item, exp.Column) else None
        if identifier is None or isinstance(identifier, exp.Star):
            raise _Unproven("unbound_target", "Every target projection must have an explicit output name.")
        key = _key(identifier)
        if key in projections:
            raise _Unproven("ambiguous_target", "The full query contains duplicate target aliases.")
        projections[key] = (text, _scalar(text))
    if isinstance(statement, exp.Insert) and isinstance(statement.this, exp.Schema):
        if [_key(item) for item in statement.this.expressions] != list(projections):
            raise _Unproven("target_mismatch", "INSERT columns and SELECT aliases do not agree positionally.")
    return _AuthoredQuery(projections, root_aliases, required, query)


def _validate_required_graph(bindings: _Bindings, required: set[str]) -> set[str]:
    """Check saved derived bodies too; declared outputs alone are not proof."""
    closure = set(required)
    for relation_id in sorted(required):
        node = bindings.nodes[relation_id]
        if relation_id in bindings.validated_definitions:
            closure.update(bindings.validated_definitions[relation_id])
            continue
        if node.kind == "PHYSICAL_TABLE":
            continue
        if relation_id in bindings.validating_definitions:
            raise _Unproven("invalid_graph", "Derived dependency definitions contain a cycle.")
        if not node.sql_text:
            raise _Unproven("unknown_cte", "A derived binding needs its current SQL definition for offline proof.")
        bindings.validating_definitions.add(relation_id)
        try:
            body = _authored_query(node.sql_text, bindings, None, definition=True)
            if not _output_keys(node).issubset(body.projections):
                raise _Unproven("unknown_cte_output", "Declared derived outputs disagree with the current SQL definition.")
            parents = set(node.parent_relation_ids)
            if not parents.issubset(bindings.nodes):
                raise _Unproven("invalid_graph", "A derived relation has a missing declared parent.")
            dependencies = body.required_ids | parents
            resolved = _validate_required_graph(bindings, dependencies)
            closure.update(resolved)
            bindings.validated_definitions[relation_id] = resolved
        finally:
            bindings.validating_definitions.remove(relation_id)
    return closure


def _validate_graph_edges(bindings: _Bindings) -> None:
    for edge in bindings.graph.edges:
        for condition in edge.conditions:
            for relation_id, name in ((edge.left_relation_id, condition.left_column), (edge.right_relation_id, condition.right_column)):
                column = exp.Column(this=_identifier(name), table=_identifier(bindings.nodes[relation_id].alias))
                bindings.column(column)
        if edge.additional_predicate:
            bindings.expression(_scalar(edge.additional_predicate))


def _check_compiler_projection(compiled_sql: str, expected: exp.Expression, bindings: _Bindings) -> None:
    query = _one(compiled_sql)
    if not isinstance(query, exp.Select) or len(query.expressions) != 1:
        raise _Unproven("compiler_changed_definition", "Compiler validation changed the scalar projection shape.")
    item = query.expressions[0]
    tree = item.this if isinstance(item, exp.Alias) else item
    aliases = dict(bindings.aliases)
    displayed = MappingSqlService._display_aliases(bindings.graph.nodes)
    for node in bindings.graph.nodes:
        for name in (displayed.get(node.alias), node.original_cte_name):
            if name:
                key = _key(_identifier(name))
                if key in aliases and aliases[key].relation_id != node.relation_id:
                    raise _Unproven("compiler_changed_definition", "Compiler output aliases cannot be bound unambiguously.")
                aliases[key] = node
    _, actual = bindings.expression(tree, aliases)
    if not _equivalent(expected, actual):
        raise _Unproven("compiler_changed_definition", "Compiler validation rewrote the authored scalar binding; no replacement was emitted.")


def _row_expression(row: WorkspaceMappingRow) -> str | None:
    if row.expression and row.expression.strip():
        expression = _scalar(row.expression)
        if row.mapping_mode in {"constant", "attribute"} and row.constant_value is not None:
            value = _one(MappingSqlService._compile_constant(row.constant_value, row.target_type))
            if not _equivalent(expression, value):
                raise _Unproven("baseline_conflict", "The row's explicit value and expression disagree; both were preserved.")
        return row.expression
    if row.rule and row.rule.strip().upper() != "VALUE" and valid_attribute_expression(row.rule):
        _scalar(row.rule)
        return row.rule
    if row.mapping_mode in {"constant", "attribute"}:
        if row.constant_value is None or row.constant_value == "":
            raise _Unproven("missing_value", "No explicit constant or placeholder is defined; NULL was not invented.")
        if row.constant_value != row.constant_value.strip():
            raise _Unproven("unrepresentable_value", "The legacy constant renderer would trim this explicit value; the baseline was preserved.")
        return MappingSqlService._compile_constant(row.constant_value, row.target_type)
    label = (row.rule or row.preprocessing_rule_type or "").strip().upper()
    if label not in {"", "DIRECT", "IDENTITY"}:
        raise _Unproven("incomplete_rule", "A transformation label without an executable expression is incomplete.")
    if len(row.source_columns) > 1:
        raise _Unproven("incomplete_rule", "Multiple selected operands require an explicit expression, not Direct.")
    return row.source_columns[0] if row.source_columns else None


def _target_projection(query: _AuthoredQuery, attribute: TargetAttributeItem, key: str,
                       row: WorkspaceMappingRow | None) -> tuple[str, exp.Expression]:
    raw = row.target_column if row else None
    # Upload strips identifier quotes in its row label; Auto-map requests the
    # catalog name. Only that existing row's exact display alias can bridge the
    # two. A SQL alias casefold or target ordinal alone is not evidence.
    bridge = raw is not None and raw != key and raw in query.projections and not _identifier(attribute.target_attribute).args.get("quoted")
    if bridge:
        if key in query.projections or sum(name.upper() == key for name in query.projections) != 1:
            raise _Unproven("ambiguous_target", "The existing display alias collides with another SQL output.")
        if _row_expression(row) is None:
            raise _Unproven("unbound_target", "A display alias requires an existing executable row binding.")
        return query.projections[raw]
    if key not in query.projections:
        raise _Unproven("unbound_target", "The full query does not project this exact target alias or a proven existing row alias.")
    return query.projections[key]


def _contains_reference(references: list[str], reference: str) -> bool:
    return any(_equivalent(_one(candidate), _one(reference)) for candidate in references)


def _string_list(extra: dict[str, Any], key: str) -> list[str]:
    value = extra.get(key)
    if value is None:
        return []
    if not isinstance(value, list) or any(not isinstance(item, str) or not item for item in value):
        raise _Unproven("invalid_dependency_contract", f"{key} must be a list of nonempty identifiers.")
    return value


def _value_ids(tree: exp.Expression, graph: RelationGraphContext, explicit: Sequence[str]) -> tuple[list[str], list[str]]:
    # Parameters are AST nodes: a string '$Name' is literal text in authored SQL.
    placeholders = sorted({parameter.sql(dialect="snowflake") for parameter in tree.find_all(exp.Parameter)})
    by_id = {binding.binding_id: binding for binding in graph.value_bindings}
    ids = list(explicit)
    if any(binding_id not in by_id for binding_id in ids):
        raise _Unproven("invalid_value_binding", "An explicit Value binding ID is not present in the current graph.")
    unresolved = []
    for placeholder in placeholders:
        matches = [binding for binding in graph.value_bindings if binding.value.upper() == placeholder.upper()]
        signatures = {(binding.resolved_value, binding.data_type, binding.resolution_status) for binding in matches}
        if len(signatures) > 1:
            raise _Unproven("invalid_value_binding", "A placeholder has conflicting current Value definitions.")
        ids.extend(binding.binding_id for binding in matches)
        if not matches or any(binding.resolved_value is None or binding.resolution_status.lower() not in {"resolved", "project_attribute"} for binding in matches):
            unresolved.append(placeholder)
    for binding_id in explicit:
        binding = by_id[binding_id]
        if binding.is_placeholder and (binding.resolved_value is None or binding.resolution_status.lower() not in {"resolved", "project_attribute"}):
            unresolved.append(binding.value)
    return list(dict.fromkeys(ids)), sorted(set(unresolved))


def _mapping(text: str, tree: exp.Expression, references: list[str], ids: list[str], target_type: str | None) -> AttributeMapping:
    mode = "source"
    value = None
    if isinstance(tree, (exp.Literal, exp.Null, exp.Boolean, exp.Parameter)):
        value = str(tree.this) if isinstance(tree, exp.Literal) else tree.sql(dialect="snowflake")
        if _equivalent(_one(MappingSqlService._compile_constant(value, target_type)), tree):
            mode = "constant"
        else:
            value = None
    direct = isinstance(tree, exp.Column)
    return AttributeMapping(
        source_attributes=references, source_dependencies=references, value_binding_ids=ids,
        confidence_score=1.0, confidence_reason="Exact current definition preservation; not business-correctness confidence.",
        preprocessing_rule=text, preprocessing_rule_type="Direct" if direct else "Value" if mode == "constant" else "Custom",
        mapping_mode=mode, constant_value=value,
        transformation_classification="direct" if direct else "complex" if references else "value",
    )


def resolve_authored_targets(
    req: STTMBuilderEnvelopeRequest, *, project_attributes: Sequence[Any] | None = None,
) -> AuthoredTargetsResolution:
    """Preserve/complete proven current bindings, returning everything else pending.

    ``project_attributes`` uses the existing compiler's project-attribute objects
    (attribute_name/value/type). None trusts the supplied graph; [] explicitly
    clears stale project resolutions. No session, agent, catalog, or file I/O is
    performed. Compiler SQL is validation-only and is never returned as authored
    SQL. ``not_validated`` means locally valid, NOT execution-ready.
    """
    workspace = req.context.workspace_context
    baseline = tuple(row.model_copy(deep=True) for row in workspace.mapping_rows) if workspace else ()
    mapping_sql = workspace.mapping_sql if workspace else None
    raw_sql = workspace.raw_mapping_sql if workspace else None
    sql = mapping_sql or raw_sql
    diagnostics: list[AuthoredDiagnostic] = []
    query = None
    graph = (req.context.relation_graph or RelationGraphContext()).model_copy(deep=True)
    graph_error = None
    query_error = None
    try:
        if project_attributes is not None:
            values: dict[str, tuple[Any, Any]] = {}
            for attribute in project_attributes:
                key = str(getattr(attribute, "attribute_name", "")).upper()
                value = (getattr(attribute, "attribute_value", None), getattr(attribute, "attribute_type", None))
                if key in values and values[key] != value:
                    raise _Unproven("invalid_value_binding", "Project attributes contain conflicting values for one name.")
                values[key] = value
            graph = MappingSqlService.with_project_values(graph, list(project_attributes))
        bindings = _Bindings(graph)
    except (ValueError, SqlglotError) as exc:
        graph_error = AuthoredDiagnostic(getattr(exc, "code", "invalid_graph"), str(exc))
        diagnostics.append(graph_error)
    table = workspace.target_table if workspace else req.context.target_table
    if sql and graph_error is None:
        try:
            if mapping_sql and raw_sql and mapping_sql != raw_sql:
                raise _Unproven("conflicting_sql", "Raw and current mapping SQL disagree; neither was silently selected.")
            query = _authored_query(sql, bindings, table.qualified_name if table else None)
        except (ValueError, SqlglotError) as exc:
            query_error = AuthoredDiagnostic(getattr(exc, "code", "invalid_sql"), str(exc))
            diagnostics.append(query_error)
    row_index: dict[str, list[WorkspaceMappingRow]] = {}
    for row in baseline:
        try:
            row_index.setdefault(_key(_identifier(row.target_column)), []).append(row)
        except _Unproven as exc:
            diagnostics.append(AuthoredDiagnostic(exc.code, str(exc), row.target_column))
    attributes = list(req.data.attributes or [])
    identities = []
    for attribute in attributes:
        try:
            identities.append((_parts(attribute.target_table.qualified_name), _key(_identifier(attribute.target_attribute))))
        except _Unproven:
            identities.append(None)
    counts = Counter(identity for identity in identities if identity is not None)
    results = []
    for attribute, identity in zip(attributes, identities):
        notes: list[AuthoredDiagnostic] = []
        rows = tuple(row_index.get(identity[1], [])) if identity else ()
        text = None
        origin: Literal["authored_sql", "current_rule", "none"] = "none"
        mapping = None
        required: set[str] = set()
        unresolved: list[str] = []
        compiler_valid = False
        try:
            if identity is None or counts[identity] != 1:
                raise _Unproven("ambiguous_target", "Target identifiers must be valid and unique per table.")
            if table is None or identity[0] != _parts(table.qualified_name):
                raise _Unproven("target_mismatch", "The target is not owned by this workspace table.")
            if len(rows) > 1:
                raise _Unproven("ambiguous_baseline", "Multiple current rows own this target; all were preserved.")
            row = rows[0] if rows else None
            if row:
                text = row.expression or row.rule
            if graph_error:
                raise _Unproven(graph_error.code, graph_error.message)
            if query_error:
                raise _Unproven(query_error.code, query_error.message)
            if query:
                origin = "authored_sql"
                text, tree = _target_projection(query, attribute, identity[1], row)
                references, compiler_tree = bindings.expression(tree, query.aliases)
                if row:
                    current = _row_expression(row)
                    if current:
                        current_scalar = _scalar(current)
                        _, current_tree = bindings.expression(current_scalar, query.aliases if _equivalent(current_scalar, tree) else None)
                        if not _equivalent(current_tree, compiler_tree):
                            raise _Unproven("baseline_conflict", "The current row and authored target projection disagree.")
                    for source in row.source_columns:
                        _, reference = bindings.column(_scalar(source))
                        if not _contains_reference(references, reference):
                            raise _Unproven("baseline_conflict", "An existing selected operand is absent from the SQL projection.")
                required.update(query.required_ids)
            else:
                if row is None:
                    raise _Unproven("no_current_definition", "No current workspace row or authored projection defines this target.")
                origin = "current_rule"
                text = _row_expression(row)
                if text is None:
                    raise _Unproven("incomplete_rule", "A complete current source/value expression is required.")
                tree = _scalar(text)
                references, compiler_tree = bindings.expression(tree)
                for source in row.source_columns:
                    _, reference = bindings.column(_scalar(source))
                    if not _contains_reference(references, reference):
                        raise _Unproven("baseline_conflict", "The expression omits an existing selected operand.")
            extra = (row.model_extra or {}) if row else {}
            dependencies = list(references)
            for dependency in _string_list(extra, "source_dependencies"):
                if dependency in bindings.nodes:
                    dependencies.append(dependency)
                else:
                    _, reference = bindings.column(_scalar(dependency))
                    dependencies.append(reference)
            dependencies = list(dict.fromkeys(dependencies))
            value_tree = query.tree if origin == "authored_sql" else tree
            ids, unresolved = _value_ids(value_tree, graph, _string_list(extra, "value_binding_ids"))
            if origin == "current_rule" and any(not column.table and column.name.lower() == "source"
                                                and not column.this.args.get("quoted") for column in tree.find_all(exp.Column)):
                raise _Unproven("compiler_changed_definition", "Bare source is a legacy compiler placeholder, not a safely representable current column.")
            candidate = _mapping(text, tree, references, ids, attribute.target_data_type or (row.target_type if row else None))
            candidate.source_dependencies = dependencies
            if row and row.mapping_mode == "attribute" and isinstance(tree, exp.Parameter):
                candidate.mapping_mode = "attribute"
                candidate.attribute_name = row.attribute_name
            compiler = MappingSqlService(session=None, analyst_client=None)
            # Column bindings were proven above. Pass relation IDs to the
            # compiler: its legacy dependency splitter is not quote-aware for
            # a column such as src."Odd.Name". Returned dependencies stay exact.
            compiler_dependencies = []
            for dependency in dependencies:
                node = bindings.nodes.get(dependency)
                if node is None:
                    node, _ = bindings.column(_scalar(dependency))
                compiler_dependencies.append(node.relation_id)
            if origin == "authored_sql":
                compiler_dependencies.extend(node.relation_id for node in query.aliases.values())
            compiled = compiler.compile(MappingSqlCompileRequest(
                relation_graph=graph, driving_relation_id=workspace.driving_relation_id if workspace else None,
                mappings=[MappingSqlMappingItem(target_column=attribute.target_attribute,
                    expression=compiler_tree.sql(dialect="snowflake"), source_dependencies=list(dict.fromkeys(compiler_dependencies)),
                    value_binding_ids=ids)],
                validate_with_explain=False, allow_unresolved_placeholders=True,
            ))
            required.update(compiled.required_relation_ids)
            required.update(_validate_required_graph(bindings, required))
            _validate_graph_edges(bindings)
            _check_compiler_projection(compiled.canonical_preview_sql, compiler_tree, bindings)
            if origin == "current_rule":
                # The complete generated scope also checks graph modifiers,
                # joins and derived bodies which the scalar does not mention.
                _authored_query(compiled.canonical_preview_sql, bindings, None, definition=True)
            if not compiled.valid:
                raise _Unproven("compiler_rejected", "The existing compiler did not validate the current binding.")
            value_trees = [value_tree, _one(compiled.canonical_preview_sql)]
            compiler_value_ids, compiler_values = _value_ids(value_trees[-1], graph, [])
            ids = list(dict.fromkeys([*ids, *compiler_value_ids]))
            unresolved = sorted(set(unresolved) | set(compiler_values))
            for relation_id in sorted(required):
                node = bindings.nodes[relation_id]
                if node.sql_text:
                    dependency_tree = _one(node.sql_text)
                    value_trees.append(dependency_tree)
                    dependency_ids, dependency_values = _value_ids(dependency_tree, graph, [])
                    ids = list(dict.fromkeys([*ids, *dependency_ids]))
                    unresolved = sorted(set(unresolved) | set(dependency_values))
            candidate.value_binding_ids = ids
            compiler_valid = compiled.valid
            unresolved = sorted(set(unresolved) | set(compiled.unresolved_placeholders))
            # The compiler deliberately has legacy quoted-placeholder semantics.
            # Do not let that turn authored literal text into a project value.
            if any(isinstance(node, exp.Literal) and node.is_string and MappingSqlService._is_placeholder(node.this)
                   for value_definition in value_trees for node in value_definition.walk()):
                raise _Unproven("literal_placeholder_contract", "Quoted placeholder text cannot be safely represented by the legacy compiler.")
            mapping = candidate
            if candidate.mapping_mode == "source" and not references:
                notes.append(AuthoredDiagnostic("baseline_only_scalar", "Source-free Custom expression is preservation metadata only; retain the baseline/query rather than regenerating a frontend value row.", attribute.target_attribute))
            if unresolved:
                notes.append(AuthoredDiagnostic("unbound_values", "Definition preserved; unresolved project values block execution.", attribute.target_attribute))
        except (ValueError, SqlglotError) as exc:
            notes.append(AuthoredDiagnostic(getattr(exc, "code", "compiler_rejected"), str(exc), attribute.target_attribute))
        diagnostics.extend(notes)
        results.append(AuthoredTargetResolution(
            attribute=attribute.model_copy(deep=True), status="definition_preserved" if mapping else "pending",
            origin=origin, mapping=mapping, baseline_rows=deepcopy(rows), definition_sql=text,
            requires_authored_query=origin == "authored_sql", compiler_valid=compiler_valid,
            execution_status="blocked" if mapping is None or unresolved else "not_validated",
            required_relation_ids=tuple(sorted(required)), unresolved_values=tuple(unresolved), diagnostics=tuple(notes),
        ))
    return AuthoredTargetsResolution(
        targets=tuple(results), pending_attributes=tuple(result.attribute.model_copy(deep=True) for result in results if result.mapping is None),
        baseline_rows=baseline, mapping_sql=mapping_sql, raw_mapping_sql=raw_sql, diagnostics=tuple(diagnostics),
    )
