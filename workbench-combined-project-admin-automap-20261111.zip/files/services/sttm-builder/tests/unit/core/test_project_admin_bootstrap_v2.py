from types import SimpleNamespace
import json
import pytest
from fastapi import HTTPException
from app.core.project_bootstrap import initialize_blank_mappings
from app.core.project_service import ProjectService
from app.schema.project import STTMCreateRequest
from app.schema.common import TableRef

class Row(dict):
 def as_dict(self):return dict(self)

class Session:
 def __init__(self):self.calls=[];self.entries=[]
 def sql(self,sql,params=None):
  self.calls.append((sql,params))
  if sql.startswith('INSERT INTO HEADERS'):
   self.entries=json.loads(params[-1])
  rows=[Row(STTM_ID=i+1,LAST_SNAPSHOT_ID=e['snapshot_id'],PROJECT_ID='1',STTM_METADATA=e['metadata']) for i,e in enumerate(self.entries)] if sql.startswith('SELECT') else []
  return SimpleNamespace(collect=lambda:rows)

def test_ten_target_bootstrap_uses_five_dml_reads_without_autosave_or_nested_transaction():
 session=Session()
 service=SimpleNamespace(_session=session,_sttm_table='HEADERS',_snapshots_table='SNAPSHOTS',_attributes_table='ATTRS',
  _actor_column_values=lambda *args:{},_table_ref_to_fqn=lambda table:table.qualified_name,
  _snapshot_to_dict=lambda value:value.model_dump(mode='json') if hasattr(value,'model_dump') else value,
  _normalized_workspace_hash=lambda snapshot:'hash',_sttm_from_row=lambda row, mapping_counts:(row,mapping_counts))
 payloads=[STTMCreateRequest(sttm_name=f'Mapping {i}',target_table=TableRef(database='D',schema='S',table=f'T{i}'),
  metadata={'bootstrap_idempotency_key':'request-123'},workspace_snapshot={'mapping_rows':[{'target_column':f'FIELD_{column}','target_type':'NUMBER','source_columns':[],'status':'UNMAPPED'} for column in range(26 if i==9 else 24)]}) for i in range(10)]
 result=initialize_blank_mappings(service,SimpleNamespace(project_id='1'),payloads,user_id='7',display_name='Admin')
 assert len(result)==10
 assert len(session.calls)==5
 assert not any('DELETE' in sql or 'BEGIN' in sql or 'COMMIT' in sql for sql,_ in session.calls)
 assert sum(counts['MAPPING_COUNT'] for _,counts in result)==242
 assert all(counts['MAPPED_COUNT']==0 for _,counts in result)
 snapshots=json.loads(session.calls[2][1][-1])
 assert all(entry['snapshot']['sttm_id'] and entry['snapshot']['snapshot_id'] for entry in snapshots)

@pytest.mark.parametrize('persona',['VIEWER','PUBLISHER'])
def test_non_admin_cannot_remove_resource(monkeypatch,persona):
 import app.api
 from app.routers import projects
 from app.auth.models import AppPersona
 monkeypatch.setattr(projects,'get_current_principal',lambda request:SimpleNamespace(app_persona=AppPersona(persona)))
 service=SimpleNamespace(_session=SimpleNamespace(sql=lambda *args:pytest.fail('Unauthorized SQL mutation')))
 with pytest.raises(HTTPException) as caught:
  projects.manage_resource('project','1','delete',SimpleNamespace(),service)
 assert caught.value.status_code==403

def test_missing_mutex_rolls_back_before_project_creation():
 service=ProjectService.__new__(ProjectService)
 calls=[]
 service.ensure_storage_exists=lambda:None
 service._settings=SimpleNamespace(snowflake_workspace_snapshots_table='SNAPSHOTS')
 service._table_columns=lambda table:{'SNAPSHOT_ID','SNAPSHOT_PAYLOAD','STTM_ID'}
 service._qualified_name=lambda name:'D.S.'+name
 service._session=SimpleNamespace(sql=lambda sql: (calls.append(sql) or SimpleNamespace(collect=lambda:[])))
 from app.schema.project import ProjectCreateFromTemplateRequest
 with pytest.raises(Exception,match='lock is not initialized'):
  service.create_project_from_template(ProjectCreateFromTemplateRequest(project_name='Example',source_system_key='OTHER',idempotency_key='request-123'),user_id='7')
 assert calls[-1]=='ROLLBACK'
 assert not any('INSERT' in sql for sql in calls)

@pytest.mark.parametrize('kind,action,expected_updates', [('project','archive',2),('project','delete',2),('mapping','delete',1)])
def test_admin_removal_is_transactional_and_retains_history(monkeypatch,kind,action,expected_updates):
 import app.api
 from app.routers import projects
 from app.auth.models import AppPersona
 principal=SimpleNamespace(app_persona=AppPersona.ADMIN,snowflake_user='ADMIN_USER',user_id=7,snowflake_role='ADMIN')
 monkeypatch.setattr(projects,'get_current_principal',lambda request:principal)
 monkeypatch.setattr(projects,'build_response_envelope',lambda **kwargs:kwargs['data'])
 calls=[]
 def sql(query,params=None):
  calls.append((query,params))
  return SimpleNamespace(collect=lambda:[Row(changed=1)])
 result=projects.manage_resource(kind,'42',action,SimpleNamespace(),SimpleNamespace(
  _session=SimpleNamespace(sql=sql),_projects_table='PROJECTS',_sttm_table='MAPPINGS'))
 assert result['history_retained'] is True
 assert result['status']==('ARCHIVED' if action=='archive' else 'DELETED')
 assert calls[0][0]=='BEGIN' and calls[-1][0]=='COMMIT'
 assert sum(query.startswith('UPDATE') for query,_ in calls)==expected_updates
 assert not any(query.startswith(('DELETE','DROP')) for query,_ in calls)
 assert calls[1][1][-1]=='42' and calls[1][1][-2]=='ADMIN_USER'


def test_admin_missing_resource_rolls_back(monkeypatch):
 import app.api
 from app.routers import projects
 from app.auth.models import AppPersona
 principal=SimpleNamespace(app_persona=AppPersona.ADMIN,snowflake_user='ADMIN_USER',user_id=7)
 monkeypatch.setattr(projects,'get_current_principal',lambda request:principal)
 calls=[]
 def sql(query,params=None):
  calls.append(query)
  return SimpleNamespace(collect=lambda:[Row(changed=0)])
 with pytest.raises(HTTPException) as caught:
  projects.manage_resource('mapping','missing','archive',SimpleNamespace(),SimpleNamespace(
   _session=SimpleNamespace(sql=sql),_sttm_table='MAPPINGS'))
 assert caught.value.status_code==404
 assert calls[-1]=='ROLLBACK' and 'COMMIT' not in calls


def test_mid_bootstrap_failure_has_one_transaction_owner():
 service=ProjectService.__new__(ProjectService)
 calls=[]
 service.ensure_storage_exists=lambda:None
 service._settings=SimpleNamespace(snowflake_workspace_snapshots_table='SNAPSHOTS')
 service._table_columns=lambda table:{'SNAPSHOT_ID','SNAPSHOT_PAYLOAD','STTM_ID'}
 service._qualified_name=lambda name:'D.S.'+name
 def sql(query,params=None):
  calls.append(query)
  return SimpleNamespace(collect=lambda:[Row(changed=1)] if query.startswith('UPDATE') else [])
 service._session=SimpleNamespace(sql=sql)
 def fail(*args,**kwargs):
  service._session.sql('INSERT INTO SNAPSHOTS fixture').collect()
  raise RuntimeError('attribute insert failed')
 service._create_project_from_template=fail
 from app.schema.project import ProjectCreateFromTemplateRequest
 with pytest.raises(RuntimeError,match='attribute insert failed'):
  service.create_project_from_template(ProjectCreateFromTemplateRequest(project_name='Example',source_system_key='OTHER',idempotency_key='request-123'),user_id='7')
 assert calls.count('BEGIN')==1 and calls[-1]=='ROLLBACK'
 assert 'COMMIT' not in calls


def test_same_request_reuses_complete_project_without_overwriting_later_edits():
 from tests.unit.core.test_project_template_bootstrap import _service,_template
 from app.schema.project import ProjectCreateFromTemplateRequest,STTMRecord
 service=_service()
 template=_template()
 service.get_project_templates=lambda **kwargs:[template]
 metadata={'bootstrap_idempotency_key':'request-123','bootstrap_status':'COMPLETE',
  'source_system_key':'OTHER','target_database':'CLIENT_DB','target_schema':'SALESFORCE',
  'selected_target_tables':['HOUSEHOLD','CALLS'],'later_business_note':'Keep this edit'}
 row=Row(PROJECT_ID=1,PROJECT_NAME='Example',CREATED_BY='7',STATUS='ACTIVE',PROJECT_METADATA=metadata)
 calls=[]
 def sql(query,params=None):
  calls.append(query)
  return SimpleNamespace(collect=lambda:[row] if query.startswith('SELECT') else [Row(changed=1)])
 service._session=SimpleNamespace(sql=sql)
 service.list_sttms=lambda project:[STTMRecord(sttm_id=str(i),project_id='1',last_snapshot_id='later-snapshot',mapping_count=1,
  metadata={'logical_target_table_key':target.logical_target_key}) for i,target in enumerate(template.available_targets)]
 service._initialize_blank_mappings=lambda *args,**kwargs:pytest.fail('Completed request was initialized twice')
 request=ProjectCreateFromTemplateRequest(project_name='Example',source_system_key='OTHER',idempotency_key='request-123')
 for _ in range(2):
  result=service.create_project_from_template(request,user_id='7')
  assert result.project.metadata['later_business_note']=='Keep this edit'
  assert len(result.mappings)==2
 assert not any(query.startswith('INSERT') or 'SET PROJECT_METADATA' in query for query in calls)
 assert calls.count('BEGIN')==calls.count('COMMIT')==2
