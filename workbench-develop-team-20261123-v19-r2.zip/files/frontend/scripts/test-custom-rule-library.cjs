const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
const Module = require('node:module');

function load(relative) {
  const filename = path.resolve(__dirname, relative);
  const loaded = new Module(filename, module);
  loaded._compile(ts.transpileModule(fs.readFileSync(filename, 'utf8'), { compilerOptions: {
    module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020,
  } }).outputText, filename);
  return loaded.exports;
}

const {
  libraryRuleForSave,
  matchingLibraryRule,
  missingLibraryColumns,
  removeDottedColumnTokens,
} = load('../src/features/sttm/mapping/custom-rule-library.ts');
const { expandColumnReferenceRange, insertSqlSnippet } = load('../src/components/sql/sql-insert.ts');

const rules = [
  { rule_id: 'rule-1', rule_name: 'Standardize Name', expression: 'UPPER(a.NAME)', version: 2 },
];

assert.equal(matchingLibraryRule(rules, '  UPPER(a.NAME)  ')?.rule_id, 'rule-1');
assert.equal(matchingLibraryRule(rules, 'LOWER(a.NAME)'), null);
assert.equal(
  libraryRuleForSave(rules, 'UPPER(a.NAME || b.CITY)', 'rule-1')?.rule_name,
  'Standardize Name',
);
assert.equal(libraryRuleForSave(rules, 'UPPER(a.NAME)', null)?.rule_id, 'rule-1');
assert.equal(libraryRuleForSave(rules, 'LOWER(a.NAME)', 'missing'), null);
assert.deepEqual(missingLibraryColumns('UPPER(a.NAME)', ['a.NAME']), []);
assert.deepEqual(missingLibraryColumns('UPPER(b.CITY)', ['a.NAME']), ['B.CITY']);
assert.equal(
  removeDottedColumnTokens('TO_CHAR(contacts.TYPE)', (token) => token.toUpperCase() === 'CONTACTS.TYPE'),
  'TO_CHAR()',
);
assert.equal(
  removeDottedColumnTokens("'EVR' || contacts.TYPE || contacts.CITY", (token) => token.toUpperCase() === 'CONTACTS.TYPE'),
  "'EVR' || || contacts.CITY",
);

const sql = "TO_CHAR(contacts.TYPE)";
const typeStart = sql.indexOf('TYPE');
const expanded = expandColumnReferenceRange(sql, typeStart, typeStart + 4);
assert.deepEqual(expanded, { start: sql.indexOf('contacts.TYPE'), end: sql.indexOf('contacts.TYPE') + 'contacts.TYPE'.length });
const replaced = insertSqlSnippet(sql, 'contacts.FIRST_NAME', typeStart, typeStart + 4, { replaceColumnReference: true });
assert.equal(replaced.nextValue, 'TO_CHAR(contacts.FIRST_NAME)');
const caretAt = 'UPPER(a.)'.length;
const caretInsert = insertSqlSnippet('UPPER(a.)', 'agent.AGENT_NAME', caretAt, caretAt, { separateTokens: false, replaceColumnReference: true });
assert.equal(caretInsert.nextValue, 'UPPER(a.)agent.AGENT_NAME');

console.log('custom rule library checks passed');
