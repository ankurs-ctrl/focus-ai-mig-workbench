"""Narrow handoff to the existing batched transformation specialist."""
from __future__ import annotations

from copy import deepcopy
from typing import Any

from app.core.automap_policy import semantic_projection
from app.core.automap_retrieval import AutoMapContext, reference_parts, scoped_record, target_name
from app.core.mapping_context import _targets


def expression_within_selection(payload: dict[str, Any], selected: Any, rule: Any) -> bool:
    """Check actual SQL references, not only the specialist's declared dependencies."""
    from sqlglot import exp, parse_one
    from app.core.mapping_sql import MappingSqlService

    store = AutoMapContext(payload)

    def identity(reference):
        relation, column = reference_parts(reference)
        owner = store.primary_owner(relation)
        name = store._column_name(owner, column)
        if name is None:
            raise ValueError("Unknown transformation source")
        return owner, name

    try:
        allowed = {identity(value) for value in [*selected.source_attributes, *selected.source_dependencies,
                  *getattr(selected, "admitted_source_attributes", [])]}
        actual = {identity(column.sql(dialect="snowflake")) for column in
                  parse_one(rule.rule, read="snowflake").find_all(exp.Column)}
        returned = {identity(value) for value in rule.source_dependencies}
        bindings = (payload.get("context") or {}).get("relation_graph", {}).get("value_bindings") or []
        allowed_values = {str(binding.get("value")).upper() for binding in bindings
                          if binding.get("resolved_value") is not None}
        actual_values = {value.upper() for value in MappingSqlService._placeholders_in_sql(rule.rule)}
        returned_values = {str(binding.get("value")).upper() for binding in bindings
                           if binding.get("binding_id") in rule.value_binding_ids or binding.get("value") in rule.value_binding_ids}
        return (actual <= allowed and returned <= allowed
                and set(rule.value_binding_ids) <= {str(binding.get("binding_id")) for binding in bindings} | allowed_values
                and actual_values <= allowed_values and actual_values <= returned_values | {
                    str(binding.get("value")).upper() for binding in bindings
                    if binding.get("binding_id") in selected.value_binding_ids or binding.get("value") in selected.value_binding_ids})
    except (ValueError, TypeError):
        return False


def transformation_packet(payload: dict[str, Any], *, factor: bool = True) -> dict[str, Any]:
    store = AutoMapContext(payload)
    focused_context = store.manifest()["context"]
    context = payload.get("context") or {}
    # The backend passes only the admitted worker recipes to this handoff, not
    # comprehensive preparation candidates. Keep their actual expressions.
    for target in store.targets:
        mapping = store.targets[target].get("selected_mapping") or {}
        used_ids = set(mapping.get("used_learning_ids") or [])
        recipes = [scoped_record(item, target) for item in
                   (context.get("learning_context") or {}).get("target_mapping_patterns", [])
                   if target.upper() in _targets(item)]
        if recipes:
            store.evidence[target]["canonical_target_mapping_patterns"] = recipes
        # These records are populated only from the owning batch's canonical
        # admission, not a fresh broad Search or untrusted request metadata.
        admitted = [scoped_record(item, target) for item in
                    (context.get("learning_context") or {}).get("search_evidence", [])
                    if target.upper() in _targets(item)]
        if admitted:
            store.evidence[target]["search_hydrated_evidence"] = admitted
    graph = context.get("relation_graph") or {}
    selected_columns: dict[str, set[str]] = {}
    selected_values = set()
    evidence = {}
    for attribute in payload["data"].get("attributes") or []:
        target = target_name(attribute["target_attribute"])
        mapping = attribute.get("selected_mapping") or {}
        for reference in [*(mapping.get("source_attributes") or []), *(mapping.get("source_dependencies") or []),
                          *(mapping.get("admitted_source_attributes") or [])]:
            relation, column = reference_parts(reference)
            try:
                owner = store.primary_owner(relation)
            except ValueError as exc:
                raise ValueError("Ambiguous transformation source binding") from exc
            name = store._column_name(owner, column)
            if name is None:
                raise ValueError("Unknown transformation source column")
            selected_columns.setdefault(owner, set()).add(name)
        selected_values.update(mapping.get("value_binding_ids") or [])
        evidence[target] = {category: store._evidence_projection(target, category)
                            for category in store.mandatory_categories(target)}
        # Historical handles require exact bodies before adapting a rule. This
        # specialist has no retrieval loop, so include the exact dependencies.
        for category, records in evidence[target].items():
            def expand(value):
                if isinstance(value, dict):
                    identity = value.get("exact_dependency_id")
                    if identity:
                        if value.get("read_required_if_recipe_used") is False:
                            return deepcopy(value)
                        return deepcopy(store.historical_dependencies[identity])
                    return {key: expand(child) for key, child in value.items()}
                return [expand(child) for child in value] if isinstance(value, list) else value
            evidence[target][category] = expand(records)
    semantics = {relation: {name: semantic_projection(store.columns[relation][name]) for name in names}
                 for relation, names in selected_columns.items()}
    target_semantics = {target: semantic_projection(store.columns.get(store.target_table, {}).get(target, []))
                        for target in store.targets}
    nodes = []
    join_columns = {}
    for edge in graph.get("edges") or []:
        for condition in edge.get("conditions") or []:
            for side in ("left", "right"):
                join_columns.setdefault(edge.get(f"{side}_relation_id"), set()).add(condition.get(f"{side}_column"))
    for node in graph.get("nodes") or []:
        owners = set()
        for alias in (node.get("relation_id"), node.get("alias")):
            owners.update(store.aliases.get(alias, set()))
        columns = set().union(*(selected_columns.get(owner, set()) for owner in owners))
        columns.update(join_columns.get(node.get("relation_id"), set()))
        # All graph identities and connecting edges stay present, but unrelated
        # outputs/descriptions are not part of the transformation task.
        projected = {key: deepcopy(value) for key, value in node.items()
                     if key not in {"output_columns", "definition_sql", "query_scope"} and (key not in {"sql_text", "column_semantics"} or columns)}
        projected["output_columns"] = [deepcopy(column) for column in node.get("output_columns") or []
                                       if column.get("name") in columns]
        nodes.append(projected)
    dependencies = {}
    for node in nodes:
        if node["output_columns"] and node["relation_id"] in store.dependencies:
            dependencies[node["relation_id"]] = store._value({"operation": "dependency", "relation_id": node["relation_id"]})[1]
    result = {key: deepcopy(payload[key]) for key in ("request_id", "operation", "data") if key in payload}
    for attribute in result.get('data', {}).get('attributes') or []:
        selected = attribute.get('selected_mapping') or {}
        for field in ('candidates','suggestions','selected_candidate_id','draft_candidate_id','confidence_provenance','scoring_issues'):
            selected.pop(field, None)
    from app.core.automap_context_packer import shared_capsule
    result["context"] = {
        **{key: deepcopy(focused_context[key]) for key in (
            "project_id", "sttm_id", "snapshot_id", "project_context", "project_context_status",
            "mapping_intent", "current_mapping_rows", "current_mapping_policy",
        ) if key in focused_context},
        "semantic_evidence_coverage": shared_capsule(context)["semantic_evidence_coverage"],
        "semantic_bundle_id": context.get("semantic_bundle_id"),
        "relation_graph": {"nodes": nodes, "edges": deepcopy(graph.get("edges") or []),
                           "value_bindings": [{key: deepcopy(value) for key, value in binding.items() if key != "resolved_value"}
                                              for binding in graph.get("value_bindings") or []
                                              if binding.get("resolved_value") is not None],
                           "query_modifiers": deepcopy(graph.get("query_modifiers") or {})},
        "source_semantics": semantics, "target_semantics": target_semantics,
        "evidence_citation_contract": {},
        "relation_contracts": {relation: deepcopy(store.contracts.get(relation, []))
                               for relation in [*selected_columns, store.target_table]},
        "population": {key: deepcopy(value) for key, value in store.dependencies.get("workspace", {}).items()
                       if key not in {"relation_graph", "selected_columns_by_table", "source_tables", "variable_bindings", "mapping_rows"}},
        "mapping_evidence": evidence, "cte_dependencies": dependencies,
        "workspace_context": {key: deepcopy(value) for key, value in (context.get("workspace_context") or {}).items()
            if key in {"project_id", "sttm_id", "project_description", "sttm_description", "business_goal",
                       "driving_relation_id", "mapping_intent"}}}
    for target in store.targets:
        for category in evidence[target]:
            store.reads.add(('evidence', target, category))
        result['context']['evidence_citation_contract'][target] = {
            'allowed_evidence_ids': sorted(store.evidence_ids(target)),
            'allowed_recipe_ids': sorted(store.recipe_ids(target)),
            'policy': 'Copy exact IDs from this target only. Descriptions, source-agent names and example tags are not evidence IDs. Return empty evidence arrays when no historical evidence is used. Selected mapping citations may still be unverified; do not copy unsupported claims.'}
    from app.core.execution_display_names import execution_display_names
    result["context"]["execution_display_names"] = execution_display_names(context)
    result["context"]["display_policy"] = "Narrative explanations use display names; executable rules and dependencies retain exact execution references."
    if not factor:
        return result
    from app.core.automap_retrieval import factor_exact_records, factor_exact_text_lines
    from app.core.agent_payload_budget import _factor_repeated_context_values
    # Specialist snapshots often contain the same CTE SQL inside different
    # wrappers. Whole-object interning alone cannot share those exact strings.
    result = factor_exact_records(result)
    _factor_repeated_context_values(result)
    return factor_exact_text_lines(result)