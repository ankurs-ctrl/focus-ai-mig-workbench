"use client";
import { AiaBox } from '@/components/ui';
import { useEffect, useRef } from "react";
import { usePathname } from "next/navigation";

import { AiChatMainOverlay } from "@/features/ai-agent/ai-chat-shell-integration";
import { AiChatRailTab, AiChatSidebarPanel } from "@/features/ai-agent/ai-chat-shell-host";
import { useAiChatLayout } from "@/features/ai-agent/ai-chat-layout-context";
import AppSidebar from "./app-sidebar";
import type { AppNavItem } from "./app-sidebar-types";

type AppShellProps = {
  activeNav?: AppNavItem;
  initialNewMappingOpen?: boolean;
  children: React.ReactNode;
};

export default function AppShell({
  activeNav,
  initialNewMappingOpen = false,
  children,
}: AppShellProps) {
  const workspaceRef = useRef<HTMLDivElement | null>(null);
  const pathname = usePathname();
  const isAiAgentRoute = pathname === "/ai-agent" || pathname.startsWith("/ai-agent/");
  const { isOpen, isFullscreen, setLayoutMetrics } = useAiChatLayout();

  useEffect(() => {
    const node = workspaceRef.current;
    if (!node) return;

    const update = () => {
      setLayoutMetrics(node.clientWidth, node.clientHeight);
    };

    update();
    const observer = new ResizeObserver(update);
    observer.observe(node);
    return () => observer.disconnect();
  }, [setLayoutMetrics]);

  return (
    <AiaBox
      sx={{
        display: "flex",
        flex: 1,
        minHeight: 0,
        overflow: "hidden",
        bgcolor: "#F7F8FA",
      }}
    >
      <AppSidebar activeNav={activeNav} initialNewMappingOpen={initialNewMappingOpen} />
      <AiaBox
        ref={workspaceRef}
        sx={{
          flex: 1,
          minWidth: 0,
          minHeight: 0,
          display: "flex",
          position: "relative",
          overflow: "hidden",
        }}
      >
        <AiaBox
          component="main"
          sx={{
            flex: 1,
            minWidth: 0,
            minHeight: 0,
            display: isAiAgentRoute || (isOpen && isFullscreen) ? "none" : "flex",
            flexDirection: "column",
            overflow: "hidden",
            position: "relative",
          }}
        >
          <AiChatMainOverlay />
          {children}
        </AiaBox>
        {/* Keep the chat mounted while the rail is collapsed or fullscreen
            changes. Unmounting it discards live Deep messages and its stream. */}
        <AiaBox sx={{ display: isAiAgentRoute || isOpen ? "flex" : "none", flex: isAiAgentRoute || (isOpen && isFullscreen) ? 1 : undefined, minWidth: 0, minHeight: 0 }}>
          <AiChatSidebarPanel pageMode={isAiAgentRoute} />
        </AiaBox>
        {!isAiAgentRoute && !isOpen ? <AiChatRailTab /> : null}
      </AiaBox>
    </AiaBox>
  );
}
