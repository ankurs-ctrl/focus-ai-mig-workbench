const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
const Module = require('node:module');
function compile(filename, source) {
  const loaded = new Module(filename, module);
  loaded.require = name => name.startsWith('@/')
    ? load(path.resolve(__dirname, `../src/${name.slice(2)}.ts`)) : name.startsWith('.') ? load(path.resolve(path.dirname(filename), name+'.ts')) : require(name);
  if(filename.endsWith('sttm-builder-slice.ts'))source='import {rowMappingStatus,rowValidationIsCurrent} from "@/features/sttm/shared/row-validation-state";\nimport {selectionValidationSignature} from "@/features/sttm/shared/validation-context";\n'+source;
  loaded._compile(ts.transpileModule(source, {compilerOptions: {
    module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020,
  }}).outputText, filename);
  return loaded.exports;
}
function load(filename) { return compile(filename, fs.readFileSync(filename, 'utf8')); }
const {missingTargetMappings, reconcileUploadedTargets, savedMappingEvidence, savedRunBlockers} = load(path.resolve(__dirname, '../src/features/sttm/shared/mapping-row-recovery.ts'));
const blank = (targetColumn, id = targetColumn) => ({id, targetColumn, status: 'UNMAPPED', sourceColumn: null});
const saved = {...blank('NAME', 'saved'), status:'UNMAPPED', sourceColumn:'cte."Name"',
  unmatchedReason:'Required relations are disconnected', transformationClassification:'unresolved'};
const targets = [blank('NAME'), blank('VALUE'), blank('OTHER')];
const existing = [saved];
const missing = missingTargetMappings(existing, targets);
assert.deepEqual(missing.map(row => row.targetColumn), ['VALUE', 'OTHER']);
assert.equal(existing[0], saved);
assert.equal(missingTargetMappings([...existing, ...missing], targets).length, 0);
assert.equal(missingTargetMappings([blank('D.S.T.NAME')], [blank('NAME')]).length, 0);
assert.equal(missingTargetMappings([blank('"name"')], [blank('NAME')]).length, 1);
assert.equal(missingTargetMappings([blank('NAME', 'VALUE')], [blank('VALUE')])[0].id, 'VALUE:missing:1');
assert.deepEqual(savedMappingEvidence({unmatched_reason:'exact reason', used_learning_ids:['learn'],
  candidate_source_attributes:['cte."Name"']}), {
  proposedSqlSource:null, draftIssues:[], reconciliationWarnings:[], descriptionEdited:false,
  aiGeneration:null, aiCandidates:[], aiSuggestions:[], selectedAiCandidateId:null, aiReviewStatus:null, aiUndoSnapshot:null, validation:null,
  unmatchedReason:'exact reason', usedLearningIds:['learn'], candidateSourceColumns:['cte."Name"'],
  usedInferenceIds:[], usedRecommendationIds:[],
});
const savedOutcome = {mappings:{'D.S.T.NAME':{unmatched_reason:'legacy graph rejection'}}};
assert.deepEqual(savedRunBlockers([saved], savedOutcome), ['legacy graph rejection']);
assert.deepEqual(savedRunBlockers([{...saved,status:'MAPPED'}], savedOutcome), ['legacy graph rejection']);
assert.deepEqual(savedRunBlockers([{...saved,targetColumn:'OTHER'}], savedOutcome), []);
assert.equal(saved.unmatchedReason, 'Required relations are disconnected');

const slicePath = path.resolve(__dirname, '../src/features/sttm/store/sttm-builder-slice.ts');
const slice = ts.createSourceFile(slicePath, fs.readFileSync(slicePath, 'utf8'), ts.ScriptTarget.Latest, true);
let recoveryReducer, restoreRow, libraryRuleNoteSource;
function visit(node) {
  if (ts.isVariableDeclaration(node) && node.name.getText(slice) === 'libraryRuleNote') libraryRuleNoteSource = node.initializer.getText(slice);
  if (ts.isPropertyAssignment(node) && node.name.getText(slice) === 'ensureTargetMappings') recoveryReducer = node.initializer.getText(slice);
  if (ts.isBinaryExpression(node) && node.left.getText(slice) === 'state.mappings'
    && ts.isCallExpression(node.right) && node.right.expression.getText(slice) === 'rawMappingRows.map') restoreRow = node.right.arguments[0].getText(slice);
  ts.forEachChild(node, visit);
}
visit(slice);
assert.ok(recoveryReducer);
assert.ok(restoreRow);
assert.ok(libraryRuleNoteSource);
const ensure = compile(slicePath, `module.exports = (missingTargetMappings, reconcileUploadedTargets, sqlIdentifierKey, hasMappingDefinition) => (${recoveryReducer});`)(
  missingTargetMappings, reconcileUploadedTargets, value => value, row => !!row.sourceColumn,
);
const state = {mappings:existing, selectedMappingIds:['saved'], pendingManualEditSnapshots:{saved:{...saved}}, pendingAiMappingReviews:[{mappingId:'saved'}]};
ensure(state, {payload:targets});
assert.equal(state.mappings.length, 3);
assert.equal(state.mappings[0], saved);
assert.deepEqual(state.selectedMappingIds, ['saved']);
assert.ok(state.pendingManualEditSnapshots.saved);
assert.equal(state.pendingAiMappingReviews.length, 1);
ensure(state, {payload:targets});
assert.equal(state.mappings.length, 3);
const restore = compile(slicePath, `module.exports = (savedMappingEvidence) => {
  const rewriteLegacyAliasReference = value => value;
  const legacyAliasRewrites = new Map();
  const dependencyIsAvailable = () => true;
  const downgradedTargetColumns = [];
  const libraryRuleNote = (${libraryRuleNoteSource});
  return (${restoreRow});
};`)(savedMappingEvidence);
const restored = restore({id:'saved', target_column:'NAME', status:'UNMAPPED',
  source_columns:['cte."Name"'], unmatched_reason:'exact graph rejection',
  confidence:0.97, transformation_classification:'unresolved', used_learning_ids:['learn']}, 0);
assert.equal(restored.unmatchedReason, 'exact graph rejection');
assert.equal(restored.status, 'UNMAPPED');
assert.equal(restored.confidenceScore, 0.97);
assert.equal(restored.transformationClassification, 'unresolved');
assert.deepEqual(restored.usedLearningIds, ['learn']);
const restoredLibrary = restore({id:'library', target_column:'NAME', source_columns:['cte.NAME'],
  LIBRARY_RULE_ID:'rule-1', LIBRARY_RULE_NAME:'Normalize name', LIBRARY_RULE_VERSION:'3'}, 0);
assert.equal(restoredLibrary.libraryRuleId, 'rule-1');
assert.equal(restoredLibrary.libraryRuleName, 'Normalize name');
assert.equal(restoredLibrary.libraryRuleVersion, 3);
console.log('Target coverage appends idempotently, preserves edits and quoted identities, and actual reopen hydration retains validation evidence.');

const graphReducers = {};
function visitGraph(node) {
  if (ts.isPropertyAssignment(node) && ['removeDerivedSource', 'toggleDerivedSource', 'clearDerivedSources'].includes(node.name.getText(slice))) {
    graphReducers[node.name.getText(slice)] = compile(slicePath, `module.exports = (${node.initializer.getText(slice)});`);
  }
  ts.forEachChild(node, visitGraph);
}
visitGraph(slice);
for (const name of Object.keys(graphReducers)) {
  const state = {derivedSources:[{id:'derived',isSelected:true}], drivingTableId:'derived',
    compiledMappingReady:true, compiledMappingContextHash:'old', mappings:[saved]};
  graphReducers[name](state, {payload:{id:'derived'}});
  assert.equal(state.drivingTableId, null);
  assert.equal(state.compiledMappingReady, false);
  assert.equal(state.compiledMappingContextHash, null);
  assert.equal(state.mappings[0], saved);
}
const unrelated = {derivedSources:[{id:'driver',isSelected:true},{id:'other',isSelected:false}], drivingTableId:'driver'};
graphReducers.toggleDerivedSource(unrelated, {payload:{id:'other'}});
assert.equal(unrelated.drivingTableId, 'driver');
console.log('Removing a derived driver invalidates compilation without choosing another population or changing mappings.');

const reducerNames = ['autoMapReviewIsApplicable', 'autoMapReviewFromRun', 'autoMapRevisionHash', 'autoMapSourceInputs', 'autoMapSharedInputs', 'autoMapInputsMatch', 'stablePreparedContextValue', 'applyAutoMapResponseToState', 'normalizeTargetKey', 'targetKeyVariants',
  'autoMapRecord', 'autoMapCount', 'extractAutoMapPreservation', 'autoMapInputSignature',
  'autoMapRowIsEdited', 'restoreAutoMapStatus', 'extractAutoMappingReview'];
const reducerSource = slice.statements.filter(node => ts.isFunctionDeclaration(node)
  && reducerNames.includes(node.name?.text)).map(node => node.getText(slice)).join('\n');
const applyAutoMap = compile(slicePath, `
  const {sha256} = require('@noble/hashes/sha256');
  const extractSemanticViewNameFromStatus = (_, fallback) => fallback;
  const normalizeSemanticContextItems = value => value;
  const buildPendingAiMappingReviews = () => [];
  const applyMappingSuggestion = row => { row.status = 'MAPPED'; row.sourceColumn = 'new.ID'; return true; };
  ${reducerSource}
  module.exports = applyAutoMapResponseToState;
`);
const preserved = {...blank('NAME'), status:'MAPPED', sourceColumn:'old.NAME', preprocessingRule:'TRIM(old.NAME)'};
const failedState = {mappings:[preserved, {...blank('VALUE'), status:'PROCESSING'}, blank('OTHER')],
  mappingSuggestions:[], pendingManualEditSnapshots:{}, pendingAiMappingReviews:[]};
const failedResponse = {warnings:[{code:'AUTO_MAPPING_BATCH_FAILED',field:'DB.S.T.NAME'},
  {code:'AUTO_MAPPING_BATCH_FAILED',field:'VALUE'}], result:{mappings:{
    NAME:{source_attributes:[],confidence_score:0}, VALUE:{source_attributes:[],confidence_score:0},
    OTHER:{source_attributes:['new.ID'],confidence_score:0.99}}}};
applyAutoMap(failedState, failedResponse);
assert.equal(preserved.status, 'MAPPED');
assert.equal(preserved.sourceColumn, 'old.NAME');
assert.equal(preserved.preprocessingRule, 'TRIM(old.NAME)');
assert.equal(failedState.mappings[1].status, 'UNMAPPED');
assert.equal(failedState.mappings[2].status, 'MAPPED');
applyAutoMap(failedState, failedResponse);
assert.equal(preserved.sourceColumn, 'old.NAME');
console.log('Mixed Auto-map failure preserves mapped expressions, clears processing, and applies successful targets idempotently.');

const pagePath = path.resolve(__dirname, '../src/app/sttm/builder/new/mapping/page.tsx');
const page = ts.createSourceFile(pagePath, fs.readFileSync(pagePath, 'utf8'), ts.ScriptTarget.Latest, true);
const pageText = page.getFullText();
assert.doesNotMatch(pageText, /lastAutomaticCompileHash|setAutoCompile/);
assert.match(pageText, /buildWorkingMappingSql\(\{mappings, sourceQuerySql: resolvedSourceQuerySql/);
assert.match(pageText, /generatedSql=\{generatedEditorSql\}/);
console.log('Workspace SQL is generated from live inputs without automatic compile.');

const reducers = {};
let captureSource, cloneSource;
function visitManual(node) {
  if (ts.isFunctionDeclaration(node)) {
    if (node.name?.text === 'captureManualEditSnapshot') captureSource = node.getText(slice);
    if (node.name?.text === 'cloneMappingSnapshot') cloneSource = node.getText(slice);
  }
  if (ts.isPropertyAssignment(node) && ['updateMapping', 'commitPendingManualMappingEdits', 'cancelPendingManualMappingEdits'].includes(node.name.getText(slice))) {
    reducers[node.name.getText(slice)] = node.initializer.getText(slice);
  }
  ts.forEachChild(node, visitManual);
}
visitManual(slice);
const manual = compile(slicePath, `${cloneSource}\n${captureSource}\nmodule.exports = {
  update: ${reducers.updateMapping},
  capture: captureManualEditSnapshot, save: ${reducers.commitPendingManualMappingEdits}, cancel: ${reducers.cancelPendingManualMappingEdits}
};`);
const approved = {id:'manual', targetColumn:'NAME', sourceColumns:['a.NAME'], expression:'a.NAME', status:'MAPPED', manuallySaved:true};
const manualState = {mappings:[{...approved}], pendingManualEditSnapshots:{}, selectedMappingIds:[], autoMapBlockedByManualEdits:false};
manual.capture(manualState, manualState.mappings[0]);
manualState.mappings[0].expression = 'TRIM(a.NAME)';
assert.equal(manualState.mappings[0].manuallySaved, false);
assert.equal(manualState.pendingManualEditSnapshots.manual.manuallySaved, true);
assert.equal(manualState.pendingManualEditSnapshots.manual.expression, 'a.NAME');
manual.cancel(manualState);
assert.equal(manualState.mappings[0].manuallySaved, true);
assert.equal(manualState.mappings[0].expression, 'a.NAME');
manual.capture(manualState, manualState.mappings[0]);
manualState.mappings[0].expression = 'TRIM(a.NAME)';
manual.save(manualState);
assert.equal(manualState.mappings[0].manuallySaved, true);
assert.equal(manualState.mappings[0].expression, 'TRIM(a.NAME)');
assert.deepEqual(manualState.pendingManualEditSnapshots, {});
console.log('Manual edit clears acceptance until Save; Cancel restores the prior accepted decision.');

const authored = load(path.resolve(__dirname,'../src/features/sttm/mapping/authored-sql-key.ts'));
const {selectMappingSqlArtifact} = load(path.resolve(__dirname,'../src/features/sttm/mapping/mapping-sql-artifact.ts'));
const {produce} = require('immer');
const getMappingSqlArtifact = state => selectMappingSqlArtifact({authoredSql:state.mappingSql,
  authoredIsCurrent:authored.authoredSqlIsCurrent(state.mappingSql,state.authoredSqlSemanticKey,state),
  fallbackSql:'new draft',fallbackPreviewSql:'new draft'});
for (const [before,after] of [["'a  b'","'a b'"],["'O''Brien  x'","'O''Brien x'"],
  ['a."two  spaces"','a."two spaces"'],['a.ID -- comment\n + 1','a.ID -- comment + 1'],
  ['a."lower"','a."LOWER"']]) {
  let current={...manualState,sources:[],targets:[],derivedSources:[],relationships:[],pendingManualEditSnapshots:{},
    mappings:[{...approved,expression:before}],mappingSql:`SELECT ${before} AS NAME`};
  current.authoredSqlSemanticKey=authored.computeAuthoredSqlSemanticKey(current);
  assert.match(current.authoredSqlSemanticKey,/^ask3:/);
  assert.equal(getMappingSqlArtifact(current).source,'authored');
  current=produce(current,draft=>manual.update(draft,{payload:{id:'manual',updates:{expression:after}}}));
  current=produce(current,draft=>manual.save(draft));
  assert.deepEqual(current.pendingManualEditSnapshots,{});
  assert.equal(current.mappings[0].expression,after);
  assert.notEqual(getMappingSqlArtifact(current).source,'authored');
  assert.notEqual(getMappingSqlArtifact(current).scriptSql,current.mappingSql);
  for(const key of [null,'ask1:1b3dc9ff:4o','ask2:1b3dc9ff:4o']) {
    assert.equal(authored.authoredSqlIsCurrent(current.mappingSql,key,current),false);
  }
}
for(const field of ['sources','targets']) {
  const input={sources:[],targets:[],derivedSources:[],relationships:[],mappings:[]};
  const key=name=>authored.computeAuthoredSqlSemanticKey({...input,[field]:[{isSelected:true,qualifiedName:name}]});
  assert.equal(key('db.schema.table'),key('DB.SCHEMA.TABLE'));
  assert.notEqual(key('DB.SCHEMA."lower"'),key('DB.SCHEMA."LOWER"'));
}
console.log('Real Immer edit/commit invalidates exact literal, escaped quote, quoted identifier and comment newline SQL; legacy keys fail closed.');
const imported = (name, index = 0) => ({
  ...blank(name, `upload:${name}:${index}`), targetSqlName: `"${name}"`,
  status: 'MAPPED', sourceColumn: 'S.VALUE', expression: 'UPPER(S.VALUE)',
});
const catalog = [{...blank('TargetColumn'), targetType: 'VARCHAR'}];
const fromSql = imported('xxxTargetColumn');
const resolve = (rows, columns = catalog) => reconcileUploadedTargets(rows, columns, row => !!row.sourceColumn);
const corrected = resolve([fromSql, blank('TargetColumn'), imported('UnknownAlias')]);
assert.equal(corrected.length, 1);
assert.equal(corrected[0].targetColumn, 'TargetColumn');
assert.equal(corrected[0].targetSqlName, undefined);
assert.equal(corrected[0].expression, 'UPPER(S.VALUE)');
assert.equal(corrected[0].targetType, 'VARCHAR');
const exact = imported('TargetColumn');
assert.deepEqual(resolve([fromSql, exact]), [exact]);
assert.equal(resolve([fromSql], [blank('TARGETCOLUMN')])[0].targetColumn, 'TARGETCOLUMN');
assert.deepEqual(resolve([fromSql], [...catalog, blank('TARGETCOLUMN')]), []);
assert.deepEqual(resolve([fromSql, imported('xxxTargetColumn', 1)]), []);
const edited = {...blank('TargetColumn'), sourceColumn: 'S.MANUAL'};
assert.deepEqual(resolve([fromSql, edited]), [edited]);
const openedUpload = {
  targets: [{qualifiedName:'D.S.TARGET', isSelected:true}],
  targetAttributeGroup: {qualifiedName:'D.S.TARGET'},
  mappings: [fromSql, imported('UnknownAlias')],
  selectedMappingIds: [fromSql.id, 'upload:UnknownAlias:0'],
};
ensure(openedUpload, {payload:catalog});
assert.deepEqual(openedUpload.mappings.map(row => row.targetColumn), ['TargetColumn']);
assert.deepEqual(openedUpload.selectedMappingIds, [fromSql.id]);
