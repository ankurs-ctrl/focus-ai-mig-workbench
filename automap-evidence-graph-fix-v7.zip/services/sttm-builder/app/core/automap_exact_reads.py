"""Identical local exact-read hydration for Auto-map preflight and workers."""
from app.core.automap_retrieval import encoded


class ExactReadBudgetError(ValueError):
    pass


def initial_operations(store, plan):
    return [operation for target in store.targets
            for operation in store.required_operations(target, {"source_attributes": []})] + list(plan.read_operations)


def read_operations(store, operations, *, settings, results, events, operation_count=0, remaining, strict=True, counter=None):
    counter = counter if counter is not None else {"count": operation_count}
    pending = list({encoded(operation): operation for operation in operations}.values())
    page_bytes = min(32768, settings.agent_outbound_message_max_bytes // 4)
    while pending:
        if remaining() <= 0:
            raise ExactReadBudgetError("Batch reasoning time expired; incomplete evidence was not accepted")
        if operation_count + len(pending) > settings.automap_context_max_operations:
            raise ExactReadBudgetError("Batch exact-retrieval operation limit reached")
        pending = [operation for operation in pending if not any(
            item.get("request") == {key: value for key, value in operation.items() if key != "cursor"}
            and not item.get("result", {}).get("error") for item in results)]
        if not pending:
            break
        chunk, pending = pending[:24], pending[24:]
        operation_count += len(chunk)
        counter["count"] = operation_count
        response = store.read_many({"tool": "AUTO_MAP_CONTEXT", "snapshot_hash": store.snapshot_hash,
            "operation": "multi_read", "reads": chunk}, max_bytes=page_bytes,
            max_total_bytes=settings.agent_outbound_message_max_bytes)
        for item in response["results"]:
            result, operation = item["result"], item["request"]
            exact_operation = {key: value for key, value in operation.items() if key != "cursor"}
            if not result.get("next_cursor") and not result.get("error"):
                key = encoded(exact_operation)
                if not any(previous.get("read_key") == key for previous in results):
                    results.append({"read_key": key, "request": exact_operation,
                                    "result": store.exact_completed_result(exact_operation)})
            elif result.get("error"):
                if strict:
                    raise ValueError("Exact evidence hydration failed")
                results.append(item)
            events.append({**operation, "error": result.get("error"), "page": result.get("page"),
                           "page_count": result.get("page_count")})
            if result.get("next_cursor"):
                pending.append({**operation, "cursor": result["next_cursor"]})
    return operation_count
