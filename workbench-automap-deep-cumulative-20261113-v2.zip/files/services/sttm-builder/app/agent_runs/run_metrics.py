"""Deterministic run metrics derived from a durable run's persisted events.

The same summary backs the end-to-end harness and any later diagnostics
surface, so baseline and post-change numbers are always computed the same way.
Inputs are the JSON shapes returned by the agent-runs API (or model dumps).
"""
from __future__ import annotations

import re
from collections import Counter
from datetime import datetime
from typing import Any, Iterable, Mapping

_CONTRACT_READ = re.compile(r"^Reading the contract for\s+(?P<table>[^\s]+?)\.?$", re.I)
_CONTRACT_BATCH_READ = re.compile(r"^Reading the contracts for \d+ tables", re.I)
_CONTRACT_CONFIRM = re.compile(r"^Confirming \d+ table contracts", re.I)
# A run segment begins whenever a worker (re)starts executing the durable run.
_SEGMENT_START = {"run.started", "run.resumed.execution"}


def _field(item: Any, name: str, default: Any = None) -> Any:
    if isinstance(item, Mapping):
        return item.get(name, default)
    return getattr(item, name, default)


def _timestamp(value: Any) -> datetime | None:
    if isinstance(value, datetime):
        return value
    if not value:
        return None
    text = str(value).replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(text)
    except ValueError:
        return None


def _seconds(start: datetime | None, end: datetime | None) -> float:
    if start is None or end is None:
        return 0.0
    return max(0.0, (end - start).total_seconds())


def _details_tables(event: Any) -> list[str]:
    data = _field(event, "data") or {}
    details = data.get("details") if isinstance(data, Mapping) else None
    tables = details.get("tables") if isinstance(details, Mapping) else None
    return [str(value).upper() for value in tables] if isinstance(tables, list) else []


def contract_read_tables(event: Any) -> list[str]:
    """Tables a contract-read trace action reads from Snowflake (single or batch)."""
    if _field(event, "event_type") != "trace.action.started":
        return []
    summary = str(_field(event, "safe_summary") or "").strip()
    if _CONTRACT_BATCH_READ.match(summary):
        return _details_tables(event)
    match = _CONTRACT_READ.match(summary)
    if not match:
        return []
    data = _field(event, "data") or {}
    structured = data.get("table_fqn") or data.get("table") if isinstance(data, Mapping) else None
    return [str(structured or match.group("table")).upper()]


def contract_revalidation_tables(event: Any) -> list[str]:
    """Stored contracts confirmed against the live catalog without re-reading them."""
    if _field(event, "event_type") != "trace.action.started":
        return []
    if not _CONTRACT_CONFIRM.match(str(_field(event, "safe_summary") or "").strip()):
        return []
    return _details_tables(event)


def contract_read_table(event: Any) -> str | None:
    """Return the table a single-table contract read refers to, if any."""
    tables = contract_read_tables(event)
    return tables[0] if len(tables) == 1 else None


def _ordered(events: Iterable[Any]) -> list[Any]:
    return sorted(events, key=lambda event: int(_field(event, "sequence") or 0))


def segment_events(events: Iterable[Any]) -> list[list[Any]]:
    """Split events into execution segments (initial start plus each resume)."""
    segments: list[list[Any]] = [[]]
    for event in _ordered(events):
        if _field(event, "event_type") in _SEGMENT_START and segments[-1] and any(
            _field(item, "event_type") in _SEGMENT_START for item in segments[-1]
        ):
            segments.append([])
        segments[-1].append(event)
    return [segment for segment in segments if segment]


def question_wait_intervals(events: Iterable[Any]) -> list[dict[str, Any]]:
    """Pair each question with the answer that released it."""
    intervals: list[dict[str, Any]] = []
    pending: list[Any] = []
    for event in _ordered(events):
        event_type = _field(event, "event_type")
        if event_type == "run.question.required":
            pending.append(event)
        elif event_type == "run.question.answered" and pending:
            asked = pending.pop(0)
            answered_at = _timestamp(_field(event, "created_at"))
            asked_at = _timestamp(_field(asked, "created_at"))
            intervals.append({
                "question": str(_field(asked, "safe_summary") or ""),
                "asked_sequence": int(_field(asked, "sequence") or 0),
                "answered_sequence": int(_field(event, "sequence") or 0),
                "wait_seconds": _seconds(asked_at, answered_at),
            })
    for asked in pending:
        intervals.append({
            "question": str(_field(asked, "safe_summary") or ""),
            "asked_sequence": int(_field(asked, "sequence") or 0),
            "answered_sequence": None,
            "wait_seconds": None,
        })
    return intervals


def _segment_summary(segment: list[Any]) -> dict[str, Any]:
    counts = Counter(str(_field(event, "event_type") or "") for event in segment)
    contract_tables = [table for event in segment for table in contract_read_tables(event)]
    first = _timestamp(_field(segment[0], "created_at"))
    last = _timestamp(_field(segment[-1], "created_at"))
    seconds = _seconds(first, last)
    # A question raised at the end of a segment is answered before the next
    # resume starts; that interval is user time, not agent work.
    waiting = sum(item["wait_seconds"] or 0.0 for item in question_wait_intervals(segment))
    return {
        "first_sequence": int(_field(segment[0], "sequence") or 0),
        "last_sequence": int(_field(segment[-1], "sequence") or 0),
        "seconds": seconds,
        "waiting_seconds": waiting,
        "active_seconds": max(0.0, seconds - waiting),
        "model_calls": counts.get("model.started", 0),
        "tool_calls": counts.get("tool.started", 0),
        "tool_failures": counts.get("tool.failed", 0),
        "tool_reuses": counts.get("tool.reused", 0),
        "contract_reads": len(contract_tables),
        "contract_read_queries": sum(1 for event in segment if contract_read_tables(event)),
        "distinct_contract_tables": len(set(contract_tables)),
        "revalidated_contracts": sum(len(contract_revalidation_tables(event)) for event in segment),
    }


def summarize_run(
    run: Any,
    events: Iterable[Any],
    review_items: Iterable[Any] = (),
) -> dict[str, Any]:
    """Compute timing, question, re-read and outcome metrics for one run."""
    ordered = _ordered(events)
    items = list(review_items)
    counts = Counter(str(_field(event, "event_type") or "") for event in ordered)
    first_at = _timestamp(_field(ordered[0], "created_at")) if ordered else None
    last_at = _timestamp(_field(ordered[-1], "created_at")) if ordered else None
    waits = question_wait_intervals(ordered)
    waiting = sum(item["wait_seconds"] or 0.0 for item in waits)
    wall = _seconds(first_at, last_at)

    reads_by_table: Counter[str] = Counter()
    segments_by_table: dict[str, set[int]] = {}
    segments = segment_events(ordered)
    for index, segment in enumerate(segments):
        for event in segment:
            for table in contract_read_tables(event):
                reads_by_table[table] += 1
                segments_by_table.setdefault(table, set()).add(index)

    question_categories = Counter(str(_field(item, "category") or "unknown") for item in items)
    open_items = [item for item in items if str(_field(item, "status") or "").upper() == "OPEN"]
    manifest = list(_field(run, "mapping_manifest") or [])
    project_ids = sorted({str(_field(event, "project_id")) for event in ordered if _field(event, "project_id")})
    sttm_ids = sorted({str(_field(event, "sttm_id")) for event in ordered if _field(event, "sttm_id")})

    status = _field(run, "status")
    return {
        "run_id": _field(run, "run_id"),
        "status": getattr(status, "value", status),
        "error_code": _field(run, "error_code"),
        "project_id": _field(run, "project_id") or (project_ids[0] if project_ids else None),
        "sttm_ids": sttm_ids,
        "timing": {
            "wall_seconds": wall,
            "waiting_on_user_seconds": waiting,
            "active_seconds": max(0.0, wall - waiting),
            "recorded_elapsed_seconds": float(_field(run, "elapsed_seconds_used") or 0.0),
        },
        "usage": {
            "model_calls_used": int(_field(run, "model_calls_used") or 0),
            "tool_calls_used": int(_field(run, "tool_calls_used") or 0),
            "specialist_calls_used": int(_field(run, "specialist_calls_used") or 0),
            "cache_hits": int(_field(run, "cache_hits") or 0),
            "category_usage": dict(_field(run, "category_usage") or {}),
        },
        "events": {
            "total": len(ordered),
            "model_started": counts.get("model.started", 0),
            "tool_started": counts.get("tool.started", 0),
            "tool_failed": counts.get("tool.failed", 0),
            "tool_reused": counts.get("tool.reused", 0),
            "by_type": dict(sorted(counts.items())),
        },
        "questions": {
            "asked": counts.get("run.question.required", 0),
            "answered": counts.get("run.question.answered", 0),
            "review_items_total": len(items),
            "review_items_open": len(open_items),
            "by_category": dict(sorted(question_categories.items())),
            "waits": waits,
        },
        "contract_reads": {
            "total": sum(reads_by_table.values()),
            "queries": sum(1 for event in ordered if contract_read_tables(event)),
            "distinct_tables": len(reads_by_table),
            "redundant_reads": sum(count - 1 for count in reads_by_table.values()),
            "tables_reread_across_segments": sorted(
                table for table, indexes in segments_by_table.items() if len(indexes) > 1
            ),
            "revalidated_tables": sum(len(contract_revalidation_tables(event)) for event in ordered),
            "revalidation_queries": sum(1 for event in ordered if contract_revalidation_tables(event)),
        },
        "knowledge_reuses": sum(1 for event in ordered if _field(event, "event_type") == "tool.reused"
                                and dict(_field(event, "data") or {}).get("reuse_scope") == "conversation"),
        "segments": [_segment_summary(segment) for segment in segments],
        "resumes": counts.get("run.resumed.execution", 0),
        "mappings": {
            "requested": len(manifest),
            "by_status": dict(sorted(Counter(
                str(_field(item, "status") or "UNKNOWN").upper() for item in manifest
            ).items())),
        },
    }
