from threading import RLock
from types import SimpleNamespace

import pytest

from app.agent_tools.workbench import WorkbenchWorkflowHandlers
from app.agent_tools import relationship_graph as graph


@pytest.mark.parametrize('coverage,unique,expected', [(1, True, 'succeeded'), (.4, True, 'needs_input'), (1, False, 'needs_input')])
def test_proposed_join_requires_current_coverage_and_unique_parent(monkeypatch, coverage, unique, expected):
    handler = object.__new__(WorkbenchWorkflowHandlers)
    handler._domain_lock = RLock()
    handler._session = SimpleNamespace(sql=lambda *a, **k: None)
    handler._setting = lambda name, default: default
    handler._tool = lambda name: None
    handler._describe_tables = lambda tables: {'DB.S.CHILD': {'columns':['PARENT_ID']}, 'DB.S.PARENT': {'columns':['ID']}}
    edge = graph.RelationshipEdge('DB.S.CHILD', 'PARENT_ID', 'DB.S.PARENT', 'ID')

    def verify(*args, **kwargs):
        checked = args[1][0]
        assert checked.child_table == 'DB.S.CHILD' and checked.parent_table == 'DB.S.PARENT'
        checked.verification = {'status': 'verified', 'coverage': coverage, 'parent_key_unique': unique}
        return 1
    monkeypatch.setattr(graph, 'verify_edges', verify)
    result = handler.verify_proposed_relationships(['DB.S.CHILD', 'DB.S.PARENT'], [{'left_table':'DB.S.CHILD', 'right_table':'DB.S.PARENT', 'conditions':[{'left_column':'PARENT_ID','right_column':'ID'}]}])
    assert result.status == expected
    assert result.data['queries'] == 1
    assert result.data['relationships'][0]['verification']['parent_key_unique'] is unique


def test_proposed_join_outside_selected_sources_never_queries_workbench():
    from app.agent_runtime.execution import ExecutionBudget
    from app.agent_tools.capability_registry import CapabilityRegistry
    called = []
    context = {'authorized_schemas': ['DB.S'], 'authorized_source_scope': ['DB.S.CHILD', 'DB.S.PARENT']}
    registry = CapabilityRegistry(context_provider=lambda: context, workflow_executor=lambda *a: {},
        workbench=SimpleNamespace(verify_proposed_relationships=lambda *a: called.append(a)),
        budget=ExecutionBudget(model_limit=5, tool_limit=5))
    registry._prepared_plan_candidate = {'source_preparation': {'driving_source': 'DB.S.CHILD',
                                                               'supporting_sources': ['DB.S.PARENT']}}
    tool = next(tool for tool in registry.tools() if tool.name == 'verify_proposed_relationships')
    result = tool.invoke({'relationships': [{'left_table': 'DB.S.CHILD', 'right_table': 'OTHER.S.PARENT',
        'conditions': [{'left_column': 'PARENT_ID', 'right_column': 'ID', 'operator': '='}]}]})
    assert result['status'] in {'denied', 'needs_input'}
    assert called == []


def test_verified_join_research_can_precede_preparation_without_staging_a_plan():
    from app.agent_runtime.execution import ExecutionBudget
    from app.agent_tools.capability_registry import CapabilityRegistry
    from app.agent_runs.models import ToolResult
    joins = [{'left_table':'DB.S.CHILD','right_table':'DB.S.PARENT','join_type':'LEFT',
              'conditions':[{'left_column':'PARENT_ID','right_column':'ID','operator':'='}]}]
    calls=[]
    def verify(tables, relationships):
        calls.append((tables, relationships))
        return ToolResult(status='succeeded',summary='Verified',data={'relationships':joins})
    registry=CapabilityRegistry(context_provider=lambda:{},workflow_executor=lambda *a:{},
        workbench=SimpleNamespace(verify_proposed_relationships=verify),budget=ExecutionBudget(model_limit=5,tool_limit=10))
    registry._catalog_candidates.update(['DB.S.CHILD','DB.S.PARENT'])
    registry._inspected_contracts.update(['DB.S.CHILD','DB.S.PARENT'])
    tool=next(t for t in registry.tools() if t.name=='verify_proposed_relationships')
    result=tool.invoke({'relationships':joins})
    assert result['status']=='succeeded'
    assert len(calls)==1
    assert registry._prepared_plan_candidate is None
    assert registry._verified_proposed_relationships==joins
    assert result['data']['next_action']=='prepare_migration_evidence_with_the_chosen_sources'


def test_table_ref_normalization_preserves_literal_case_and_component_boundaries():
    from app.agent_tools.contract_reader import normalize_fqn
    assert normalize_fqn({'database':'DB','schema':'S','table':'T'}) == 'DB.S.T'
    assert normalize_fqn({'database':'DB','schema':'S','table':'Mixed.Table'}) == 'DB.S."Mixed.Table"'
    assert normalize_fqn({'database':'DB','schema':'S'}) == ''


def test_declared_driving_cte_normalizes_without_becoming_a_physical_authorization():
    from copy import deepcopy
    from app.agent_tools.capability_registry import _normalize_source_preparation
    source={'driving_source':'PARSED_CENTS','derived_sources':[{'name':'PARSED_CENTS','sql':'SELECT * FROM DB.S.T',
        'base_source_tables':[{'database':'DB','schema':'S','table':'T'}]}]}
    original=deepcopy(source)
    result=_normalize_source_preparation(source)
    assert result['driving_source']=='DB.S.T'
    assert result['derived_sources'][0]['is_driving_source'] is True
    assert source==original
    source['derived_sources'][0]['base_source_tables'].append({'database':'DB','schema':'S','table':'U'})
    assert _normalize_source_preparation(source)['driving_source']=='PARSED_CENTS'
    assert _normalize_source_preparation(source,prepared_driver='DB.S.T')['driving_source']=='DB.S.T'
    source['derived_sources'][0]['sql']=''
    assert _normalize_source_preparation(source,prepared_driver='DB.S.T')['driving_source']=='PARSED_CENTS'


def test_declared_cte_output_counts_as_scoped_proposal_without_wildcard_guessing():
    from app.agent_tools.source_readiness import declared_derived_bindings
    definitions=[{'name':'PARSED_CENTS','sql':'SELECT t.*, TRY_TO_NUMBER(t.TOTAL_AMOUNT_CENTS) AS NUMERIC_CENTS FROM DB.S.T t'}]
    outputs=declared_derived_bindings(definitions,{'DB.S.T'})
    assert outputs=={'PARSED_CENTS.NUMERIC_CENTS'}
    assert 'PARSED_CENTS.UNKNOWN' not in outputs
    definitions[0]['sql']='SELECT SECRET AS NUMERIC_CENTS FROM OTHER.S.T'
    with pytest.raises(PermissionError):declared_derived_bindings(definitions,{'DB.S.T'})
    definitions[0]['sql']='DELETE FROM DB.S.T'
    with pytest.raises(ValueError):declared_derived_bindings(definitions,{'DB.S.T'})


def test_proposal_scope_preserves_cte_outputs_quoted_case_and_ambiguous_tables():
    from app.agent_tools.source_readiness import proposal_reference_in_scope
    tables={'DB.S.T','DB.U.T','DB.S."Mixed.Table"'}
    assert proposal_reference_in_scope('DB.S.T.ID',tables,set())
    assert not proposal_reference_in_scope('T.ID',tables,set())
    assert not proposal_reference_in_scope('ID',tables,set())
    assert proposal_reference_in_scope('DB.S."Mixed.Table"."MixedColumn"',tables,set())
    assert not proposal_reference_in_scope('DB.S."mixed.table".ID',tables,set())
    assert proposal_reference_in_scope('C.NUMERIC_CENTS',tables,{'C.NUMERIC_CENTS'})
    assert not proposal_reference_in_scope('C.UNKNOWN',tables,{'C.NUMERIC_CENTS'})
    assert proposal_reference_in_scope('src:DB.S.T.ID',tables,set())
    assert not proposal_reference_in_scope('src:OTHER.S.T.ID',tables,set())


def test_current_verified_columns_expand_only_real_cte_wildcard_outputs():
    from app.agent_tools.source_readiness import declared_derived_bindings,proposal_reference_in_scope
    definition={'name':'PARSED','id':'cte_current','alias':'parsed_current',
                'sql':'SELECT t.*, TRY_TO_NUMBER(t.CENTS) AS AMOUNT FROM DB.S.T t'}
    columns={'DB.S.T':{'ID':'NUMBER','AUTO_CALCULATED':'VARCHAR','CENTS':'VARCHAR'}}
    outputs=declared_derived_bindings([definition],{'DB.S.T'},verified_source_columns=columns)
    assert 'PARSED.AUTO_CALCULATED' in outputs
    assert proposal_reference_in_scope('parsed_current.AUTO_CALCULATED',{'DB.S.T'},outputs)
    assert not proposal_reference_in_scope('PARSED.INVENTED',{'DB.S.T'},outputs)
    assert 'PARSED.AUTO_CALCULATED' not in declared_derived_bindings([definition],{'DB.S.T'})


def test_plan_proposals_resolve_current_alias_and_citation_without_foreign_rebinding():
    from app.agent_tools.source_readiness import resolve_proposal_reference
    from app.core.workspace_snapshot import relation_alias_for
    table='DB.S.NOTE';alias=relation_alias_for(table)
    assert resolve_proposal_reference(alias+'.ACTIVITY',{table},set())==table+'.ACTIVITY'
    assert resolve_proposal_reference('src:'+alias+'.ACTIVITY',{table},set())==table+'.ACTIVITY'
    assert resolve_proposal_reference('src:foreign.ACTIVITY',{table},set()) is None
    assert resolve_proposal_reference('NOTE.ID',{'DB.S.NOTE','DB.OTHER.NOTE'},set()) is None
