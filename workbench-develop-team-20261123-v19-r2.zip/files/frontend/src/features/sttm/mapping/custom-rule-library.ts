export type LibraryRuleRef = {
  rule_id: string;
  rule_name: string;
  expression: string;
  version: number;
};

export function customRuleSqlKey(expression: string): string {
  return expression.replace(/\s+/g, " ").trim();
}

export function matchingLibraryRule<T extends LibraryRuleRef>(
  rules: T[],
  expression: string,
): T | null {
  const key = customRuleSqlKey(expression);
  if (!key) return null;
  return rules.find((rule) => customRuleSqlKey(rule.expression) === key) ?? null;
}

/** The rule the user clicked, even after they edit its SQL. Falls back to an exact SQL match. */
export function libraryRuleForSave<T extends LibraryRuleRef>(
  rules: T[],
  expression: string,
  selectedRuleId: string | null,
): T | null {
  if (selectedRuleId) {
    const selected = rules.find((rule) => rule.rule_id === selectedRuleId);
    if (selected) return selected;
  }
  return matchingLibraryRule(rules, expression);
}

const DOTTED_COLUMN_REF = /[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)+/g;

/** Removes whole `table.COLUMN` tokens. The rest of the SQL, including function names, stays. */
export function removeDottedColumnTokens(
  expression: string,
  shouldRemove: (token: string) => boolean,
): string {
  return expression
    .replace(DOTTED_COLUMN_REF, (token) => (shouldRemove(token) ? "" : token))
    .replace(/[ \t]{2,}/g, " ")
    .replace(/\(\s+/g, "(")
    .replace(/\s+\)/g, ")")
    .trim();
}

export function columnRefsInExpression(expression: string): string[] {
  const matches = expression.match(/\b[A-Za-z_][A-Za-z0-9_]*\.[A-Za-z_][A-Za-z0-9_]*\b/g) ?? [];
  return [...new Set(matches.map((item) => item.toUpperCase()))];
}

export function missingLibraryColumns(expression: string, available: string[]): string[] {
  const known = new Set(available.map((item) => item.toUpperCase()));
  return columnRefsInExpression(expression).filter((item) => !known.has(item));
}
