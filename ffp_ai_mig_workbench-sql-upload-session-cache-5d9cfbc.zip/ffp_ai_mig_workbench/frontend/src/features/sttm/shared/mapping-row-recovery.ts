import type { MappingState } from '@/features/sttm/types/sttm.types';
import { sqlIdentifierSuffixMatches } from '@/features/sttm/shared/sql-identifiers';

/** Append target placeholders without replacing saved rows or accepting old AI results. */
export function missingTargetMappings(existing: MappingState[], targets: MappingState[]): MappingState[] {
  const seenIds = new Set(existing.map(row => row.id));
  const rows = [...existing];
  const missing: MappingState[] = [];
  for (const target of targets) {
    if (rows.some(row => row.targetColumn === target.targetColumn
      || sqlIdentifierSuffixMatches(row.targetColumn, target.targetColumn))) continue;
    let id = target.id;
    let suffix = 1;
    while (seenIds.has(id)) id = `${target.id}:missing:${suffix++}`;
    const row = {...target, id};
    missing.push(row);
    rows.push(row);
    seenIds.add(id);
  }
  return missing;
}

export function savedMappingEvidence(row: Record<string, unknown>) {
  const strings = (lower: string, upper: string) => {
    const value = row[lower] ?? row[upper];
    return Array.isArray(value) ? value.map(String) : [];
  };
  return {
    unmatchedReason: (row.unmatched_reason ?? row.UNMATCHED_REASON ?? null) as string | null,
    candidateSourceColumns: strings('candidate_source_attributes', 'CANDIDATE_SOURCE_ATTRIBUTES'),
    usedInferenceIds: strings('used_inference_ids', 'USED_INFERENCE_IDS'),
    usedRecommendationIds: strings('used_recommendation_ids', 'USED_RECOMMENDATION_IDS'),
    usedLearningIds: strings('used_learning_ids', 'USED_LEARNING_IDS'),
  };
}

/** Legacy reopen may already have dropped row reasons; show the saved run as diagnostics only. */
export function savedRunBlockers(rows: MappingState[], outcome: Record<string, unknown> | null): string[] {
  const unresolved = rows.filter(row => row.status !== 'MAPPED' && row.transformationClassification === 'unresolved');
  const mappings = outcome?.mappings;
  if (!mappings || typeof mappings !== 'object' || Array.isArray(mappings)) return [];
  return Array.from(new Set(Object.entries(mappings).flatMap(([target, value]) => {
    if (!unresolved.some(row => row.targetColumn === target || sqlIdentifierSuffixMatches(target, row.targetColumn))) return [];
    if (!value || typeof value !== 'object') return [];
    const reason = (value as Record<string, unknown>).unmatched_reason;
    return typeof reason === 'string' && reason ? [reason] : [];
  })));
}