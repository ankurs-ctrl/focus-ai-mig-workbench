param(
    [string]$EnvFile = "",
    [switch]$ForceRecreate
)

$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "common.ps1")

if (-not $EnvFile) {
    $EnvFile = Get-DefaultEnvFile
}

$snowExe = Ensure-SnowInstalled
$cfg = Import-DemoEnv -Path $EnvFile

Require-ConfigValues -Config $cfg -RequiredKeys @(
    "SNOWFLAKE_CONNECTION",
    "SNOWFLAKE_ACCOUNT",
    "SNOWFLAKE_USER",
    "SNOWFLAKE_ROLE",
    "SNOWFLAKE_WAREHOUSE",
    "SNOWFLAKE_DATABASE",
    "SNOWFLAKE_SCHEMA"
) -EnvFile $EnvFile

$authenticator = if ($cfg.ContainsKey("SNOWFLAKE_AUTHENTICATOR") -and $cfg["SNOWFLAKE_AUTHENTICATOR"]) {
    $cfg["SNOWFLAKE_AUTHENTICATOR"]
} else {
    "externalbrowser"
}

try {
    & $snowExe connection test -c $cfg["SNOWFLAKE_CONNECTION"] *> $null
    if ($LASTEXITCODE -eq 0 -and -not $ForceRecreate) {
        Write-Host "Snow connection '$($cfg["SNOWFLAKE_CONNECTION"])' already works. Reusing it."
        exit 0
    }
} catch {
}

if ($ForceRecreate) {
    try {
        & $snowExe connection remove $cfg["SNOWFLAKE_CONNECTION"] --format TABLE
    } catch {
    }
} else {
    try {
        & $snowExe connection remove $cfg["SNOWFLAKE_CONNECTION"] --format TABLE *> $null
    } catch {
    }
}

Write-Host "Creating Snow CLI connection '$($cfg["SNOWFLAKE_CONNECTION"])'"
& $snowExe connection add `
    --connection-name $cfg["SNOWFLAKE_CONNECTION"] `
    --account $cfg["SNOWFLAKE_ACCOUNT"] `
    --user $cfg["SNOWFLAKE_USER"] `
    --role $cfg["SNOWFLAKE_ROLE"] `
    --warehouse $cfg["SNOWFLAKE_WAREHOUSE"] `
    --database $cfg["SNOWFLAKE_DATABASE"] `
    --schema $cfg["SNOWFLAKE_SCHEMA"] `
    --authenticator $authenticator `
    --default `
    --format TABLE

Write-Host ""
Write-Host "Testing connection '$($cfg["SNOWFLAKE_CONNECTION"])'"
& $snowExe connection test -c $cfg["SNOWFLAKE_CONNECTION"]
Write-Host ""
Write-Host "Connection configured successfully."
