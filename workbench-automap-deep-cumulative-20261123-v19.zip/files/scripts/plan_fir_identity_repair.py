"""Read-only repair proposal from exported rows and original published patterns.

Inputs are JSON arrays. --published must contain original patterns reconstructed
from published snapshots, not current draft rows. This tool deliberately has no
apply option: review the proposal and rollback records before authorizing DML.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

APP_ROOT = Path(__file__).resolve().parents[1] / "services" / "sttm-builder"
if str(APP_ROOT) not in sys.path:
    sys.path.insert(0, str(APP_ROOT))

from app.core.mapping_contracts import optional_identifier, published_expression
from app.core.target_mapping_patterns import reuse_key_for_payload


def _payload(row):
    value = row.get("PATTERN_PAYLOAD") or {}
    return json.loads(value) if isinstance(value, str) else value


def plan(rows: list[dict], published: list[dict]) -> list[dict]:
    by_id = {str(row["PATTERN_ID"]): row for row in rows}
    originals = {str(row["PATTERN_ID"]): row for row in published}
    proposals = []
    for pattern_id, row in by_id.items():
        payload = _payload(row)
        target = payload.get("target_contract") or {}
        replacement = by_id.get(str(row.get("SUPERSEDED_BY")))
        different_entity = bool(replacement and str(row.get("TARGET_TABLE", "")).rsplit(".", 1)[-1].upper()
                                != str(replacement.get("TARGET_TABLE", "")).rsplit(".", 1)[-1].upper())
        old_key = payload.get("reuse_key")
        new_key = reuse_key_for_payload(payload)
        null_identity = optional_identifier(target.get("logical_target_key")) is None
        original = originals.get(pattern_id)
        proven = bool(original and original.get("VALIDATION_STATUS") == "published"
                      and str(original.get("TARGET_TABLE", "")).upper() == str(row.get("TARGET_TABLE", "")).upper()
                      and str(original.get("TARGET_COLUMN") or (_payload(original).get("target_contract") or {}).get("target_column", "")).upper()
                          == str(row.get("TARGET_COLUMN") or target.get("target_column", "")).upper()
                      and optional_identifier(row.get("STTM_ID")) is not None
                      and str(original.get("STTM_ID")) == str(row.get("STTM_ID")))
        original_expression = published_expression({"expression": (_payload(original).get("mapping_recipe") or {}).get("expression")}) if proven else ""
        expression_lost = bool(original_expression and not published_expression(
            {"expression": (payload.get("mapping_recipe") or {}).get("expression")}))
        if not (null_identity and old_key != new_key) and not (expression_lost and proven):
            continue
        active = str(row.get("STATUS", "")).lower() == "active"
        can_restore = bool(proven and different_entity and null_identity and old_key
                           and old_key == _payload(replacement).get("reuse_key"))
        if not active and not can_restore:
            continue  # Preserve legitimate corrections and unexplained inactive rows.
        original_payload = json.loads(json.dumps(_payload(original) if can_restore else payload))
        if expression_lost:
            original_payload.setdefault("mapping_recipe", {})["expression"] = original_expression
        original_payload["target_contract"]["logical_target_key"] = optional_identifier(
            original_payload["target_contract"].get("logical_target_key")
        )
        repaired_key = reuse_key_for_payload(original_payload)
        original_payload["reuse_key"] = repaired_key
        support_key = f"sttm:{row['STTM_ID']}" if row.get("STTM_ID") else None
        support_keys = sorted(set(payload.get("support_keys") or []) | ({support_key} if support_key else set()))
        original_payload["support_keys"] = support_keys
        proposals.append({
            "pattern_id": pattern_id,
            "action": "restore_proven_cross_entity_supersession" if can_restore else "repair_identity",
            "old_reuse_key": old_key,
            "new_reuse_key": repaired_key,
            "proposed_payload": original_payload,
            "support_keys": support_keys,
            "support_count_requires_review": row.get("SUPPORT_COUNT") != len(support_keys),
            "restore_expression_from_published": bool(expression_lost and proven),
            "rollback_row": row,
            "requires_approval": True,
        })
    return proposals


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rows", type=Path, required=True, help="Export including inactive supersession chains")
    parser.add_argument("--published", type=Path, required=True, help="Reconstructed original published patterns")
    args = parser.parse_args()
    print(json.dumps(plan(json.loads(args.rows.read_text()), json.loads(args.published.read_text())), indent=2))


if __name__ == "__main__":
    main()