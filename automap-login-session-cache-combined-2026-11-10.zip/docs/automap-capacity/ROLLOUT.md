# Client rollout of durable Auto-map v2

This package contains application source and non-secret deployment profiles. Keep the client's existing `.env`, credentials, account settings, warehouse, instance settings and OAuth encryption key. The migration and commands below are for the client environment; they have not been executed there.

## 1. Quiesce legacy dispatchers

Drain/stop all old web and worker dispatchers, including other replicas and out-of-band callers. Record their retirement. A deployment job's concurrency setting is not proof that old processes cannot dispatch. Inventory the old pool; the generator intentionally accepts only FREE or QUARANTINED legacy rows. Active HELD work must be dealt with before migration.

The shipped UAT profile uses four legacy slots and twelve new execution slots plus four recovery slots. It points to the same configured archive and a distinct `TBL_AUTOMAP_CALL_ADMISSION_UAT_V2` table. Check the scope against the client's approved account/role before running anything. If the legacy inventory differs, inspect it and use the correct bounded legacy capacity; never delete rows to make validation pass.

## 2. Generate and review migration SQL

From the repository root:

```sh
python scripts/prepare_automap_durable_runs.py \
  --profile infra/snowflake/env/parallel.uat.durable-v2.json \
  --environment UAT --stage migrate \
  --legacy-table FFP_HDP_DLAB_MIG_WORKBENCH_DB_UAT.SCH_STTM_METADATA.TBL_AUTOMAP_CALL_ADMISSION_UAT \
  --legacy-capacity 4 --exclusive-deployment --retired-dispatchers \
  --out /tmp/automap-durable-migrate.sql
```

The flags attest actual completed quiescence; they do not terminate dispatchers. Execute the reviewed SQL through the client's authenticated deployment connection. Native account/database/schema/role guards must pass. The generator creates a new inventory, 64 short claim-control stripes and an append-only event table, then atomically copies uncertain legacy ownership and references into recovery slots. It never resets the old inventory. Repeat execution validates the existing new inventory without overwriting it.

The existing scoped archive must already exist. Verify native row/access policies and privileges for every runtime caller role: SELECT/UPDATE on the new pool and control table; INSERT on the event table; existing SELECT/INSERT on the scoped archive and durable job table permissions. Grant only through the client's established security process. The application and migration generator do not silently grant access. Operational discovery needs the web/worker service identity's existing metadata SELECT access to the pool and OAuth session references; provider and archive operations still execute as the authenticated caller. The encryption key and custom OAuth session table must be available after restart.

## 3. Validate and enable

```sh
python scripts/prepare_automap_durable_runs.py \
  --profile infra/snowflake/env/parallel.uat.durable-v2.json \
  --environment UAT --stage validate --out /tmp/automap-durable-validate.sql
```

Run that SQL with the client's approved connection. This stage is read-only and verifies that the protocol and event-table columns exist. Verify all sixteen pool rows, their epoch/fences/state, all 64 control stripes, the event table and archive permissions. Verify Cortex background runs, original-thread reads and cancellation are supported for the client's account and caller roles.

The UAT workflow uses repository variable `AUTOMAP_USE_DURABLE_V2=true` to select `parallel.uat.durable-v2.json`. Leave the legacy first-provisioning flag off. In v2 mode CI runs only the new read-only inventory validator; it does not execute migration. The profile enables durable jobs/background runs, twelve concurrent application calls, four recovery reservations, a 330-second run budget, a 600-second batch budget and a separate 900-second admission queue limit. Six caller control sessions per purpose are independent of the twelve model reservations; recovery has its own two-session bound.

Use the existing deployment wrapper for an offline render check with the approved env file:

```powershell
./scripts/deploy_parallel_automap.ps1 -Environment UAT -EnvFile <existing-approved-env> -ImageTag <release-tag> -ProfileFile infra/snowflake/env/parallel.uat.durable-v2.json -ValidateOnly
```

Deployment must update web and worker together with the same profile and new inventory. Keep five SPCS instances initially unless client measurements justify another count; twelve reservations are shared globally across replicas, not multiplied per replica. The JSON legacy profile remains available for deliberate rollback.

## 4. Client acceptance

Verify a selected-target Auto-map, a full mapping, existing human definitions and publish validation. Observe actual model POSTs and calls that reach the model; do not infer dispatch from a UI progress message. Confirm a fresh job starts with four old quarantines present and available execution capacity. Confirm twelve reservations under concurrency and that repeated quarantine never grows outstanding calls above sixteen.

Restart web/worker while a background operation exists; verify original-caller restoration, completed-result reuse, partial-batch resumption and absence of duplicate submission. Exercise lost acknowledgement and native cancellation, including a 409 followed by terminal inspection. Verify revoked OAuth sessions cannot recover under another identity and that reauthentication restores the matching scope. Exercise administrator health and ensure non-admin access is denied.

Retain the exact archive/permit/event records until all imported uncertain operations have authoritative outcomes or remain explicitly accounted as unknown. Provider outages, missing original archives, expired login without refresh and genuine capacity saturation remain visible operational conditions, rather than business mapping rejections.

## Rollback

Drain/stop v2 dispatchers and account for all v2 outstanding work first. Do not run legacy readers against the new sixteen-row table or switch to a blank pool to forget remote calls. Restoring the legacy profile does not reconcile v2 operations. Preserve v2 state for recovery, and do not resume historical background jobs through the synchronous protocol. Start replacement jobs only after accounting for prior exposure and saved progress.

Provider reference: [Snowflake Cortex Agents Run API](https://docs.snowflake.com/en/user-guide/snowflake-cortex/cortex-agents-run).
