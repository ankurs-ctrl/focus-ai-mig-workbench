"use client";

import type { ReactNode } from "react";
import AppHeader from "@/features/layout/app-header";
import AppShellGate from "@/features/layout/app-shell-gate";
import WorkspaceProviders from "./workspace-providers";

export default function WorkspaceShell({ children }: { children: ReactNode }) {
  return (
    <WorkspaceProviders>
      <div className="flex h-screen flex-col overflow-hidden">
        <AppHeader />
        <div className="flex min-h-0 flex-1 flex-col overflow-hidden">
          <AppShellGate>{children}</AppShellGate>
        </div>
      </div>
    </WorkspaceProviders>
  );
}
