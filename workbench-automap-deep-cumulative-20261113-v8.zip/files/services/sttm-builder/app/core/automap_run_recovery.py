"""Backend-owned bounded recovery loop. Snowflake is the durable source of truth.

Registration retains only currently authenticated caller contexts in memory. No
bearer credentials are persisted or substituted. Restarted backends restore
fresh caller authentication from the existing encrypted OAuth store. Unauthenticated old work
remains counted in recovery inventory and cannot occupy free execution slots.
"""
from dataclasses import replace
from threading import Event, Lock, Thread
import hashlib
import json
import logging
import time

from app.core.automap_admission import ScanCallAdmission, ThreadReference, request_digest, StalePermit
from app.core.automap_runtime import SnowflakeReductionArchive, reconcile_parallel_runtime, ReconciliationStatus
from app.core.automap_scan import ScanRequest
from app.core.automap_shards import SnapshotScope, MessageBudget
from app.core.automap_background_transport import BackgroundRunTransport

logger=logging.getLogger(__name__)


class RunRecoveryCoordinator:
    def __init__(self):
        self._lock=Lock();self._contexts={};self._stop=Event();self._thread=None;self._health_at={}
        self._settings=None;self._resume_jobs=False;self._restore_at=0

    def register(self,bundle,backend,specialist,settings):
        key=(bundle.admission.store._table,bundle.archive._caller.access_scope)
        with self._lock:
            self._contexts.pop(key,None)
            if len(self._contexts)>=64:
                # Evict memory only, never durable work or outstanding exposure.
                # Stale auth contexts must not block newly authenticated jobs.
                old_key=next(iter(self._contexts));self._contexts.pop(old_key)
                if not any(k[0]==old_key[0] for k in self._contexts):self._health_at.pop(old_key[0],None)
            self._contexts[key]=(bundle,backend,specialist,settings,time.monotonic())

    def start(self,settings=None,*,resume_jobs=False):
        with self._lock:
            if self._thread is not None and self._thread.is_alive():return
            self._settings=settings;self._resume_jobs=resume_jobs;self._restore_at=0
            self._stop.clear()
            self._thread=Thread(target=self._run,name='automap-run-recovery',daemon=True)
            self._thread.start()

    def stop(self):
        self._stop.set()
        thread=self._thread
        if thread is not None:thread.join(timeout=10)
        with self._lock:self._contexts.clear()

    def _run(self):
        while not self._stop.wait(1):
            now=time.monotonic()
            if self._settings is not None and now>=self._restore_at:
                self._restore_at=now+60
                try:
                    from app.core.automap_restart import restore_work
                    restore_work(self,self._settings,resume_jobs=self._resume_jobs)
                except Exception as exc:
                    logger.warning('Auto-map restart discovery unavailable error_type=%s',type(exc).__name__)
            with self._lock:
                contexts=[]
                for key,value in list(self._contexts.items()):
                    bundle,backend,specialist,settings,due=value
                    if due<=now and len(contexts)<2:
                        contexts.append(value[:4])
                        self._contexts[key]=(*value[:4],now+settings.automap_recovery_poll_seconds)
            for context in contexts:
                if self._stop.is_set():break
                try:self.tick(*context)
                except Exception as exc:
                    # No provider exception bodies, credentials or customer SQL.
                    logger.warning('Auto-map recovery pass unavailable error_type=%s',type(exc).__name__)

    def tick(self,bundle,backend,specialist,settings):
        from app.core.automap_durable_admission import DurableRunAdmission
        original=bundle.admission.store
        pool=type(original)(session_factory=getattr(original._factory,'recovery_factory',original._factory),
            table=original._table,account_namespace=original.account_namespace,pool_epoch=original.pool_epoch,
            capacity=original.capacity,recovery_capacity=original.recovery_capacity)
        recovery_bundle=replace(bundle,admission=ScanCallAdmission(pool,
            job_id=bundle.admission.job_id,caller_id=bundle.admission.caller_id))
        now=time.monotonic()
        if now-self._health_at.get(pool._table,float('-inf'))>=60:
            health=pool.health()
            self._health_at[pool._table]=now
            if health['quarantined'] or health['expired_held']:
                logger.warning('Auto-map capacity requires recovery execution_free=%s quarantine=%s oldest_seconds=%s',
                    health['execution_free'],health['quarantined'],health['oldest_quarantine_seconds'])
        rows=pool.recovery_candidates(bundle.archive._caller.native_user,limit=4)
        for row in rows:
            if self._stop.is_set():break
            permit=pool.permit_for(row)
            lease=pool.claim_recovery(permit)
            if lease is None:continue
            reason='unknown_outcome'
            try:
                self._recover(recovery_bundle,backend,specialist,settings,row,permit)
            except StalePermit:
                continue
            except PermissionError:
                reason='auth_unavailable'
            except LookupError:
                reason='missing_archive'
            except Exception as exc:
                logger.warning('Auto-map recovery incomplete slot=%s error_type=%s',permit.slot_id,type(exc).__name__)
            else:
                continue
            if getattr(pool,'shared_capacity_limit',True) and permit.slot_id<=pool.capacity and row.get('STATE')=='HELD':
                # A crashed dispatcher must not strand uncertain exposure in an
                # execution reservation. Handoff preserves it in bounded recovery
                # inventory; it does not assert termination or resubmit anything.
                try:
                    pool.quarantine(permit)
                    continue
                except StalePermit:
                    continue
            try:pool.defer_recovery(permit,lease,reason)
            except StalePermit:pass

    def _recover(self,bundle,source,specialist,settings,row,permit):
        deadline=time.monotonic()+55
        pool=bundle.admission.store
        if row.get('DISPATCH_PROTOCOL')=='background_v2' and not row.get('RECONCILIATION_REF') and not row.get('MODEL_RUN_ID'):
            pool.recover_not_dispatched(permit)
            return
        reference=ThreadReference.parse(row['RECONCILIATION_REF'])
        allowed={b._config.agent:b for b in (source,specialist) if b is not None}
        if reference.agent_fqn not in allowed:raise PermissionError('Original agent unavailable')
        template=allowed[reference.agent_fqn]
        caller=bundle.archive._caller
        # Original fast request generation is its immutable snapshot ID. Legacy
        # formats without exact archives are surfaced, never silently upgraded.
        scope=SnapshotScope(caller.native_user,permit.identity.generation)
        archive=SnowflakeReductionArchive(session_factory=pool._factory,table=bundle.archive._table,
            caller=caller,scope=scope,deadline=deadline)
        ref=row.get('REQUEST_ARCHIVE_REF')
        if not ref:
            with archive._session() as session:
                results=session.sql(f"SELECT DISTINCT CONTENT_HASH FROM {archive._table} "
                    "WHERE OWNER_ID=? AND ACCESS_SCOPE=? AND SNAPSHOT_ID=? "
                    "AND TRY_PARSE_JSON(BODY):value:protocol::VARCHAR='automap_fast_model_request_v1' "
                    "AND TRY_PARSE_JSON(BODY):value:job_id::VARCHAR=? "
                    "AND TRY_PARSE_JSON(BODY):value:request_digest::VARCHAR=? LIMIT 2",
                    params=[caller.native_user,caller.access_scope,scope.snapshot_id,
                            permit.identity.job_id,reference.request_digest]).collect(
                        statement_params={'STATEMENT_TIMEOUT_IN_SECONDS':'5','LOCK_TIMEOUT':'1'})
            if len(results)!=1:raise LookupError('Original archive not uniquely available')
            result=results[0].as_dict() if hasattr(results[0],'as_dict') else dict(results[0]);ref=result['CONTENT_HASH']
        body=json.loads(archive.get(ref));value=body['value'];data=value['request']
        if (value['protocol']!='automap_fast_model_request_v1' or value['job_id']!=permit.identity.job_id
                or value['agent_fqn']!=reference.agent_fqn or data['generation']!=permit.identity.generation
                or data['shard_id']!=permit.identity.shard_id or data['scope']!={'owner_id':scope.owner_id,'snapshot_id':scope.snapshot_id}):
            raise LookupError('Original recovery identity mismatch')
        request=ScanRequest(scope,data['generation'],data['shard_id'],tuple(data['target_ids']),tuple(data['record_ids']),
            data['message'],MessageBudget(**data['output_budget']),deadline,Event(),Event(),request_archive_ref=ref)
        if request_digest(request)!=reference.request_digest:raise LookupError('Original request digest mismatch')
        gate=ScanCallAdmission(pool,job_id=permit.identity.job_id,caller_id=caller.native_user)
        transport=BackgroundRunTransport(agent_client=template._agent_client,http_client=template._http_client,
            config=template._config,admission=gate)
        transport.result_archive=archive;transport.run_seconds=settings.automap_run_seconds
        terminal,run_id,messages=transport.inspect_run(request,reference,row.get('MODEL_RUN_ID'))
        if terminal is None:
            expiry=row.get('RUN_DEADLINE') or row.get('LEASE_EXPIRES_AT')
            expired=expiry is not None and expiry.timestamp()<=time.time()
            if not expired or run_id is None:raise LookupError('Original run not yet controllable')
            transport.cancel_run(request,run_id)
            terminal,_,messages=transport.inspect_run(request,reference,run_id)
        if terminal is None:raise LookupError('Cancellation not terminal yet')
        if terminal.status.value=='completed':
            # Preserve model result before release so resumed jobs can reuse it.
            from app.core.automap_admission import RemoteCallCompleted
            try: transport._result(terminal,messages,request,lambda *a,**k:None)
            except RemoteCallCompleted: pass  # terminal but invalid output must not leak a permit
        # Discovery/cache recovery and terminal audit each have a fresh bounded
        # control budget. Neither can extend inference or submit a model call.
        release_deadline=time.monotonic()+55
        archive=archive.with_deadline(release_deadline)
        request=replace(request,deadline=release_deadline)
        recovery_bundle=replace(bundle,scope=scope,archive=archive,admission=gate,backend=transport)
        # New transport executes a single submission guarded by durable identity.
        # Exact unique terminal root proves that submission has already occurred;
        # it cannot be a paused pre-submission dispatcher. No replay is issued.
        result=reconcile_parallel_runtime(recovery_bundle,permit=permit,original_request=request,
            snapshot_archive_ref=value['snapshot_archive_ref'],retired_dispatcher=True,deadline=release_deadline)
        if result.status not in {ReconciliationStatus.RELEASED,ReconciliationStatus.STALE_PERMIT}:
            raise RuntimeError('Recovery release not acknowledged')
        logger.info('Auto-map run recovery result=%s slot=%s',result.status.value,permit.slot_id)


recovery_coordinator=RunRecoveryCoordinator()
