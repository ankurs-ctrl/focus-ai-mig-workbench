param(
    [string]$EnvFile = "",
    [string]$RoleName = ""
)

$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "common.ps1")

# Purpose:
# - grant service endpoint access to a client-facing role
# Why this matters:
# - public ingress can still exist, but users need the service role grant to
#   open the endpoint successfully

if (-not $EnvFile) {
    $EnvFile = Get-DefaultEnvFile
}

$snowExe = Ensure-SnowInstalled
$cfg = Import-DemoEnv -Path $EnvFile

Require-ConfigValues -Config $cfg -RequiredKeys @(
    "SNOWFLAKE_CONNECTION",
    "SNOWFLAKE_DATABASE",
    "SNOWFLAKE_SCHEMA",
    "STREAMLIT_DEMO_SERVICE_NAME"
) -EnvFile $EnvFile

if (-not $RoleName) {
    if ($cfg.ContainsKey("CLIENT_ENDPOINT_ROLE") -and $cfg["CLIENT_ENDPOINT_ROLE"]) {
        $RoleName = [string]$cfg["CLIENT_ENDPOINT_ROLE"]
    } else {
        throw "RoleName is required, or set CLIENT_ENDPOINT_ROLE in $EnvFile"
    }
}

Write-Host "Granting endpoint access to role $RoleName"
Invoke-SnowSql -SnowExe $snowExe -ConnectionName $cfg["SNOWFLAKE_CONNECTION"] -Sql @"
GRANT USAGE ON DATABASE $($cfg["SNOWFLAKE_DATABASE"]) TO ROLE $RoleName;
GRANT USAGE ON SCHEMA $($cfg["SNOWFLAKE_DATABASE"]).$($cfg["SNOWFLAKE_SCHEMA"]) TO ROLE $RoleName;
GRANT SERVICE ROLE $($cfg["STREAMLIT_DEMO_SERVICE_NAME"])!browser_access TO ROLE $RoleName;
"@

Write-Host ""
Write-Host "Endpoint access grant complete."
