#!/usr/bin/env bash
set -euo pipefail
TASK_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TASK_SERVICE="${TASK_ROOT}/services/sttm-builder"
TASK_PYTHON="${DEEP_WORKER_PYTHON:-${TASK_SERVICE}/.venv/bin/python}"
if [[ ! -x "${TASK_PYTHON}" ]]; then
  printf 'Set DEEP_WORKER_PYTHON to an environment with the locked backend dependencies.\n' >&2
  exit 1
fi
cd "${TASK_SERVICE}"
printf 'Starting Deep worker from %s\n' "${TASK_ROOT}"
exec "${TASK_PYTHON}" -m app.agent_worker_main
