from copy import deepcopy
import json
import time

import pytest

from app.core.automap_batch import freeze_fast_handoff, invoke_batch
from app.core.automap_fast_context import FastContextPlan, hydrate_authored_cte_graph, validate_derived_output_contracts
from app.core.automap_input_budget import wire_text
from app.core.automap_retrieval import digest, encoded
from app.core.sttm_builder import STTMBuilderService
from app.schema.sttm_builder import STTMBuilderEnvelopeRequest
from tests.unit.core.test_automap_fast_batch import FinalAgent, prepared_request, service
from tests.unit.core.test_automap_fast_context import fast_payload
from types import SimpleNamespace
from tests.test_automap_fast_transport import harness as transport_harness, build as build_runtime


def identifier_request(sql_alias, display):
    return STTMBuilderEnvelopeRequest.model_validate({"operation": "sttm.auto_map", "data": {"intent": "AUTO_MAP"},
        "context": {"workspace_context": {"driving_relation_id": "c", "mapping_sql":
            f"WITH JimsHH AS (SELECT 1 AS {sql_alias}) SELECT * FROM JimsHH"}, "relation_graph": {"nodes": [{
                "relation_id": "c", "alias": "cte_jimshh", "kind": "DERIVED_SOURCE", "original_cte_name": "JimsHH",
                "sql_text": "SELECT * FROM JimsHH", "output_columns": [{"name": display}]}]}}})


@pytest.mark.parametrize("sql_alias,display,reference", [
    ("LEGACYPASID", "LegacyPASID", "cte_jimshh.LEGACYPASID"),
    ("LegacyPASID", "LegacyPASID", "cte_jimshh.LEGACYPASID"),
    ('"LegacyPASID"', "LegacyPASID", 'cte_jimshh."LegacyPASID"'),
    ('"Legacy.PASID"', "Legacy.PASID", 'cte_jimshh."Legacy.PASID"'),
])
def test_output_validation_compiles_authoritative_sql_identifier(sql_alias, display, reference, monkeypatch):
    from app.core.mapping_sql import MappingSqlService
    req = hydrate_authored_cte_graph(identifier_request(sql_alias, display))
    before = req.model_dump()
    requests = []
    compile_sql = MappingSqlService.compile
    def capture(self, body):
        requests.append(body)
        result = compile_sql(self, body)
        assert result.ready
        return result
    monkeypatch.setattr(MappingSqlService, "compile", capture)
    assert set(validate_derived_output_contracts(req, None)) == {"c"}
    assert requests[0].mappings[0].source_columns == [reference]
    assert req.model_dump() == before


def frozen_request(value=None):
    req = prepared_request(value or fast_payload())
    discovery = {item.target_attribute: {"diagnostics": {"status": "no_match"}}
                 for item in req.data.attributes}
    req.meta["_automap_fast_handoff"] = freeze_fast_handoff(req, discovery=discovery)
    return req


def test_preflight_measures_identical_complete_worker_message():
    builder = service(FinalAgent())
    req = frozen_request()
    planned = STTMBuilderService.project_agent_payload(req, builder._settings)
    invoke_batch(builder, req, SimpleNamespace())
    messages = builder._agent.calls[0][0]
    baseline = planned.diagnostics["fast_preflight"]
    assert baseline["exact_reads_included"] and baseline["discovery_complete"]
    assert baseline["complete_message_chars"] == len(wire_text(messages))
    assert baseline["complete_message_bytes"] == len(wire_text(messages).encode("utf-8"))
    assert baseline["complete_message_digest"] == digest(messages)
    packet = json.loads(messages[0]["content"][0]["text"])
    assert "response_schema_example" in packet or "exact_record_encoding" in packet


def source_answer(source, *, target="NAME0", **extra):
    return json.dumps({"agent": "AGT_SOURCE_MAPPING", "data": {"result": {"mappings": {target: {
        "source_attributes": source, "confidence_score": .9, "transformation_classification": "direct", **extra}}}}})


def test_object_source_uniquely_bound_to_roster_remains_subject_to_grounding():
    value = fast_payload()
    answer = source_answer([{"source_column": "X47", "source_table": "D.S.A", "sql_qualifier": "a"}])
    builder = service(FinalAgent([answer]))
    result = json.loads(invoke_batch(builder, prepared_request(value), SimpleNamespace())[0])
    assert result["data"]["result"]["mappings"]["NAME0"]["source_attributes"] == ['a."X47"']
    assert len(builder._agent.calls) == 1
    invalid = source_answer([{"source_column": "X47", "source_table": "D.S.A", "sql_qualifier": "a"}],
                            used_learning_ids=["fabricated"])
    builder = service(FinalAgent([invalid] * 8))
    result = json.loads(invoke_batch(builder, prepared_request(value), SimpleNamespace())[0])
    assert result["data"]["result"]["mappings"]["NAME0"]["transformation_classification"] == "unresolved"


def test_format_repair_is_focused_and_keeps_already_validated_target():
    value = fast_payload(2)
    first = {"agent": "AGT_SOURCE_MAPPING", "data": {"result": {"mappings": {
        "NAME0": {"source_attributes": ["a.X47"], "confidence_score": .9, "transformation_classification": "direct"},
        "NAME1": {"source_attributes": [{"source_column": "INVENTED", "sql_qualifier": "a"}],
                  "confidence_score": .9, "transformation_classification": "direct"}}}}}
    second = source_answer(["a.X47"], target="NAME1")
    builder = service(FinalAgent([json.dumps(first), second]))
    result = json.loads(invoke_batch(builder, prepared_request(value), SimpleNamespace())[0])
    assert result["data"]["result"]["mappings"]["NAME0"]["source_attributes"] == ["a.X47"]
    assert result["data"]["result"]["mappings"]["NAME1"]["source_attributes"] == ["a.X47"]
    from tests.unit.core.test_automap_fast_context import unpack
    assert [item["target_attribute"] for item in unpack(builder._agent.calls[1][0])["data"]["attributes"]] == ["NAME1"]
    assert len(builder._agent.calls) == 2


def test_target_catalog_omissions_are_not_missing_source_evidence():
    from tests.unit.core.test_automap_fast_context import plan_for
    value = fast_payload()
    model = value["context"]["semantic_context"][1]["semantic_model"]
    model["attributes"].extend({"name": f"OTHER_TARGET_{index}", "business_meaning": "x" * 500} for index in range(100))
    store, plan = plan_for(value)
    assert plan.omitted_target_groups
    assert not set(plan.omitted_target_groups) & set(plan.omitted_source_groups)
    warnings = [item for item in plan.warnings if item["field"] == store.target_table]
    assert warnings and all(item["code"] == "auto_map_fast_target_metadata_omitted" for item in warnings)
    assert all("not missing source evidence" in item["message"] for item in warnings)


def test_134k_model_input_is_admitted_without_raising_response_or_scan_limits(transport_harness):
    h = transport_harness
    h.service._settings.agent_outbound_message_max_chars = 180_000
    h.service._settings.agent_outbound_message_max_bytes = 180_000
    model = build_runtime(h)
    messages = [{"role": "user", "content": "x" * 134_134}]
    assert model.run(messages, 1)[0] == h.state.answer
    assert len(model.request_for(1).message) > 134_134
    assert model.bundle.limits.selection_budget.max_chars == 180_000
    assert model.bundle.limits.scan_budget.max_chars == 120_000
    assert model.request_for(1).output_budget.max_chars == 120_000
    assert model.bundle.backend._config.max_response_bytes == 120_000


def test_utf8_input_byte_limit_is_independent_of_character_limit(transport_harness):
    from app.core.agent_payload_budget import AgentPayloadBudgetError
    h = transport_harness
    h.service._settings.agent_outbound_message_max_chars = 180_000
    h.service._settings.agent_outbound_message_max_bytes = 180_000
    model = build_runtime(h)
    with pytest.raises(AgentPayloadBudgetError):
        model.run([{"role": "user", "content": "界" * 61_000}], 1)
    assert not h.wire


def test_preflight_repacks_exact_read_overflow_that_baseline_alone_would_accept():
    from app.core.automap_batch import _FastAutoMapContext
    from app.core.automap_exact_reads import initial_operations, read_operations
    from app.core.automap_policy import focused_learning
    from app.schema.sttm_builder import STTMAgentRequestEnvelope
    from app.core.agent_payload_budget import AgentPayloadBudgetError
    builder = service(FinalAgent())
    req = frozen_request()
    raw = STTMAgentRequestEnvelope.from_builder_request(req).model_dump(mode="json", exclude_none=True)
    raw["context"]["learning_context"] = focused_learning(raw["context"].get("learning_context") or {})
    store = _FastAutoMapContext(raw)
    store.manifest()
    store.replay_parent_discovery(req.meta["_automap_fast_handoff"])
    plan = FastContextPlan(store, max_chars=180_000, max_bytes=180_000)
    baseline = len(wire_text(plan.messages([])))
    results, events = [], []
    read_operations(store, initial_operations(store, plan), settings=builder._settings, results=results,
                    events=events, remaining=lambda: 60)
    complete = len(wire_text(plan.messages(results)))
    assert complete > baseline
    limit = (complete + baseline) // 2
    settings = builder._settings.model_copy(update={"agent_outbound_message_max_chars": limit,
                                                    "agent_outbound_message_max_bytes": 180_000})
    projected = STTMBuilderService.project_agent_payload(req, settings)
    assert projected.diagnostics['fast_preflight']['complete_message_chars'] <= limit
    assert projected.diagnostics['fast_preflight']['exact_reads_included'] is True
    assert projected.diagnostics['fast_preflight']['model_calls'] == 0
    assert not builder._agent.calls


@pytest.mark.parametrize("name", ["webapp", "automap-worker"])
def test_checked_in_uat_profile_renders_180k_without_modifying_client_env(name):
    from tests.unit.core.test_parallel_deployment import ROOT, SPECS, render_values
    from scripts.render_spcs_spec import render_template
    import yaml
    values = render_values("UAT")
    profile = ROOT / "infra/snowflake/env/parallel.uat.json"
    values.update(AUTOMAP_DEPLOY_PROFILE_FILE=str(profile), AUTOMAP_DEPLOY_ENVIRONMENT="UAT",
                  SNOWFLAKE_CONNECTION="client-spcs")
    original = deepcopy(values)
    rendered = yaml.safe_load(render_template((SPECS / f"{name}.yaml.tmpl").read_text(), values))
    env = rendered["spec"]["containers"][0]["env"]
    assert env["AGENT_OUTBOUND_MESSAGE_MAX_CHARS"] == env["AGENT_OUTBOUND_MESSAGE_MAX_BYTES"] == "180000"
    assert values == original


def test_self_join_source_object_requires_unique_binding():
    from tests.unit.core.test_automap_fast_context import plan_for
    from app.core.automap_source_format import normalize_source_objects
    value = fast_payload()
    node = deepcopy(value["context"]["relation_graph"]["nodes"][0])
    node.update(relation_id="b", alias="b")
    value["context"]["relation_graph"]["nodes"].append(node)
    value["context"]["relation_graph"]["edges"].append({"edge_id": "self", "left_relation_id": "a",
        "right_relation_id": "b", "conditions": [{"left_column": "X47", "right_column": "X47"}]})
    store, plan = plan_for(value)
    ambiguous = json.loads(source_answer([{"source_column": "X47", "source_table": "D.S.A"}]))
    converted = normalize_source_objects(ambiguous, plan)
    assert isinstance(converted["data"]["result"]["mappings"]["NAME0"]["source_attributes"][0], dict)
    ambiguous["data"]["result"]["mappings"]["NAME0"]["source_attributes"][0]["sql_qualifier"] = "b"
    converted = normalize_source_objects(ambiguous, plan)
    assert converted["data"]["result"]["mappings"]["NAME0"]["source_attributes"] == ['b."X47"']


def test_live_identifier_probe_generates_only_application_explain_queries():
    from scripts.verify_automap_identifier_contracts import validation_queries
    statements = validation_queries()
    assert len(statements) == 4 and all(item.startswith("EXPLAIN USING TEXT ") for item in statements)
    assert 'cte_jimshh."LegacyPASID"' not in statements[0]
    assert 'cte_jimshh."LegacyPASID"' in statements[2]


def test_canonical_cte_reference_reads_uppercase_semantics_when_display_name_differs():
    value = fast_payload()
    value["context"]["source_tables"] = []
    value["context"]["semantic_context"] = value["context"]["semantic_context"][1:]
    value["context"]["workspace_context"]["driving_relation_id"] = "c"
    value["context"]["relation_graph"]["nodes"] = [{"relation_id": "c", "alias": "cte_jimshh",
        "kind": "DERIVED_SOURCE", "sql_text": "SELECT 1 AS LEGACYPASID",
        "output_columns": [{"name": "LegacyPASID", "data_type": "NUMBER"}], "column_semantics": [
            {"name": "LEGACYPASID", "business_meaning": "Authoritative legacy portfolio identifier"},
            *[{"name": f"UNUSED_{index}", "business_meaning": "Archived catalog semantics " + str(index) + "x" * 1000}
              for index in range(100)]]}]
    builder = service(FinalAgent([source_answer(["cte_jimshh.LEGACYPASID"])]))
    raw, _, audit = invoke_batch(builder, prepared_request(value), SimpleNamespace())
    assert json.loads(raw)["data"]["result"]["mappings"]["NAME0"]["source_attributes"] == ["cte_jimshh.LEGACYPASID"]
    assert ["column", "c", "LEGACYPASID"] in audit["auto_map_retrieval"]["completed_reads"]
    assert "Authoritative legacy portfolio identifier" in wire_text(builder._agent.calls[0][0])


def test_failed_format_repair_stops_after_one_attempt_and_keeps_valid_target():
    value = fast_payload(2)
    invalid = {"agent": "AGT_SOURCE_MAPPING", "data": {"result": {"mappings": {
        "NAME0": {"source_attributes": ["a.X47"], "confidence_score": .9, "transformation_classification": "direct"},
        "NAME1": {"source_attributes": [{"source_column": "X47", "sql_qualifier": "unknown"}],
                  "confidence_score": .9, "transformation_classification": "direct"}}}}}
    builder = service(FinalAgent([json.dumps(invalid), json.dumps(invalid)]))
    raw, _, _ = invoke_batch(builder, prepared_request(value), SimpleNamespace())
    result = json.loads(raw)["data"]["result"]["mappings"]
    assert result["NAME0"]["source_attributes"] == ["a.X47"]
    assert result["NAME1"]["source_attributes"] == [] and "format" in result["NAME1"]["unmatched_reason"]
    assert len(builder._agent.calls) == 2


def test_real_batch_planner_splits_complete_inputs_and_every_worker_batch_fits():
    from app.core.auto_mapping_proxy import AutoMappingProxyClient
    value = fast_payload(8)
    for index, item in enumerate(value["data"]["attributes"]):
        item["target_description"] = f"Exact requirement {index}: " + "x" * 6000
    req = frozen_request(value)
    builder = service(FinalAgent())
    settings = builder._settings.model_copy(update={"agent_outbound_message_max_chars": 180_000,
        "agent_outbound_message_max_bytes": 180_000, "automap_context_batch_count": 4})
    one = req.model_copy(update={"data": req.data.model_copy(update={"attributes": req.data.attributes[:1]})})
    minimum = STTMBuilderService.project_agent_payload(one, settings).diagnostics["fast_preflight"]["complete_message_chars"]
    settings = settings.model_copy(update={"agent_outbound_message_max_chars": minimum + 1500})
    builder._settings = settings
    batches = AutoMappingProxyClient(settings)._build_batches(req)
    assert 4 <= len(batches) <= 8
    assert sorted(item.target_attribute for batch in batches for item in batch) == sorted(item.target_attribute for item in req.data.attributes)
    for batch in batches:
        child = req.model_copy(update={"data": req.data.model_copy(update={"attributes": batch})})
        planned = STTMBuilderService.project_agent_payload(child, settings).diagnostics["fast_preflight"]
        before = len(builder._agent.calls)
        raw, _, audit = invoke_batch(builder, child, SimpleNamespace())
        assert len(builder._agent.calls) >= before + 1
        assert planned['complete_message_chars'] <= settings.agent_outbound_message_max_chars
        assert all(len(wire_text(messages)) <= settings.agent_outbound_message_max_chars
            and len(wire_text(messages).encode('utf-8')) <= settings.agent_outbound_message_max_bytes
            for messages, _ in builder._agent.calls[before:])
        assert all(mapping["source_attributes"] for mapping in json.loads(raw)["data"]["result"]["mappings"].values())
