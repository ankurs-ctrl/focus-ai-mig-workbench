"use client";
import { AiaBox, AiaPaper } from '@/components/ui';
import { AiaText } from '@/components/ui/aia-text';
import { CAPTION_SX, SECONDARY_TEXT_SX } from '@/config/typography-tokens';
import { AutorenewOutlinedIcon, CheckCircleOutlinedIcon } from "@/utils/icons";

import type { STTMRecord } from "@/services/projectService";
import { getMappingCounts } from "./mappingStats";
import { CLIENT_CONFIG } from "@/config/client.config";

// BBI uses its brand orange; Focus (and any other client) uses green.
const PUBLISHED_COLOR =
    CLIENT_CONFIG.clientId === "bbi" ? CLIENT_CONFIG.branding.colors.secondary : "#16A34A";
const IN_PROGRESS_COLOR = "#9CA3AF";
const TRACK_COLOR = "#ECEFF3";

const DONUT_SIZE = 220;
const DONUT_STROKE = 20;
const DONUT_RADIUS = (DONUT_SIZE - DONUT_STROKE) / 2;
const DONUT_CIRCUMFERENCE = 2 * Math.PI * DONUT_RADIUS;

type QuickStatsPanelProps = {
    sttms: STTMRecord[];
};

export default function QuickStatsPanel({ sttms }: QuickStatsPanelProps) {
    const { total, published, inProgress } = getMappingCounts(sttms);
    const publishedPct = total ? Math.round((published / total) * 100) : 0;
    // Derive from publishedPct so the two shares always sum to 100%.
    const inProgressPct = total ? 100 - publishedPct : 0;
    const publishedArc = total ? (published / total) * DONUT_CIRCUMFERENCE : 0;

    const breakdown = [
        {
            label: "Published",
            count: published,
            pct: publishedPct,
            color: PUBLISHED_COLOR,
            icon: <CheckCircleOutlinedIcon sx={{ fontSize: 20 }} />,
        },
        {
            label: "In Progress",
            count: inProgress,
            pct: inProgressPct,
            color: IN_PROGRESS_COLOR,
            icon: <AutorenewOutlinedIcon sx={{ fontSize: 20 }} />,
        },
    ];

    return (
        <AiaPaper
            elevation={0}
            className="flex min-h-[360px] flex-col rounded-[20px] border border-[#EEF2F7] bg-white p-6"
        >
            <AiaBox className="flex items-center justify-between">
                <AiaText sx={{ ...CAPTION_SX, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.08em" }}>
                    Quick Stats
                </AiaText>
                <AiaText
                    sx={{
                        ...CAPTION_SX,
                        fontWeight: 600,
                        px: 1.25,
                        py: 0.25,
                        borderRadius: "999px",
                        border: "1px solid #DCE3EC",
                        bgcolor: "#FAFBFC",
                    }}
                >
                    {total} {total === 1 ? "mapping" : "mappings"}
                </AiaText>
            </AiaBox>

            <AiaBox className="mt-6 flex flex-1 flex-col items-center gap-10 sm:flex-row">
                {/* Donut: published arc over an in-progress ring */}
                <AiaBox
                    className="relative shrink-0"
                    sx={{
                        width: DONUT_SIZE,
                        height: DONUT_SIZE,
                        transition: "transform 0.2s ease",
                        "& svg": { transition: "filter 0.2s ease" },
                        // Same lift as the stat cards; drop-shadow follows the ring's circular shape.
                        "&:hover": { transform: "translateY(-4px) scale(1.03)" },
                        "&:hover svg": { filter: "drop-shadow(0 12px 14px rgba(17, 24, 39, 0.12))" },
                    }}
                >
                    <svg
                        width={DONUT_SIZE}
                        height={DONUT_SIZE}
                        viewBox={`0 0 ${DONUT_SIZE} ${DONUT_SIZE}`}
                        role="img"
                        aria-label={`${publishedPct}% of mappings published`}
                    >
                        <circle
                            cx={DONUT_SIZE / 2}
                            cy={DONUT_SIZE / 2}
                            r={DONUT_RADIUS}
                            fill="none"
                            stroke={inProgress > 0 ? IN_PROGRESS_COLOR : TRACK_COLOR}
                            strokeWidth={DONUT_STROKE}
                        />
                        {published > 0 && (
                            <circle
                                cx={DONUT_SIZE / 2}
                                cy={DONUT_SIZE / 2}
                                r={DONUT_RADIUS}
                                fill="none"
                                stroke={PUBLISHED_COLOR}
                                strokeWidth={DONUT_STROKE}
                                strokeLinecap="round"
                                strokeDasharray={`${publishedArc} ${DONUT_CIRCUMFERENCE}`}
                                transform={`rotate(-90 ${DONUT_SIZE / 2} ${DONUT_SIZE / 2})`}
                                style={{ transition: "stroke-dasharray 0.6s ease" }}
                            />
                        )}
                    </svg>
                    <AiaBox className="absolute inset-0 flex flex-col items-center justify-center">
                        <AiaText
                            sx={{
                                fontSize: "44px",
                                fontWeight: 600,
                                lineHeight: 1,
                                color: "var(--aia-text-color)",
                            }}
                        >
                            {publishedPct}
                            <AiaBox component="span" sx={{ fontSize: "18px", fontWeight: 500, ml: 0.25, color: "#6B7280" }}>
                                %
                            </AiaBox>
                        </AiaText>
                        <AiaText sx={{ ...CAPTION_SX, mt: 0.75 }}>Complete</AiaText>
                    </AiaBox>
                </AiaBox>

                {/* Legend */}
                <AiaBox className="flex w-full min-w-0 flex-1 flex-col">
                    {breakdown.map((item, index) => (
                        <AiaBox
                            key={item.label}
                            className={`flex items-center justify-between gap-3 py-3 ${
                                index < breakdown.length - 1 ? "border-b border-[#F1F5F9]" : ""
                            }`}
                        >
                            <AiaBox className="flex items-center gap-2.5">
                                <AiaBox
                                    sx={{
                                        display: "flex",
                                        alignItems: "center",
                                        justifyContent: "center",
                                        p: 0.75,
                                        borderRadius: "10px",
                                        border: "1px solid #DCE3EC",
                                        bgcolor: "#FFFFFF",
                                        color: item.color,
                                    }}
                                >
                                    {item.icon}
                                </AiaBox>
                                <AiaText sx={{ ...SECONDARY_TEXT_SX, fontWeight: 500, color: "#4B5563" }}>
                                    {item.label}
                                </AiaText>
                            </AiaBox>
                            <AiaBox className="flex items-baseline gap-3">
                                <AiaText sx={{ fontSize: "22px", fontWeight: 600, lineHeight: 1, color: "var(--aia-text-color)" }}>
                                    {item.count}
                                </AiaText>
                                <AiaText sx={{ ...CAPTION_SX, fontWeight: 600, minWidth: "36px", textAlign: "right" }}>
                                    {item.pct}%
                                </AiaText>
                            </AiaBox>
                        </AiaBox>
                    ))}
                    <AiaText sx={{ ...CAPTION_SX, mt: 1.5 }}>
                        {total
                            ? `${published} of ${total} mappings published`
                            : "No mappings yet"}
                    </AiaText>
                </AiaBox>
            </AiaBox>
        </AiaPaper>
    );
}
