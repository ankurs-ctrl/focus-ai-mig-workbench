"use client";

import {
  useCallback,
  useContext,
  useEffect,
  useMemo,
  createContext,
} from "react";
import { useAiChatLayout } from "@/features/ai-agent/ai-chat-layout-context";
import { useSttmBuilderContext } from "@/features/sttm/context/sttm-builder-context";
import { recommendationService } from "@/services/recommendationService";
import type { FIRRecommendation } from "@/types/api-contract";

export const APPROVAL_RESPONSE_PATTERN =
  /^(yes|yep|yeah|ok|okay|sure|approve|approved|apply|apply it|please apply|go ahead|looks good|do it|use it)[.! ]*$/i;
export const SKIP_RESPONSE_PATTERN = /^(skip|pass|next one|next)[.! ]*$/i;

export type AiAgentSendApi = {
  send: (rawMessage: string) => boolean;
  isLoading: boolean;
};

type AiAgentCocoSendOptions = {
  isActive: boolean;
  isBusy: boolean;
  send: (message: string) => void;
};

type UseAiAgentSendControllerOptions = {
  coco?: AiAgentCocoSendOptions;
  pendingCorrectionRecommendation?: FIRRecommendation | null;
  clearPendingCorrection?: () => void;
};

export type RegisterAiAgentSend = (api: AiAgentSendApi) => void;

export const AiAgentSendRegisterContext = createContext<RegisterAiAgentSend | null>(null);
export const AiAgentSendApiContext = createContext<AiAgentSendApi | null>(null);

export const idleSendApi: AiAgentSendApi = {
  send: () => false,
  isLoading: false,
};

export function useRegisterAiAgentSend(api: AiAgentSendApi) {
  const register = useContext(AiAgentSendRegisterContext);

  useEffect(() => {
    if (!register) return;
    register(api);
    return () => {
      register(idleSendApi);
    };
  }, [api, register]);
}

export function useAiAgentSendApi(): AiAgentSendApi {
  return useContext(AiAgentSendApiContext) ?? idleSendApi;
}

/**
 * Shared AI Agent send pipeline used by the side panel and `/ai-agent` page.
 * CoCo / FIR-correction branches are optional injectables from the panel.
 */
export function useAiAgentSendController(
  options: UseAiAgentSendControllerOptions = {},
): AiAgentSendApi {
  const {
    chatLoading,
    sendChatMessage,
    pendingAiMappingReviews,
    applyPendingAiMappingReview,
    skipPendingAiMappingReview,
    firRecommendationContextKey,
    session,
  } = useSttmBuilderContext();
  const { markRecommendationResolved } = useAiChatLayout();

  const coco = options.coco;
  const pendingCorrectionRecommendation = options.pendingCorrectionRecommendation ?? null;
  const clearPendingCorrection = options.clearPendingCorrection;

  const recordRecommendationOutcome = useCallback(
    async (
      recommendation: FIRRecommendation,
      outcomeType: string,
      payload: Record<string, unknown> = {},
    ) => {
      try {
        await recommendationService.recordOutcome(recommendation.recommendation_id, {
          outcome_type: outcomeType,
          context_key: firRecommendationContextKey,
          user_id: session ? String(session.user_id) : null,
          payload,
        });
      } catch (error) {
        console.warn("Could not record FIR recommendation outcome", error);
      }
    },
    [firRecommendationContextKey, session],
  );

  const isLoading = Boolean(coco?.isActive ? coco.isBusy : chatLoading);

  const send = useCallback(
    (rawMessage: string) => {
      const message = rawMessage.trim();
      if (!message) return false;

      if (coco?.isActive) {
        if (coco.isBusy) return false;
        coco.send(message);
        return true;
      }

      if (chatLoading) return false;

      if (pendingAiMappingReviews[0] && APPROVAL_RESPONSE_PATTERN.test(message)) {
        applyPendingAiMappingReview();
        return true;
      }

      if (pendingAiMappingReviews[0] && SKIP_RESPONSE_PATTERN.test(message)) {
        skipPendingAiMappingReview();
        return true;
      }

      if (pendingCorrectionRecommendation) {
        void recordRecommendationOutcome(pendingCorrectionRecommendation, "corrected", {
          correction: message,
          checkpoint: pendingCorrectionRecommendation.checkpoint,
        });
        markRecommendationResolved(pendingCorrectionRecommendation.recommendation_id);
        clearPendingCorrection?.();
      }

      sendChatMessage(message);
      return true;
    },
    [
      applyPendingAiMappingReview,
      chatLoading,
      clearPendingCorrection,
      coco,
      markRecommendationResolved,
      pendingAiMappingReviews,
      pendingCorrectionRecommendation,
      recordRecommendationOutcome,
      sendChatMessage,
      skipPendingAiMappingReview,
    ],
  );

  return useMemo(() => ({ send, isLoading }), [send, isLoading]);
}
