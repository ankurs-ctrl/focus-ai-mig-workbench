'use client';

import { useCallback, useEffect, useState } from 'react';

import { listProjectAttributes } from '@/services/projectService';
import type { ProjectAttributeRecord } from '@/services/projectService';

import {
  filterAttributesForProject,
  normalizeProjectAttributeRecords,
  STTM_PROJECT_ATTRIBUTES_CHANGED_EVENT,
} from './project-attribute-utils';

export function useProjectAttributes(projectId: string | null | undefined) {
  const [attributes, setAttributes] = useState<ProjectAttributeRecord[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const reloadProjectAttributes = useCallback(async () => {
    const normalizedProjectId = projectId?.trim();
    if (!normalizedProjectId) {
      setAttributes([]);
      return;
    }

    setIsLoading(true);
    try {
      const records = await listProjectAttributes(normalizedProjectId);
      setAttributes(
        filterAttributesForProject(
          normalizeProjectAttributeRecords(records, normalizedProjectId),
          normalizedProjectId,
        ),
      );
    } catch {
      setAttributes([]);
    } finally {
      setIsLoading(false);
    }
  }, [projectId]);

  useEffect(() => {
    setAttributes([]);
    void reloadProjectAttributes();
  }, [reloadProjectAttributes]);

  useEffect(() => {
    const normalizedProjectId = projectId?.trim();
    if (!normalizedProjectId) {
      return;
    }

    const handleAttributesChanged = (event: Event) => {
      const detail = (event as CustomEvent<{ projectId?: string }>).detail;
      if (!detail?.projectId || detail.projectId === normalizedProjectId) {
        void reloadProjectAttributes();
      }
    };

    const handleWindowFocus = () => {
      void reloadProjectAttributes();
    };

    window.addEventListener(STTM_PROJECT_ATTRIBUTES_CHANGED_EVENT, handleAttributesChanged);
    window.addEventListener('focus', handleWindowFocus);

    return () => {
      window.removeEventListener(STTM_PROJECT_ATTRIBUTES_CHANGED_EVENT, handleAttributesChanged);
      window.removeEventListener('focus', handleWindowFocus);
    };
  }, [projectId, reloadProjectAttributes]);

  return {
    projectAttributes: attributes,
    isLoadingProjectAttributes: isLoading,
    reloadProjectAttributes,
  };
}
