import json
import logging
import time
from threading import Lock
from typing import Callable, TypeVar

from snowflake.snowpark.functions import col

from app.core.config import Settings
from app.core.exceptions import SnowflakeQueryError
from app.core.snowflake import SnowflakeClient
from app.schema.common import TableRef

logger = logging.getLogger(__name__)
from app.schema.table_selection import (
    ColumnItem,
    DatabaseItem,
    RelationshipColumnMapping,
    RelationshipItem,
    SchemaItem,
    TableAttributes,
    TableItem,
)

_T = TypeVar("_T")
_CACHE_TTL_SECONDS = 300.0
_CACHE_LOCK = Lock()
_CACHE: dict[str, tuple[float, object]] = {}


def _cached(key: str, loader: Callable[[], _T], *, ttl_seconds: float = _CACHE_TTL_SECONDS) -> _T:
    now = time.monotonic()
    with _CACHE_LOCK:
        cached = _CACHE.get(key)
        if cached and cached[0] > now:
            return cached[1]  # type: ignore[return-value]
    value = loader()
    with _CACHE_LOCK:
        _CACHE[key] = (now + ttl_seconds, value)
    return value


class TableSelectionService:
    def __init__(self, client: SnowflakeClient, settings: Settings) -> None:
        self._session = client.session
        self._settings = settings

    @staticmethod
    def _quote_identifier(identifier: str) -> str:
        return '"' + identifier.replace('"', '""') + '"'

    @staticmethod
    def _quote_literal(value: str) -> str:
        return "'" + value.replace("'", "''") + "'"

    @staticmethod
    def _row_value(row, *names: str):
        values = row.as_dict() if hasattr(row, "as_dict") else dict(row)
        for name in names:
            for candidate in (name, name.upper(), name.lower()):
                if candidate in values:
                    return values[candidate]
        return None

    def list_databases(self) -> list[DatabaseItem]:
        return _cached("databases", self._list_databases_uncached)

    def _list_databases_uncached(self) -> list[DatabaseItem]:
        try:
            db_rows = self._session.sql("SHOW TERSE DATABASES").collect()
        except Exception as e:
            raise SnowflakeQueryError(f"Failed to list databases: {e}") from e

        result = []
        for row in db_rows:
            db_name = self._row_value(row, "name", "database_name")
            if not db_name:
                continue
            result.append(
                DatabaseItem(
                    database_name=str(db_name),
                    created=self._row_value(row, "created_on", "created"),
                    schemas=[],
                )
            )
        return sorted(result, key=lambda item: item.database_name)

    def list_schemas(self, db_name: str) -> list[SchemaItem]:
        return _cached(f"schemas:{db_name.upper()}", lambda: self._list_schemas_uncached(db_name))

    def _list_schemas_uncached(self, db_name: str) -> list[SchemaItem]:
        try:
            rows = self._session.sql(
                "SHOW TERSE SCHEMAS IN DATABASE "
                f"{self._quote_identifier(db_name)}"
            ).collect()
        except Exception as e:
            raise SnowflakeQueryError(
                f"Failed to list schemas in {db_name!r}: {e}"
            ) from e

        schemas = []
        for row in rows:
            schema_name = self._row_value(row, "name", "schema_name")
            if not schema_name:
                continue
            schemas.append(
                SchemaItem(
                    schema_name=str(schema_name),
                    created=self._row_value(row, "created_on", "created"),
                )
            )
        return sorted(schemas, key=lambda item: item.schema_name)

    def list_tables(self, db_name: str, schema_name: str) -> list[TableItem]:
        return _cached(
            f"tables:{db_name.upper()}.{schema_name.upper()}",
            lambda: self._list_tables_uncached(db_name, schema_name),
        )

    def _list_tables_uncached(self, db_name: str, schema_name: str) -> list[TableItem]:
        try:
            table_rows = self._session.sql(
                "SHOW TABLES IN SCHEMA "
                f"{self._quote_identifier(db_name)}.{self._quote_identifier(schema_name)}"
            ).collect()
        except Exception as e:
            raise SnowflakeQueryError(
                f"Failed to list tables in {db_name!r}.{schema_name!r}: {e}"
            ) from e

        try:
            column_rows = (
                self._session.table(f"{db_name}.INFORMATION_SCHEMA.COLUMNS")
                .select("TABLE_NAME")
                .filter(col("TABLE_SCHEMA") == schema_name.upper())
                .collect()
            )
        except Exception as e:
            raise SnowflakeQueryError(
                f"Failed to list columns for tables in {db_name!r}.{schema_name!r}: {e}"
            ) from e

        column_count_by_table: dict[str, int] = {}
        for row in column_rows:
            table_name = self._row_value(row, "TABLE_NAME", "table_name")
            if not table_name:
                continue
            key = str(table_name)
            column_count_by_table[key] = column_count_by_table.get(key, 0) + 1

        result: list[TableItem] = []
        for row in table_rows:
            table_name = self._row_value(row, "name", "table_name")
            if not table_name:
                continue
            name = str(table_name)
            row_count = self._row_value(row, "rows", "row_count")
            result.append(
                TableItem(
                    table_name=name,
                    row_count=int(row_count) if row_count is not None else None,
                    column_count=column_count_by_table.get(name, 0),
                )
            )

        return sorted(result, key=lambda item: item.table_name)

    def list_attributes_for_tables(self, qualified_names: list[str]) -> list[TableAttributes]:
        key = "attributes:" + "|".join(sorted(qn.upper() for qn in qualified_names))
        return _cached(key, lambda: self._list_attributes_for_tables_uncached(qualified_names))

    def _list_attributes_for_tables_uncached(self, qualified_names: list[str]) -> list[TableAttributes]:
        from app.core.exceptions import AppValidationError

        result = []
        for qn in qualified_names:
            parts = qn.split(".", 2)
            if len(parts) != 3:
                raise AppValidationError(
                    f"Invalid table reference {qn!r}. Expected format: DATABASE.SCHEMA.TABLE"
                )
            db, schema, table = parts
            columns = self._list_columns(db, schema, table)
            result.append(
                TableAttributes(
                    table=TableRef(database=db, schema=schema, table=table),
                    columns=columns,
                )
            )
        return result

    def list_relationships_for_tables(self, tables: list[TableRef]) -> list[RelationshipItem]:
        key = "relationships:" + "|".join(sorted(table.qualified_name.upper() for table in tables))
        return _cached(key, lambda: self._list_relationships_for_tables_uncached(tables))

    def _list_relationships_for_tables_uncached(self, tables: list[TableRef]) -> list[RelationshipItem]:
        selected = {table.qualified_name.upper(): table for table in tables}
        relationships: dict[str, RelationshipItem] = {}
        logger.info("Relationship lookup for %d tables: %s", len(tables), list(selected.keys()))

        for table in tables:
            payload = self._get_relationship_from_semantic_view(table)
            logger.info("Semantic view for %s: %s", table.qualified_name, "found" if payload else "not found")
            if payload:
                logger.info("  outgoing=%d incoming=%d", len(payload.get("outgoing", [])), len(payload.get("incoming", [])))
            if not payload:
                try:
                    payload = self._get_relationship_payload(table)
                except Exception:
                    continue
                if str(payload.get("status", "")).upper() != "OK":
                    continue

            # Process both outgoing and incoming relationships
            for direction in ["outgoing", "incoming"]:
                for item in payload.get(direction, []) or []:
                    # For outgoing: table is left, target is right
                    # For incoming: target is left, table is right
                    if direction == "outgoing":
                        left_table = table
                        right_table = TableRef(
                            database=table.database,
                            schema=str(item.get("schema", "")),
                            table=str(item.get("table", "")),
                        )
                        left_col_key, right_col_key = "fk_column", "pk_column"
                    else:
                        right_table = table
                        left_table = TableRef(
                            database=table.database,
                            schema=str(item.get("schema", "")),
                            table=str(item.get("table", "")),
                        )
                        left_col_key, right_col_key = "pk_column", "fk_column"

                    # Only include if both tables are selected
                    if left_table.qualified_name.upper() not in selected:
                        continue
                    if right_table.qualified_name.upper() not in selected:
                        continue

                    conditions = [
                        RelationshipColumnMapping(
                            left_column=str(mapping.get(left_col_key, "")),
                            right_column=str(mapping.get(right_col_key, "")),
                        )
                        for mapping in item.get("column_mappings", []) or []
                        if mapping.get(left_col_key) and mapping.get(right_col_key)
                    ]
                    if not conditions:
                        continue

                    constraint_name = (
                        str(item.get("constraint_name"))
                        if item.get("constraint_name") is not None
                        else None
                    )
                    edge_id = constraint_name or f"{left_table.qualified_name}->{right_table.qualified_name}"

                    # Don't overwrite existing relationships (dedup)
                    if edge_id not in relationships:
                        relationships[edge_id] = RelationshipItem(
                            id=edge_id,
                            left_table=left_table,
                            right_table=right_table,
                            constraint_name=constraint_name,
                            conditions=conditions,
                        )

        return list(relationships.values())

    def _get_relationship_from_semantic_view(self, table: TableRef) -> dict | None:
        """Fetch relationships from SEM_TABLE_VIEWS semantic_model.

        Extracts FK references from two locations:
        1. SEMANTIC_VIEW:semantic_model:relationships (top-level, if present)
        2. SEMANTIC_VIEW:semantic_model:attributes[].constraints (FK refs in column metadata)
        """
        try:
            fqn = table.qualified_name.upper()
            sem_table = self._settings.resolved_semantic_views_table
            base_query = (
                f"SELECT SEMANTIC_VIEW:semantic_model:relationships as RELATIONSHIPS, "
                f"       SEMANTIC_VIEW:semantic_model:attributes as ATTRIBUTES "
                f"FROM {{table}} "
                f"WHERE FQN = {self._quote_literal(fqn)} AND STATUS IN ('ACTIVE', 'PENDING') "
                f"ORDER BY GENERATED_AT DESC LIMIT 1"
            )
            rows = self._session.sql(base_query.format(table=sem_table)).collect()
            if not rows:
                meta_sem_table = self._settings.qualify_table_name("SEM_TABLE_VIEWS")
                if meta_sem_table != sem_table:
                    try:
                        rows = self._session.sql(base_query.format(table=meta_sem_table)).collect()
                    except Exception:
                        pass
            if not rows:
                logger.debug("No ACTIVE semantic view found for %s", fqn)
                return None

            # Try top-level relationships first
            raw_rels = rows[0]["RELATIONSHIPS"]
            if raw_rels:
                if isinstance(raw_rels, str):
                    raw_rels = json.loads(raw_rels)
                if isinstance(raw_rels, dict) and (raw_rels.get("outgoing") or raw_rels.get("incoming")):
                    return raw_rels

            # Extract FK relationships from attributes constraints
            raw_attrs = rows[0]["ATTRIBUTES"]
            if isinstance(raw_attrs, str):
                raw_attrs = json.loads(raw_attrs)
            if not isinstance(raw_attrs, list):
                return None

            outgoing = []
            for attr in raw_attrs:
                if not isinstance(attr, dict):
                    continue
                col_name = attr.get("name", "")
                for constraint in attr.get("constraints", []):
                    if not isinstance(constraint, dict):
                        continue
                    if constraint.get("type") != "FOREIGN_KEY":
                        continue
                    confidence = (constraint.get("confidence") or "LOW").upper()
                    if confidence not in ("HIGH", "MEDIUM"):
                        continue
                    refs = constraint.get("references", {})
                    ref_table = refs.get("table", "")
                    ref_col = refs.get("column", "")
                    if not ref_table or not ref_col:
                        continue
                    outgoing.append({
                        "schema": table.schema,
                        "table": ref_table,
                        "constraint_name": f"FK_{col_name}_{ref_table}_{ref_col}",
                        "column_mappings": [
                            {"fk_column": col_name, "pk_column": ref_col}
                        ],
                    })

            if not outgoing:
                return None
            return {"status": "OK", "outgoing": outgoing, "incoming": []}
        except Exception:
            return None

    def _list_columns(self, db_name: str, schema_name: str, table_name: str) -> list[ColumnItem]:
        primary_key_columns = self._primary_key_columns(db_name, schema_name, table_name)
        foreign_key_columns = self._foreign_key_columns(db_name, schema_name, table_name)
        try:
            rows = (
                self._session.table(f"{db_name}.INFORMATION_SCHEMA.COLUMNS")
                .select(
                    "COLUMN_NAME",
                    "DATA_TYPE",
                    "IS_NULLABLE",
                    "ORDINAL_POSITION",
                    "COMMENT",
                )
                .filter(
                    (col("TABLE_SCHEMA") == schema_name.upper())
                    & (col("TABLE_NAME") == table_name.upper())
                )
                .sort("ORDINAL_POSITION")
                .collect()
            )
        except Exception as e:
            raise SnowflakeQueryError(
                f"Failed to list columns in {db_name!r}.{schema_name!r}.{table_name!r}: {e}"
            ) from e
        return [
            ColumnItem(
                column_name=r["COLUMN_NAME"],
                data_type=r["DATA_TYPE"],
                is_nullable=r["IS_NULLABLE"],
                ordinal_position=r["ORDINAL_POSITION"],
                comment=r["COMMENT"],
                is_primary_key=r["COLUMN_NAME"] in primary_key_columns,
                is_foreign_key=r["COLUMN_NAME"] in foreign_key_columns,
            )
            for r in rows
        ]

    def _primary_key_columns(
        self,
        db_name: str,
        schema_name: str,
        table_name: str,
    ) -> set[str]:
        try:
            rows = self._session.sql(
                "SHOW PRIMARY KEYS IN TABLE "
                f"{self._quote_identifier(db_name)}."
                f"{self._quote_identifier(schema_name)}."
                f"{self._quote_identifier(table_name)}"
            ).collect()
        except Exception:
            return set()

        return {
            str(column_name)
            for row in rows
            if (column_name := self._row_value(row, "column_name", "COLUMN_NAME"))
        }

    def _foreign_key_columns(
        self,
        db_name: str,
        schema_name: str,
        table_name: str,
    ) -> set[str]:
        try:
            rows = self._session.sql(
                "SHOW IMPORTED KEYS IN TABLE "
                f"{self._quote_identifier(db_name)}."
                f"{self._quote_identifier(schema_name)}."
                f"{self._quote_identifier(table_name)}"
            ).collect()
        except Exception:
            return set()

        return {
            str(column_name)
            for row in rows
            if (
                column_name := self._row_value(
                    row,
                    "fk_column_name",
                    "FK_COLUMN_NAME",
                    "column_name",
                    "COLUMN_NAME",
                )
            )
        }

    def _get_relationship_payload(self, table: TableRef) -> dict:
        proc_name = self._settings.resolved_relationships_procedure
        if not proc_name:
            raise SnowflakeQueryError(
                "Could not resolve the table relationship procedure. "
                "Set SNOWFLAKE_RELATIONSHIPS_PROCEDURE or provide "
                "SNOWFLAKE_DATABASE/SNOWFLAKE_SCHEMA."
            )

        proc_parts = proc_name.split(".", 2)
        quoted_proc_name = ".".join(
            self._quote_identifier(part) for part in proc_parts if part
        )
        try:
            rows = self._session.sql(
                "CALL "
                f"{quoted_proc_name}("
                f"{self._quote_literal(table.database)}, "
                f"{self._quote_literal(table.schema)}, "
                f"{self._quote_literal(table.table)})"
            ).collect()
        except Exception as e:
            raise SnowflakeQueryError(
                f"Failed to fetch table relationships for {table.qualified_name!r}: {e}"
            ) from e

        if not rows:
            return {}

        raw_result = list(rows[0].as_dict().values())[0]
        if isinstance(raw_result, dict):
            return raw_result
        if isinstance(raw_result, str):
            try:
                return json.loads(raw_result)
            except json.JSONDecodeError:
                return {}
        return raw_result or {}
