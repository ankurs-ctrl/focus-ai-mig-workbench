-- Apply in the configured metadata database/schema after the control-plane migration.
-- Backfill search identity only. Preserve payloads, approval, trust and status.
UPDATE TBL_AGENT_LEARNINGS
SET SUBJECT_TYPE = COALESCE(SUBJECT_TYPE, CASE
      WHEN LEARNING_TYPE = 'table_relationship' THEN 'relationship'
      WHEN LEARNING_TYPE = 'cte_lineage' THEN 'derived_source'
      ELSE LEARNING_TYPE END),
    SUBJECT_KEY = CONCAT(LEARNING_TYPE, ':',
      UPPER(COALESCE(ATTRIBUTES:target_table::STRING, LEARNING_KEY, LEARNING_ID)), ':',
      SHA2(TO_JSON(ATTRIBUTES), 256)),
    CLAIM_KEY = COALESCE(CLAIM_KEY, LEARNING_TYPE)
WHERE SUBJECT_KEY IS NULL
  AND ATTRIBUTES IS NOT NULL
  AND LEARNING_TYPE IN ('table_relationship', 'cte_lineage', 'source_selection_pattern',
                       'mapping_dependency', 'column_dependency');
