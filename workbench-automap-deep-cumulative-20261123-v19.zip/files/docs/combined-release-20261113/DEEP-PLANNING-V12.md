# Deep Agent planning and specialist handoff — V12

V12 preserves the cumulative V11 overlay, Deep Agent, PR #63 and the earlier Auto-map, SQL-upload, publication, administration and OAuth work. Apply the final versioned overlay at the repository root, preserving all environment files and credentials. Matching frontend, API and worker code must be deployed together.

## Changes

- Keep verified conversation evidence across follow-up turns. Only successful retained tool evidence grants discovery/contract reuse; failed searches do not establish object absence.
- Parse the requested target separately from named supporting sources, and distinguish cancellation from instructions such as “stop at plan approval.”
- Make the actual provider-bound plan schema include source preparation, approved Values, execution steps and project decisions. LangChain's tool-call subset conversion discarded the previous Field.json_schema_extra contract. The schema is now annotation metadata, with regression coverage of the real StructuredTool-to-provider conversion.
- Retain the complete prepared candidate in server-owned run state. The model can submit its current-run reference and changed fields; the backend materializes and validates the entire plan. References are run-scoped, reject stale/foreign candidates and remain stable when Snowflake VARIANT normalizes integral JSON floats. Arrays supplied as changes replace complete arrays; source_preparation and auto_map merge at one level.
- Make large JSON tool evidence pageable before Deep Agent virtual-filesystem offload. Preserve complete values, SQL and citations instead of repeatedly reading a truncated minified line. Mark legacy clipped pages incomplete, and deduplicate repeated complete tool records.
- Preserve the latest checkpoint head when LangGraph reads older parent checkpoints to reconstruct delta channels. Historical reads cannot rewind the run head.
- Preserve pending plan evidence during process restart without marking it validated. Resume supplies the current run reference; validation and immutable Plan-mode approval still apply.
- Bound idle planning decisions with the existing submission allowance. A focused planning call requests the structured validation tool and compact changes rather than re-emitting unchanged evidence. Transport diagnostics record safe exception categories and stream counters without request bodies or credentials.
- Send every custom scalar expression through AGT_TRANSFORMATION_RULE, including source-agent SQL, conversions, CASE, column-plus-Value and Value-only expressions. Constants, direct columns and direct approved Values skip the specialist. Preserve NL intent for rule generation.
- Keep full-width transcript scrolling, working-plan steps, formatted findings and the restored Quick/Deep navigation. No test reports, diagnostic payloads or fixture responses are injected into the application UI.

## Agent capabilities

Deep is the orchestration owner. It uses its registered Workbench capabilities for catalog discovery, contract inspection, stored semantics, FIR and precedent retrieval, Cortex Search/RAG, Cortex Analyst, bounded read-only SQL, source preparation, mapping and draft persistence. AGT_STTM_BUILDER remains the separate Quick Agent orchestrator; Deep does not invoke a second orchestration agent. Its mapping workflow calls AGT_SOURCE_MAPPING and AGT_TRANSFORMATION_RULE through the configured specialist adapter.

The native RAG/Analyst smoke check returned five citations in 1.007 seconds, Analyst SQL in 20.499 seconds and three bounded preview rows. These checks prove those capabilities are callable; they are not a complete plan-to-draft acceptance.

## Deployment

1. Preserve client.env and existing secrets. This change introduces no environment variable, metadata table, context increase, execution slot or additional OAuth login.
2. Run the normal metadata bootstrap. As documented in V11, it includes the existing 20260929_deep_run_knowledge.sql migration, qualifies the configured namespace and validates the knowledge-table contract without replacing saved research.
3. Build matching frontend, API and Deep-worker images. These Deep supervisor instructions and tool schemas ship in the worker image; no new Snowflake agent-spec installation is introduced by V12. Retain earlier source/transformation agent-spec deployment prerequisites.
4. Keep worker housekeeping on service identity and user execution on the initiating delegated OAuth identity. Restart at a safe boundary. Do not replay uncertain calls or failed client incidents.
5. Locally use ./start-ai-workbench.sh for localhost:3000 and localhost:8000. Start the Deep worker with APP_ENV=local bash scripts/start_deep_worker_local.sh. Diagnostic wrappers used during development are excluded from the overlay.

## Verification and limits

See DEEP-PLANNING-V12-RESULTS.json for the final regression counts and native acceptance outcome. Failed native attempts are not counted as successful mapping tests. Discovery verified the four actual Loan Income/NOTE/PORTAL_USER_HISTORY objects in 9.379 seconds; the model must adapt current columns rather than copy old fixture assumptions.

The exact FIR lookup returned zero cards for this fixture. Two useful historical SQL precedents were drafts; neither must be described as published FIR. The full workbook contains business conditions not all represented by these fixtures, so sample-value checks do not establish complete business parity.

No new final-image SPCS concurrency acceptance has been completed. Earlier Auto-map timing limits still apply: the prior V10 200-second acceptance gate was not met. This release does not claim a universal completion-time guarantee. The local Deep model is configured with a 90-second read timeout; an exact diagnostic model-only replay returned a complete streamed tool response in 128 seconds, while a non-streamed replay timed out at 120 seconds. Compact submission is tested separately; that replay executed no tools and created no draft.

Changes are working-tree changes until explicitly committed/pushed. ZIP reconstruction and file hashes do not imply CodeCommit synchronization or SPCS deployment.
