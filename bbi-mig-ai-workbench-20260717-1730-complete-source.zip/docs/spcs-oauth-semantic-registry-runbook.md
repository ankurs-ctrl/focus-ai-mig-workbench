# SPCS OAuth, Cortex Dispatch, and Semantic Registry Runbook

## Final architecture

The browser signs in through `STTM_BUILDER_LOCAL_OAUTH`. The backend stores the
user's encrypted access/refresh tokens and uses the refreshed access token for
every Cortex Agent or Cortex Analyst REST request. `AGT_STTM_BUILDER` remains the
routing orchestrator; backend-dispatched Analyst and Auto-map calls avoid nested
SPCS caller-token failures.

Semantic generation is outside the application request path:

1. The scheduled pipeline invokes `AGT_SEMANTIC_MODEL_V2`.
2. The agent profiles source data with the owner-rights tools in
   `FOCUS_DB_2.STTM_MCP` and calls the workbench `SP_SAVE_SEMANTIC_VIEW` tool.
3. The publisher calls `SP_PUBLISH_SEMANTIC_ASSET` to validate the canonical
   result and prepare deterministic YAML.
4. The pipeline verifies and creates/replaces the semantic view with top-level
   `SYSTEM$CREATE_SEMANTIC_VIEW_FROM_YAML` calls, then calls
   `SP_LINK_PHYSICAL_SEMANTIC_VIEW` with the expected registry version.
5. Chat and Auto-map only read `TBL_SEMANTIC_MODELS`, `SEM_TABLE_VIEWS`, and
   `SEM_COLUMN_VIEWS`. Missing assets return `SEMANTIC_ASSET_NOT_FOUND`.

Snowflake's YAML publisher supports a verify-only call and replaces an existing
view while copying its grants. It requires schema access, `CREATE SEMANTIC VIEW`,
source-object `SELECT`, and ownership of an existing view being replaced. See
[SYSTEM$CREATE_SEMANTIC_VIEW_FROM_YAML](https://docs.snowflake.com/en/sql-reference/stored-procedures/system_create_semantic_view_from_yaml).

## Why OAuth originally failed

Three separate failures appeared during the repair:

1. The authorization redirect worked, but the token endpoint returned
   `invalid_client` only inside SPCS. The service had not enabled
   `capabilities.securityContext.enableCustomCredentials`; its default is false.
   Custom OAuth credentials therefore could not be used correctly in the
   container.
2. A deployment rendered the local callback (`localhost:3000`) into the SPCS
   service. Snowflake correctly redirected to the registered URI it received.
   The renderer now rejects a custom-OAuth SPCS callback unless it is public
   HTTPS and non-loopback.
3. Login succeeded, but Cortex Agent calls still used the SPCS ingress/caller
   token. Cortex REST rejected that token with `401/395090`. Agent and Analyst
   REST clients now use the signed-in user's refreshed OAuth bearer token.

The service keeps both `executeAsCaller: true` and
`enableCustomCredentials: true`. Caller rights remain useful for SPCS ingress
and connector behavior; user OAuth is the credential used for Cortex REST.
Snowflake describes custom-credential requirements in
[SPCS SQL execution](https://docs.snowflake.com/en/developer-guide/snowpark-container-services/spcs-execute-sql)
and the client integration in
[custom OAuth](https://docs.snowflake.com/en/user-guide/oauth-custom).

## OAuth configuration that is required

- A Snowflake security integration with authorization-code and refresh-token
  grants, the intended role scope, and PKCE enabled after the PKCE-capable build
  is deployed.
- The exact SPCS callback, for example
  `https://<service-endpoint>/api/v1/auth/callback`, in the integration's allowed
  redirect list. A local callback may remain as an additional allowed URI for
  development.
- A password-type Snowflake secret for the OAuth client credentials. `username`
  maps to `SNOWFLAKE_OAUTH_CLIENT_ID`; `password` maps to
  `SNOWFLAKE_OAUTH_CLIENT_SECRET`.
- A separate password-type secret for the state-signing and token-encryption
  keys.
- Service `READ` grants on both secrets, the egress integration for the account
  token/Cortex endpoints, and `enableCustomCredentials: true`.
- Snowflake Connector `>=4.5.0,<5`.

The token client sends credentials only through HTTP Basic authentication. It
does not retry with form-body credentials. PKCE verifier/challenge, signed state,
secure HttpOnly cookies, refresh rotation, and sanitized envelope `1.0` errors
are enforced. Logs contain request IDs and credential fingerprints, never codes,
tokens, or secrets.

Do not render `SNOWFLAKE_ACCOUNT`, `SNOWFLAKE_HOST`, client secrets, or session
keys into SPCS YAML. Snowflake supplies the runtime account/host; secret mappings
inject credentials at container start.

## Redirect behavior on redeploy

The redirect is tied to the public endpoint hostname, not to an image or service
revision. Rebuilding or altering a service at the same endpoint needs no OAuth
integration change. Creating a new service, renaming it, changing account/region,
or receiving a different public endpoint does require adding the new exact
callback URI to the integration and setting `SNOWFLAKE_OAUTH_REDIRECT_URI` to it.
Keep the old URI only while the old deployment must remain usable.

## Registry ownership and privileges

Canonical storage is
`FFP_HDP_CRM_MIG_DB_DEV.SCH_STTM_METADATA`:

- `SEM_TABLE_VIEWS`: immutable table-level version history and active pointer.
- `SEM_COLUMN_VIEWS`: immutable column versions associated with a table version.
- `TBL_SEMANTIC_MODELS`: canonical read model used by the application.

`SP_GET_SEMANTIC_ASSET` is the read interface. `SP_PATCH_SEMANTIC_ASSET` requires
producer, request ID, change reason, and `expected_view_id`; a stale writer gets
`VERSION_CONFLICT`. `SP_PUBLISH_SEMANTIC_ASSET` validates exact physical columns,
so a stale model cannot overwrite a changed table. Application roles get only
database/schema usage, table select, and the getter. Generator/approved agent
roles get procedure usage but no direct table DML.

The generator role also needs `USAGE` on every source database/schema and
`SELECT` on tables it is authorized to profile. Without these grants the agent
returns `DATABASE_NOT_ACCESSIBLE`, even when the registry staleness check itself
succeeds.

## Runtime semantic composition

The UI envelope contains exact source FQNs, target FQN, derived-source IDs, and
selected relationships. The backend resolves every exact saved asset. A
single-table Analyst request uses its saved physical semantic view. A multi-table
request composes one in-memory YAML model containing source and target tables plus
the selected relationships; passing several independent models would not express
one joined model. The request path performs no generation, staleness check,
promotion, DDL, or registry write. See the
[Cortex Analyst REST API](https://docs.snowflake.com/en/user-guide/snowflake-cortex/cortex-analyst/rest-api).

Derived queries follow the same lifecycle: materialize the saved query once,
enqueue `AGT_SEMANTIC_MODEL_V2`, and publish the derived asset. Until publication,
the application reports the asset as missing rather than generating it inline.

## Auto-map service

The web service partitions the ordered target attributes into batches and sends
up to two batches concurrently to the private `WORKBENCH_AUTOMAP_DEV` endpoint.
The refreshed user OAuth token is forwarded only in the private
`X-Workbench-OAuth-Access-Token` header. It is never included in the envelope.
The worker invokes `AGT_SOURCE_MAPPING` with the same resolved compact source and
target semantic context. Responses are merged by original batch order and remain
contract envelope `1.0`.

## Client deployment checklist

1. Create registry tables and the save/get/publish/link/patch procedures.
2. Create the OAuth integration, two password secrets, network rule/integration,
   external-access integration, and OAuth session table.
3. Grant the pipeline/agent role source metadata access and controlled procedure
   usage; grant application roles registry reads only.
4. Rebind `AGT_SEMANTIC_MODEL_V2` persistence tools to the client registry while
   retaining profiling/relationship tools in the profiling schema.
5. Publish initial semantics for every selectable physical table before enabling
   the app for users.
6. Deploy the Auto-map compute pool with two nodes and private service role, then
   deploy the web service with the private worker URL.
7. Complete incognito login, session/context checks, general orchestrator chat,
   Analyst-routed chat, Auto-map, refresh, logout, and query-history validation.
8. Enable enforced PKCE only after the PKCE-capable service revision is live.

