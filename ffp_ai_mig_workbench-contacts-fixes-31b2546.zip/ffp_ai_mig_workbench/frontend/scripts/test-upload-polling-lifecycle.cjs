const assert=require('node:assert/strict'),fs=require('fs'),path=require('path'),ts=require('typescript'),Module=require('module');
const file=path.resolve(__dirname,'../src/features/sttm/mapping/sql-bundle-review-panel.tsx');
const ast=ts.createSourceFile(file,fs.readFileSync(file,'utf8'),ts.ScriptTarget.Latest,true);
let effect;
function visit(n){if(ts.isCallExpression(n)&&n.expression.getText(ast)==='useEffect'&&n.arguments[0]?.getText(ast).includes('const deadlineTimer'))effect=n.arguments[0].getText(ast);ts.forEachChild(n,visit);}visit(ast);assert.ok(effect);
async function probe(mode){
 let now=0,id=0,refs=0,status=0,warnings=[],results=[];const timers=new Map();
 const later=(fn,ms)=>{timers.set(++id,{fn,time:now+ms});return id;};
 const timeout=ms=>{const c=new AbortController();later(()=>c.abort(),ms);return c.signal;};
 const fetch=async(url,options)=>{
  const isStatus=url.includes('/requests/');isStatus?status++:refs++;
  if(mode==='auth')return {ok:false,status:401};
  if((mode==='status-hang'&&isStatus)||(mode==='references-hang'&&!isStatus))return new Promise((resolve,reject)=>options.signal.addEventListener('abort',()=>reject(new Error('timeout')),{once:true}));
  if(mode==='server')return {ok:false,status:500};
  return {ok:true,status:200,json:async()=>({status:'ready',table_references:[{catalog_status:'available'}]})};
 };
 const m=new Module(file,module);m._compile(ts.transpileModule(`module.exports = c => {const {projectId,result,AbortController,AbortSignal,Date,setTimeout,clearTimeout,fetch,resolveApiBaseUrl,API_ROUTES,setReferenceWarning,setTableReferences,onReferencesChangeRef}=c; return (${effect})();};`,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText,file);
 const cleanup=m.exports({projectId:'501',result:{asset_id:'asset',upload_request_id:'request'},AbortController,
  AbortSignal:{any:AbortSignal.any.bind(AbortSignal),timeout},Date:{now:()=>now},setTimeout:later,clearTimeout:key=>timers.delete(key),fetch,
  resolveApiBaseUrl:()=>'',API_ROUTES:{upload:{sqlReferences:()=>'/references'}},setReferenceWarning:x=>warnings.push(x),setTableReferences:x=>results.push(x),onReferencesChangeRef:{current:()=>{}}});
 const settle=async()=>{for(let i=0;i<15;i++)await Promise.resolve();};await settle();
 if(mode==='unmount'){cleanup();await settle();assert.equal(results.length,1);return;}
 for(let i=0;i<100&&timers.size;i++){
  const [key,timer]=[...timers].sort((a,b)=>a[1].time-b[1].time)[0];timers.delete(key);now=timer.time;timer.fn();await settle();
  if(now>=60000)break;
 }
 if(['status-hang','references-hang','server'].includes(mode))assert.ok(warnings.some(x=>x&&/timed out|not completed/.test(x)),mode);
 if(mode==='status-hang')assert.equal(refs,0);
 if(mode==='auth')assert.equal(refs,0);
 assert.ok(now<=60000);cleanup();
}
(async()=>{for(const mode of ['status-hang','references-hang','server','auth','unmount'])await probe(mode);console.log('Reference observation is bounded during stalled requests, server/auth errors and cleanup.');})().catch(e=>{console.error(e);process.exitCode=1});
