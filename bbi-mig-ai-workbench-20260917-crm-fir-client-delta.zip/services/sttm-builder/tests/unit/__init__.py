"""Unit-test package namespace.

Keeping unit and integration tests in distinct package namespaces prevents
same-named test folders (for example ``fir_system``) from colliding during a
full pytest collection.
"""
