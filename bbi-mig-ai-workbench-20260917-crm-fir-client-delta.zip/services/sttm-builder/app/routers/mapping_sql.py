import re
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Request

from app.api.deps import (
    get_mapping_sql_execution_service,
    get_mapping_sql_service,
)
from app.core.exceptions import AppValidationError, SnowflakeQueryError
from app.core.mapping_sql import MappingSqlService
from app.schema.contracts import ApiRequestEnvelope, ApiResponseEnvelope, ApiWarning, build_response_envelope
from app.schema.mapping_sql import (
    MappingSqlCompileRequest,
    MappingSqlCompileResponse,
    MappingSqlParseRequest,
    MappingSqlParseResponse,
    MappingSqlPreviewRequest,
    MappingSqlPreviewResponse,
    MappingSqlReviewRequest,
    MappingSqlReviewResponse,
)

router = APIRouter(prefix="/workbench/mapping-sql", tags=["Mapping SQL"])


@router.post("/compile", response_model=ApiResponseEnvelope[MappingSqlCompileResponse])
def compile_mapping_sql(
    body: ApiRequestEnvelope[MappingSqlCompileRequest] | MappingSqlCompileRequest,
    request: Request,
    service: Annotated[
        MappingSqlService,
        Depends(get_mapping_sql_execution_service),
    ],
) -> ApiResponseEnvelope[MappingSqlCompileResponse]:
    if isinstance(body, MappingSqlCompileRequest):
        payload, request_id, actor, context = body, None, None, {}
    else:
        payload, request_id, actor, context = body.data, body.request_id, body.actor, body.context
    try:
        result = service.compile(payload)
    except ValueError as exc:
        message = str(exc)
        field = "relation_graph"
        error_type = "invalid_relation_graph"
        if "dependency" in message.lower() or "mapping expression" in message.lower():
            field = "mappings.source_dependencies"
            error_type = "missing_mapping_dependency"
        elif "placeholder" in message.lower() or "value binding" in message.lower():
            field = "relation_graph.value_bindings"
            error_type = "unresolved_value_binding"
        elif "join" in message.lower() or "disconnected" in message.lower():
            field = "relation_graph.edges"
            error_type = "missing_or_disconnected_join"
        target_match = re.search(r"\(target:\s*([^\)]+)\)", message, flags=re.IGNORECASE)
        detail = {
            "field": field,
            "message": message,
            "error_type": error_type,
            "recommended_action": (
                "Reconcile the affected mapping against the current selected relation graph."
                if error_type == "missing_mapping_dependency"
                else "Add or approve a verified relationship connecting the required relations."
                if error_type == "missing_or_disconnected_join"
                else "Resolve the reported compiler input before validating SQL."
            ),
        }
        if target_match:
            detail["affected_target_column"] = target_match.group(1).strip()
        raise AppValidationError(
            message,
            details=[detail],
        ) from exc
    return build_response_envelope(
        operation="mapping_sql.compile",
        request=request,
        request_id=request_id,
        actor=actor,
        context=context,
        warnings=[
            ApiWarning(code="MAPPING_SQL_WARNING", message=warning)
            for warning in result.warnings
        ],
        data=result,
    )


@router.post("/parse", response_model=ApiResponseEnvelope[MappingSqlParseResponse])
def parse_mapping_sql(
    body: ApiRequestEnvelope[MappingSqlParseRequest] | MappingSqlParseRequest,
    request: Request,
    service: Annotated[MappingSqlService, Depends(get_mapping_sql_service)],
) -> ApiResponseEnvelope[MappingSqlParseResponse]:
    if isinstance(body, MappingSqlParseRequest):
        payload, request_id, actor, context = body, None, None, {}
    else:
        payload, request_id, actor, context = body.data, body.request_id, body.actor, body.context
    result = service.parse(payload)
    return build_response_envelope(
        operation="mapping_sql.parse",
        request=request,
        request_id=request_id,
        actor=actor,
        context=context,
        warnings=result.warnings,
        data=result,
    )


@router.post("/review", response_model=ApiResponseEnvelope[MappingSqlReviewResponse])
def review_mapping_sql(
    body: ApiRequestEnvelope[MappingSqlReviewRequest] | MappingSqlReviewRequest,
    request: Request,
    service: Annotated[
        MappingSqlService,
        Depends(get_mapping_sql_execution_service),
    ],
) -> ApiResponseEnvelope[MappingSqlReviewResponse]:
    if isinstance(body, MappingSqlReviewRequest):
        payload = body
        request_id = None
        actor = None
        context: dict[str, object] = {}
        warnings = []
        meta: dict[str, object] = {}
    else:
        payload = body.data
        request_id = body.request_id
        actor = body.actor
        context = body.context
        warnings = body.warnings
        meta = body.meta

    try:
        result = service.review(payload)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    return build_response_envelope(
        operation="mapping_sql.review",
        request=request,
        request_id=request_id,
        actor=actor,
        context=context,
        warnings=warnings,
        meta=meta,
        data=result,
    )


@router.post("/preview", response_model=ApiResponseEnvelope[MappingSqlPreviewResponse])
def preview_mapping_sql(
    body: ApiRequestEnvelope[MappingSqlPreviewRequest] | MappingSqlPreviewRequest,
    request: Request,
    service: Annotated[
        MappingSqlService,
        Depends(get_mapping_sql_execution_service),
    ],
) -> ApiResponseEnvelope[MappingSqlPreviewResponse]:
    if isinstance(body, MappingSqlPreviewRequest):
        payload = body
        request_id = None
        actor = None
        context: dict[str, object] = {}
        warnings = []
        meta: dict[str, object] = {}
    else:
        payload = body.data
        request_id = body.request_id
        actor = body.actor
        context = body.context
        warnings = body.warnings
        meta = body.meta

    try:
        result = service.preview(payload)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise SnowflakeQueryError(
            "Snowflake could not run the mapping preview SQL: "
            f"{MappingSqlService._summarize_sql_error(exc)}"
        ) from exc

    return build_response_envelope(
        operation="mapping_sql.preview",
        request=request,
        request_id=request_id,
        actor=actor,
        context=context,
        warnings=warnings,
        meta=meta,
        data=result,
    )
