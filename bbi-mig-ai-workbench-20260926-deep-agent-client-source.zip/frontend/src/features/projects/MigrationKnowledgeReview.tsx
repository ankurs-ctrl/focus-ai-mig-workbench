"use client";
import { useEffect, useRef, useState } from "react";
import { getApiData, postApiData } from "@/api/axiosInstance";

type Note = {
  learning_id: string; summary: string; kind: string; approval_status: string;
  revision: number; structured_rule: Record<string, unknown>; evidence_ids: string[];
  origin_document: string; document_version: string; reviewed_by?: string;
  superseded_by?: string;
};

export default function MigrationKnowledgeReview({ projectId }: { projectId: string }) {
  const [open, setOpen] = useState(false);
  const [notes, setNotes] = useState<Note[]>([]);
  const [canReview, setCanReview] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [transcript, setTranscript] = useState("");
  const [documentName, setDocumentName] = useState("");
  const [documentVersion, setDocumentVersion] = useState("");
  const [semanticVersion, setSemanticVersion] = useState("");
  const [contractVersion, setContractVersion] = useState("");
  const [evidenceId, setEvidenceId] = useState("");
  const [nextOffset, setNextOffset] = useState<number | null>(0);
  const [notice, setNotice] = useState("");
  const operationBusy = useRef(false);
  const generation = useRef(0);
  useEffect(() => {
    setTranscript(""); setDocumentName(""); setDocumentVersion("");
    setSemanticVersion(""); setContractVersion(""); setEvidenceId("");
    setNextOffset(0); setNotice(""); operationBusy.current = false;
  }, [projectId]);
  useEffect(() => {
    const current = ++generation.current;
    operationBusy.current = false;
    if (!open) return;
    const abort = new AbortController();
    setBusy(true); setError(""); setNotes([]);
    getApiData<{ notes: Note[]; can_review: boolean }>(
      `/v1/migration-knowledge/notes?project_id=${encodeURIComponent(projectId)}`, { signal: abort.signal },
    ).then(result => {
      if (generation.current !== current) return;
      setNotes(result.notes); setCanReview(result.can_review);
    }).catch((cause: unknown) => {
      if (!abort.signal.aborted && generation.current === current) setError(cause instanceof Error ? cause.message : "Unable to load learning review.");
    }).finally(() => { if (generation.current === current) setBusy(false); });
    return () => { abort.abort(); generation.current++; };
  }, [open, projectId]);

  async function review(note: Note, decision: "submit" | "approve" | "reject") {
    const current = generation.current;
    setBusy(true); setError("");
    try {
      const updated = await postApiData<unknown, Note>(`/v1/migration-knowledge/notes/${encodeURIComponent(note.learning_id)}/review`, {
        project_id: projectId, decision, expected_revision: note.revision,
      });
      if (current === generation.current) setNotes(values => values.map(value => value.learning_id === updated.learning_id ? updated : value));
    } catch (cause) {
      if (current === generation.current) setError(cause instanceof Error ? cause.message : "Review failed. Refresh to check the current revision.");
    } finally { if (current === generation.current) setBusy(false); }
  }

  async function extractNotes() {
    if (operationBusy.current) return;
    operationBusy.current = true;
    const current = generation.current;
    setBusy(true); setError("");
    try {
      let id = evidenceId;
      if (!id) {
        const stored = await postApiData<unknown, { evidence_id: string }>("/v1/migration-knowledge/transcripts", {
          project_id: projectId, meeting_id: documentName.trim(), document_version: documentVersion.trim(), text: transcript,
        });
        if (current !== generation.current) return;
        id = stored.evidence_id; setEvidenceId(id);
      }
      const result = await postApiData<unknown, { notes: Note[]; next_offset: number | null }>("/v1/migration-knowledge/extract", {
        project_id: projectId, evidence_id: id, offset: nextOffset ?? 0,
        semantic_version: semanticVersion.trim(), contract_version: contractVersion.trim(),
      });
      if (current !== generation.current) return;
      setNotes(values => Array.from(new Map([...values, ...result.notes].map(note => [note.learning_id, note])).values()));
      setNextOffset(result.next_offset);
      setNotice(result.next_offset === null ? "Extraction complete. Review each candidate before approval." : "This section is extracted. Continue to process the next section.");
    } catch (cause) {
      if (current === generation.current) setError(cause instanceof Error ? cause.message : "Extraction failed. Retry resumes the saved evidence.");
    } finally {
      if (current === generation.current) {
        operationBusy.current = false;
        setBusy(false);
      }
    }
  }
  return <section className="my-4 rounded-xl border bg-white p-4" aria-label="Migration learning review">
    <button type="button" aria-expanded={open} onClick={() => setOpen(value => !value)} className="font-semibold">Migration learning review</button>
    {open && <div className="mt-3 space-y-3">
      <p className="text-sm text-slate-600">Review extracted rules and their evidence before they become reusable business knowledge.</p>
      {error && <p role="alert" className="text-red-700">{error}</p>}
      {busy && <p role="status">Loading…</p>}
      <details className="rounded border p-3"><summary>Add transcript evidence</summary>
        <p className="my-2 text-sm">The original text is preserved. Extracted notes stay unapproved until business review. Bind them to the semantic and contract versions where they apply.</p>
        <fieldset disabled={busy || Boolean(evidenceId)} className="grid gap-2">
          <label>Document name<input className="block w-full rounded border p-2" value={documentName} onChange={e => setDocumentName(e.target.value)} /></label>
          <label>Document version<input className="block w-full rounded border p-2" value={documentVersion} onChange={e => setDocumentVersion(e.target.value)} /></label>
          <label>Semantic version<input className="block w-full rounded border p-2" value={semanticVersion} onChange={e => setSemanticVersion(e.target.value)} /></label>
          <label>Contract version<input className="block w-full rounded border p-2" value={contractVersion} onChange={e => setContractVersion(e.target.value)} /></label>
          <label>Transcript text<textarea className="block min-h-40 w-full rounded border p-2" maxLength={2000000} value={transcript} onChange={e => setTranscript(e.target.value)} /></label>
        </fieldset>
        <button className="mt-2 rounded border px-3 py-2" disabled={busy || nextOffset === null || !transcript.trim() || !documentName.trim() || !documentVersion.trim() || !semanticVersion.trim() || !contractVersion.trim()} onClick={extractNotes}>
          {evidenceId ? "Continue extraction" : "Save evidence and extract candidates"}
        </button>
        {evidenceId && <button disabled={busy} className="ml-3" onClick={() => { setEvidenceId(""); setNextOffset(0); setTranscript(""); setNotice(""); }}>Add another document</button>}
        {notice && <p role="status" className="mt-2 text-sm">{notice}</p>}
      </details>
      {!busy && !notes.length && !error && <p>No learning notes are awaiting review.</p>}
      {notes.map(note => <article key={note.learning_id} className="rounded border p-3">
        <p className="font-medium">{note.summary}</p>
        <p className="text-sm">{note.kind} · {note.approval_status} · Revision {note.revision}{note.superseded_by ? " · Superseded" : ""}</p>
        <p className="text-sm">Source: {note.origin_document}, version {note.document_version}</p>
        <details><summary>Rule and evidence</summary><pre className="overflow-auto whitespace-pre-wrap text-xs">{JSON.stringify(note.structured_rule, null, 2)}</pre><ul>{note.evidence_ids.map(id => <li key={id} className="break-all text-xs">{id}</li>)}</ul></details>
        <div className="mt-2 flex gap-4">
          {note.approval_status === "EXTRACTED_NOTE_DRAFT" && <button disabled={busy} onClick={() => review(note, "submit")}>Submit for review</button>}
          {canReview && note.approval_status === "BUSINESS_REVIEW" && <><button disabled={busy} onClick={() => review(note, "approve")}>Approve rule</button><button disabled={busy} onClick={() => review(note, "reject")}>Reject rule</button></>}
        </div>
      </article>)}
    </div>}
  </section>;
}
