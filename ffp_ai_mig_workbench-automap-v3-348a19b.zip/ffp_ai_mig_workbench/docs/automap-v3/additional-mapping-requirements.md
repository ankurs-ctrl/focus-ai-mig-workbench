# Additional mapping requirements — 2026-11-05

These changes are on `sync/uat-frontend-native-integration`. The user explicitly
requested the CTE Library and save-dialog changes after the earlier no-UI-change
constraint. No other product UI layout was changed.

## Checked targets

The existing scope implementation was exercised through the actual frontend thunk
and reducers (`test-automap-scope.cjs`) and backend durable-job regressions. Checked
rows alone become processing targets and are sent in the explicit target scope.
Unchecked definitions are retained. Existing definitions on checked rows become
review proposals rather than silently overwritten. Stale checkbox identities fail
before submission. No selection reevaluates all rows.

This is gated by the backend's v3 project capabilities. The checked-target action
is disabled when those capabilities are unavailable; the current UAT canary is
project 501. Deploying the code alone does not enable every project.

## CTE Library

The library loads the existing global CTE endpoint and defaults to All projects.
The Project selector includes individual project names and shared CTEs. Every row
shows its project, and search applies within the selected project. Browsing does
not change selected CTEs. Same-named CTEs retain their distinct IDs. Nested parent
CTEs remain in the workspace closure even when only the child is selected.
Editing a CTE owned by a different project opens the existing duplicate workflow
for the current project instead of updating the original project's CTE.

## Manual Save

The save callback commits edits, flushes the exact committed Redux snapshot, and
closes after the backend acknowledges persistence. This behavior already exists
on this branch and was rechecked. The dialog now displays Saving, disables repeat
Save/Cancel/Close actions during persistence, and keeps the original mapping count
when the in-memory dirty list is cleared. Failed saves remain open and retryable.
All 33 persistence regressions pass, including delayed acknowledgement, coalesced
writes, failure/retry, immediate commit without a React rerender, and background
projection work that must not keep the dialog open.

## Service instance sizing

37 targets / 4 targets per batch requires **10 batches**, not nine. Eight source
calls in flight is the plan's initial concurrency target. Instances and concurrent
model calls are different: each process has a configurable tenant semaphore
(`AUTO_MAPPING_WORKER_MAX_CONCURRENCY`), and the dispatcher has its own cap
(`AUTOMAP_FAST_MAX_IN_FLIGHT` and `AUTO_MAPPING_PROXY_MAX_IN_FLIGHT`).

The prepared UAT profile sets those caps to eight, but keeps durable admission at
its provisioned capacity of four (`AUTOMAP_PARALLEL_POOL_CAPACITY` and
`AUTOMAP_PARALLEL_MAX_WORKERS`). UAT enables that durable path. Increasing service
instances to ten does not bypass that pool. Resizing must update the provisioned
permit rows and matching pool configuration together; changing a number alone is
insufficient. Start by measuring eight admitted calls using the existing five
instances, then add instances if queueing or resource utilization warrants it.
No client service or permit pool was modified in this test account.

Snowflake service scaling documentation:
https://docs.snowflake.com/en/developer-guide/snowpark-container-services/scaling-services

## Transformation assistant

The deployed test-account `AGT_STTM_BUILDER` answered two read-only transformation
questions against the existing loan-calculation semantic model from
`FOCUS_DB_2.STTM_MCP.SEM_NATIVE_VIEWS`. It generated CASE and COALESCE expressions
with null-behavior explanations (34.621 and 28.216 seconds). Both expressions
passed Snowflake EXPLAIN against the physical source and four synthetic rows each,
including NULL and empty-string cases. See
`local-assistant-transformation-validation.json`.

A follow-up canonical mapping-screen request returned a structured proposal. Its
live response passed through the actual frontend proposal builder, fresh-Values
acceptance thunk and Apply reducer. The row remained unchanged until Apply, then
received the CASE expression. A browser click and client deployment were not tested.

A captured live tool-use and successful matching tool-result confirm execution of
`AGT_TRANSFORMATION_RULE`; the result includes a Snowflake procedure query ID.

For CTE generation the orchestrator can request typed CORTEX_ANALYST delegation.
The backend loads the exact prepared bundle and passes its executable semantic
view or composed YAML to Analyst. Explicit derived SQL generation can call Analyst
directly. Optional request-local Analyst tool binding is default-off. All 84
payload/Analyst/CTE regressions passed, including lazy bundle loading and exact
bundle hash binding. A live CTE-generation request was not run in these checks.

## Validation

- TypeScript: `tsc --noEmit --incremental false` passed.
- Save/persistence: 33/33 passed.
- Global library: global load, project/shared/search filters, distinct identities,
  unchanged selection, and parent closure passed.
- Selected-target frontend suite passed.
- Targeted backend jobs, workspace CTE, and chat latency suites: 172 passed.

Client DEV/UAT deployment and browser smoke tests remain separate release checks.
