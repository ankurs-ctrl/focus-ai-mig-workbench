"""Read-only source-estate orientation and complete saved graph retrieval."""
from __future__ import annotations
import json
import re
from typing import Any
from app.agent_runs.models import ToolResult
from app.agent_tools.catalog_discovery import authorized_scope, identifier_parts, quote_identifier, sql_diagnostics
from app.agent_tools.contract_reader import normalize_fqn
from app.agent_runtime.execution import BudgetExceededError, ExecutionCancelledError, ExecutionLeaseLostError
from app.core.exceptions import DelegatedSessionRequired, DelegatedCredentialsRotated

BOUNDARIES = (BudgetExceededError, ExecutionCancelledError, ExecutionLeaseLostError, DelegatedSessionRequired, DelegatedCredentialsRotated)


def internal_tables(settings):
    from app.agent_tools.workbench_knowledge import ROUTES
    names=set()
    qualify=getattr(settings,'qualify_metadata_object_name',None)
    for field,_ in ROUTES.values():
        value=getattr(settings,field,None)
        if isinstance(value,str) and value:
            fqn=qualify(value) if callable(qualify) else value
            if isinstance(fqn,str):names.add(tuple(identifier_parts(fqn)))
    return names




def unpublished_agent_draft(record):
    """Working copies remain inspectable, but are not accepted precedents."""
    value=record if isinstance(record,dict) else {
        'metadata':getattr(record,'metadata',{}),'status':getattr(record,'status','')}
    metadata=value.get('metadata') or {}
    return bool(isinstance(metadata,dict) and metadata.get('draft_only')
                and (metadata.get('migration_run_id') or metadata.get('created_by_migration_run'))
                and str(value.get('status') or '').upper() not in {'COMPLETE','PUBLISHED'})


def preserve_saved_driver(derived, *, saved_driver, parsed_driver, physical_driver_matches):
    """Keep a saved output role on the proposed graph; never infer a join."""
    names={tuple(identifier_parts(value)) for value in (saved_driver,parsed_driver) if value}
    matches=[item for item in derived if any(tuple(identifier_parts(item.get(key))) in names
             for key in ('id','name','alias') if item.get(key))]
    explicit=[item for item in derived if item.get('is_driving_source') is True]
    if physical_driver_matches and len(matches)==1 and not explicit:
        matches[0]['is_driving_source']=True
        matches[0]['driver_evidence']='saved_mapping_driving_output'
    return derived


def saved_definition_sql(snapshot):
    """Read a complete saved definition, including UI-compiled mappings.

    Preview SQL is deliberately excluded: it may contain limits/wrappers and
    cannot replace a saved population definition. This is historical evidence,
    never proof of freshness, authorization or execution readiness.
    """
    for field in ('published_mapping_sql','mapping_sql','raw_mapping_sql',
                  'compiled_mapping_script_sql','compiled_mapping_sql'):
        value = snapshot.get(field)
        if isinstance(value,str) and value.strip():
            return value, field
    return '', None


def mapping_graph(workbench, project_id, sttm_id, section='summary', offset=0, limit=20, *, project_context=None):
    """Section pages contain complete records, never sliced SQL strings."""
    cache = workbench.__dict__.setdefault('_orientation_graph_reads', {})
    project = project_context if project_context is not None else cache.get(('project', str(project_id)))
    if project is None:
        project = workbench.get_project_context(project_id)
        if project.status == 'succeeded': cache[('project', str(project_id))] = project
    if project.status != 'succeeded': return project
    if str(sttm_id) not in {str(row.get('sttm_id')) for row in project.data.get('mappings', [])}:
        return ToolResult(status='denied', summary='Mapping is outside the accessible project.', error_code='mapping_project_mismatch')
    key = ('mapping', str(project_id), str(sttm_id))
    detail = cache.get(key)
    if detail is None:
        detail = workbench._precedent_detail(str(sttm_id), 'project.read_mapping_graph')
        if detail is not None: cache[key] = detail
    if detail is None: return ToolResult(status='failed', summary='Saved mapping unavailable.', error_code='mapping_not_found')
    snapshot = dict(detail.latest_snapshot or {})
    sql, sql_source = saved_definition_sql(snapshot)
    from app.agent_tools.workbench import parse_sql_document
    parsed = parse_sql_document(sql) if sql else None
    def data(value):
        from dataclasses import asdict, is_dataclass
        if callable(getattr(value, 'to_dict', None)): return value.to_dict()
        if is_dataclass(value): return asdict(value)
        return value.model_dump(mode='json') if hasattr(value, 'model_dump') else dict(value) if isinstance(value, dict) else str(value)
    filters=[]
    if sql:
        from sqlglot import parse, exp
        try:
            filters=[{'sql':node.sql(dialect='snowflake'),'kind':type(node).__name__}
                     for statement in parse(sql,read='snowflake') if statement is not None
                     for node in statement.walk() if isinstance(node,(exp.Where,exp.Having,exp.Qualify))]
        except Exception:
            filters=[]
    saved_filters = snapshot.get('filters')
    if isinstance(saved_filters, dict):
        populated = {key: value for key, value in saved_filters.items() if value}
        saved_filters = [populated] if populated else []
    sections = {
        'sources': [data(v) for v in snapshot.get('source_tables') or detail.sources or []],
        'joins': [data(v) for v in snapshot.get('relationships') or (parsed.join_patterns if parsed else [])],
        'ctes': [data(v) for v in snapshot.get('derived_sources') or (parsed.ctes if parsed else [])],
        'rows': [data(v) for v in snapshot.get('mapping_rows') or detail.mapping_rows or []],
        'filters': [data(v) for v in saved_filters or filters],
        'sql': [sql] if sql else [],
    }
    provenance = {'project_id':str(project_id), 'sttm_id':str(sttm_id), 'status':detail.sttm.status,
                  'historical':True, 'sql_source':sql_source, 'unpublished_agent_working_copy':unpublished_agent_draft(detail.sttm), 'version':str(snapshot.get('snapshot_id') or snapshot.get('version_id') or snapshot.get('version') or getattr(detail.sttm,'last_snapshot_id','') or getattr(detail.sttm,'current_version','')),
                  'target_table':detail.sttm.target_table, 'driving_table':snapshot.get('driving_table') or (parsed.driving_physical_table if parsed else None),
                  'driving_relation_id':snapshot.get('driving_relation_id'),
                  'driving_output':parsed.driving_relation if parsed else None,
                  'grain':snapshot.get('grain'), 'coverage':'Saved evidence; not authorization or current execution proof.'}
    if section == 'summary':
        payload={**provenance, 'section_counts':{key:len(values) for key,values in sections.items()},
                 'sources':[], 'source_count':len(sections['sources']), 'sources_complete':False,
                 'joins':[], 'ctes':[], 'filters':[], 'rows':[], 'mapping_sql':None,
                 'complete_sections':[], 'deferred_sections':[]}
        def fits():
            encoded=json.dumps(payload,ensure_ascii=False)
            # Reserve framing for completeness/deferred metadata as well.
            return len(encoded)<=46000 and len(encoded.encode('utf-8'))<=46000
        # Give the planning agent a usable graph in one read, rather than just
        # counts that require another model decision for every small section.
        for key in ('sources','joins','filters','ctes','sql','rows'):
            complete=True
            source_size=0
            for index,record in enumerate(sections[key]):
                if key=='sql':payload['mapping_sql']=record
                else:payload[key].append(record)
                encoded_record=json.dumps(record,ensure_ascii=False)
                if key=='sources':source_size+=max(len(encoded_record),len(encoded_record.encode('utf-8')))
                if not fits() or key=='sources' and source_size>10000:
                    if key=='sql':payload['mapping_sql']=None
                    else:payload[key].pop()
                    payload['deferred_sections'].append({'section':key,'offset':index})
                    complete=False
                    break
            if complete:payload['complete_sections'].append(key)
        payload['sources_complete']='sources' in payload['complete_sections']
        payload['deferred_sources_offset']=None if payload['sources_complete'] else len(payload['sources'])
        payload['next_source_offset']=payload['deferred_sources_offset']
        payload['sql_deferred']=bool(sql and payload['mapping_sql'] is None)
        payload['sql_section']='sql' if payload['sql_deferred'] else None
        return ToolResult(status='succeeded',summary='Read saved graph and complete fitting design sections without migration preparation.',
            data=payload,evidence_refs=[f'saved_mapping:{sttm_id}'])
    if section not in sections: return ToolResult(status='failed',summary='Choose a returned section.',error_code='invalid_graph_section')
    offset=max(0,int(offset));limit=max(1,min(int(limit),50));records=[];used=0;deferred=None
    for record in sections[section][offset:offset+limit]:
        size=max(len(json.dumps(record,ensure_ascii=False)),len(json.dumps(record,ensure_ascii=False).encode('utf-8')))
        if used+size>48000: deferred={'index':offset+len(records),'reason':'complete_record_exceeds_page_budget'};break
        records.append(record);used+=size
    return ToolResult(status='succeeded',summary='Read complete saved graph records.',data={**provenance,'section':section,'records':records,'offset':offset,'next_offset':offset+len(records) if records and offset+len(records)<len(sections[section]) else None,'deferred':deferred}, evidence_refs=[f'saved_mapping:{sttm_id}'])


def resolve(workbench, context, project_id=None, hint='', database=None, schema=None):
    project_id=project_id or context.get('project_id')
    candidates={};checked=[];gaps=[]
    known_internal=internal_tables(workbench._settings)
    targets = {tuple(identifier_parts(value)) for value in context.get('orientation_targets', [])}

    def relevant_mapping(row):
        return not targets or tuple(identifier_parts(row.get('target_table'))) in targets
    words=[w.casefold() for w in re.findall(r'[A-Za-z0-9]+', hint) if len(w)>2 and w.casefold() not in {'sources','source','schema','schemas','database','databases','tables','table','data','project','using','from','for','the'}]
    if len(words)>1:words=[word for word in words if word!='firm']
    def add(value, provenance, rank):
        parts=identifier_parts(value)
        if len(parts)==2: parts.append('_scope')
        if len(parts)!=3 or not authorized_scope(value,context): return
        if rank>0 and tuple(parts) in known_internal:return
        key=tuple(parts[:2])
        entry=candidates.setdefault(key,{'database':key[0],'schema':key[1],'evidence':[],'rank':rank})
        entry['rank']=min(entry['rank'],rank)
        if provenance not in entry['evidence']:entry['evidence'].append(provenance)
    for key in ('authorized_source_scope','source_tables','selected_sources'):
        for table in context.get(key,[]):add(table,'current source selection',0)
    def selected_metadata(value):
        if not isinstance(value,dict):return
        for key,item in value.items():
            if key in ('source_tables','selected_sources','source_scope','source_schemas'):
                for source in item if isinstance(item,list) else []:add(source,'project source configuration',1)
            elif isinstance(item,dict):selected_metadata(item)
    if project_id:
        cache=workbench.__dict__.setdefault('_orientation_graph_reads', {})
        project=cache.get(('project',str(project_id)))
        if project is None:
            project=workbench.get_project_context(str(project_id))
            if project.status=='succeeded':cache[('project',str(project_id))]=project
        if project.status!='succeeded':return project
        selected_metadata(project.data.get('project',{}))
        for row in [item for item in project.data.get('mappings', []) if relevant_mapping(item)][:8]:
            graph=mapping_graph(workbench,str(project_id),str(row.get('sttm_id')),project_context=project)
            if graph.status=='succeeded':
                for source in graph.data.get('sources',[]):add(source,f"saved_mapping:{row.get('sttm_id')}",4 if unpublished_agent_draft(row) else 2)
        for link in project.data.get('precedents',[])[:3]:
            linked_id=link.get('precedent_project_id') or link.get('source_project_id')
            if not linked_id:continue
            linked=workbench.get_project_context(str(linked_id))
            if linked.status!='succeeded':continue
            for row in [item for item in linked.data.get('mappings', []) if relevant_mapping(item)][:4]:
                graph=mapping_graph(workbench,str(linked_id),str(row.get('sttm_id')),project_context=linked)
                if graph.status=='succeeded':
                    for source in graph.data.get('sources',[]):add(source,f"linked_mapping:{row.get('sttm_id')}",4 if unpublished_agent_draft(row) else 2)
    if database and schema:
        db,sc=identifier_parts(database),identifier_parts(schema)
        if len(db)!=1 or len(sc)!=1:return ToolResult(status='failed',summary='Provide exact database/schema identifiers.',error_code='catalog_scope_required')
        explicit='.'.join(quote_identifier(v) for v in [db[0],sc[0]])
        if not authorized_scope(explicit,context):return ToolResult(status='denied',summary='Scope is outside this run.',error_code='authorization_denied')
        add(explicit,'explicit requested schema',0)
    if not candidates or words and not any(all(w in (d+'.'+s).casefold() for w in words) for d,s in candidates):
        try:
            registry=getattr(workbench._settings,'resolved_semantic_native_views_table',None)
            if registry and words and not getattr(workbench,'_scope_registry_failure',None):
                from app.agent_tools.catalog_discovery import MAX_DISCOVERY_QUERIES
                used=getattr(workbench,'_catalog_discovery_queries',0)
                if used>=MAX_DISCOVERY_QUERIES:
                    return ToolResult(status='succeeded',summary='Discovery allowance exhausted; source scope remains unverified.',data={'resolution':'unresolved','candidates':[],'coverage_gaps':[{'operation':'discovery','category':'budget_exhausted'}]})
                workbench._catalog_discovery_queries=used+1
                workbench._tool('semantic.resolve_source_scope')
                predicates=' AND '.join("LOWER(DATABASE_NAME || '.' || SCHEMA_NAME) LIKE ?" for _ in words)
                with workbench._domain_lock:
                    rows=workbench._session.sql(f'SELECT DISTINCT DATABASE_NAME, SCHEMA_NAME FROM {registry} WHERE UPPER(STATUS) = \'ACTIVE\' AND '+predicates+' ORDER BY DATABASE_NAME, SCHEMA_NAME LIMIT 25',params=['%'+w+'%' for w in words]).collect()
                for raw in rows:
                    row=raw.as_dict() if hasattr(raw,'as_dict') else raw
                    add('.'.join(quote_identifier(str(row[k])) for k in ('DATABASE_NAME','SCHEMA_NAME')),'published semantic registry',3)
        except BOUNDARIES:raise
        except Exception as error:
            workbench._scope_registry_failure=sql_diagnostics(error) or {'category':'unavailable'}
            gaps.append({'operation':'published_semantic_scope','diagnostics':workbench._scope_registry_failure})
    if not candidates or words and not any(all(w in (d+'.'+s).casefold() for w in words) for d,s in candidates):
        try:
            from app.agent_tools.catalog_discovery import _caller_schema_scopes
            inventory,partial=_caller_schema_scopes(workbench,context,set(),database=database)
            if partial:gaps.append({'operation':'schema_inventory','coverage':'limited_to_1000'})
            for db,sc in inventory:
                if not words or not all(w in (db+'.'+sc).casefold() for w in words):continue
                scope='.'.join(quote_identifier(v) for v in (db,sc));add(scope,'caller-visible schema name match',4)
                checked.append({'database':db,'schema':sc})
        except BOUNDARIES:raise
        except Exception as error:gaps.append({'operation':'schema_inventory','diagnostics':sql_diagnostics(error)})
    if getattr(workbench,'_scope_registry_failure',None):
        gaps.append({'operation':'published_semantic_scope','diagnostics':workbench._scope_registry_failure,'reused_failure':True})
    values=list(candidates.values())
    if database:
        parts=identifier_parts(database)
        values=[v for v in values if len(parts)==1 and v['database']==parts[0]]
    if schema:
        parts=identifier_parts(schema)
        values=[v for v in values if len(parts)==1 and v['schema']==parts[0]]
    if words:
        matching=[v for v in values if all(w in (v['database']+'.'+v['schema']).casefold() for w in words)]
        if matching:values=matching
    # Never promote the configured metadata namespace by default.
    metadata_db=getattr(workbench._settings,'resolved_metadata_database',None)
    metadata_schema=getattr(workbench._settings,'resolved_metadata_schema',None) or getattr(workbench._settings,'snowflake_schema',None)
    values=[v for v in values if (v['database'],v['schema'])!=(metadata_db,metadata_schema) or v['rank']<=2]
    values.sort(key=lambda v:(v['rank'],v['database'],v['schema']))
    best=[v for v in values if v['rank']==values[0]['rank']] if values else []
    common=set(best[0]['evidence']) if best else set()
    for candidate in best[1:]:common.intersection_update(candidate['evidence'])
    together=bool(best and (best[0]['rank']==0 or any(e.startswith('saved_mapping:') or e.startswith('linked_mapping:') for e in common)))
    status='resolved' if len(best)==1 or together else 'ambiguous' if values else 'unresolved'
    return ToolResult(status='succeeded',summary=f'Source estate {status}; target location does not select business sources.',data={'resolution':status,'candidates':values[:8],'recommended_scope':best[0] if len(best)==1 else None,'recommended_scopes':best if status=='resolved' else [],'checked_scopes':checked[:8],'deferred_scopes':values[8:],'coverage_gaps':gaps,'exhaustive':False},evidence_refs=list(dict.fromkeys(e for v in values[:8] for e in v['evidence'] if ':' in e)))
