// Synthetic UI/service fixtures; executes actual thunk and reducers, no browser or live Snowflake.
const assert = require('node:assert/strict');
const test = require('node:test').test;
const ts = require('typescript');
const h = require('./test-automap-preservation.cjs');
const {helpers, reducer, blank, imported, stateFor, response, direct} = h;
const begin = (state, options) => reducer(h.pendingReducer)(state, {meta:{requestId:'run-one',arg:options}});
const pending = () => stateFor(blank('NAME'),blank('NEW'));

for (const checked of [['NAME'],['NAME','NEW']]) test(`checked pending scope: ${checked}`, () => {
  const state = pending(); state.selectedMappingIds = checked;
  const scope = helpers.autoMapScope(state);
  assert.deepEqual(scope.names,checked); assert.equal(scope.mode,'preserve_and_complete');
  assert.deepEqual(scope.existing,[]);
  begin(state);
  assert.deepEqual(state.mappings.filter(row=>row.status==='PROCESSING').map(row=>row.targetColumn),checked);
});

test('no selection reevaluates all; explicit retry ignores current checkbox selection', () => {
  const state = pending(); assert.deepEqual(helpers.autoMapScope(state).names,['NAME','NEW']);
  assert.equal(helpers.autoMapScope(state).mode,'reeval_all');
  assert.deepEqual(helpers.autoMapScope(state).existing,[]);
  state.mappings[1].transformationClassification='unresolved'; state.selectedMappingIds=['NAME'];
  assert.deepEqual(helpers.autoMapScope(state,{action:'retry_unresolved'}).names,['NEW']);
  assert.equal(helpers.autoMapScope(state,{action:'retry_unresolved'}).mode,'preserve_and_complete');
});

test('invalid or stale checkbox IDs fail before a request', () => {
  const state=pending(); state.selectedMappingIds=['deleted-row'];
  assert.throws(()=>helpers.autoMapScope(state),/stale/);
  begin(state); assert.equal(state.mappings.some(row=>row.status==='PROCESSING'),false);
});

test('checked existing definitions are replacements for review, never automatic overwrites', () => {
  const original={...imported(),manuallySaved:true}; const state=stateFor(structuredClone(original),blank('NEW'));
  state.selectedMappingIds=['NAME']; begin(state);
  const proposal=response(direct); proposal.result.mappings.NEW=direct;
  helpers.applyAutoMapResponseToState(state,proposal);
  assert.deepEqual(state.mappings[0],original);
  assert.equal(state.pendingAiMappingReviews.length,1);
  assert.deepEqual(state.pendingAiMappingReviews[0].sourceAttributes,['src.NewName']);
  assert.equal(state.mappings[1].sourceColumn,null);
  assert.equal(state.mappingSuggestions.some(row=>row.targetAttribute==='NEW'),false);
});

test('explicit reevaluate all scopes every row but retains existing work', () => {
  const state=stateFor(imported(),blank('NEW')); state.selectedMappingIds=['NAME'];
  const scope=helpers.autoMapScope(state,{action:'reeval_all'});
  assert.equal(scope.mode,'reeval_all'); assert.deepEqual(scope.names,['NAME','NEW']);
  begin(state,{action:'reeval_all'}); helpers.applyAutoMapResponseToState(state,response(direct));
  assert.equal(state.mappings[0].expression,imported().expression);
  assert.equal(state.pendingAiMappingReviews.length,1);
});

test('later manual edits invalidate reevaluation proposals and their eventual acceptance', () => {
  const state=stateFor(imported()); state.selectedMappingIds=['NAME']; begin(state);
  helpers.applyAutoMapResponseToState(state,response(direct)); const review=state.pendingAiMappingReviews[0];
  state.mappings[0].expression='src.UserEdit';
  assert.equal(helpers.autoMapReviewIsCurrent(state,state.mappings[0],review),false);
  state.pendingAiMappingReviews=[]; helpers.applyAutoMapResponseToState(state,response(direct));
  assert.equal(state.mappings[0].expression,'src.UserEdit'); assert.equal(state.pendingAiMappingReviews.length,0);
});

for (const [name,change] of [
  ['authored SQL',s=>s.mappingSql='SELECT changed'],
  ['compiled SQL',s=>s.compiledMappingSql='SELECT changed'],
  ['join predicate',s=>s.relationships=[{additionalPredicate:'a.ID=b.ID AND b.ACTIVE=1'}]],
  ['filter',s=>s.sourceFilterSql='a.ACTIVE=1'],
  ['source membership',s=>s.sources=[{qualifiedName:'D.S.OTHER',isSelected:true}]],
  ['CTE output',s=>s.derivedSources=[{id:'cte',sqlText:'SELECT 2 AS "New"',columns:[{name:'New'}]}]],
  ['semantic revision',s=>s.semanticBundleHash='new-version'],
  ['business rule',s=>s.mappingIntent={business_goal:'Use the approved new population rule'}],
]) test(`shared ${name} changes fence active results`, () => {
  const state=pending(); begin(state); change(state); const before=structuredClone(state.mappings);
  helpers.applyAutoMapResponseToState(state,response(direct));
  assert.deepEqual(state.mappings,before); assert.equal(state.mappingSuggestions.length,0);
  assert.match(state.errorState.autoMap,/held/);
});

test('authored SQL representations invalidate evidence while compiled output alone does not', () => {
  const fn=h.compile(`${h.functions(h.slice,['stablePreparedContextValue','compactPreparedContextHash','preparedWorkspaceSnapshot'])}; return preparedWorkspaceSnapshot;`);
  const workspace={compiled_mapping_sql:'',raw_mapping_sql:'SELECT first',mapping_sql:'SELECT display'};
  const before=fn(workspace).dependencyHash;
  assert.notEqual(fn({...workspace,raw_mapping_sql:'SELECT second'}).dependencyHash,before);
  assert.notEqual(fn({...workspace,mapping_sql:'SELECT other'}).dependencyHash,before);
  assert.equal(fn({...workspace,compiled_mapping_sql:'SELECT compiled'}).dependencyHash,before);
});

let semanticReducer,condition;
function visit(node){
  if(ts.isPropertyAssignment(node)&&node.name.getText(h.slice)==='autoMapSemanticPrepared')semanticReducer=node.initializer.getText(h.slice);
  if(ts.isVariableDeclaration(node)&&node.name.getText(h.slice)==='runAutoMap') condition=node.initializer.arguments[2].properties[0].initializer.getText(h.slice);
  ts.forEachChild(node,visit);
}
visit(h.slice);

test('a second click cannot create another active job',()=>{
  const check=h.compile(`return (${condition});`);
  assert.equal(check(undefined,{getState:()=>({sttmBuilder:{mappingLoading:true}})}),false);
  assert.equal(check(undefined,{getState:()=>({sttmBuilder:{mappingLoading:false}})}),true);
});

function harness({change,valuesChange=false,options,advanced=true}={}){
  const state={...pending(),sources:[{tableId:'D.S.SOURCE',tableName:'SOURCE',qualifiedName:'D.S.SOURCE',isSelected:true}],targets:[{qualifiedName:'D.T.TARGET',isSelected:true}],
    derivedSources:[],sourceAttributeGroups:[{columns:[{name:'Name'}]}],
    targetAttributeGroup:{qualifiedName:'D.T.TARGET',columns:[{name:'NAME'},{name:'NEW'}]},
    semanticBundleId:'bundle',semanticContextItems:[{}],relationships:[],activeSttmId:'one',activeProjectId:'project'};
  state.semanticDependencySignature=helpers.autoMapSourceInputs(state);
  if(options?.checked)state.selectedMappingIds=options.checked;
  begin(state,options);
  const requests=[],applied=[];let valueReads=0;
  const creator=type=>payload=>({type,payload});
  const resultResponse=response(direct);resultResponse.result.mappings.NEW=direct;
  const thunk=h.compile(`return (${h.thunkSource});`,{
    ...helpers,resolveSelectedSourceTables:s=>s.sources,resolveSelectedTargetTable:s=>s.targets[0],
    makeTableRef:q=>{const[database,schema,table]=q.split('.');return{database,schema,table};},
    estimateAutoMapComplexity:()=>0,autoMapBatchesInitialized:creator('initialized'),autoMapStreamStatus:creator('status'),
    autoMapSemanticPrepared:creator('semantic-prepared'),autoMapBatchStarted:creator('started'),autoMapBatchApplied:creator('applied'),
    getSelectedDerivedSourceIds:()=>[],listProjectAttributes:async()=>[{name:'FirmID',value:valuesChange&&++valueReads>=3?'new':'old'}],
    snapshotFromState:()=>({mapping_rows:[],raw_mapping_sql:state.mappingSql}),
    findTargetDescription:()=>null,qualifiedTableRefOrNull:()=>null,buildRelationshipPayload:()=>[],
    buildRelationGraph:()=>({}),buildSelectedColumnsByTable:()=>({}),getErrorMessage:err=>err.message,
    workbenchService:{getAutoMapCapabilities:async()=>({selected_scope:advanced,reevaluation:advanced}),
      startAutoMapJob:async request=>{requests.push(request);if(change)change(state);return{status:'completed',partial_responses:[],response:resultResponse};}},
  });
  return {state,requests,applied,run:()=>thunk(options,{requestId:'run-one',getState:()=>({sttmBuilder:state}),dispatch:action=>{
    if(action.type==='started')reducer(h.startReducer)(state,action);
    if(action.type==='semantic-prepared')reducer(semanticReducer)(state,action);
    if(action.type==='applied'){applied.push(action);reducer(h.appliedReducer)(state,action);}
  },rejectWithValue:error=>({error})})};
}

test('real thunk sends only checked pending targets with explicit scope and preservation mode',async()=>{
  const t=harness({options:{checked:['NEW']}});const result=await t.run();assert.equal(result.error,undefined);
  assert.equal(t.requests.length,1); const req=t.requests[0];
  assert.deepEqual(req.attributes.map(item=>item.target_attribute),['NEW']);
  assert.deepEqual(req.meta.auto_map_target_scope,['NEW']);assert.equal(req.meta.auto_map_resolution_mode,'preserve_and_complete');
  assert.equal(t.state.mappings[0].sourceColumn,null);assert.equal(t.state.mappings[1].sourceColumn,'src.NewName');
});

test('non-fast capability cannot silently turn selected completion into a full run',async()=>{
  const t=harness({options:{checked:['NEW']},advanced:false});const result=await t.run();
  assert.match(result.error,/not enabled/);assert.equal(t.requests.length,0);
});

test('project Values changed during a run hold results without another POST',async()=>{
  const t=harness({valuesChange:true}); const result=await t.run();
  assert.match(result.error,/Values changed/);assert.equal(t.requests.length,1);assert.equal(t.applied.length,0);
  assert.equal(t.state.mappings[0].sourceColumn,null);
});

test('shared SQL edited during the real job is not overwritten by its result',async()=>{
  const t=harness({change:s=>s.mappingSql='SELECT user_changed'});const result=await t.run();
  assert.match(result.error,/shared inputs changed/);assert.equal(t.requests.length,1);assert.equal(t.applied.length,0);
  assert.equal(t.state.mappingSql,'SELECT user_changed');assert.equal(t.state.mappings[0].sourceColumn,null);
});

test('chunked-evidence proposals remain review-only even for an empty target',()=>{
  const state=pending();begin(state);
  const proposal=response(direct,{meta:{automap_evidence_review_only_targets:['NAME']}});
  helpers.applyAutoMapResponseToState(state,proposal);
  assert.equal(state.mappings[0].sourceColumn,null);
  assert.equal(state.pendingAiMappingReviews.length,1);
  assert.equal(state.pendingAiMappingReviews[0].targetColumn,'NAME');
  assert.equal(state.pendingAiMappingReviews[0].autoMapSharedRevision.length,64);
  assert.ok(state.pendingAiMappingReviews[0].autoMapInputSignature.length===64,'do not duplicate huge SQL or semantics into every review');
});
