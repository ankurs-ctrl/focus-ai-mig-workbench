"""Remove provable duplicate dependency catalog expressions, never executable SQL."""
from __future__ import annotations

from copy import deepcopy
from typing import Any

from sqlglot import exp, parse_one
from sqlglot.optimizer.scope import Scope, build_scope


def _output_select(tree: exp.Select) -> exp.Select:
    """Resolve SELECT * passthrough wrappers, not unrelated embedded CTEs."""
    scope = build_scope(tree)
    seen = set()
    while scope is not None and id(scope) not in seen:
        seen.add(id(scope))
        select = scope.expression
        if not isinstance(select, exp.Select):
            return tree
        expressions = select.expressions
        if len(expressions) != 1 or not isinstance(expressions[0], exp.Star):
            return select
        sources = list(scope.selected_sources.values())
        if len(sources) != 1 or not isinstance(sources[0][1], Scope):
            return tree
        scope = sources[0][1]
    return tree


def _reachable_cte_projection(tree: exp.Select) -> tuple[exp.Select, list[str]]:
    """Drop only definitions unreachable from the query scope, not unused columns/joins."""
    root = build_scope(tree)
    if root is None:
        return tree, []
    pending, seen, reachable = [root], set(), set()
    while pending:
        scope = pending.pop()
        if id(scope) in seen:
            continue
        seen.add(id(scope))
        reachable.add(id(scope.expression))
        pending.extend(source for _node, source in scope.selected_sources.values() if isinstance(source, Scope))
        pending.extend(scope.subquery_scopes + scope.union_scopes + scope.table_scopes)
    removed = []
    # Operate only at the outer wrapper. Nested correlated/recursive scopes are
    # unchanged; no SELECT output, join, filter, window or ordering is pruned.
    with_key = "with" if "with" in tree.args else "with_"
    with_clause = tree.args.get(with_key)
    if with_clause is None or with_clause.args.get("recursive"):
        return tree, removed
    retained = []
    for cte in with_clause.expressions:
        if id(cte.this) in reachable:
            retained.append(cte)
        else:
            removed.append(cte.alias)
    if removed:
        with_clause.set("expressions", retained)
        if not retained:
            tree.set(with_key, None)
    return tree, removed


def dependency_projection(value: Any, *, required_outputs: set[str] | None = None) -> Any:
    if isinstance(value, list):
        return [dependency_projection(item, required_outputs=required_outputs) for item in value]
    if not isinstance(value, dict):
        return deepcopy(value)
    result = deepcopy(value)
    if not isinstance(value.get("sql_text"), str):
        return result
    try:
        tree = parse_one(value["sql_text"], read="snowflake")
        if not isinstance(tree, exp.Select):
            return result
        outputs = {}
        for expression in _output_select(tree).expressions:
            name = expression.alias_or_name
            body = expression.this if isinstance(expression, exp.Alias) else expression
            if name in outputs:
                return result  # Ambiguous duplicate output aliases retain the catalog.
            outputs[name] = body.sql(dialect="snowflake")
        for column in result.get("output_columns") or []:
            if not isinstance(column, dict) or not column.get("expression") or column.get("name") not in outputs:
                continue
            rendered = parse_one(column["expression"], read="snowflake").sql(dialect="snowflake")
            if rendered == outputs[column["name"]]:
                column.pop("expression")
        if required_outputs and required_outputs <= set(outputs):
            for column in result.get("output_columns") or []:
                if not isinstance(column, dict) or column.get("name") in required_outputs:
                    continue
                # Full SQL retains all outputs. Only raw catalog lineage for
                # unrelated outputs is deferred; business/type constraints stay.
                for field in ("expression", "source_references", "unresolved_references"):
                    column.pop(field, None)
        projected_tree, removed = _reachable_cte_projection(tree)
        if removed:
            result["sql_text"] = projected_tree.sql(dialect="snowflake")
            result["dependency_projection"] = {"removed_unreachable_ctes": removed,
                "preserved": "All reachable scopes, selected outputs and population clauses; original wrapper retained backend-side"}
        return result
    except Exception:
        return deepcopy(value)


def recipe_output_names(recipe: dict[str, Any]) -> set[str]:
    names = set()
    try:
        for reference in recipe.get("logical_source_dependencies") or []:
            column = parse_one(reference, read="snowflake")
            if not isinstance(column, exp.Column):
                return set()
            names.add(column.name)
        if recipe.get("expression"):
            expression = parse_one(recipe["expression"], read="snowflake")
            names.update(column.name for column in expression.find_all(exp.Column))
    except Exception:
        return set()  # Unknown recipe closure retains the complete catalog.
    return names
