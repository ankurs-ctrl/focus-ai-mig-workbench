from types import SimpleNamespace

import pytest

from app.routers.upload import (
    _learning_coverage,
    _resolve_existing_mapping_context,
    _target_names_match,
)
from app.core.performance import snapshot


def test_workbook_commits_asset_and_job_before_background(monkeypatch):
    import asyncio
    from io import BytesIO
    from unittest.mock import Mock
    from fastapi import BackgroundTasks, UploadFile
    from app.routers import upload
    session = Mock()
    service = Mock()
    service.upsert_patterns.return_value = 1
    service.create_learning_job.return_value = SimpleNamespace(learning_job_id="workbook-job", status="running")
    parsed = SimpleNamespace(source_datasets=[], target_tables=[], to_dict=lambda: {"column_mappings": []})
    monkeypatch.setattr(upload, "parse_excel_mapping", lambda *_: parsed)
    monkeypatch.setattr(upload, "store_excel_asset", Mock())
    monkeypatch.setattr(upload, "enqueue_fir_document_event", Mock())
    monkeypatch.setattr(upload, "FIRAssetTableResolver", Mock())
    monkeypatch.setattr(upload, "TargetMappingPatternService", Mock(return_value=service))
    background = BackgroundTasks()
    lease = Mock()
    result = asyncio.run(upload.upload_excel(
        background_tasks=background, client=SimpleNamespace(session=session), agent_client=Mock(),
        settings=SimpleNamespace(fir_target_mapping_patterns_v2=True, fir_process_uploads_immediately=True),
        project_service=Mock(), file=UploadFile(filename="mapping.csv", file=BytesIO(b"target,source")),
        project_id="301", mode="auto_populate", source_table_hints="", target_table_hint="",
        sttm_id="", expected_target_table="", logical_target_key="", source_system_key="", session_lease=lease,
    ))
    assert result["learning_job_id"] == "workbook-job"
    assert [call.args[0] for call in session.sql.call_args_list] == ["BEGIN TRANSACTION", "COMMIT"]
    assert background.tasks[0].func is upload._drain_fir_learning_on_lease
    assert background.tasks[0].kwargs["session_lease"] is lease


def test_learning_coverage_does_not_claim_unresolved_rows() -> None:
    coverage = _learning_coverage(
        {
            "column_mappings": [
                {"target_column": "ID", "source_columns": ["SRC.ID"]},
                {"target_column": "NAME", "source_columns": [], "unresolved_references": ["SRC.NAME"]},
            ],
            "parse_warnings": ["row 3 was skipped"],
        },
        deterministic_saved=1,
        learning_job_id="job-1",
    )

    assert coverage["parsed_mapping_rows"] == 2
    assert coverage["resolved_mapping_rows"] == 1
    assert coverage["deterministic_learnings_saved"] == 1
    assert coverage["complete"] is False
    assert len(coverage["unresolved_rows"]) == 1
    assert len(coverage["skipped_rows"]) == 1


def test_learning_coverage_accepts_actual_sql_parser_keys() -> None:
    coverage = _learning_coverage(
        {"column_mappings": [{"target_alias": "NAME", "transformation": "TRIM(a.NAME_R)",
                               "source_columns": ["a.NAME_R"]},
                              {"target_alias": "FLAG", "transformation": "TRUE"}]},
        deterministic_saved=2, learning_job_id="job-sql",
    )
    assert coverage["resolved_mapping_rows"] == 2
    assert coverage["target_columns_represented"] == ["FLAG", "NAME"]
    assert coverage["complete"] is True


def test_locked_target_comparison_supports_excel_leaf_names() -> None:
    assert _target_names_match("CLIENT_DB.SALESFORCE.HOUSEHOLD", "HOUSEHOLD")
    assert _target_names_match("CLIENT_DB.SALESFORCE.HOUSEHOLD", "client_db.salesforce.household")
    assert not _target_names_match("CLIENT_DB.SALESFORCE.HOUSEHOLD", "CALLS")


def test_existing_mapping_context_uses_persisted_contract_metadata() -> None:
    project_service = SimpleNamespace(
        get_sttm_record=lambda _sttm_id: SimpleNamespace(
            project_id="project-1",
            target_table="CLIENT_DB.SALESFORCE.HOUSEHOLD",
            metadata={
                "physical_target_fqn": "CLIENT_DB.SALESFORCE.HOUSEHOLD",
                "logical_target_table_key": "CRM.HOUSEHOLD",
                "source_system_key": "REDTAIL",
            },
        )
    )

    assert _resolve_existing_mapping_context(
        project_service,
        sttm_id="sttm-1",
        project_id="project-1",
        expected_target_table="HOUSEHOLD",
        logical_target_key="UNTRUSTED.TARGET",
        source_system_key="UNTRUSTED_CRM",
    ) == (
        "CLIENT_DB.SALESFORCE.HOUSEHOLD",
        "CRM.HOUSEHOLD",
        "REDTAIL",
    )


def test_sql_upload_timing_metrics_are_exposed_by_diagnostics_registry() -> None:
    from app.core.performance import observe

    observe("sql_upload.parse.duration_ms", 12.0)
    observe("sql_upload.response.duration_ms", 34.0)

    durations = snapshot()["durations"]

    assert durations["sql_upload.parse.duration_ms"]["count"] >= 1
    assert durations["sql_upload.response.duration_ms"]["max_ms"] >= 34.0


@pytest.mark.parametrize("durable,fail_job", [(False, False), (True, False), (True, True)])
def test_upload_response_preserves_ctes_without_waiting_for_fir_or_model(monkeypatch, durable, fail_job):
    import asyncio
    from io import BytesIO
    from unittest.mock import Mock
    from fastapi import BackgroundTasks, UploadFile
    from app.routers import upload

    session = Mock()
    persistence = Mock()
    enrichment = Mock(side_effect=AssertionError("FIR must run after the response"))
    monkeypatch.setattr(upload, "store_sql_asset", persistence)
    monkeypatch.setattr(upload, "_finish_sql_upload_enrichment", enrichment)
    monkeypatch.setattr(upload, "BundleCurationService", Mock())
    pattern_service = Mock()
    pattern_service.extract_document_patterns.return_value = []
    pattern_service.upsert_patterns.return_value = 0
    pattern_service.create_learning_job.return_value = SimpleNamespace(learning_job_id="durable-job")
    monkeypatch.setattr(upload, "TargetMappingPatternService", Mock(return_value=pattern_service))
    monkeypatch.setattr(upload, "_qualified_upload_references", lambda *args, **kwargs: [
        {"raw_identifier": "DB.S.A", "resolved_fqn": "DB.S.A", "resolution_status": "resolved",
         "reference_role": "source", "semantic_status": "active"},
    ])
    if fail_job:
        pattern_service.create_learning_job.side_effect = RuntimeError("queue unavailable")
    tasks = BackgroundTasks()
    async def invoke():
        return await upload.upload_sql(
        background_tasks=tasks, client=SimpleNamespace(session=session),
        settings=SimpleNamespace(fir_document_lineage_v3=False, fir_target_mapping_patterns_v2=durable),
        semantic_service=Mock(), project_service=Mock(),
        file=UploadFile(filename="mapping.sql", file=BytesIO(
            b"WITH base AS (SELECT ID FROM DB.S.A), final AS (SELECT ID FROM base) SELECT ID FROM final"
        )), project_id="test", mode="auto_populate", source_table_hints="",
        target_table_hint="", workspace_context="", import_behavior="preview", sttm_id="",
        expected_target_table="", logical_target_key="", source_system_key="", known_tables="",
        )
    if fail_job:
        from fastapi import HTTPException
        with pytest.raises(HTTPException, match="stored for FIR"):
            asyncio.run(invoke())
        assert [call.args[0] for call in session.sql.call_args_list] == ["BEGIN TRANSACTION", "ROLLBACK"]
        assert not tasks.tasks
        return
    result = asyncio.run(invoke())
    assert result["status"] == "success"
    assert [cte["name"] for cte in result["parsed_summary"]["ctes"]] == ["base", "final"]
    assert result["parsed_summary"]["query_scopes"]
    assert len(tasks.tasks) == 1
    persistence.assert_called_once()
    enrichment.assert_not_called()
    if durable:
        pattern_service.create_learning_job.assert_called_once()
        assert result["learning_job_id"] == "durable-job"
        assert result["learning_coverage"]["semantic_enrichment"]["status"] == "queued"
        pattern_service.process_learning_job.assert_not_called()
    else:
        pattern_service.create_learning_job.assert_not_called()
        assert result["learning_job_id"] is None
    assert [call.args[0] for call in session.sql.call_args_list] == ["BEGIN TRANSACTION", "COMMIT"]


@pytest.mark.parametrize("fail_write", [False, True])
@pytest.mark.parametrize("pooled", [False, True])
def test_cancel_actual_upload_route_keeps_dependency_lease_until_worker_finishes(monkeypatch, fail_write, pooled):
    import threading
    from contextlib import contextmanager
    from unittest.mock import Mock
    import anyio
    import httpx
    from fastapi import FastAPI
    from app.api import deps
    from app.routers import upload

    entered = threading.Event()
    release = threading.Event()
    closed = threading.Event()
    worker_finished = threading.Event()
    events = []
    settings = SimpleNamespace(
        snowflake_write_lease_pool_v1=pooled,
        fir_document_lineage_v3=False, fir_target_mapping_patterns_v2=False,
    )

    class Session:
        def sql(self, query):
            assert not closed.is_set(), "Transaction accessed a released session"
            events.append(query)
            return SimpleNamespace(collect=lambda: [])

    def close():
        events.append("lease_finally")
        closed.set()
        assert worker_finished.is_set(), "Dependency released the lease while worker was running"

    client = SimpleNamespace(session=Session(), close=close)

    @contextmanager
    def lease(*args):
        try:
            yield client
        finally:
            close()

    monkeypatch.setattr(deps, "caller_write_lease", lease)
    monkeypatch.setattr(deps, "SnowflakeClient", lambda **_: client)
    monkeypatch.setattr(deps, "_request_user_token", lambda *_: "offline-caller")
    monkeypatch.setattr(deps, "_default_role_for_principal", lambda *_: "CALLER_ROLE")
    monkeypatch.setattr(deps, "using_local_dev_auth", lambda *_: False)
    monkeypatch.setattr(upload, "BundleCurationService", Mock())
    monkeypatch.setattr(upload, "_qualified_upload_references", lambda *args, **kwargs: [])
    monkeypatch.setattr(upload, "_finish_sql_upload_on_lease", lambda **_: None)

    def persist(*args, **kwargs):
        entered.set()
        assert release.wait(5), "Test failed to release the blocked worker"
        assert not closed.is_set()
        events.append("write_finished")
        if fail_write:
            raise RuntimeError("write failed after cancellation")

    monkeypatch.setattr(upload, "store_sql_asset", persist)
    prepare = upload._prepare_sql_upload

    def observed_prepare(**kwargs):
        try:
            return prepare(**kwargs)
        finally:
            events.append("worker_finished")
            worker_finished.set()

    monkeypatch.setattr(upload, "_prepare_sql_upload", observed_prepare)
    application = FastAPI()
    application.include_router(upload.router)
    application.dependency_overrides[deps.get_settings] = lambda: settings
    application.dependency_overrides[deps.get_project_service] = lambda: Mock()
    application.dependency_overrides[deps.get_semantic_context_service] = lambda: Mock()
    application.dependency_overrides[deps.get_background_session_lease] = lambda: Mock()
    # Keep the actual get_upload_snowflake_client yield/finally dependency.

    async def run():
        scope_ready = anyio.Event()
        request_done = anyio.Event()
        request_scopes = []
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=application), base_url="http://test") as browser:
            async def request():
                try:
                    with anyio.CancelScope() as scope:
                        request_scopes.append(scope)
                        scope_ready.set()
                        await browser.post("/upload/sql", data={"project_id": "p1"},
                                           files={"file": ("mapping.sql", b"SELECT ID FROM DB.S.T", "text/plain")})
                finally:
                    request_done.set()

            async with anyio.create_task_group() as group:
                group.start_soon(request)
                try:
                    with anyio.fail_after(5):
                        await scope_ready.wait()
                        while not entered.is_set():
                            await anyio.sleep(0.005)
                    assert events == ["BEGIN TRANSACTION"]
                    request_scopes[0].cancel()
                    await anyio.sleep(0.05)
                    assert not request_done.is_set()
                    assert not closed.is_set()
                    assert not worker_finished.is_set()
                finally:
                    release.set()
                with anyio.fail_after(5):
                    await request_done.wait()

    anyio.run(run)
    assert closed.is_set()
    assert events == ["BEGIN TRANSACTION", "write_finished", "ROLLBACK" if fail_write else "COMMIT",
                      "worker_finished", "lease_finally"]


@pytest.mark.parametrize("failure", ["catalog_timeout", "registry_timeout", "metadata_unexpected", "qualification_unexpected"])
def test_real_sql_upload_preserves_preview_and_does_not_block_event_loop(monkeypatch, failure):
    import asyncio
    import threading
    from io import BytesIO
    from unittest.mock import Mock
    from fastapi import BackgroundTasks, UploadFile
    from app.routers import upload
    from app.core.fir_document_ingestion import upload_asset_id
    from app.core.sql_parser import parse_sql_document
    from snowflake.snowpark.exceptions import SnowparkSQLException

    content = ("-- preserve original SQL and literals\r\n"
               "INSERT INTO DB.S.TARGET_TABLE (ID, FLAG) WITH base AS (SELECT ID FROM DB.S.T0) "
               "SELECT b.ID, 'literal  value' AS FLAG FROM base b " +
               " ".join(f"LEFT JOIN DB.S.T{i} t{i} ON b.ID=t{i}.ID" for i in range(1, 120))).encode()
    parsed = parse_sql_document(content.decode())
    entered = threading.Event()
    release = threading.Event()
    loop_thread = threading.get_ident()
    thread_ids = []
    calls = []
    persisted = []
    background = BackgroundTasks()
    lease = Mock(side_effect=AssertionError("Background must not run before response"))
    shared_project = Mock()
    exclusive_project = Mock()
    exclusive_project.get_sttm_record.return_value = SimpleNamespace(
        project_id="p1", target_table="DB.S.TARGET_TABLE", metadata={},
    )
    project_factory = Mock(return_value=exclusive_project)
    monkeypatch.setattr(upload, "ProjectService", project_factory)
    monkeypatch.setattr(upload, "BundleCurationService", Mock())
    settings = SimpleNamespace(fir_document_lineage_v3=False, fir_target_mapping_patterns_v2=False,
                               resolved_semantic_views_table="DB.M.TABLE_REGISTRY",
                               resolved_semantic_native_views_table="DB.M.NATIVE_REGISTRY")
    model = Mock(side_effect=AssertionError("No model or uploaded SQL evaluation"))
    monkeypatch.setattr(upload, "complete_text", model)
    monkeypatch.setattr(upload, "_finish_sql_upload_enrichment", model)
    monkeypatch.setattr(upload, "TargetMappingPatternService", model)

    class Session:
        def sql(self, query, params=None):
            thread_ids.append(threading.get_ident())
            assert threading.get_ident() != loop_thread
            calls.append((query, params))
            def collect(**kwargs):
                if query in {"BEGIN TRANSACTION", "COMMIT", "ROLLBACK"}:
                    return []
                assert 1 <= kwargs["statement_params"]["STATEMENT_TIMEOUT_IN_SECONDS"] <= 5
                if query.startswith("DESCRIBE TABLE"):
                    if failure == "catalog_timeout":
                        raise SnowparkSQLException("statement timeout 5", sql_error_code=630)
                    return [{"name": "ID", "type": "NUMBER"}]
                if "WITH requested" in query:
                    raise SnowparkSQLException("statement timeout 5", sql_error_code=630)
                raise AssertionError(f"Unexpected SQL (must never evaluate upload): {query}")
            return SimpleNamespace(collect=collect)

    session = Session()
    def persist(*args, **kwargs):
        assert args[0] is session
        thread_ids.append(threading.get_ident())
        assert threading.get_ident() != loop_thread
        entered.set()
        assert release.wait(5), "Upload blocked the event loop"
        persisted.append((args, kwargs))
    monkeypatch.setattr(upload, "store_sql_asset", persist)
    if failure == "metadata_unexpected":
        monkeypatch.setattr(upload, "inspect_upload_references", Mock(side_effect=RuntimeError("unavailable")))
    if failure == "qualification_unexpected":
        monkeypatch.setattr(upload, "qualify_upload_references", Mock(side_effect=RuntimeError("unavailable")))

    async def invoke():
        async def heartbeat():
            try:
                for _ in range(1000):
                    if entered.is_set():
                        return True
                    await asyncio.sleep(0.005)
                return False
            finally:
                release.set()
        beat = asyncio.create_task(heartbeat())
        result = await upload.upload_sql(
            background_tasks=background, client=SimpleNamespace(session=session), settings=settings,
            semantic_service=model, project_service=shared_project,
            file=UploadFile(filename="mapping.sql", file=BytesIO(content)), project_id="p1",
            mode="auto_populate", source_table_hints="", target_table_hint="", workspace_context="",
            import_behavior="preview", sttm_id="existing", expected_target_table="DB.S.TARGET_TABLE",
            logical_target_key="", source_system_key="", known_tables="", session_lease=lease,
        )
        assert await beat
        return result

    result = asyncio.run(invoke())
    assert result["status"] == "success"
    assert result["asset_id"] == upload_asset_id(content, "p1")
    assert result["import_preview"]["sql"].encode() == content
    assert result["import_preview"]["mapping_rows"] == [row.to_dict() for row in parsed.column_mappings]
    assert result["import_preview"]["coverage"]["constants"] == 1
    assert result["parsed_summary"]["ctes"] == parsed.to_dict()["ctes"]
    assert result["metadata_warnings"]
    assert all(item["status"] == "unknown" for item in result["metadata_warnings"])
    assert all(item["semantic_status"] == "lookup_failed" for item in result["table_references"])
    assert all(item["semantic_table_view_id"] is None for item in result["table_references"])
    assert any(item.get("availability") == "unknown" for item in result["import_preview"]["diagnostics"])
    assert result["warnings"]
    assert result["reference_enrichment"] == {"status": "queued"}
    assert len(background.tasks) == 1
    assert background.tasks[0].kwargs["session_lease"] is lease
    lease.assert_not_called()
    model.assert_not_called()
    shared_project.get_sttm_record.assert_not_called()
    assert project_factory.call_args.kwargs["session"] is session
    assert len(set(thread_ids)) == 1
    assert [query for query, _ in calls if query in {"BEGIN TRANSACTION", "COMMIT", "ROLLBACK"}] == ["BEGIN TRANSACTION", "COMMIT"]
    if failure == "catalog_timeout":
        assert len(calls) == 10  # BEGIN, at most eight exact caller checks, COMMIT.
    assert persisted[0][0][3].encode() == content


def test_worker_rolls_back_on_its_own_thread_before_propagating_persistence_error(monkeypatch):
    import asyncio
    import threading
    from io import BytesIO
    from unittest.mock import Mock
    from fastapi import BackgroundTasks, HTTPException, UploadFile
    from app.routers import upload

    loop_thread = threading.get_ident()
    calls = []
    class Session:
        def sql(self, query):
            calls.append((query, threading.get_ident()))
            return SimpleNamespace(collect=lambda: [])
    monkeypatch.setattr(upload, "store_sql_asset", Mock(side_effect=RuntimeError("write failed")))
    monkeypatch.setattr(upload, "BundleCurationService", Mock())
    tasks = BackgroundTasks()
    with pytest.raises(HTTPException, match="stored for FIR"):
        asyncio.run(upload.upload_sql(
            background_tasks=tasks, client=SimpleNamespace(session=Session()),
            settings=SimpleNamespace(fir_document_lineage_v3=False, fir_target_mapping_patterns_v2=False),
            semantic_service=Mock(), project_service=Mock(),
            file=UploadFile(filename="mapping.sql", file=BytesIO(b"SELECT ID FROM DB.S.T")),
            project_id="p1", mode="auto_populate", source_table_hints="", target_table_hint="",
            workspace_context="", import_behavior="preview", sttm_id="", expected_target_table="",
            logical_target_key="", source_system_key="", known_tables="", session_lease=Mock(),
        ))
    assert [query for query, _ in calls] == ["BEGIN TRANSACTION", "ROLLBACK"]
    assert len({thread for _, thread in calls}) == 1
    assert calls[0][1] != loop_thread
    assert not tasks.tasks
