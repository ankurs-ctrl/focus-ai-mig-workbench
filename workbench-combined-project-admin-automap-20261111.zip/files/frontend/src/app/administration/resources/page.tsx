import ResourcesPage from '@/features/administration/resources/ResourcesPage';
export default ResourcesPage;
