"""Distributed Auto-map admission over deployment-preallocated Snowflake slots.

Safety contract
---------------
All replicas MUST use the same table, canonical ORG.ACCOUNT namespace, pool epoch
and capacity. Runtime code never inserts, deletes, or creates slots. Provisioning
must be exclusive, and the runtime role must not be able to insert/delete/reset
this table. Standard-table primary keys are NOT used as enforced constraints.

Claims read the small fixed inventory, then UPDATE a FREE slot conditional on its
observed fence and epoch. Exactly one updated row and an acknowledged COMMIT are
required before dispatch. A stale read can lose a claim, never authorize a call.
Each update is in an explicit transaction so unexpected affected counts roll back.
No count-then-insert, process semaphore, or SELECT FOR UPDATE is involved.

HELD and QUARANTINED slots both consume capacity, including after lease expiry.
Expiry only stops renewal; it NEVER frees a slot or authorizes takeover. A crash,
lost COMMIT acknowledgement, timeout, or uncertain remote failure can leak capacity
until explicit terminal reconciliation. Fences protect the store, NOT the remote
provider: reconciliation must prove the old call terminal AND prevent a paused
old dispatcher from subsequently sending it. Absence in query history is not proof.

The session factory must yield an EXCLUSIVE, transaction-free Snowpark session per
operation (including heartbeat operations), discard it after errors, never suppress
exceptions, and bound connection/network waits. It owns credentials; this module
stores none. SQL execution/lock timeouts are bounded too, but Python cannot interrupt
blocked session creation or networking exactly at the scan deadline.

Use BOTH ScanCallAdmission and its wrap_backend() with scan_registry. The scan
catches backend exceptions inside admission, so a normal context exit is NOT proof
of terminal completion. A wrapped backend must perform at most ONE synchronous
remote call, no hidden retries, and return only after remote completion. Only a
transport that has confirmed a terminal remote error may raise RemoteCallCompleted.
Other exceptions, including cancellation, are uncertain and quarantined.

Only the global concurrent-call cap is implemented. Job/caller IDs are attribution,
not quotas or fairness. No FIFO scheduling, per-job/caller cap, or live wiring.
See https://docs.snowflake.com/en/sql-reference/transactions (resource locking,
READ COMMITTED, explicit transactions, multi-threading). Live concurrency and SQL
compilation still require verification in an approved isolated DEV environment.
"""
from __future__ import annotations

from collections.abc import Callable, Iterator
from contextlib import AbstractContextManager, contextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field
import hashlib
import json
from enum import Enum
import math
import random
import re
from threading import Event, Lock, Thread
import time
from typing import Any, Protocol, TYPE_CHECKING

if TYPE_CHECKING:
    from app.core.automap_scan_transport import ScanTransportDiagnostic
from uuid import UUID, uuid4


class AdmissionError(RuntimeError):
    """No remote call is authorized by a failed admission operation."""


class AdmissionUnavailable(AdmissionError):
    """Store outcome may be uncertain; never fall back to local admission."""


class AdmissionClaimUncertain(AdmissionUnavailable):
    """A write or commit may have succeeded; claiming again could leak capacity."""


class AdmissionContended(AdmissionUnavailable):
    """A rolled-back Snowflake lock/statement timeout; bounded retry is safe."""


def _is_contention(exc: Exception) -> bool:
    code = getattr(exc, "errno", None)
    return str(code).lstrip("0") in {"627", "630"}


class AdmissionInvariantError(AdmissionError):
    """Invalid inventory or unrecognized affected-row result."""


class StalePermit(AdmissionError):
    """The owner/fence no longer matches, or renewal is too late."""


class UnreportedCompletion(AdmissionError):
    """No paired backend reported a terminal outcome."""


class RemoteCallCompleted(RuntimeError):
    """Transport attests a terminal remote failure (NOT a timeout/disconnect)."""


class Completion(str, Enum):
    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"
    NOT_DISPATCHED = "NOT_DISPATCHED"


@dataclass(frozen=True)
class AdmissionCapabilities:
    global_call_cap: bool = True
    per_job_limit: bool = False
    per_caller_limit: bool = False
    fairness: bool = False
    automatic_expiry_reclaim: bool = False


CAPABILITIES = AdmissionCapabilities()


def _identity(value: str, name: str) -> str:
    if type(value) is not str or not value.strip() or len(value) > 256:
        raise ValueError(f"Invalid {name}")
    if any(ord(char) < 32 or ord(char) == 127 for char in value):
        raise ValueError(f"Invalid {name}")
    value.encode("utf-8")
    return value


def _positive_int(value: int, name: str) -> int:
    if type(value) is not int or value <= 0:
        raise ValueError(f"Invalid {name}")
    return value


@dataclass(frozen=True)
class CallIdentity:
    job_id: str
    caller_id: str
    generation: str
    shard_id: str

    def __post_init__(self) -> None:
        for name in ("job_id", "caller_id", "generation", "shard_id"):
            _identity(getattr(self, name), name)


@dataclass(frozen=True)
class Permit:
    account_namespace: str
    pool_epoch: str
    slot_id: int
    owner: str
    fence: int
    identity: CallIdentity


@dataclass(frozen=True)
class ThreadReference:
    """Nonsecret, versioned correlation fitting the existing VARCHAR(256)."""

    thread_id: int
    agent_fqn: str
    request_digest: str
    version: int = 1

    def __post_init__(self) -> None:
        if (type(self.version) is not int or self.version != 1
                or type(self.thread_id) is not int or not 0 < self.thread_id < 2**63
                or type(self.agent_fqn) is not str or not re.fullmatch(
                    r"[A-Z_][A-Z0-9_$]*(\.[A-Z_][A-Z0-9_$]*){2}", self.agent_fqn)
                or type(self.request_digest) is not str
                or not re.fullmatch(r"[0-9a-f]{64}", self.request_digest)):
            raise ValueError("Invalid thread reconciliation reference")
        if len(self.serialize().encode("ascii")) > 256:
            raise ValueError("Thread reconciliation reference exceeds existing column capacity")

    def serialize(self) -> str:
        return json.dumps(dict(version=self.version, thread_id=self.thread_id,
            agent_fqn=self.agent_fqn, request_digest=self.request_digest), separators=(",", ":"))

    @classmethod
    def parse(cls, value: str) -> ThreadReference:
        try:
            if type(value) is not str or len(value.encode("utf-8")) > 256:
                raise ValueError
            data = json.loads(value)
            if type(data) is not dict or set(data) != {"version", "thread_id", "agent_fqn", "request_digest"}:
                raise ValueError
            reference = cls(**data)
            if reference.serialize() != value:
                raise ValueError
            return reference
        except (ValueError, TypeError, UnicodeError, RecursionError):
            raise AdmissionInvariantError("Invalid persisted thread reference") from None


def request_digest(request: AdmissionRequest) -> str:
    """Bind exact checked message bytes AND snapshot/generation/shard scope."""
    return hashlib.sha256(json.dumps([
        request.scope.owner_id, request.scope.snapshot_id, request.generation,
        request.shard_id, request.message,
    ], ensure_ascii=False, separators=(",", ":")).encode("utf-8")).hexdigest()


class SqlSession(Protocol):
    def sql(self, query: str, params: list[Any] | None = None) -> Any: ...


SessionFactory = Callable[[], AbstractContextManager[SqlSession]]


def _row(value: Any) -> dict[str, Any]:
    return value.as_dict() if hasattr(value, "as_dict") else dict(value)


def _affected(rows: list[Any]) -> int:
    if len(rows) != 1:
        raise AdmissionInvariantError("Missing UPDATE result")
    result = {key.lower(): value for key, value in _row(rows[0]).items()}
    count = result.get("number of rows updated")
    if type(count) is not int or count < 0:
        raise AdmissionInvariantError("Invalid UPDATE affected-row count")
    return count


class SnowflakeCallAdmission:
    """Fixed global pool. Construction performs no I/O; no implicit configuration."""

    capabilities = CAPABILITIES

    def __init__(self, *, session_factory: SessionFactory, table: str,
                 account_namespace: str, pool_epoch: str, capacity: int,
                 lease_seconds: int = 120, statement_timeout_seconds: int = 5) -> None:
        if not callable(session_factory):
            raise TypeError("An exclusive session factory is required")
        # Deliberately reject quoted/partial identifiers, URLs and account aliases.
        if type(table) is not str or not re.fullmatch(
                r"[A-Za-z_][A-Za-z0-9_$]*(\.[A-Za-z_][A-Za-z0-9_$]*){2}", table):
            raise ValueError("table requires an unquoted DATABASE.SCHEMA.TABLE")
        if type(account_namespace) is not str or not re.fullmatch(
                r"[A-Za-z0-9_]+\.[A-Za-z0-9_]+", account_namespace):
            raise ValueError("account_namespace requires canonical ORG.ACCOUNT")
        if type(pool_epoch) is not str or str(UUID(pool_epoch)) != pool_epoch:
            raise ValueError("pool_epoch requires a canonical deployment UUID")
        self._factory = session_factory
        self._table = table.upper()
        self.account_namespace = account_namespace.upper()
        self.pool_epoch = pool_epoch
        self.capacity = _positive_int(capacity, "capacity")
        self.lease_seconds = _positive_int(lease_seconds, "lease_seconds")
        self._timeout = _positive_int(statement_timeout_seconds, "statement_timeout_seconds")

    def _sql(self, session: SqlSession, query: str, params: list[Any] | None = None) -> list[Any]:
        return session.sql(query, params=params).collect(statement_params={
            "STATEMENT_TIMEOUT_IN_SECONDS": str(self._timeout), "LOCK_TIMEOUT": "1"})

    @contextmanager
    def _transaction(self) -> Iterator[SqlSession]:
        committed = False
        try:
            with self._factory() as session:
                context = self._sql(session,
                    "SELECT CURRENT_ORGANIZATION_NAME() || '.' || CURRENT_ACCOUNT_NAME() AS ACCOUNT_NAMESPACE, "
                    "CURRENT_TRANSACTION() AS TRANSACTION_ID")
                if len(context) != 1:
                    raise AdmissionInvariantError("Missing session context")
                context_row = _row(context[0])
                if context_row.get("ACCOUNT_NAMESPACE") != self.account_namespace:
                    raise AdmissionInvariantError("Session account namespace mismatch")
                if context_row.get("TRANSACTION_ID") is not None:
                    raise AdmissionInvariantError("Session already has an active transaction")
                try:
                    self._sql(session, "BEGIN TRANSACTION")
                    yield session
                    try:
                        self._sql(session, "COMMIT")
                    except Exception as exc:
                        # The COMMIT result is uncertain. Never claim another slot.
                        raise AdmissionClaimUncertain("Claim COMMIT outcome uncertain") from exc
                    committed = True
                except BaseException as exc:
                    # A failed rollback after a write leaves claim ownership uncertain.
                    try:
                        self._sql(session, "ROLLBACK")
                    except Exception as rollback_exc:
                        raise AdmissionClaimUncertain("Claim rollback outcome uncertain") from rollback_exc
                    raise
            if not committed:
                raise AdmissionUnavailable("Session factory suppressed a transaction failure")
        except AdmissionError:
            raise
        except Exception as exc:
            # Acknowledged rollback means a lock timeout cannot own a permit.
            # Keep the cause for type-only diagnostics, never its message.
            if _is_contention(exc):
                raise AdmissionContended("Admission claim contended") from exc
            raise AdmissionUnavailable("Admission store unavailable; reconciliation may be required") from exc

    def try_claim(self, identity: CallIdentity) -> Permit | None:
        if not isinstance(identity, CallIdentity):
            raise TypeError("A trusted CallIdentity is required")
        permit = None
        with self._transaction() as session:
            rows = self._sql(session,
                f"SELECT SLOT_ID, POOL_EPOCH, STATE, OWNER_TOKEN, FENCE FROM {self._table} "
                f"WHERE ACCOUNT_NAMESPACE = ? ORDER BY SLOT_ID LIMIT {self.capacity + 1}",
                [self.account_namespace])
            inventory = [_row(row) for row in rows]
            # Validate the entire namespace, not just FREE rows: PKs are unenforced.
            if (len(inventory) != self.capacity
                    or [row.get("SLOT_ID") for row in inventory] != list(range(1, self.capacity + 1))):
                raise AdmissionInvariantError("Pool inventory does not match deployment capacity")
            for row in inventory:
                if (row.get("POOL_EPOCH") != self.pool_epoch
                        or row.get("STATE") not in {"FREE", "HELD", "QUARANTINED"}
                        or type(row.get("FENCE")) is not int or row["FENCE"] < 0
                        or (row["STATE"] == "FREE") != (row.get("OWNER_TOKEN") is None)):
                    raise AdmissionInvariantError("Pool inventory is corrupt or epoch changed")
            free = next((row for row in inventory if row["STATE"] == "FREE"), None)
            if free is not None:
                owner = uuid4().hex
                count = _affected(self._sql(session,
                    f"UPDATE {self._table} SET STATE = 'HELD', OWNER_TOKEN = ?, FENCE = FENCE + 1, "
                    "JOB_ID = ?, CALLER_ID = ?, GENERATION = ?, SHARD_ID = ?, "
                    "LEASE_EXPIRES_AT = DATEADD('second', ?, CURRENT_TIMESTAMP()), "
                    "UPDATED_AT = CURRENT_TIMESTAMP(), COMPLETION = NULL, RECONCILIATION_REF = NULL "
                    "WHERE ACCOUNT_NAMESPACE = ? AND POOL_EPOCH = ? AND SLOT_ID = ? "
                    "AND STATE = 'FREE' AND OWNER_TOKEN IS NULL AND FENCE = ?",
                    [owner, identity.job_id, identity.caller_id, identity.generation, identity.shard_id,
                     self.lease_seconds, self.account_namespace, self.pool_epoch, free["SLOT_ID"], free["FENCE"]]))
                if count > 1:
                    raise AdmissionInvariantError("Claim updated multiple slots")
                if count == 1:
                    permit = Permit(self.account_namespace, self.pool_epoch, free["SLOT_ID"],
                                    owner, free["FENCE"] + 1, identity)
        return permit

    def _permit_params(self, permit: Permit) -> list[Any]:
        if (not isinstance(permit, Permit) or permit.account_namespace != self.account_namespace
                or permit.pool_epoch != self.pool_epoch or not 1 <= permit.slot_id <= self.capacity):
            raise StalePermit("Permit belongs to a different pool")
        return [permit.account_namespace, permit.pool_epoch, permit.slot_id, permit.owner, permit.fence,
                permit.identity.job_id, permit.identity.caller_id, permit.identity.generation,
                permit.identity.shard_id]

    def _change(self, permit: Permit, assignment: str, values: list[Any], condition: str) -> None:
        params = self._permit_params(permit)
        with self._transaction() as session:
            count = _affected(self._sql(session,
                f"UPDATE {self._table} SET {assignment}, UPDATED_AT = CURRENT_TIMESTAMP() "
                "WHERE ACCOUNT_NAMESPACE = ? AND POOL_EPOCH = ? AND SLOT_ID = ? "
                "AND OWNER_TOKEN = ? AND FENCE = ? AND JOB_ID = ? AND CALLER_ID = ? "
                f"AND GENERATION = ? AND SHARD_ID = ? AND {condition}", values + params))
            if count == 0:
                raise StalePermit("Permit no longer matches or lease expired")
            if count != 1:
                raise AdmissionInvariantError("Permit update affected multiple slots")

    def renew(self, permit: Permit) -> None:
        """Same logical owner, NEW exclusive session. Never revive expired/quarantined work."""
        self._change(permit, "LEASE_EXPIRES_AT = DATEADD('second', ?, CURRENT_TIMESTAMP())",
                     [self.lease_seconds], "STATE = 'HELD' AND LEASE_EXPIRES_AT > CURRENT_TIMESTAMP()")

    def record_reconciliation(self, permit: Permit, reference: ThreadReference) -> None:
        """Write once while HELD; returning requires one row and acknowledged COMMIT."""
        if type(reference) is not ThreadReference:
            raise TypeError("A trusted ThreadReference is required")
        self._change(permit, "RECONCILIATION_REF = ?", [reference.serialize()],
            "STATE = 'HELD' AND LEASE_EXPIRES_AT > CURRENT_TIMESTAMP() AND RECONCILIATION_REF IS NULL")

    def read_reconciliation(self, permit: Permit) -> ThreadReference:
        """Read-only scoped lookup. Never upgrades untracked old permits."""
        params = self._permit_params(permit)
        try:
            with self._factory() as session:
                rows = self._sql(session,
                    f"SELECT RECONCILIATION_REF FROM {self._table} "
                    "WHERE ACCOUNT_NAMESPACE = ? AND POOL_EPOCH = ? AND SLOT_ID = ? "
                    "AND OWNER_TOKEN = ? AND FENCE = ? AND JOB_ID = ? AND CALLER_ID = ? "
                    "AND GENERATION = ? AND SHARD_ID = ? AND STATE IN ('HELD', 'QUARANTINED') "
                    "AND ACCOUNT_NAMESPACE = CURRENT_ORGANIZATION_NAME() || '.' || CURRENT_ACCOUNT_NAME() LIMIT 2",
                    params)
                if len(rows) != 1:
                    raise StalePermit("Recovery permit scope does not match exactly one occupied slot")
                return ThreadReference.parse(_row(rows[0]).get("RECONCILIATION_REF"))
        except AdmissionError:
            raise
        except Exception:
            raise AdmissionUnavailable("Scoped thread reference unavailable") from None

    def quarantine(self, permit: Permit) -> None:
        """Retain owner and fence indefinitely, even if the liveness lease expired."""
        self._change(permit, "STATE = 'QUARANTINED'", [], "STATE IN ('HELD', 'QUARANTINED')")

    def complete(self, permit: Permit, completion: Completion, *, reconciliation_ref: str | None = None) -> None:
        """Release ONLY on explicit terminal evidence; allowed after expiry.

        For orphan/uncertain calls, use reconcile_terminal instead. An expired
        lease alone, elapsed wall time, or caller cancellation is never evidence.
        """
        if not isinstance(completion, Completion):
            raise ValueError("Explicit terminal Completion is required")
        if reconciliation_ref is not None:
            _identity(reconciliation_ref, "reconciliation_ref")
        self._change(permit,
            "STATE = 'FREE', OWNER_TOKEN = NULL, FENCE = FENCE + 1, LEASE_EXPIRES_AT = NULL, "
            "COMPLETION = ?, RECONCILIATION_REF = ?",
            [completion.value, reconciliation_ref], "STATE IN ('HELD', 'QUARANTINED')")

    def reconcile_terminal(self, permit: Permit, completion: Completion, *, evidence_ref: str,
                           retired_dispatcher: bool) -> None:
        """Trusted reconciler attests terminal remote work + retired old dispatcher.

        evidence_ref is a non-secret audit reference, NOT credentials or payload.
        This method does not contact the provider or verify evidence automatically.
        """
        if retired_dispatcher is not True:
            raise AdmissionError("Terminal reconciliation requires an explicitly retired dispatcher")
        _identity(evidence_ref, "evidence_ref")
        self.complete(permit, completion, reconciliation_ref=evidence_ref)


class RequestScope(Protocol):
    @property
    def owner_id(self) -> str: ...
    @property
    def snapshot_id(self) -> str: ...


class AdmissionRequest(Protocol):
    """Structural ScanRequest subset, avoiding a circular scan import."""
    @property
    def scope(self) -> RequestScope: ...
    @property
    def generation(self) -> str: ...
    @property
    def shard_id(self) -> str: ...
    @property
    def message(self) -> str: ...
    def check_active(self) -> None: ...
    def remaining_seconds(self) -> float: ...


@dataclass
class _CallState:
    request: AdmissionRequest
    permit: Permit
    renewal_failed: Event
    invoked: bool = False
    completion: Completion | None = None
    lifecycle_bound: bool = False
    reference: ThreadReference | None = None
    diagnostics: list[ScanTransportDiagnostic] = field(default_factory=list)
    active: bool = True
    lock: Any = field(default_factory=Lock, repr=False)


@dataclass(frozen=True)
class ScanCallLifecycle:
    """Exact-request capability; no thread-local lookup in the transport.

    The paired gate validates the capability on every operation. A copied context,
    reused request, or different admission cannot dispatch a second model call.
    """

    _gate: ScanCallAdmission = field(repr=False)
    _state: _CallState = field(repr=False)

    def record_reconciliation(self, reference: ThreadReference) -> None:
        if type(reference) is not ThreadReference:
            raise TypeError("A trusted ThreadReference is required")
        self._gate._validate_lifecycle(self._state)
        if self._state.reference is not None:
            raise AdmissionError("Thread reference was already recorded")
        if reference.request_digest != request_digest(self._state.request):
            raise AdmissionError("Thread reference request digest mismatch")
        self._state.request.check_active()
        self._gate.store.record_reconciliation(self._state.permit, reference)
        self._state.reference = reference
        self._state.request.check_active()
        self._gate._validate_lifecycle(self._state)

    def check_dispatch(self) -> None:
        self._gate._validate_lifecycle(self._state)
        if self._state.reference is None:
            raise AdmissionError("Model dispatch requires acknowledged thread persistence")
        self._state.request.check_active()

    def record_diagnostic(self, diagnostic: ScanTransportDiagnostic) -> None:
        # Only bounded in-memory append: never call a sink or store here.
        from app.core.automap_scan_transport import ScanTransportDiagnostic
        if (type(diagnostic) is ScanTransportDiagnostic and len(self._state.diagnostics) < 6
                and diagnostic.scope == self._state.request.scope
                and diagnostic.generation == self._state.request.generation
                and diagnostic.shard_id == self._state.request.shard_id):
            self._state.diagnostics.append(diagnostic)


class ScanCallAdmission:
    """Pass admission=adapter, backend=adapter.wrap_backend(transport) to the scan.

    job_id/caller_id must come from the trusted job/auth context, never a model.
    The scope owner must match caller_id; applications using composite owner IDs
    must supply that same trusted identifier. One adapter may serve many threads.
    """

    def __init__(self, store: SnowflakeCallAdmission, *, job_id: str, caller_id: str,
                 poll_seconds: float = 0.05, heartbeat_seconds: float | None = None) -> None:
        self.store = store
        self.job_id = _identity(job_id, "job_id")
        self.caller_id = _identity(caller_id, "caller_id")
        self._poll = poll_seconds
        self._heartbeat = store.lease_seconds / 3 if heartbeat_seconds is None else heartbeat_seconds
        for value in (self._poll, self._heartbeat):
            if type(value) not in (int, float) or not math.isfinite(value) or value <= 0:
                raise ValueError("Wait intervals must be positive and finite")
        if self._heartbeat >= store.lease_seconds:
            raise ValueError("Heartbeat must be shorter than the lease")
        self._current: ContextVar[_CallState | None] = ContextVar("automap_admission", default=None)

    @contextmanager
    def __call__(self, request: AdmissionRequest) -> Iterator[bool]:
        if self._current.get() is not None:
            raise AdmissionError("Nested admission is not supported")
        if request.scope.owner_id != self.caller_id:
            raise AdmissionError("Request caller scope mismatch")
        identity = CallIdentity(self.job_id, self.caller_id, request.generation, request.shard_id)
        attempt = 0
        while True:
            request.check_active()
            try:
                permit = self.store.try_claim(identity)
            except AdmissionContended:
                # Transient lock/statement failures are contention, not a shard
                # refusal. The same deadline bounds all retries.
                permit = None
            if permit is not None:
                break
            request.check_active()
            delay = min(2.0, max(0.25, self._poll) * 2 ** min(attempt, 3))
            delay *= 0.75 + random.random() * 0.5
            attempt += 1
            time.sleep(min(delay, request.remaining_seconds()))
        state = _CallState(request, permit, Event())
        stop = Event()

        def heartbeat() -> None:
            while not stop.wait(self._heartbeat):
                try:
                    self.store.renew(permit)
                except Exception:
                    state.renewal_failed.set()
                    try:
                        self.store.quarantine(permit)
                    except Exception:
                        pass  # HELD is just as non-reclaimable as QUARANTINED.
                    return

        thread = Thread(target=heartbeat, name="automap-permit-renew", daemon=True)
        token = self._current.set(state)
        entered = False
        try:
            request.check_active()
            thread.start()
            entered = True
            yield True
        finally:
            stop.set()
            if thread.ident is not None:
                # An in-flight renewal uses an independent session; fencing makes
                # a late heartbeat harmless after completion/reuse of this slot.
                thread.join(timeout=self._heartbeat)
            state.active = False
            self._current.reset(token)
            if not entered:
                self.store.complete(permit, Completion.NOT_DISPATCHED)
            elif state.completion is not None:
                self.store.complete(permit, state.completion)
            else:
                self.store.quarantine(permit)
                if not state.invoked:
                    raise UnreportedCompletion("Paired backend did not report completion")

    def _validate_lifecycle(self, state: _CallState) -> None:
        if (self._current.get() is not state or not state.active or not state.invoked
                or state.completion is not None or state.renewal_failed.is_set()):
            raise AdmissionError("Lifecycle requires its active paired backend permit")

    def bind_lifecycle(self, request: AdmissionRequest) -> ScanCallLifecycle:
        state = self._current.get()
        if state is None:
            raise AdmissionError("Lifecycle requires its unique admitted request")
        with state.lock:
            if state.request is not request or state.lifecycle_bound:
                raise AdmissionError("Lifecycle requires its unique admitted request")
            self._validate_lifecycle(state)
            state.lifecycle_bound = True
        return ScanCallLifecycle(self, state)

    def diagnostics_for(self, request: AdmissionRequest) -> tuple[ScanTransportDiagnostic, ...]:
        state = self._current.get()
        if state is None or state.request is not request:
            raise AdmissionError("Diagnostics require their admitted request")
        return tuple(state.diagnostics)

    def wrap_backend(self, backend: Callable[[AdmissionRequest], str]) -> Callable[[AdmissionRequest], str]:
        if not callable(backend):
            raise TypeError("A synchronous one-call backend is required")

        def guarded(request: AdmissionRequest) -> str:
            state = self._current.get()
            if state is None:
                raise AdmissionError("Backend requires its unused admission context")
            with state.lock:
                if not state.active or state.request is not request or state.invoked:
                    raise AdmissionError("Backend requires its unused admission context")
                state.invoked = True
            state.completion = Completion.NOT_DISPATCHED
            request.check_active()
            if state.renewal_failed.is_set():
                raise AdmissionUnavailable("Permit renewal failed before dispatch")
            self.store.renew(state.permit)
            request.check_active()
            state.completion = None
            try:
                result = backend(request)
            except RemoteCallCompleted:
                state.completion = Completion.FAILED
                raise
            else:
                state.completion = Completion.SUCCEEDED
                return result

        return guarded
