"""Run the local backend with the v3 test registry and existing credentials.

No credentials are copied to disk. Client DEV/UAT deployment files are untouched.
"""
import argparse
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--credential-env', required=True, type=Path)
    parser.add_argument('--profile', type=Path, help='Optional existing local test profile')
    parser.add_argument('--port', type=int, default=8103)
    parser.add_argument('--host', choices=['localhost','127.0.0.1'], default='127.0.0.1')
    parser.add_argument('--warehouse', help='Existing test warehouse; no warehouse settings are changed')
    parser.add_argument('--frontend-origin', help='Local frontend origin for this process only')
    args = parser.parse_args()
    from dotenv import dotenv_values
    if not args.credential_env.is_file() or (args.profile and not args.profile.is_file()):
        raise ValueError('Local credential/profile file does not exist')
    config = {**dotenv_values(args.credential_env), **(dotenv_values(args.profile) if args.profile else {})}
    if args.frontend_origin:
        from urllib.parse import urlparse
        origin = urlparse(args.frontend_origin)
        if origin.scheme != 'http' or origin.hostname not in {'127.0.0.1', 'localhost'} or origin.path not in {'', '/'} or origin.query or origin.fragment or origin.username:
            raise ValueError('Frontend origin must be an HTTP loopback origin')
        config['CORS_ALLOWED_ORIGINS'] = args.frontend_origin.rstrip('/')
    if args.warehouse:
        config['SNOWFLAKE_WAREHOUSE'] = args.warehouse
    if config.get('SNOWFLAKE_ACCOUNT', '').upper() != 'A0581299278961-BBINSIGHT_PARTNER':
        raise ValueError('This launcher is restricted to the separate local test account')
    # Runtime settings reject unsupported feature routes; preserve source credentials.
    os.environ.update({key: value for key, value in config.items() if value is not None})
    import hashlib
    for name, file in (('AGENT_SPEC_SOURCE_MAPPING_SHA256', 'agent_spec_source_mapping.yaml'),
                       ('AGENT_SPEC_TRANSFORMATION_RULE_SHA256', 'agent_spec_transformation_rule.yaml')):
        os.environ[name] = hashlib.sha256((ROOT / 'infra/snowflake/agents' / file).read_bytes()).hexdigest()
    sys.path.insert(0, str(ROOT / 'services/sttm-builder'))
    os.chdir(ROOT / 'services/sttm-builder')
    from app.core.config import Settings
    settings = Settings(_env_file=None)
    assert settings.resolved_semantic_native_views_table in {
        'FOCUS_DB_2.STTM_MCP.SEM_NATIVE_VIEWS', 'FOCUS_DB_2.STTM_MCP.LATEST_NATIVE_VIEWS'}
    import uvicorn
    uvicorn.run('app.main:app', host=args.host, port=args.port, log_level='warning')


if __name__ == '__main__':
    main()
