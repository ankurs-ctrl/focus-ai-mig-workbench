import type { STTMRecord } from "@/services/projectService";

const PUBLISHED_STATUSES = ["COMPLETE", "COMPLETED", "PUBLISHED"];

export function getMappingCounts(sttms: STTMRecord[]) {
  const total = sttms.length;
  const published = sttms.filter((row) =>
    PUBLISHED_STATUSES.includes(row.status?.toUpperCase()),
  ).length;
  return { total, published, inProgress: total - published };
}
