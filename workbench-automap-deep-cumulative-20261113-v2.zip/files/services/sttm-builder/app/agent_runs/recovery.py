"""Shared recovery policy for the worker, API and conversation diagnostics."""
from __future__ import annotations
from app.agent_runtime.execution import BudgetExceededError
from app.agent_runs.models import RunStatus

PERMANENT_FAILURES = {'authorization_denied','authorization_error','validation_error',
    'missing_scope','permanent_tool_failure','schema_contract_error'}
# Snowflake lock/statement timeouts and an expired session token: retrying the same step can succeed.
_TRANSIENT_SQL_CODES = {'000625', '000627', '000630', '390114'}


def failure_code(exc: Exception) -> str:
    seen: set[int] = set()
    current: BaseException | None = exc
    while current is not None and id(current) not in seen:
        if isinstance(current, BudgetExceededError):
            return 'budget_exhausted'
        seen.add(id(current))
        current = current.__cause__ or current.__context__
    sql_code = str(getattr(exc,'sql_error_code','') or getattr(exc,'errno',''))
    detail = str(exc).lower()
    if sql_code == '100078' or ('too long' in detail and 'truncated' in detail):
        return 'schema_contract_error'
    if isinstance(exc,PermissionError):
        return 'authorization_denied'
    if isinstance(exc,ValueError):
        return 'validation_error'
    if getattr(exc, 'error_code', None):
        return str(exc.error_code)
    # A timeout or dropped connection says nothing about the request itself;
    # the run can resume from its last durable checkpoint.
    if isinstance(exc, (TimeoutError, ConnectionError)) or sql_code.zfill(6) in _TRANSIENT_SQL_CODES:
        return 'transient_failure'
    return 'permanent_tool_failure'


def can_resume(run) -> bool:
    code = str(run.error_code or '').casefold()
    detail = str(run.safe_error or '').lower()
    # Legacy Snowpark wrappers recorded 1304 instead of the underlying error.
    if code == '1304' and 'too long' in detail and 'truncated' in detail:
        return False
    return (run.status is RunStatus.FAILED and run.resume_attempt < getattr(getattr(run, "policy", None), "max_resume_attempts", 1)
            and not run.cancel_requested_at and code not in PERMANENT_FAILURES)
