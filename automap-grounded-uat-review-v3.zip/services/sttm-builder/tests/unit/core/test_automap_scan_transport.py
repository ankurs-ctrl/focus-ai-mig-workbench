"""Offline transport contract tests: real httpx.Client and MockTransport only."""
from dataclasses import asdict, replace
import json
import logging
from pathlib import Path
import runpy
from threading import Event
from types import SimpleNamespace
import time
import traceback
from unittest.mock import Mock

import httpx
import pytest

from app.core.automap_admission import (
    Completion, Permit, RemoteCallCompleted, ScanCallAdmission, SnowflakeCallAdmission,
)
from app.core.automap_scan import (
    InvalidScanResponse, ScanOutputBudgetError, ScanRequest, ScanStatus, ScanStopped, ScanTransportReason,
    scan_registry, validate_scan_response,
)
from app.core.automap_scan_transport import (
    AUTOMAP_USER_AGENT, DiagnosticEncoding, DiagnosticMedia, DiagnosticPhase, DiagnosticReason, DiagnosticStatus,
    DiagnosticBlockType, DiagnosticContentKind, TerminalResponseReason,
    RawResponseBudgetError, ScanTransportConfig, ScanTransportDiagnostic, ScanTransportError,
    SnowflakeScanTransport, TerminalCallFailure, TerminalOutputBudgetError, TerminalResponseError,
)
from app.core.automap_shards import ContextRecord, MessageBudget, ShardRegistry, SnapshotScope
from app.core.snowflake_agent import SnowflakeAgentClient


SCOPE = SnapshotScope("caller", "snapshot")
TOKEN = "private-test-credential-do-not-log"
MESSAGES = [{"role": "user", "status": "completed", "content": [
    {"type": "text", "text": 'Checked \\"context\\"\n\u00e9\U0001f680'}]}]


def request(**changes):
    return replace(ScanRequest(SCOPE, "generation", "shard", ("target",), ("record",),
                               json.dumps(MESSAGES, ensure_ascii=False), MessageBudget(2000, 4000),
                               time.monotonic() + 10, Event(), Event()), **changes)


def answer(text="{}", **changes):
    return {"role": "assistant", "status": "completed",
            "content": [{"type": "text", "text": text}], **changes}


def response(data=None, *, status=200, raw=None, headers=None, stream=None):
    if raw is None:
        raw = json.dumps(answer() if data is None else data, ensure_ascii=False).encode("utf-8")
    return httpx.Response(status, headers=headers, stream=stream or httpx.ByteStream(raw))


class Chunks(httpx.SyncByteStream):
    def __init__(self, chunks):
        self.chunks = chunks
        self.closed = False
        self.reads = 0

    def __iter__(self):
        for chunk in self.chunks:
            self.reads += 1
            if callable(chunk):
                chunk = chunk()
            if isinstance(chunk, Exception):
                raise chunk
            yield chunk

    def close(self):
        self.closed = True


@pytest.fixture
def make_transport(monkeypatch):
    clients = []
    agent = SnowflakeAgentClient(token=TOKEN, host="account.snowflakecomputing.com",
                                 role="CALLER_ROLE", warehouse="CALLER_WH")
    # Any accidental route through the old retried/audited path fails offline.
    for method in ("run", "run_detailed", "stream_events", "get_specification"):
        monkeypatch.setattr(agent, method, Mock(side_effect=AssertionError("Unexpected model API path")))

    def make(handler, *, max_response_bytes=10000, agent_client=agent, diagnostic_sink=None, **client_options):
        client = httpx.Client(transport=httpx.MockTransport(handler), **client_options)
        clients.append(client)
        backend = SnowflakeScanTransport(agent_client=agent_client, http_client=client,
            config=ScanTransportConfig("db.sc.scan_agent", max_response_bytes), diagnostic_sink=diagnostic_sink)
        return backend, client

    yield make
    for client in clients:
        client.close()


def admission():
    store = Mock(spec=SnowflakeCallAdmission)
    store.lease_seconds = 120
    store.try_claim.side_effect = lambda identity: Permit("ORG.ACCOUNT", "epoch", 1, "owner", 1, identity)
    gate = ScanCallAdmission(store, job_id="job", caller_id="caller", heartbeat_seconds=30)
    return gate, store


PROVIDER_ID = "12fcb8bb-d91e-491a-ae30-6cf934017462"


@pytest.mark.parametrize("case,phases,reason", [
    ("encoding", ["before_parse", "failure"], ScanTransportReason.UNSUPPORTED_CONTENT_ENCODING),
    ("non200", ["before_parse", "parsed", "failure"], ScanTransportReason.UNEXPECTED_HTTP_STATUS),
    ("malformed", ["before_parse", "failure"], ScanTransportReason.MALFORMED_JSON),
    ("terminal", ["before_parse", "parsed", "failure"], DiagnosticReason.TERMINAL_FAILURE),
    ("success", ["before_parse", "parsed"], None),
])
def test_diagnostic_phases_and_fixed_projection(make_transport, case, phases, reason):
    events = []
    stream = Chunks([b"private malformed body"] if case == "malformed" else [json.dumps(
        answer(request_id=PROVIDER_ID, run_id="123-456", status="error" if case == "terminal" else "completed",
               error_message=TOKEN)).encode()])
    headers = {"Content-Encoding": "gzip" if case == "encoding" else "identity",
               "Content-Type": "application/json; private=" + TOKEN,
               "Authorization": TOKEN, "Cookie": TOKEN, "X-Private": TOKEN,
               "X-Request-Id": PROVIDER_ID}
    backend, _ = make_transport(lambda _: response(status=503 if case in ("encoding", "non200") else 200,
        headers=headers, stream=stream), diagnostic_sink=events.append)
    if case == "success":
        assert backend(request()) == "{}"
    else:
        with pytest.raises(TerminalCallFailure if case == "terminal" else ScanTransportError):
            backend(request())
    assert [event.phase.value for event in events] == phases
    assert all(event.request_id == PROVIDER_ID for event in events)
    assert events[-1].reason == reason
    assert events[0].http_status == (503 if case in ("encoding", "non200") else 200)
    assert events[0].media is DiagnosticMedia.JSON
    assert events[0].encoding is (DiagnosticEncoding.GZIP if case == "encoding" else DiagnosticEncoding.IDENTITY)
    if case == "encoding":
        assert stream.reads == 0
        assert all(event.run_id is None for event in events)
    if "parsed" in phases:
        assert events[1].run_id == "123-456"
    assert TOKEN not in json.dumps([asdict(event) for event in events])
    assert stream.closed


@pytest.mark.parametrize("location", ["header", "body_snake", "body_camel"])
@pytest.mark.parametrize("value", [TOKEN, "Bearer " + PROVIDER_ID, PROVIDER_ID + "\n", " " + PROVIDER_ID,
    "a" * 1024, "00000000-0000-0000-0000-00000000000Z", "request-123", "\u00e9" * 36])
def test_malformed_provider_ids_are_ignored(make_transport, location, value):
    events = []
    headers, data = {}, answer()
    if location == "header":
        headers["X-Request-Id"] = value.encode("utf-8")
    else:
        data["request_id" if location == "body_snake" else "requestId"] = value
    backend, _ = make_transport(lambda _: response(data, headers=headers), diagnostic_sink=events.append)
    assert backend(request()) == "{}"
    assert len(events) == 2 and all(event.request_id is None for event in events)


@pytest.mark.parametrize("location", ["x-request-id", "x-snowflake-request-id", "request_id", "requestId"])
def test_recognized_uuid_locations_only(make_transport, location):
    events = []
    data, headers = answer(), {}
    (headers if location.startswith("x-") else data)[location] = PROVIDER_ID.upper()
    backend, _ = make_transport(lambda _: response(data, headers=headers), diagnostic_sink=events.append)
    assert backend(request()) == "{}"
    assert events[-1].request_id == PROVIDER_ID


@pytest.mark.parametrize("run_id", [None, True, 123, {}, "123", "123-456-789", "-1-2", "1-2\n",
    "1-" + "2" * 20, "\u0661-2", TOKEN])
def test_invalid_run_ids_never_persist(make_transport, run_id):
    events = []
    backend, _ = make_transport(lambda _: response(answer(run_id=run_id)), diagnostic_sink=events.append)
    assert backend(request()) == "{}"
    assert all(event.run_id is None for event in events)


def test_arbitrary_and_nested_identifiers_are_not_promoted(make_transport):
    events = []
    backend, _ = make_transport(lambda _: response(answer(metadata={"request_id": PROVIDER_ID, "run_id": "1-2"},
        correlation_id=PROVIDER_ID), headers={"Authorization": PROVIDER_ID, "X-Correlation-Id": PROVIDER_ID}),
        diagnostic_sink=events.append)
    assert backend(request()) == "{}"
    assert all(event.request_id is None and event.run_id is None for event in events)


@pytest.mark.parametrize("case", ["success", "terminal", "uncertain", "disconnect"])
def test_sink_failure_never_masks_outcome_or_retries(make_transport, caplog, case):
    events, sent = [], []

    def sink(event):
        events.append(event)
        raise RuntimeError(TOKEN)

    def handler(outgoing):
        sent.append(outgoing)
        if case == "disconnect":
            raise httpx.ReadTimeout(TOKEN)
        return response(answer(status="error" if case == "terminal" else "completed"),
                        status=503 if case == "uncertain" else 200)

    backend, _ = make_transport(handler, diagnostic_sink=sink)
    gate, store = admission()
    req = request()
    with gate(req):
        if case == "success":
            assert gate.wrap_backend(backend)(req) == "{}"
        else:
            with pytest.raises(TerminalCallFailure if case == "terminal" else ScanTransportError) as caught:
                gate.wrap_backend(backend)(req)
            assert TOKEN not in "".join(traceback.format_exception(caught.value))
    assert len(sent) == 1 and 1 <= len(events) <= 3
    assert TOKEN not in caplog.text
    if case in ("uncertain", "disconnect"):
        store.quarantine.assert_called_once()
        store.complete.assert_not_called()
    else:
        store.quarantine.assert_not_called()
        assert store.complete.call_args.args[1] == (Completion.SUCCEEDED if case == "success" else Completion.FAILED)


@pytest.mark.parametrize("encoding", ["gzip", "deflate", "br", "PRIVATE", "identity, gzip"])
def test_unsupported_encoding_diagnostic_never_parses_or_reads(make_transport, monkeypatch, encoding):
    import app.core.automap_scan_transport as transport
    original = transport._load_json
    parses = []

    def parse(value):
        parses.append(value)
        return original(value)

    monkeypatch.setattr(transport, "_load_json", parse)
    events = []
    stream = Chunks([lambda: pytest.fail("Encoded body must never be read")])
    backend, _ = make_transport(lambda _: response(status=429, headers={"Content-Encoding": encoding},
        stream=stream), diagnostic_sink=events.append)
    with pytest.raises(ScanTransportError):
        backend(request())
    assert len(parses) == 1  # outbound normalized messages only
    assert len(events) == 2 and all(event.http_status == 429 for event in events)
    assert stream.closed and stream.reads == 0


@pytest.mark.parametrize("media,expected", [("text/event-stream", DiagnosticMedia.EVENT_STREAM),
    ("PRIVATE", DiagnosticMedia.OTHER), ("", DiagnosticMedia.UNKNOWN)])
def test_media_is_enum_not_raw_header(make_transport, media, expected):
    events = []
    backend, _ = make_transport(lambda _: response(headers={"Content-Type": media}), diagnostic_sink=events.append)
    assert backend(request()) == "{}"
    assert events[0].media is expected
    assert "PRIVATE" not in json.dumps([asdict(event) for event in events])


@pytest.mark.parametrize("status,expected", [("completed", DiagnosticStatus.COMPLETED),
    ("error", DiagnosticStatus.ERROR), ("cancelled", DiagnosticStatus.CANCELLED),
    ("timed_out", DiagnosticStatus.TIMED_OUT), (TOKEN, DiagnosticStatus.UNKNOWN)])
def test_parsed_status_never_persists_arbitrary_provider_text(make_transport, status, expected):
    events = []
    backend, _ = make_transport(lambda _: response(answer(status=status)), diagnostic_sink=events.append)
    if status == "completed":
        assert backend(request()) == "{}"
    else:
        with pytest.raises((ScanTransportError, TerminalCallFailure)):
            backend(request())
    assert events[1].status is expected
    assert TOKEN not in json.dumps([asdict(event) for event in events])


@pytest.mark.parametrize("status,error", [(429, TerminalCallFailure), (503, ScanTransportError)])
def test_diagnostic_only_parse_failure_cannot_replace_http_outcome(make_transport, status, error):
    events = []
    backend, _ = make_transport(lambda _: response(status=status, raw=b"not json"), diagnostic_sink=events.append)
    with pytest.raises(error):
        backend(request())
    assert [event.phase for event in events] == [DiagnosticPhase.BEFORE_PARSE, DiagnosticPhase.FAILURE]


def test_header_event_survives_immediate_cancel(make_transport):
    events = []
    req = request()
    stream = Chunks([lambda: pytest.fail("No reads after cancellation")])

    def handler(outgoing):
        req._cancel.set()
        return response(headers={"X-Request-Id": PROVIDER_ID}, stream=stream)

    backend, _ = make_transport(handler, diagnostic_sink=events.append)
    with pytest.raises(ScanStopped):
        backend(req)
    assert [event.phase for event in events] == [DiagnosticPhase.BEFORE_PARSE, DiagnosticPhase.FAILURE]
    assert events[0].request_id == PROVIDER_ID
    assert events[-1].reason is DiagnosticReason.STOPPED
    assert stream.closed and stream.reads == 0


def test_unknown_exception_diagnostic_uses_static_reason(make_transport):
    events = []
    error = RuntimeError(TOKEN)

    def handler(outgoing):
        raise error

    backend, _ = make_transport(handler, diagnostic_sink=events.append)
    with pytest.raises(RuntimeError) as caught:
        backend(request())
    assert caught.value is error  # original behavior, not diagnostic completion
    assert len(events) == 1 and events[0].reason is DiagnosticReason.UNKNOWN_FAILURE
    assert TOKEN not in json.dumps(asdict(events[0]))


def test_diagnostic_is_immutable_and_rejects_freeform_values():
    from dataclasses import FrozenInstanceError
    event = ScanTransportDiagnostic(SCOPE, "generation", "shard", DiagnosticPhase.BEFORE_PARSE)
    with pytest.raises(FrozenInstanceError):
        event.request_id = TOKEN
    for changes in ({"reason": TOKEN}, {"encoding": TOKEN}, {"http_status": True}, {"request_id": TOKEN},
                    {"run_id": TOKEN}, {"generation": "g" * 257}):
        with pytest.raises(ValueError):
            replace(event, **changes)


def test_exact_messages_fixed_wrapper_same_caller_headers_and_reuse(make_transport, caplog):
    sent = []

    def handler(outgoing):
        sent.append(outgoing)
        return response(answer('{"targets":[]}'))

    backend, client = make_transport(handler, headers={"X-Other-Caller": "must-not-send",
                                                       "User-Agent": "untrusted-client-agent"},
                                      cookies={"session": "must-not-send"}, params={"agent": "foreign"},
                                      auth=("wrong", "credential"))
    req = request()
    with caplog.at_level(logging.DEBUG):
        assert backend(req) == '{"targets":[]}'
        assert backend(req) == '{"targets":[]}'
    assert not client.is_closed and len(sent) == 2
    for outgoing in sent:
        assert outgoing.method == "POST"
        assert str(outgoing.url) == (
            "https://account.snowflakecomputing.com/api/v2/databases/DB/schemas/SC/agents/SCAN_AGENT:run")
        assert outgoing.content == ('{"messages":' + req.message + ',"stream":false}').encode("utf-8")
        assert json.loads(outgoing.content) == {"messages": MESSAGES, "stream": False}
        assert outgoing.headers["Authorization"] == f"Bearer {TOKEN}"
        assert outgoing.headers["X-Snowflake-Authorization-Token-Type"] == "OAUTH"
        assert outgoing.headers["X-Snowflake-Role"] == "CALLER_ROLE"
        assert outgoing.headers["X-Snowflake-Warehouse"] == "CALLER_WH"
        assert outgoing.headers["Accept-Encoding"] == "identity"
        assert outgoing.headers.get_list("User-Agent") == [AUTOMAP_USER_AGENT]
        assert "cookie" not in outgoing.headers and "X-Other-Caller" not in outgoing.headers
        assert all(0 < value <= 10 for value in outgoing.extensions["timeout"].values())
    assert TOKEN not in caplog.text and req.message not in caplog.text
    assert TOKEN not in repr(backend)


def test_raw_request_drops_default_user_agent_but_transport_sets_static_value(make_transport):
    seen = []

    def handler(outgoing):
        seen.append(outgoing.headers.get("User-Agent"))
        if not seen[-1]:
            return response({"code": "391903"}, status=400)
        return response()

    backend, client = make_transport(handler)
    assert client.headers["User-Agent"].startswith("python-httpx/")
    raw = httpx.Request("POST", backend._url, headers=backend._agent_client._build_headers(), content=b"{}")
    rejected = client.send(raw, stream=True, auth=None, follow_redirects=False)
    try:
        assert rejected.status_code == 400
    finally:
        rejected.close()
    with client.stream("GET", backend._url) as metadata:
        assert metadata.status_code == 200
    assert backend(request()) == "{}"
    assert seen == [None, client.headers["User-Agent"], "ffp-ai-migration-workbench/1.0"]


@pytest.mark.parametrize("mode", ["diagnose_http", "diagnose_request_validation"])
def test_diagnostic_probes_share_static_user_agent(monkeypatch, capsys, mode):
    from snowflake.snowpark import Session
    from app.core.snowflake import SnowflakeClient

    script = Path(__file__).resolve().parents[5] / "scripts" / "test_parallel_automap_dev.py"
    probe = runpy.run_path(str(script))
    session = Mock()
    builder = Mock()
    builder.config.return_value = builder
    builder.create.return_value = session
    monkeypatch.setattr(Session, "builder", builder)
    function = probe[mode]
    monkeypatch.setitem(function.__globals__, "validate_identity",
                        lambda actual: SimpleNamespace(role=probe["EXPECTED_ROLE"]))
    monkeypatch.setattr(SnowflakeClient, "get_rest_session_context",
                        lambda actual: SimpleNamespace(token=TOKEN, host=probe["EXPECTED_HOST"]))
    sent = []

    def handler(outgoing):
        sent.append(outgoing)
        assert outgoing.headers.get_list("User-Agent") == [AUTOMAP_USER_AGENT]
        assert outgoing.headers.get_list("Authorization") == [f'Snowflake Token="{TOKEN}"']
        assert outgoing.headers["Accept-Encoding"] == "identity"
        assert "cookie" not in outgoing.headers
        assert "X-Snowflake-Authorization-Token-Type" not in outgoing.headers
        assert "proxy-authorization" not in outgoing.headers
        if mode == "diagnose_request_validation":
            assert outgoing.method == "POST" and outgoing.content == b"{}"
            assert set(outgoing.headers) == {"host", "content-length", "authorization",
                "content-type", "accept", "accept-encoding", "user-agent"}
            return response({"code": "000001", "message": "messages required"}, status=400,
                            headers={"Content-Type": "application/json"})
        assert outgoing.method == "GET"
        return response()

    real_client = httpx.Client
    monkeypatch.setattr(httpx, "Client", lambda **kwargs: real_client(
        transport=httpx.MockTransport(handler), **kwargs))
    assert function("offline-test") == 0
    assert len(sent) == 1
    builder.config.assert_called_once_with("connection_name", "offline-test")
    session.close.assert_called_once()
    assert TOKEN not in capsys.readouterr().out


@pytest.fixture
def live_fenced_selection():
    # Offline reconstruction of the reported completed/fenced response shape.
    # A seeded answer is a format smoke fixture, not accuracy evidence.
    selection = ('{"generation":"generation","shard_id":"shard","targets":['
                 '{"target_id":"target","candidates":[{"record_id":"record",'
                 '"role":"source","evidence_refs":["record"]}]}]}')
    return selection, {"message": answer("```json\n" + selection + "\n```")}


def test_live_shape_fenced_raw_selection_passes_strict_validator(make_transport, live_fenced_selection):
    selection, data = live_fenced_selection
    raw = json.dumps(data).encode("utf-8")
    backend, _ = make_transport(lambda _: response(raw=raw))
    req = request(eligible_source_record_ids=("record",))
    extracted = backend(req)
    assert extracted == selection
    targets = validate_scan_response(extracted, request=req, output_budget=req.output_budget)
    assert targets[0].candidates[0].record_id == "record"
    assert targets[0].candidates[0].evidence_refs == ("record",)


@pytest.mark.parametrize("opening", ["```json", "```"])
@pytest.mark.parametrize("newline", ["\n", "\r\n"])
@pytest.mark.parametrize("padding", ["", " \t\r\n"])
def test_single_outer_fence_only_changes_wrapper(make_transport, opening, newline, padding):
    selection = '{ "literal": "  ```json \\n ```  ", "escaped": "\\\"" }'
    text = padding + opening + newline + selection + newline + "```" + padding
    backend, _ = make_transport(lambda _: response(answer(text)))
    assert backend(request()) == selection


@pytest.mark.parametrize("text", ["{}", ' \n { "value": "```json\\n```" } \t\r\n'])
def test_plain_json_text_is_unchanged(make_transport, text):
    backend, _ = make_transport(lambda _: response(answer(text)))
    assert backend(request()) == text


@pytest.mark.parametrize("template", [
    "Here is the result:\n```json\n%s\n```",
    "```json\n%s\n```\nDone.",
    "```json\n%s\n```\n```json\n{}\n```",
    "```json\n```\n%s\n```\n```",
    "```python\n%s\n```",
    "````json\n%s\n````",
    "```JSON\n%s\n```",
    "```json %s```",
    "```json\n%s\n````",
    "```json\n%s",
])
def test_prose_multiple_or_unsupported_fences_remain_rejected(
        make_transport, live_fenced_selection, template):
    selection, _ = live_fenced_selection
    text = template % selection
    backend, _ = make_transport(lambda _: response(answer(text)))
    req = request(eligible_source_record_ids=("record",))
    assert backend(req) == text
    with pytest.raises(json.JSONDecodeError):
        validate_scan_response(text, request=req, output_budget=req.output_budget)


@pytest.mark.parametrize("body,error", [
    ('{"generation":', json.JSONDecodeError),
    ('{"generation":"generation","generation":"generation",'
     '"shard_id":"shard","targets":[]}', InvalidScanResponse),
])
def test_fence_removal_does_not_repair_json_or_duplicate_keys(make_transport, body, error):
    backend, _ = make_transport(lambda _: response(answer("```json\n" + body + "\n```")))
    req = request()
    extracted = backend(req)
    assert extracted == body
    with pytest.raises(error):
        validate_scan_response(extracted, request=req, output_budget=req.output_budget)


@pytest.mark.parametrize("limit", ["chars", "bytes", "raw"])
def test_fenced_output_limits_are_enforced_before_normalization(make_transport, monkeypatch, limit):
    body = '{"value":"\u00e9"}'
    text = " \n```json\n" + body + "\n```\t "
    raw = json.dumps(answer(text), ensure_ascii=False).encode("utf-8")
    budget = MessageBudget(len(text) - 1, 4000) if limit == "chars" else MessageBudget(
        2000, len(text.encode("utf-8")) - 1 if limit == "bytes" else 4000)
    assert len(body) <= budget.max_chars and len(body.encode("utf-8")) <= budget.max_bytes
    backend, _ = make_transport(lambda _: response(raw=raw),
                               max_response_bytes=len(raw) - 1 if limit == "raw" else len(raw))
    monkeypatch.setattr("app.core.automap_scan_transport._strip_outer_json_fence",
                        Mock(side_effect=AssertionError("Must check budgets before stripping")))
    expected = RawResponseBudgetError if limit == "raw" else TerminalOutputBudgetError
    with pytest.raises(expected):
        backend(request(output_budget=budget))


def test_fenced_output_exact_original_limits_succeed(make_transport):
    text = " \n```json\n{}\n```\t "
    raw = json.dumps(answer(text)).encode("utf-8")
    backend, _ = make_transport(lambda _: response(raw=raw), max_response_bytes=len(raw))
    assert backend(request(output_budget=MessageBudget(len(text), len(text.encode("utf-8"))))) == "{}"


@pytest.mark.parametrize("status,error", [
    ("in_progress", ScanTransportError), ("error", TerminalCallFailure),
])
def test_fenced_text_is_not_normalized_until_completion(make_transport, monkeypatch, status, error):
    backend, _ = make_transport(lambda _: response(answer("```json\n{}\n```", status=status)))
    monkeypatch.setattr("app.core.automap_scan_transport._strip_outer_json_fence",
                        Mock(side_effect=AssertionError("Must establish completion before stripping")))
    with pytest.raises(error):
        backend(request())


def test_existing_session_token_header_is_preserved(make_transport):
    agent = SnowflakeAgentClient(token=TOKEN, host="account.snowflakecomputing.com", auth_mode="snowflake_token")
    sent = []
    backend, _ = make_transport(lambda outgoing: sent.append(outgoing) or response(), agent_client=agent)
    backend(request())
    assert sent[0].headers["Authorization"] == f'Snowflake Token="{TOKEN}"'
    assert "X-Snowflake-Authorization-Token-Type" not in sent[0].headers


@pytest.mark.parametrize("agent", [None, "", "AGENT", "DB.AGENT", "DB.SC.AGENT.EXTRA", "DB..AGENT",
                                    'DB.SC."AGENT"', "DB.SC.AGENT/other", "DB.SC.AGENT?x=y",
                                    "DB.SC.AGENT\n", "DB.SC.AGENT;DROP", " DB.SC.AGENT", "DB.SC." + "A" * 256])
def test_agent_configuration_requires_three_validated_parts(agent):
    with pytest.raises(ValueError):
        ScanTransportConfig(agent, 100)


@pytest.mark.parametrize("limit", [True, False, 0, -1, 1.5, None])
def test_raw_limit_requires_positive_integer(limit):
    with pytest.raises(ValueError):
        ScanTransportConfig("DB.SC.AGENT", limit)


@pytest.mark.parametrize("host", ["name@evil.example", "account.example/path", "account.example?x=y",
                                   "account.example#fragment"])
def test_malformed_existing_origin_is_rejected(make_transport, host):
    agent = SnowflakeAgentClient(token=TOKEN, host=host)
    with pytest.raises(ValueError):
        make_transport(lambda _: pytest.fail("Network forbidden"), agent_client=agent)


@pytest.mark.parametrize("message", ["not-json", "{}", "[]", "null", '[{"role":"user","content":"text"}]',
    '[{"role":"user","status":"completed","content":[]}]',
    '[{"role":"user","status":"completed","content":[{"type":"tool_result","text":"x"}]}]',
    '[{"role":"user","status":"completed","status":"error","content":[]}]',
    '[{"role":"user","status":"completed","content":[{"type":"text","text":"\\ud800"}]}]',
    '[{"role":"user","status":"completed","content":[{"type":"text","text":NaN}]}]',
    json.dumps([{**MESSAGES[0], "tools": []}]), json.dumps([{**MESSAGES[0], "role": "assistant"}])])
def test_invalid_messages_fail_before_post(make_transport, message):
    backend, _ = make_transport(lambda _: pytest.fail("Must not dispatch"))
    with pytest.raises(ScanTransportError):
        backend(request(message=message))


@pytest.mark.parametrize("mode", ["cancel", "stop", "deadline"])
def test_inactive_request_never_posts(make_transport, mode):
    req = request()
    if mode == "deadline":
        req = replace(req, deadline=time.monotonic() - 1)
    else:
        (req._cancel if mode == "cancel" else req._stop).set()
    backend, _ = make_transport(lambda _: pytest.fail("Must not dispatch"))
    with pytest.raises(ScanStopped):
        backend(req)


@pytest.mark.parametrize("deadline", [float("nan"), float("inf"), True])
def test_invalid_deadline_never_posts(make_transport, deadline):
    backend, _ = make_transport(lambda _: pytest.fail("Must not dispatch"))
    with pytest.raises(ScanTransportError):
        backend(request(deadline=deadline))


def test_accepted_post_then_readtimeout_is_one_post_and_real_admission_quarantine(make_transport, caplog):
    sent = []
    stream = Chunks([b'{"role":"assistant",', httpx.ReadTimeout(TOKEN)])
    backend, _ = make_transport(lambda outgoing: sent.append(outgoing) or response(stream=stream))
    gate, store = admission()
    req = request()
    with caplog.at_level(logging.DEBUG), gate(req):
        # Like scan_registry, swallow the error INSIDE admission's context.
        with pytest.raises(ScanTransportError) as error:
            gate.wrap_backend(backend)(req)
    assert len(sent) == 1 and stream.closed
    store.quarantine.assert_called_once()
    store.complete.assert_not_called()
    rendered = "".join(traceback.format_exception(error.value))
    assert TOKEN not in rendered and TOKEN not in caplog.text
    assert not isinstance(error.value, RemoteCallCompleted)
    assert error.value.reason is ScanTransportReason.HTTP_READ_TIMEOUT


@pytest.mark.parametrize("raw,headers,expected_reads", [
    (b"x" * 11, {}, 1), (b"x" * 11, {"Content-Length": "11"}, 0),
    (b"x" * 11, {"Content-Length": "1"}, 1),
])
def test_raw_body_limit_stops_read_and_quarantines(make_transport, raw, headers, expected_reads):
    stream = Chunks([raw, lambda: pytest.fail("Must stop before next chunk")])
    backend, _ = make_transport(lambda _: response(stream=stream, headers=headers), max_response_bytes=10)
    gate, store = admission()
    req = request()
    with gate(req), pytest.raises(RawResponseBudgetError):
        gate.wrap_backend(backend)(req)
    assert stream.closed and stream.reads == expected_reads
    store.quarantine.assert_called_once()
    store.complete.assert_not_called()


def test_raw_cap_exact_boundary_and_reasoning_metadata_separate_from_text_budget(make_transport):
    data = answer("{}", metadata={"reasoning": "m" * 200})
    data["content"].insert(0, {"type": "thinking", "thinking": {"text": "r" * 200}})
    raw = json.dumps(data).encode()
    backend, _ = make_transport(lambda _: response(raw=raw), max_response_bytes=len(raw))
    assert backend(request(output_budget=MessageBudget(2, 2))) == "{}"


@pytest.mark.parametrize("text,budget", [("abc", MessageBudget(2, 100)), ("\u00e9\u00e9", MessageBudget(2, 3))])
def test_output_limits_are_terminal_and_preserve_scan_budget_error(make_transport, text, budget):
    backend, _ = make_transport(lambda _: response(answer(text)))
    gate, store = admission()
    req = request(output_budget=budget)
    with gate(req), pytest.raises(TerminalOutputBudgetError) as error:
        gate.wrap_backend(backend)(req)
    assert isinstance(error.value, ScanOutputBudgetError)
    assert store.complete.call_args.args[1] == Completion.FAILED
    store.quarantine.assert_not_called()


@pytest.mark.parametrize("status", ["error", "cancelled", "timed_out"])
@pytest.mark.parametrize("wrapped", [False, True])
def test_known_remote_terminal_status_never_returns_text(make_transport, status, wrapped):
    data = answer(status=status)
    if wrapped:
        data = {"message": data}
    backend, _ = make_transport(lambda _: response(data))
    gate, store = admission()
    req = request()
    with gate(req), pytest.raises(TerminalCallFailure):
        gate.wrap_backend(backend)(req)
    assert store.complete.call_args.args[1] == Completion.FAILED
    store.quarantine.assert_not_called()


@pytest.mark.parametrize("status", ["in_progress", "queued", "failed", "future_status", None, [], 1, ""])
def test_unknown_or_nonterminal_status_quarantines_even_with_text_and_error(make_transport, status):
    backend, _ = make_transport(lambda _: response(answer(status=status, error={"message": TOKEN})))
    gate, store = admission()
    req = request()
    with gate(req), pytest.raises(ScanTransportError) as error:
        gate.wrap_backend(backend)(req)
    assert error.value.reason is ScanTransportReason.UNKNOWN_STATUS
    store.quarantine.assert_called_once()
    store.complete.assert_not_called()


def test_outer_nonterminal_beats_inner_completed(make_transport):
    backend, _ = make_transport(lambda _: response({"status": "in_progress", "message": answer()}))
    with pytest.raises(ScanTransportError):
        backend(request())


@pytest.mark.parametrize("data", [answer(error={"code": "bad"}), answer(error=None), answer(code="390112")])
def test_terminal_error_envelope_not_success(make_transport, data):
    backend, _ = make_transport(lambda _: response(data))
    with pytest.raises(TerminalCallFailure):
        backend(request())


@pytest.mark.parametrize("raw", [b"", b"not-json", b"[]", b"null", b'"{}"', b"\xff",
    b'{"status":"in_progress","status":"completed","content":[]}',
    b'{"status":"completed","metadata":NaN}',
    b'{"message":"error","code":"390112"}', b'{"message":"{}"}', b'{"content":[]}'])
def test_malformed_or_unrecognized_success_envelope_is_uncertain(make_transport, raw):
    backend, _ = make_transport(lambda _: response(raw=raw))
    with pytest.raises(ScanTransportError):
        backend(request())


@pytest.mark.parametrize("content", [None, "{}", [], [None], [{"type": "text", "text": 5}],
    [{"type": "error", "error": TOKEN}], [{"type": "tool_use", "tool_use": {"client_side_execute": True}}],
    [{"type": "text", "text": "{}"}, {"type": "tool_result", "tool_result": {"status": "error"}}]])
def test_terminal_malformed_or_tool_content_is_rejected(make_transport, content):
    backend, _ = make_transport(lambda _: response(answer(content=content)))
    with pytest.raises(TerminalResponseError):
        backend(request())


@pytest.mark.parametrize("changes,reason,kinds,count", [
    ({"message": TOKEN}, "invalid_message", (), 0),
    ({"role": TOKEN}, "invalid_role", ("text",), 1),
    ({"content": TOKEN}, "invalid_content_shape", (), 0),
    ({"content": [TOKEN]}, "invalid_block_shape", ("non_object",), 1),
    ({"content": [{"type": "text", "error": TOKEN}]}, "block_error", ("text",), 1),
    ({"content": [{"type": "text", "text": {"value": TOKEN, "secret": TOKEN}}]},
     "invalid_text_value", ("text",), 1),
    ({"content": []}, "no_text", (), 0),
    ({"content": [{"type": "thinking", "thinking": TOKEN}]}, "no_text", ("thinking",), 1),
    ({"content": [{"type": "text", "text": " \n"}]}, "no_text", ("text",), 1),
    ({"content": [{"type": "text", "text": "\ud800"}]}, "invalid_extraction", ("text",), 1),
])
def test_precise_terminal_reason_and_safe_shape(make_transport, caplog, changes, reason, kinds, count):
    events = []
    backend, _ = make_transport(lambda _: response(raw=json.dumps(answer(**changes)).encode()),
                                diagnostic_sink=events.append)
    gate, store = admission()
    req = request()
    with gate(req):
        with pytest.raises(TerminalResponseError) as caught:
            gate.wrap_backend(backend)(req)
    error = caught.value
    assert isinstance(error, RemoteCallCompleted)
    assert error.response_reason is TerminalResponseReason(reason)
    event = events[-1]
    assert event.reason is DiagnosticReason.TERMINAL_RESPONSE
    assert event.response_reason is error.response_reason
    assert event.block_count == count and tuple(item.value for item in event.block_types) == kinds
    assert store.complete.call_args.args[1] is Completion.FAILED
    store.quarantine.assert_not_called()
    expected = (f"Auto-map terminal response rejected code={reason} content_kind={event.content_kind.value} "
                f"block_count={count} block_types={','.join(kinds) or 'none'}")
    assert [record.getMessage() for record in caplog.records if record.name == backend.__module__] == [expected]
    assert TOKEN not in caplog.text + json.dumps(asdict(event)) + str(error)


@pytest.mark.parametrize("kind,expected", [
    ("tool_use", "tool_use"), ("tool_result", "tool_result"), ("citation", "citation"), ("file", "file"),
    ("error", "error"), (TOKEN + "\nBearer secret", "unknown"), ({"credential": TOKEN}, "invalid"),
    (None, "invalid"), ("TEXT", "unknown"),
])
def test_nontext_block_types_are_diagnostic_only_never_skipped(make_transport, caplog, kind, expected):
    events = []
    blocks = [{"type": "text", "text": "{}"}, {"type": kind, "value": TOKEN}]
    backend, _ = make_transport(lambda _: response(answer(content=blocks)), diagnostic_sink=events.append)
    with pytest.raises(TerminalResponseError) as caught:
        backend(request())
    assert caught.value.response_reason is TerminalResponseReason.INVALID_CONTENT_KIND
    assert set(events[-1].block_types) == {DiagnosticBlockType.TEXT, DiagnosticBlockType(expected)}
    assert events[-1].block_count == 2
    assert TOKEN not in caplog.text + json.dumps(asdict(events[-1]))
    assert all(record.exc_info is None for record in caplog.records)


def test_block_shape_projection_is_bounded_and_rejects_freeform():
    error = TerminalResponseError("static", content=[{"type": TOKEN + str(index)} for index in range(1000)])
    assert error.block_types == (DiagnosticBlockType.UNKNOWN,)
    event = ScanTransportDiagnostic(SCOPE, "generation", "shard", DiagnosticPhase.FAILURE)
    for changes in ({"response_reason": TOKEN}, {"content_kind": TOKEN}, {"block_types": (TOKEN,)},
                    {"block_count": True}, {"block_count": -1}, {"block_count": 1_000_001},
                    {"block_types": (DiagnosticBlockType.TEXT,) * 2}):
        with pytest.raises(ValueError):
            replace(event, **changes)


@pytest.mark.parametrize("status", ["in_progress", TOKEN, None, "absent"])
def test_diagnostic_content_cannot_upgrade_unknown_to_terminal(make_transport, caplog, status):
    data = answer(status=status, content=[{"type": "tool_use", "name": TOKEN}])
    if status == "absent":
        del data["status"]
    events = []
    backend, _ = make_transport(lambda _: response(data), diagnostic_sink=events.append)
    gate, store = admission()
    req = request()
    with gate(req), pytest.raises(ScanTransportError) as caught:
        gate.wrap_backend(backend)(req)
    assert not isinstance(caught.value, RemoteCallCompleted)
    assert events[-1].response_reason is None
    assert not caplog.records
    store.quarantine.assert_called_once()
    store.complete.assert_not_called()


def test_valid_thinking_and_text_unchanged_and_no_failure_log(make_transport, caplog):
    events = []
    data = answer(content=[{"type": "thinking", "thinking": TOKEN},
                           {"type": "text", "text": {"value": " {"}}, {"type": "text", "text": "} "}])
    backend, _ = make_transport(lambda _: response(data), diagnostic_sink=events.append)
    assert backend(request()) == " {} "
    assert not caplog.records and all(event.response_reason is None for event in events)


def test_completed_answer_accepts_inert_suggested_queries(make_transport):
    data = answer(content=[{"type": "thinking", "thinking": TOKEN},
                           {"type": "text", "text": "{}"},
                           {"type": "suggested_queries", "suggested_queries": [{"query": "What next?"}]}])
    backend, _ = make_transport(lambda _: response(data))
    assert backend(request()) == "{}"


@pytest.mark.parametrize("suggestions", [None, "question", ["question"], [{}],
    [{"query": 3}], [{"query": "x", "tool": "run"}]])
def test_malformed_suggested_queries_remain_rejected(make_transport, suggestions):
    data = answer(content=[{"type": "text", "text": "{}"},
                           {"type": "suggested_queries", "suggested_queries": suggestions}])
    backend, _ = make_transport(lambda _: response(data))
    with pytest.raises(TerminalResponseError):
        backend(request())


def test_suggestions_alone_are_not_an_answer(make_transport):
    data = answer(content=[{"type": "suggested_queries", "suggested_queries": [{"query": "What next?"}]}])
    backend, _ = make_transport(lambda _: response(data))
    with pytest.raises(TerminalResponseError) as caught:
        backend(request())
    assert caught.value.response_reason is TerminalResponseReason.NO_TEXT


@pytest.mark.parametrize("query", ["", "x" * 3000])
def test_suggestion_strings_use_whole_response_budget(make_transport, query):
    data = answer(content=[{"type": "text", "text": "{}"},
        {"type": "suggested_queries", "suggested_queries": [{"query": query}]}])
    backend, _ = make_transport(lambda _: response(data))
    assert backend(request()) == "{}"


def test_suggestion_count_is_aggregate_across_blocks(make_transport):
    data = answer(content=[{"type": "text", "text": "{}"}, *[
        {"type": "suggested_queries", "suggested_queries": [{"query": "x"}] * count}
        for count in (17, 16)]])
    backend, _ = make_transport(lambda _: response(data))
    with pytest.raises(TerminalResponseError):
        backend(request())


def test_extractor_exception_class_and_text_never_logged(make_transport, monkeypatch, caplog):
    backend, _ = make_transport(lambda _: response())
    error_type = type(TOKEN, (ValueError,), {})
    monkeypatch.setattr(backend._agent_client, "_extract_text_and_thread", Mock(side_effect=error_type(TOKEN)))
    with pytest.raises(TerminalResponseError) as caught:
        backend(request())
    assert caught.value.response_reason is TerminalResponseReason.INVALID_EXTRACTION
    assert TOKEN not in caplog.text + "".join(traceback.format_exception(caught.value))


def test_logging_failure_does_not_change_terminal_disposition(make_transport, monkeypatch):
    backend, _ = make_transport(lambda _: response(answer(content=[{"type": "tool_use"}])))
    monkeypatch.setattr("app.core.automap_scan_transport.logger.warning", Mock(side_effect=RuntimeError(TOKEN)))
    gate, store = admission()
    req = request()
    with gate(req), pytest.raises(TerminalResponseError):
        gate.wrap_backend(backend)(req)
    assert store.complete.call_args.args[1] is Completion.FAILED
    store.quarantine.assert_not_called()


@pytest.mark.parametrize("wrapped", [False, True])
def test_documented_final_shape_without_status_and_existing_parser_value_shape(make_transport, wrapped):
    data = {"role": "assistant", "content": [{"type": "text", "text": {"value": "{"}},
                                             {"type": "text", "text": "}"}]}
    if wrapped:
        data = {"message": data, "metadata": {"thread_id": "unused"}}
    backend, _ = make_transport(lambda _: response(data))
    assert backend(request()) == "{}"


@pytest.mark.parametrize("status", [202, 204, 301, 307, 400, 401, 403, 408, 500, 503, 504])
def test_http_status_alone_is_not_completion_and_redirects_never_followed(make_transport, status):
    sent = []
    backend, _ = make_transport(lambda outgoing: sent.append(outgoing) or response(status=status,
        headers={"Location": "https://foreign.example/agent"}), follow_redirects=True)
    with pytest.raises(ScanTransportError) as error:
        backend(request())
    assert error.value.reason is ScanTransportReason.UNEXPECTED_HTTP_STATUS
    assert len(sent) == 1


def test_http429_with_incomplete_read_remains_quarantined(make_transport):
    sent = []
    stream = Chunks([httpx.ReadTimeout("rejection body incomplete")])
    backend, _ = make_transport(lambda outgoing: sent.append(outgoing) or response(status=429, stream=stream))
    gate, store = admission()
    req = request()
    with gate(req), pytest.raises(ScanTransportError):
        gate.wrap_backend(backend)(req)
    assert len(sent) == 1 and stream.closed
    store.quarantine.assert_called_once()
    store.complete.assert_not_called()


def test_definitive_http429_releases_failed_without_retry(make_transport):
    sent = []
    backend, _ = make_transport(lambda outgoing: sent.append(outgoing) or response(status=429))
    gate, store = admission()
    req = request()
    with gate(req), pytest.raises(TerminalCallFailure):
        gate.wrap_backend(backend)(req)
    assert len(sent) == 1
    assert store.complete.call_args.args[1] == Completion.FAILED
    store.quarantine.assert_not_called()


@pytest.mark.parametrize("headers", [{"Content-Encoding": "gzip"}, {"Content-Length": "oops"},
                                       {"Content-Length": "-1"}, {"Content-Length": "999"}])
def test_encoded_or_incomplete_entities_cannot_be_success(make_transport, headers):
    backend, _ = make_transport(lambda _: response(headers=headers))
    with pytest.raises(ScanTransportError):
        backend(request())


@pytest.mark.parametrize("phase", ["headers", "chunk", "eof"])
@pytest.mark.parametrize("stop_kind", ["cancel", "deadline"])
def test_deadline_and_cancellation_checked_throughout_stream(make_transport, monkeypatch, phase, stop_kind):
    req = request()
    clock = [req.deadline - 5]
    monkeypatch.setattr("app.core.automap_scan.time.monotonic", lambda: clock[0])
    sent = []

    def stop():
        if stop_kind == "cancel":
            req._cancel.set()
        else:
            clock[0] = req.deadline + 1
        return b" "

    def pieces():
        if phase == "chunk":
            yield stop()
            pytest.fail("Should not read another chunk")
        yield json.dumps(answer()).encode()
        if phase == "eof":
            stop()

    stream = Chunks(pieces())

    def handler(outgoing):
        sent.append(outgoing)
        if phase == "headers":
            stop()
        return response(stream=stream)

    backend, _ = make_transport(handler)
    gate, store = admission()
    with gate(req), pytest.raises(ScanStopped) as error:
        gate.wrap_backend(backend)(req)
    assert error.value.status == (ScanStatus.CANCELED if stop_kind == "cancel" else ScanStatus.TIMED_OUT)
    assert len(sent) == 1 and stream.closed
    store.quarantine.assert_called_once()
    store.complete.assert_not_called()


def test_remaining_read_timeout_shrinks_instead_of_resetting(make_transport, monkeypatch):
    req = request()
    clock = [req.deadline - 3]
    monkeypatch.setattr("app.core.automap_scan.time.monotonic", lambda: clock[0])
    observed = []

    def handler(outgoing):
        def pieces():
            for chunk in [b'{"role":"assistant",', b'"content":[{"type":"text","text":"{}"}]}']:
                observed.append(outgoing.extensions["timeout"]["read"])
                clock[0] += 1
                yield chunk
        return response(stream=Chunks(pieces()))

    backend, _ = make_transport(handler)
    assert backend(req) == "{}"
    assert observed == [3, 2]


def test_cumulative_raw_limit_not_just_individual_chunks(make_transport):
    stream = Chunks([b"123456", b"78901", lambda: pytest.fail("Must stop reading")])
    backend, _ = make_transport(lambda _: response(stream=stream), max_response_bytes=10)
    with pytest.raises(RawResponseBudgetError):
        backend(request())
    assert stream.reads == 2 and stream.closed


def test_utf8_split_between_raw_chunks(make_transport):
    raw = json.dumps(answer("\u00e9"), ensure_ascii=False).encode("utf-8")
    split = raw.index(b"\xc3") + 1
    backend, _ = make_transport(lambda _: response(stream=Chunks([raw[:split], raw[split:]])))
    assert backend(request(output_budget=MessageBudget(1, 2))) == "\u00e9"


@pytest.mark.parametrize("kind", ["text", "thinking"])
def test_error_embedded_in_allowed_content_block_is_not_ignored(make_transport, kind):
    content = [{"type": kind, "text": "{}", "error": {"message": TOKEN}},
               {"type": "text", "text": "{}"}]
    backend, _ = make_transport(lambda _: response(answer(content=content)))
    with pytest.raises(TerminalResponseError):
        backend(request())


def test_cancellation_during_existing_parser_never_returns_success(make_transport, monkeypatch):
    backend, _ = make_transport(lambda _: response())
    req = request()

    def parser(data, fallback_thread_id):
        req._cancel.set()
        return "{}", "unused"

    monkeypatch.setattr(backend._agent_client, "_extract_text_and_thread", parser)
    with pytest.raises(ScanStopped):
        backend(req)


def test_cancellation_during_header_preparation_never_posts(make_transport, monkeypatch):
    backend, _ = make_transport(lambda _: pytest.fail("Must not dispatch"))
    req = request()
    build_headers = backend._agent_client._build_headers

    def headers():
        req._cancel.set()
        return build_headers()

    monkeypatch.setattr(backend._agent_client, "_build_headers", headers)
    with pytest.raises(ScanStopped):
        backend(req)


HTTP_ERRORS = [
    (httpx.ConnectTimeout, "http_connect_timeout"),
    (httpx.ReadTimeout, "http_read_timeout"),
    (httpx.WriteTimeout, "http_write_timeout"),
    (httpx.PoolTimeout, "http_pool_timeout"),
    (httpx.ConnectError, "http_connect_error"),
    (httpx.ReadError, "http_read_error"),
    (httpx.WriteError, "http_write_error"),
    (httpx.CloseError, "http_close_error"),
    (httpx.LocalProtocolError, "http_local_protocol_error"),
    (httpx.RemoteProtocolError, "http_remote_protocol_error"),
    (httpx.ProxyError, "http_proxy_error"),
    (httpx.UnsupportedProtocol, "http_unsupported_protocol"),
    (httpx.DecodingError, "http_decoding_error"),
    (httpx.TooManyRedirects, "http_too_many_redirects"),
    (httpx.HTTPStatusError, "http_status_error"),
    (httpx.TimeoutException, "http_error"),
    (httpx.NetworkError, "http_error"),
    (httpx.ProtocolError, "http_error"),
    (httpx.RequestError, "http_error"),
    (httpx.TransportError, "http_error"),
    (httpx.HTTPError, "http_error"),
    (type("PRIVATE_HTTP_SUBCLASS", (httpx.HTTPError,), {}), "http_error"),
]


@pytest.mark.parametrize("error_type,suffix", HTTP_ERRORS)
@pytest.mark.parametrize("phase", ["send", "read"])
def test_http_subtypes_use_only_static_diagnostics_and_suppress_sensitive_traceback(
        make_transport, caplog, error_type, suffix, phase):
    sent = []
    stream = None

    def handler(outgoing):
        nonlocal stream
        sent.append(outgoing)
        error = error_type(TOKEN, request=outgoing, response=response(raw=TOKEN.encode())) if (
            error_type is httpx.HTTPStatusError) else error_type(TOKEN)
        if phase == "send":
            raise error
        stream = Chunks([error])
        return response(stream=stream)

    backend, _ = make_transport(handler)
    gate, store = admission()
    req = request()
    with caplog.at_level(logging.DEBUG), gate(req), pytest.raises(ScanTransportError) as caught:
        gate.wrap_backend(backend)(req)
    assert caught.value.reason.value == "scan_transport_" + suffix
    assert type(caught.value.reason) is ScanTransportReason
    assert caught.value.__cause__ is None and caught.value.__suppress_context__
    assert not isinstance(caught.value, RemoteCallCompleted)
    assert len(sent) == 1
    if stream is not None:
        assert stream.closed
    store.quarantine.assert_called_once()
    store.complete.assert_not_called()
    rendered = "".join(traceback.format_exception(caught.value))
    assert TOKEN not in rendered + caplog.text + repr(caught.value)
    assert "PRIVATE_HTTP_SUBCLASS" not in rendered + caplog.text


@pytest.mark.parametrize("case,expected", [
    ("read_timeout", "scan_transport_http_read_timeout"),
    ("encoding", "scan_transport_unsupported_content_encoding"),
    ("http_status", "scan_transport_unexpected_http_status"),
    ("json", "scan_transport_malformed_json"),
    ("utf8", "scan_transport_malformed_json"),
    ("duplicate_json", "scan_transport_malformed_json"),
    ("nonfinite_json", "scan_transport_malformed_json"),
    ("status", "scan_transport_unknown_status"),
    ("missing_terminal_status", "scan_transport_unknown_status"),
    ("raw_budget", "RawResponseBudgetError"),
    ("output_budget", "output_budget_exceeded"),
    ("unknown_error", "RuntimeError"),
])
def test_safe_diagnostics_survive_real_scan_serialization_without_secrets_or_retries(
        make_transport, caplog, case, expected):
    sent = []
    streams = []
    secret = "PRIVATE_RESPONSE_BODY_AND_HEADER"

    def handler(outgoing):
        sent.append(outgoing)
        if case == "unknown_error":
            raise RuntimeError(secret + TOKEN)
        raw = json.dumps(answer(secret)).encode()
        headers = {"X-Private": secret}
        status = 200
        if case == "encoding":
            headers["Content-Encoding"] = secret
        elif case == "http_status":
            status = 503
        elif case == "json":
            raw = secret.encode()
        elif case == "utf8":
            raw = b"\xff" + secret.encode()
        elif case == "duplicate_json":
            raw = ('{"status":"' + secret + '","status":"completed"}').encode()
        elif case == "nonfinite_json":
            raw = ('{"status":"completed","value":NaN,"private":"' + secret + '"}').encode()
        elif case == "status":
            raw = json.dumps(answer(secret, status=secret, error={"message": TOKEN})).encode()
        elif case == "missing_terminal_status":
            raw = json.dumps({"error": secret, "code": TOKEN}).encode()
        elif case == "raw_budget":
            raw = secret.encode() * 1000
        elif case == "output_budget":
            raw = json.dumps(answer(secret * 100)).encode()
        stream = Chunks([httpx.ReadTimeout(TOKEN)] if case == "read_timeout" else [raw])
        streams.append(stream)
        return response(status=status, headers=headers, stream=stream)

    registry = ShardRegistry(scope=SCOPE, records=[
        ContextRecord(scope=SCOPE, record_id="record", kind="column", body={})],
        budget=MessageBudget(4000, 4000), message_builder=lambda payload: json.dumps(MESSAGES))
    backend, _ = make_transport(handler)
    gate, store = admission()
    with caplog.at_level(logging.DEBUG):
        result = scan_registry(registry=registry, scope=SCOPE, target_ids=["target"],
            admission=gate, backend=gate.wrap_backend(backend), max_workers=1, max_calls=1,
            total_seconds=5, output_budget=MessageBudget(2000, 2000))
        # Exercise the metadata a downstream summary/logger can actually receive.
        serialized = json.dumps(asdict(result))
        logging.getLogger(__name__).info("Scan result: %s", serialized)
    shard, = result.shards
    assert shard.error_code == expected
    assert shard.status == (ScanStatus.OUTPUT_BUDGET_EXCEEDED if case == "output_budget"
                            else ScanStatus.BACKEND_FAILED)
    assert not result.complete and shard.targets == ()
    assert result.reserved_calls == len(sent) == 1
    assert all(stream.closed for stream in streams)
    if case == "output_budget":
        assert store.complete.call_args.args[1] == Completion.FAILED
        store.quarantine.assert_not_called()
    else:
        store.quarantine.assert_called_once()
        store.complete.assert_not_called()
    for sensitive in (secret, TOKEN, request().message):
        assert sensitive not in repr(result) + serialized + caplog.text


@pytest.mark.parametrize("fenced", [False, True])
@pytest.mark.parametrize("failure", [False, True])
def test_actual_scan_registry_with_real_transport_and_admission(make_transport, failure, fenced):
    sent = []

    def builder(payload):
        return json.dumps(SnowflakeAgentClient._normalize_messages([
            {"role": "user", "content": json.dumps(payload)}]))

    registry = ShardRegistry(scope=SCOPE, records=[
        ContextRecord(scope=SCOPE, record_id="record", kind="column", body={})],
        budget=MessageBudget(4000, 4000), message_builder=builder)

    def handler(outgoing):
        sent.append(outgoing)
        if failure:
            return response(stream=Chunks([httpx.ReadTimeout("accepted remotely")]))
        packet = json.loads(json.loads(outgoing.content)["messages"][0]["content"][0]["text"])
        text = json.dumps({"generation": registry.generation, "shard_id": packet["shard_id"],
                           "targets": [{"target_id": "target", "candidates": []}]})
        if fenced:
            text = "```json\n" + text + "\n```"
        return response(answer(text))

    backend, _ = make_transport(handler)
    gate, store = admission()
    result = scan_registry(registry=registry, scope=SCOPE, target_ids=["target"],
        admission=gate, backend=gate.wrap_backend(backend), max_workers=1, max_calls=1,
        total_seconds=5, output_budget=MessageBudget(2000, 2000))
    assert len(sent) == 1 and result.reserved_calls == 1
    if failure:
        assert result.shards[0].status == ScanStatus.BACKEND_FAILED
        assert result.shards[0].error_code == "scan_transport_http_read_timeout"
        store.quarantine.assert_called_once()
        store.complete.assert_not_called()
    else:
        assert result.complete
        assert store.complete.call_args.args[1] == Completion.SUCCEEDED
        store.quarantine.assert_not_called()
