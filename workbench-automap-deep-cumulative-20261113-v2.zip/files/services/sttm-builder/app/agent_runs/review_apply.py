"""Apply a reviewer's mapping choice to the run-owned draft it concerns."""
from __future__ import annotations

import logging
import re
from typing import Any, Callable

from app.core.workspace_snapshot import apply_review_choice

logger = logging.getLogger(__name__)


def make_draft_writer(session: Any, settings: Any) -> Callable[..., dict[str, Any]]:
    """A writer that saves a chosen candidate into the draft as a new snapshot.

    Only a draft this run (or, for a follow-up, its owned lineage) created is
    changed; the user's edit permission is checked by the route before the
    answer reaches the service.
    """
    def write(*, run: Any, sttm_id: str, target_column: str, candidate: dict[str, Any], actor: Any,
              lineage: list[str] | None = None) -> dict[str, Any]:
        from app.core.project_service import ProjectService
        from app.schema.project import STTMAutosaveRequest

        projects = ProjectService(session=session, settings=settings)
        detail = projects.get_sttm_detail(sttm_id)
        if detail is None:
            raise ValueError("The draft for this review item no longer exists")
        owners = {str(run.run_id), *map(str, lineage or [])}
        if str(detail.sttm.metadata.get("migration_run_id") or "") not in owners:
            raise PermissionError("Only a draft created by this run can be changed from its review")
        candidate = ensure_firm_value(projects, str(detail.sttm.project_id), candidate, user_id=str(actor.user_id))
        snapshot = apply_review_choice(dict(detail.latest_snapshot or {}), target_column, candidate,
                                       answered_by=str(actor.user_id))
        receipt = projects.autosave_sttm(sttm_id, STTMAutosaveRequest(
            workspace_snapshot=snapshot, action="migration_agent.review_choice_applied",
            session_id=str(run.run_id), thread_id=str(run.run_id),
        ), user_id=str(actor.user_id))
        _credit_recommendations(session, settings, run=run, sttm_id=sttm_id, target_column=target_column,
                                candidate=candidate, user_id=str(actor.user_id))
        return {"sttm_id": sttm_id, "snapshot_id": getattr(receipt, "snapshot_id", None)}

    return write


_UUID = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.IGNORECASE)


def _credit_recommendations(session: Any, settings: Any, *, run: Any, sttm_id: str, target_column: str,
                            candidate: dict[str, Any], user_id: str) -> None:
    """The user chose this candidate: the FIR recommendations it cited were accepted."""
    cited = [str(value) for value in candidate.get("evidence_ids") or [] if _UUID.match(str(value))]
    if not cited:
        return
    from app.core.conversation_memory import ConversationMemoryService

    memory = ConversationMemoryService(session, settings)
    for recommendation_id in dict.fromkeys(cited):
        try:
            memory.record_fir_recommendation_outcome(
                recommendation_id=recommendation_id, outcome_type="accepted",
                context_key=f"migration:{run.run_id}:review", request_id=f"{run.run_id}:{sttm_id}:{target_column}",
                user_id=user_id, payload={"agent_name": "deep_agent", "sttm_id": sttm_id,
                                          "target_column": target_column, "source": "review_choice"},
            )
        except Exception:  # noqa: BLE001 - learning never blocks the user's decision
            logger.debug("Recommendation acceptance was not recorded", exc_info=True)


def ensure_firm_value(projects: Any, project_id: str, candidate: dict[str, Any], *, user_id: str) -> dict[str, Any]:
    """Create the firm value a chosen candidate needs in the draft's project.

    A value the project already holds under that name wins: the row binds to
    it, so the draft never disagrees with the project's firm values.
    """
    name = str(candidate.get("attribute_name") or "").strip()
    if not name:
        return candidate
    from app.schema.project import ProjectAttributeCreateRequest
    from app.agent_tools.firm_values import norm

    current = next((item for item in projects.list_project_attributes(project_id)
                    if norm(item.attribute_name) == norm(name)), None)
    if current is None:
        wanted = dict(candidate.get("firm_value") or {})
        value = str(wanted.get("value") if wanted.get("value") is not None else candidate.get("constant_value") or "")
        kind = str(wanted.get("type") or "VARCHAR").upper()
        kind = "VARCHAR" if kind in {"TEXT", "STRING"} or kind.startswith(("VARCHAR", "CHAR")) else kind.split("(")[0]
        current = projects.create_project_attribute(
            project_id,
            ProjectAttributeCreateRequest(attribute_name=name, attribute_type=kind, attribute_value=value),
            user_id=user_id,
            source_project_id=wanted.get("source_project_id") or None,
            source_attribute_id=wanted.get("source_attribute_id") or None,
        )
    return {**candidate, "attribute_name": current.attribute_name, "constant_value": current.attribute_value}
