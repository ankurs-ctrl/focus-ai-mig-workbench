import type { AutoMapSuggestion } from '@/types/api-contract';
import type { JoinConfig, TableNode } from '../types/sttm.types';

export const JOIN_REVIEW_KEY = 'workbench:row-join-review:v1';
export type JoinReviewIntent = {id: string; projectId: string | null; sttmId: string | null; mappingId: string;
  targetColumn: string; purpose: string; base: string; recommendation: NonNullable<AutoMapSuggestion['join_recommendation']>; status: 'pending' | 'saved'};
export function mappingBase(sttmId: string | null, path = '') {
  const match = /^\/sttm\/builder\/(new|[^/?#]+)/.exec(path);
  return match ? match[0] : `/sttm/builder/${encodeURIComponent(sttmId || 'new')}`;
}
export function rowReviewUrl(base: string, mappingId: string, section: 'candidates' | 'suggestions' = 'candidates') {
  return `${base}/mapping?reviewRow=${encodeURIComponent(mappingId)}&reviewSection=${section}`;
}
export function readJoinReview(storage: Pick<Storage, 'getItem'>, projectId: string | null, sttmId: string | null): JoinReviewIntent | null {
  try {const value = JSON.parse(storage.getItem(JOIN_REVIEW_KEY) || 'null');
    return value && value.projectId === projectId && value.sttmId === sttmId && typeof value.mappingId === 'string'
      && /^\/sttm\/builder\/[^/?#]+$/.test(value.base) && value.recommendation && ['pending','saved'].includes(value.status) ? value : null;
  } catch {return null;}
}
export function knownReviewSources(intent: JoinReviewIntent, sources: TableNode[]) {
  sources=Array.from(new Map(sources.map(source=>[source.tableId,source])).values());
  const wanted = [intent.recommendation.left_relation_id, intent.recommendation.right_relation_id].filter(Boolean);
  return sources.filter(source => wanted.includes(source.tableId) || (wanted.includes(source.qualifiedName)
    && sources.filter(other => other.qualifiedName === source.qualifiedName).length === 1));
}
export function joinReviewDraft(intent: JoinReviewIntent, tableIds: string[], joins: JoinConfig[]): JoinConfig {
  const rec = intent.recommendation;
  const left = tableIds.includes(rec.left_relation_id || '') ? rec.left_relation_id! : '';
  const right = tableIds.includes(rec.right_relation_id || '') ? rec.right_relation_id! : '';
  const existing = joins.find(join => join.leftTableId === left && join.rightTableId === right && left && right);
  if (existing) return {...existing, conditions: existing.conditions?.map(condition => ({...condition}))};
  return {id: `review:${intent.id}`, leftTableId: left, rightTableId: right, joinType: rec.join_type ?? undefined,
    source: 'USER_DEFINED', conditions: (rec.conditions ?? []).filter(item => item.left_column && item.right_column && item.operator)
      .map(item => ({leftColumn:item.left_column,rightColumn:item.right_column,operator:item.operator,
        connector: item.connector === 'OR' ? 'OR' : 'AND'}))};
}
