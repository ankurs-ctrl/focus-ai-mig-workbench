const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
const Module = require('node:module');
const filename = path.resolve(__dirname,'../middleware.ts');
const loaded = new Module(filename,module);
loaded.require = name => name === 'next/server' ? {NextResponse:{next:()=>({next:true}),redirect:url=>({redirect:url.pathname})}} : require(name);
loaded._compile(ts.transpileModule(fs.readFileSync(filename,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS}}).outputText,filename);
const request = (host,cookie=false) => ({nextUrl:{pathname:'/dashboard',hostname:host,clone(){return {...this};}},cookies:{get:()=>cookie?{value:'existing-session'}:undefined}});
const previous = {node:process.env.NODE_ENV,local:process.env.LOCAL_DEV_AUTH_ENABLED};
try {
  process.env.NODE_ENV='development';process.env.LOCAL_DEV_AUTH_ENABLED='true';
  assert.equal(loaded.exports.middleware(request('127.0.0.1')).next,true);
  assert.equal(loaded.exports.middleware(request('localhost')).next,true);
  assert.equal(loaded.exports.middleware(request('deployed.snowflakecomputing.app')).redirect,'/home');
  process.env.NODE_ENV='production';
  assert.equal(loaded.exports.middleware(request('127.0.0.1')).redirect,'/home');
  assert.equal(loaded.exports.middleware(request('deployed.snowflakecomputing.app',true)).next,true);
  process.env.NODE_ENV='development';delete process.env.LOCAL_DEV_AUTH_ENABLED;
  assert.equal(loaded.exports.middleware(request('127.0.0.1')).redirect,'/home');
  console.log('Local session routing is opt-in, development-only and loopback-only; production cookie guards remain.');
} finally {
  for(const [key,value] of [['NODE_ENV',previous.node],['LOCAL_DEV_AUTH_ENABLED',previous.local]]) {
    if(value === undefined) delete process.env[key]; else process.env[key]=value;
  }
}