import api from '../api/axiosInstance';
import {
  type MappingIntent,
  type RelationshipContextItem,
  type SemanticLevel,
  type SemanticContextItem,
  type SemanticSurface,
  type STTMBuilderEnvelopeRequest,
  type STTMBuilderEnvelopeResponse,
  type STTMIntent,
  type STTMOperation,
  type TableRef,
  type TargetAttributeItem,
  type WorkbenchContextSnapshotV1,
} from '@/types/api-contract';
import { buildApiEnvelope, getApiData, postEnvelopeData, resolveApiBaseUrl } from '@/api/axiosInstance';
import { API_ROUTES } from '@/api/routes';
import { handleApiClientError } from '@/api/errors/error-bus';
import {
  buildMockWorkbenchInvokeResponse,
  mockInvokeStream,
  mockWorkbenchInfo,
} from './mock/workbenchMockData';
import { mockDelay, throwMockError, useMockDb } from './mock/mockConfig';
import { extractSseChunk } from './streaming/sse';

export type { RelationshipContextItem, TableRef, TargetAttributeItem };

export type AutoMapJob = {
  job_id: string;
  request_id?: string | null;
  status: "queued" | "running" | "completed" | "failed";
  created_at: string;
  updated_at: string;
  attribute_count: number;
  batch_count: number;
  completed_batch_count?: number;
  completed_attribute_count?: number;
  partial_responses?: Array<{
    batch_index: number;
    attribute_count: number;
    target_attributes?: string[];
    response: STTMBuilderEnvelopeResponse;
    completed_at?: string;
  }>;
  response?: STTMBuilderEnvelopeResponse | null;
  error?: { code?: string; message?: string } | null;
};

export type WorkbenchRequest = {
  interface: STTMIntent;
  intent_route?: string | null;
  thread_id?: string | null;
  parent_message_id?: number | null;
  session_id?: string | null;
  attributes?: TargetAttributeItem[] | null;
  source_tables?: TableRef[] | null;
  message?: string | null;
  driving_table?: TableRef | null;
  relationships?: RelationshipContextItem[] | null;
  semantic_context?: SemanticContextItem[] | null;
  selected_columns_by_table?: Record<string, string[]> | null;
  surface?: SemanticSurface | null;
  semantic_level_requested?: SemanticLevel | null;
  target_table?: TableRef | null;
  selected_derived_sources?: string[] | null;
  semantic_bundle_id?: string | null;
  semantic_view_name?: string | null;
  derived_source_lineage?: Array<Record<string, unknown>> | null;
  datahub_context?: Record<string, unknown> | null;
  mapping_intent?: MappingIntent | null;
  workspace_context?: WorkbenchContextSnapshotV1 | null;
};

const operationByIntent: Record<STTMIntent, STTMOperation> = {
  AUTO_MAP: "sttm.auto_map",
  CHAT: "sttm.chat",
  TRANSFORM: "sttm.transform",
};

function nullableNonEmptyArray<T>(items?: T[] | null): T[] | null {
  return items && items.length > 0 ? items : null;
}

function toEnvelope(payload: WorkbenchRequest): STTMBuilderEnvelopeRequest {
  return buildApiEnvelope(
    operationByIntent[payload.interface],
    {
      intent: payload.interface,
      intent_route: payload.intent_route ?? null,
      attributes: nullableNonEmptyArray(payload.attributes),
      message: payload.message ?? null,
    },
    {
      thread_id: payload.thread_id ?? null,
      parent_message_id: payload.parent_message_id ?? null,
      session_id: payload.session_id ?? null,
      source_tables: nullableNonEmptyArray(payload.source_tables),
      driving_table: payload.driving_table ?? null,
      relationships: payload.relationships ?? null,
      semantic_context: payload.semantic_context ?? null,
      selected_columns_by_table: payload.selected_columns_by_table ?? null,
      surface: payload.surface ?? "SOURCE_SELECTION",
      semantic_level_requested: payload.semantic_level_requested ?? "L1_CONTEXT",
      target_table: payload.target_table ?? null,
      selected_derived_sources: nullableNonEmptyArray(payload.selected_derived_sources),
      semantic_bundle_id: payload.semantic_bundle_id ?? null,
      semantic_view_name: payload.semantic_view_name ?? null,
      derived_source_lineage: payload.derived_source_lineage ?? null,
      datahub_context: payload.datahub_context ?? null,
      mapping_intent: payload.mapping_intent ?? null,
      workspace_context: payload.workspace_context ?? null,
      routing_hint: payload.intent_route ?? null,
    },
  ) as STTMBuilderEnvelopeRequest;
}

type WorkbenchStreamEvent =
  | { event: "status"; data: Record<string, unknown> }
  | { event: "delta"; data: { text: string } }
  | { event: "suggestions"; data: { items: string[] } }
  | { event: "final"; data: STTMBuilderEnvelopeResponse }
  | { event: "error"; data: { message?: string; code?: string } };

type GatewayServerFrame = {
  contract_version: "1.0";
  type: string;
  session_id: string;
  request_id: string;
  event_id: string;
  timestamp: string;
  context_hash: string;
  data?: Record<string, unknown> | null;
  error?: { detail?: string; message?: string; code?: string; title?: string } | null;
};

function resolveWorkbenchAgentGatewayUrl(): string {
  const apiBase = resolveApiBaseUrl();
  const baseUrl = new URL(apiBase, window.location.origin);
  const wsPath = `${baseUrl.pathname.replace(/\/$/, "")}${API_ROUTES.workbench.agentGatewayWs}`;
  const protocol = baseUrl.protocol === "https:" ? "wss:" : "ws:";
  return `${protocol}//${baseUrl.host}${wsPath}`;
}

function mapGatewayFrame(frame: GatewayServerFrame): WorkbenchStreamEvent | null {
  if (frame.type === "assistant.status" || frame.type === "session.ready" || frame.type === "tool.started" || frame.type === "tool.completed") {
    return { event: "status", data: frame.data ?? {} };
  }
  if (frame.type === "assistant.delta") {
    return { event: "delta", data: { text: String(frame.data?.text ?? "") } };
  }
  if (frame.type === "assistant.suggestions") {
    const items = Array.isArray(frame.data?.items) ? frame.data.items.map(String) : [];
    return { event: "suggestions", data: { items } };
  }
  if (frame.type === "assistant.final") {
    return { event: "final", data: frame.data as unknown as STTMBuilderEnvelopeResponse };
  }
  if (frame.type === "assistant.error") {
    return {
      event: "error",
      data: {
        message: frame.error?.detail ?? frame.error?.message ?? frame.error?.title ?? "Workbench Agent Gateway request failed.",
        code: frame.error?.code,
      },
    };
  }
  if (frame.type === "mapping.partial" || frame.type === "artifact.ready") {
    return { event: "status", data: frame.data ?? {} };
  }
  return null;
}

async function* invokeGatewayStream(payload: WorkbenchRequest): AsyncGenerator<WorkbenchStreamEvent> {
  const envelope = toEnvelope(payload);
  const contextHash = payload.workspace_context?.context_hash ?? "";
  const requestId = envelope.request_id || crypto.randomUUID();
  const socket = new WebSocket(resolveWorkbenchAgentGatewayUrl());
  const queue: Array<WorkbenchStreamEvent | { event: "__done" } | { event: "__error"; error: Error }> = [];
  let notify: (() => void) | null = null;
  let opened = false;
  let terminal = false;

  const wake = () => {
    notify?.();
    notify = null;
  };
  const push = (item: WorkbenchStreamEvent | { event: "__done" } | { event: "__error"; error: Error }) => {
    queue.push(item);
    wake();
  };

  socket.onopen = () => {
    opened = true;
    socket.send(JSON.stringify({
      contract_version: "1.0",
      type: "message.send",
      request_id: requestId,
      event_id: crypto.randomUUID(),
      timestamp: new Date().toISOString(),
      context_hash: contextHash,
      data: { envelope },
    }));
  };
  socket.onmessage = (event) => {
    try {
      const frame = JSON.parse(String(event.data)) as GatewayServerFrame;
      const mapped = mapGatewayFrame(frame);
      if (mapped) push(mapped);
      if (frame.type === "assistant.final" || frame.type === "assistant.error") {
        terminal = true;
        socket.close();
        push({ event: "__done" });
      }
    } catch (error) {
      terminal = true;
      socket.close();
      push({ event: "__error", error: error instanceof Error ? error : new Error(String(error)) });
    }
  };
  socket.onerror = () => {
    if (!opened) {
      push({ event: "__error", error: new Error("Workbench Agent Gateway WebSocket could not connect.") });
    }
  };
  socket.onclose = () => {
    if (!terminal) {
      if (!opened) {
        push({ event: "__error", error: new Error("Workbench Agent Gateway disconnected before opening.") });
      } else {
        push({ event: "__done" });
      }
    }
  };

  while (true) {
    if (!queue.length) {
      await new Promise<void>((resolve) => {
        notify = resolve;
      });
    }
    const item = queue.shift();
    if (!item) continue;
    if (item.event === "__done") return;
    if (item.event === "__error") throw item.error;
    yield item;
  }
}

export const workbenchService = {
  invoke: async (payload: WorkbenchRequest) => {
    if (useMockDb) {
      throwMockError();
      return mockDelay(buildMockWorkbenchInvokeResponse(payload));
    }

    const response = await api.post<STTMBuilderEnvelopeResponse>(API_ROUTES.workbench.invoke, toEnvelope(payload), {
      timeout: 300000,
    });
    return response.data;
  },

  getInfo: async () => {
    if (useMockDb) {
      throwMockError();
      return mockDelay(mockWorkbenchInfo);
    }
    return getApiData(API_ROUTES.workbench.info);
  },

  startAutoMapJob: async (payload: WorkbenchRequest): Promise<AutoMapJob> => {
    return postEnvelopeData<AutoMapJob>(
      API_ROUTES.workbench.autoMapJobs,
      toEnvelope(payload),
      { timeout: 120000 },
    );
  },

  getAutoMapJob: async (jobId: string): Promise<AutoMapJob> => {
    return getApiData<AutoMapJob>(
      `${API_ROUTES.workbench.autoMapJobs}/${encodeURIComponent(jobId)}`,
      { timeout: 30000 },
    );
  },

  invokeStream: async function* (payload: WorkbenchRequest): AsyncGenerator<WorkbenchStreamEvent> {
    if (useMockDb) {
      throwMockError();
      yield* mockInvokeStream(payload);
      return;
    }

    try {
      yield* invokeGatewayStream(payload);
      return;
    } catch (error) {
      // Fall back to the existing SSE route when the new gateway is unavailable.
      // Agent/application errors that arrive through the socket are yielded as
      // normal error events and do not reach this fallback path.
      console.warn("Workbench Agent Gateway unavailable; falling back to SSE stream.", error);
    }

    const response = await fetch(`${resolveApiBaseUrl()}${API_ROUTES.workbench.invokeStream}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(toEnvelope(payload)),
    });

    if (!response.ok || !response.body) {
      const errorText = await response.text().catch(() => "");
      const streamError = new Error(
        errorText
          ? `Streaming request failed with HTTP ${response.status}: ${errorText}`
          : `Streaming request failed with HTTP ${response.status}`
      );
      handleApiClientError(streamError, {
        title: 'Streaming request failed',
        subHeader: 'Workbench invoke stream',
        fallbackMessage: 'Unable to stream the workbench response.',
      });
      throw streamError;
    }

    const decoder = new TextDecoder();
    const reader = response.body.getReader();
    let buffer = "";

    const parseChunk = (chunk: string) => {
      let eventName = "message";
      const dataParts: string[] = [];
      for (const line of chunk.split(/\r?\n/)) {
        if (!line.trim()) continue;
        if (line.startsWith("event:")) {
          eventName = line.slice(6).trim();
          continue;
        }
        if (line.startsWith("data:")) {
          dataParts.push(line.slice(5).trimStart());
        }
      }
      if (!dataParts.length) return null;
      const raw = dataParts.join("\n");
      try {
        return { event: eventName, data: JSON.parse(raw) };
      } catch {
        return { event: eventName, data: { text: raw } };
      }
    };

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      let extracted = extractSseChunk(buffer);
      while (extracted !== null) {
        const parsed = parseChunk(extracted.chunk);
        buffer = extracted.remaining;
        if (parsed) {
          yield parsed as
            | { event: "status"; data: Record<string, unknown> }
            | { event: "delta"; data: { text: string } }
            | { event: "suggestions"; data: { items: string[] } }
            | { event: "final"; data: STTMBuilderEnvelopeResponse }
            | { event: "error"; data: { message?: string; code?: string } };
        }
        extracted = extractSseChunk(buffer);
      }
    }

    if (buffer.trim()) {
      const parsed = parseChunk(buffer);
      if (parsed) {
        yield parsed as
          | { event: "status"; data: Record<string, unknown> }
          | { event: "delta"; data: { text: string } }
          | { event: "suggestions"; data: { items: string[] } }
          | { event: "final"; data: STTMBuilderEnvelopeResponse }
          | { event: "error"; data: { message?: string; code?: string } };
      }
    }
  },
};
