'use client';

import {
  Alert,
  LinearProgress,
  CircularProgress,
  Snackbar,
} from '@mui/material';

export const AiaAlert = Alert;
export const AiaSnackbar = Snackbar;
export const AiaLinearProgress = LinearProgress;
export const AiaCircularProgress = CircularProgress;
