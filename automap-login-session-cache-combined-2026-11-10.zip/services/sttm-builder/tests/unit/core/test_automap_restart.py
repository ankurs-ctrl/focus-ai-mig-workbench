from types import SimpleNamespace
import sys
import pytest

from app.core import automap_restart as restart


def test_disabled_and_non_oauth_restart_never_discover_or_use_owner_credentials(monkeypatch):
    monkeypatch.setattr(restart, '_rows', lambda *a: pytest.fail('Unexpected metadata access'))
    restart.restore_work(None, SimpleNamespace(automap_durable_runs_v2=False))
    restart.restore_work(None, SimpleNamespace(automap_durable_runs_v2=True, uses_custom_oauth=False))


@pytest.mark.parametrize('revoked,wrong_user,wrong_role', [(True,False,False),(False,True,False),(False,False,True)])
def test_original_session_identity_and_revocation_checked_before_decryption(monkeypatch, revoked, wrong_user, wrong_role):
    from app.auth import custom_oauth as oauth
    record=SimpleNamespace(is_active=not revoked,snowflake_user='OTHER' if wrong_user else 'CALLER',
                           snowflake_role='OTHER_ROLE' if wrong_role else 'ROLE')
    monkeypatch.setattr(oauth,'_session_select_row',lambda *a:record)
    monkeypatch.setattr(oauth,'_refresh_session_if_needed',lambda *a,**k:pytest.fail('Must reject first'))
    monkeypatch.setattr(oauth,'decrypt_access_token',lambda *a:pytest.fail('Must not decrypt'))
    with pytest.raises(PermissionError):restart.authenticated_headers(object(),'session','CALLER','ROLE')


def test_session_refresh_rechecks_identity_and_only_existing_store_holds_tokens(monkeypatch):
    from app.auth import custom_oauth as oauth
    record=SimpleNamespace(is_active=True,snowflake_user='CALLER',snowflake_role='ROLE',email='caller@example.test')
    monkeypatch.setattr(oauth,'_session_select_row',lambda *a:record)
    monkeypatch.setattr(oauth,'_refresh_session_if_needed',lambda *a,**k:record)
    monkeypatch.setattr(oauth,'decrypt_access_token',lambda *a:'private-token')
    headers=restart.authenticated_headers(object(),'session','CALLER','ROLE')
    assert headers.session_id=='session'
    assert 'session' not in dict(headers).values()
    assert headers['X-Workbench-OAuth-Access-Token']=='private-token'
    record.snowflake_user='OTHER'
    with pytest.raises(PermissionError):restart.authenticated_headers(object(),'session','CALLER','ROLE')


def test_discovery_is_bounded_and_auth_failure_does_not_block_other_callers_or_resume(monkeypatch):
    settings=SimpleNamespace(automap_durable_runs_v2=True,uses_custom_oauth=True,
        automap_parallel_permit_table_fqn='DB.SCH.POOL',qualified_oauth_sessions_table='DB.SCH.OAUTH',
        automap_parallel_account_namespace='ORG.ACC',automap_parallel_pool_epoch='epoch',auto_map_pipeline_v2=True,
        qualify_metadata_object_name=lambda name:'DB.SCH.'+name)
    queries=[];registered=[];resumed=[]
    def rows(settings,sql,params=()):
        queries.append(sql)
        if len(queries)==1:
            assert params==('ORG.ACC','epoch') and 'LIMIT 16' in sql
            return [dict(SESSION_ID=str(i),SNOWFLAKE_USER=str(i),SNOWFLAKE_ROLE='R') for i in range(2)]
        assert 'LIMIT 4' in sql and "execution_protocol::VARCHAR='background_v2'" in sql
        assert 'LEASE_EXPIRES_AT<CURRENT_TIMESTAMP()' in sql
        return [{'JOB_ID':'job'}]
    def register(*args):
        registered.append(args[3])
        if args[3]=='0':raise PermissionError('expired')
    monkeypatch.setattr(restart,'_rows',rows)
    monkeypatch.setattr(restart,'register_caller',register)
    monkeypatch.setattr(restart,'resume_job',lambda settings,row:resumed.append(row))
    restart.restore_work(object(),settings,resume_jobs=True)
    assert registered==['0','1'] and resumed==[{'JOB_ID':'job'}]


def test_old_job_without_session_reference_never_uses_service_identity():
    record=dict(owner='CALLER',job_id='job',execution_protocol='background_v2',status='running')
    restart.resume_job(object(),dict(OWNER_ID='CALLER',JOB_ID='job',JOB_STATE=record))
    record['owner']='OTHER'
    with pytest.raises(PermissionError):restart.resume_job(object(),dict(OWNER_ID='CALLER',JOB_ID='job',JOB_STATE=record))


def test_resume_restores_frozen_request_then_uses_existing_distributed_lease(monkeypatch):
    from app.core import auto_mapping_proxy as proxy
    from app.schema import sttm_builder as schema
    record=dict(owner='CALLER',job_id='restart-test',execution_protocol='background_v2',status='running',
                recovery_session_hash='a'*64,recovery_role='ROLE',request_envelope={'immutable':'original'},
                partial_responses=[{'batch_index':0}])
    envelope=object();calls=[]
    monkeypatch.setattr(restart,'authenticated_headers',lambda *a:{'caller':'verified'})
    def rows(settings,sql,params):
        assert params==('a'*64,'CALLER','ROLE') and 'SHA2(SESSION_ID,256)=%s' in sql
        return [{'SESSION_ID':'session'}]
    monkeypatch.setattr(restart,'_rows',rows)
    monkeypatch.setattr(schema.STTMBuilderEnvelopeRequest,'model_validate',lambda value: envelope if value=={'immutable':'original'} else pytest.fail('Changed request'))
    class Proxy:
        def __init__(self,settings):pass
        def _launch_job_runner(self,job_id,**kwargs):calls.append((job_id,kwargs))
    monkeypatch.setattr(proxy,'AutoMappingProxyClient',Proxy)
    try:
        settings=SimpleNamespace(qualified_oauth_sessions_table='DB.SCH.OAUTH')
        restart.resume_job(settings,dict(OWNER_ID='CALLER',JOB_ID='restart-test',JOB_STATE=record))
        assert len(calls)==1 and calls[0][1]['req'] is envelope
        assert calls[0][1]['record']['partial_responses']==[{'batch_index':0}]
        proxy._AUTO_MAP_ACTIVE_RUNNERS.add('restart-test')
        restart.resume_job(settings,dict(OWNER_ID='CALLER',JOB_ID='restart-test',JOB_STATE=record))
        assert len(calls)==1
    finally:
        proxy._AUTO_MAP_ACTIVE_RUNNERS.discard('restart-test')
        proxy._AUTO_MAP_JOBS.pop('restart-test',None)
