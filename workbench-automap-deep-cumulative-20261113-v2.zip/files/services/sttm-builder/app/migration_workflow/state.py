from __future__ import annotations

from typing import Annotated, Any, TypedDict

from langgraph.graph.message import add_messages


class MigrationState(TypedDict, total=False):
    # CompiledSubAgent requires a messages channel. It contains only compact,
    # safe summaries; authoritative mappings remain in Workbench domain tables.
    messages: Annotated[list[Any], add_messages]
    run_id: str
    prompt: str
    effort_policy: dict[str, Any]
    effort: str
    run_mode: str
    actor_user_id: str
    effective_role: str
    tenant_id: str
    authorized_source_scope: list[str]
    authorized_target_scope: list[str]
    authorized_schemas: list[str]
    target_candidates: list[str]
    discovered_catalog_tables: list[str]
    page_context: dict[str, Any]
    mapping_context_package: dict[str, Any]
    mapping_context_packages: dict[str, dict[str, Any]]
    migration_plan: dict[str, Any]
    supervisor_plan: dict[str, Any]
    research_clarification: dict[str, Any]
    approved_plan_hash: str | None
    plan_revision: int
    plan_revision_request: str | dict[str, Any] | None
    plan_approval_required: bool
    plan_review_suggested: bool
    plan_review_reason: str | None
    source_preparation_result: dict[str, Any]
    workspace_sync: dict[str, Any]
    workbench_result: dict[str, Any]
    conversation_history: list[dict[str, Any]]
    conversation_summary: str
    # A follow-up child run: its parent and the owned run chain whose drafts it may edit.
    parent_run_id: str
    run_lineage: list[str]
    app_user_id: str
    snowflake_username: str
    attachment_ids: list[str]
    # Role, intent and cited facts read from each attachment once per run.
    attachment_readings: list[dict[str, Any]]
    requested_mappings: list[str]
    precedent_project_ids: list[str]
    precedent_sttm_ids: list[str]
    project_id: str | None
    project_name: str | None
    manifest: list[dict[str, Any]]
    manifest_version: int
    mapping_results: list[dict[str, Any]]
    review_items: list[dict[str, Any]]
    assistant_message: str
    retrieved_learning_ids: list[str]
    used_learning_ids: list[str]
    validation_artifact_refs: list[str]
    validation_report: dict[str, Any]
    model_calls_used: int
    tool_calls_used: int
    status: str
    cancel_requested: bool
