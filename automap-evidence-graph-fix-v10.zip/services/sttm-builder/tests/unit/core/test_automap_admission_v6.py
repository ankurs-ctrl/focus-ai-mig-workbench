"""Synthetic regression fixtures based on the reported shape; NOT archive replay."""
from copy import deepcopy
import json
import random
import string
from types import SimpleNamespace

import pytest

from app.core.automap_batch import invoke_batch
from app.core.automap_input_budget import wire_text
from tests.unit.core.test_automap_fast_batch import FinalAgent, prepared_request, service, answer_for
from tests.unit.core.test_automap_fast_context import fast_payload, plan_for, unpack
from tests.test_automap_fast_job import authored, proxy


def wide_value(target_count=1, *, join=False):
    value = fast_payload(target_count)
    value['context']['learning_context'] = {}
    columns = [{'name': f'FIELD_{index:03d}', 'data_type': 'TEXT',
                'business_meaning': f'Synthetic field {index}: ' + 'context ' * 80} for index in range(600)]
    value['context']['semantic_context'][0]['semantic_model'] = {'attributes': columns}
    value['context']['relation_graph']['nodes'][0]['output_columns'] = [
        {'name': column['name'], 'data_type': 'TEXT'} for column in columns]
    if join:
        table = {'database': 'D', 'schema': 'S', 'table': 'LOOKUP'}
        value['context']['source_tables'].append(table)
        value['context']['semantic_context'].append({'table': table, 'semantic_model': {'attributes': [
            {'name': 'CODE', 'data_type': 'TEXT', 'business_meaning': 'Lookup code'}]}})
        value['context']['relation_graph']['nodes'].append({'relation_id': 'lookup', 'alias': 'lookup',
            'kind': 'PHYSICAL_TABLE', 'table': table, 'output_columns': [{'name': 'CODE', 'data_type': 'TEXT'}]})
        value['context']['relation_graph']['edges'] = [{'edge_id': 'lookup', 'left_relation_id': 'a',
            'right_relation_id': 'lookup', 'join_type': 'LEFT', 'conditions': [
                {'left_column': 'FIELD_599', 'right_column': 'CODE', 'operator': '='}]}]
    return value


def run(value, answers):
    builder = service(FinalAgent(answers))
    builder._settings = builder._settings.model_copy(update={
        'agent_outbound_message_max_chars': 180000, 'agent_outbound_message_max_bytes': 180000})
    req = prepared_request(value)
    before = req.model_dump()
    raw, _, meta = invoke_batch(builder, req, SimpleNamespace())
    assert req.model_dump() == before
    for messages, _ in builder._agent.calls:
        assert len(wire_text(messages)) <= 180000
        assert len(wire_text(messages).encode('utf-8')) <= 180000
    return builder, json.loads(raw)['data']['result']['mappings'], meta


def refs(messages):
    return {row['source_ref'] for row in unpack(messages)['context']['selectable_sources']}


def test_join_column_exact_read_and_selectable_binding_are_admitted_together():
    value = wide_value(join=True)
    builder, rows, meta = run(value, [answer_for(['NAME0'], NAME0={'source_attributes': ['a.FIELD_599']})])
    assert rows['NAME0']['source_attributes'] == ['a.FIELD_599']
    packet = unpack(builder._agent.calls[0][0])
    assert 'a."FIELD_599"' in refs(builder._agent.calls[0][0])
    assert any(item['request'].get('column') == 'FIELD_599' for item in packet['retrieved_auto_map_context'])
    assert len(builder._agent.calls) == 1


@pytest.mark.parametrize('lookup', [False, True])
def test_existing_but_unadmitted_reference_is_admitted_then_reevaluated(lookup):
    value = wide_value(join=lookup)
    # Select from the actual worker packet, not a separate preparation whose
    # admission can differ after canonical wire/governance normalization.
    class UnreadAgent(FinalAgent):
        def run_detailed(self, messages, **kwargs):
            packet = unpack(messages)
            if not self.calls:
                first = refs(messages)
                inventory = packet['context']['archived_source_inventory']['a']
                self.unadmitted = next(f'a.{column}' for column in inventory if f'a.{column}' not in first)
                self.selected = ['lookup.CODE'] if lookup else [self.unadmitted]
                self.answers = [answer_for(['NAME0'], NAME0={'source_attributes': self.selected,
                    'source_dependencies': [self.unadmitted]})] * 2
            return super().run_detailed(messages, **kwargs)
    agent = UnreadAgent()
    builder = service(agent)
    builder._settings = builder._settings.model_copy(update={
        'agent_outbound_message_max_chars': 180000, 'agent_outbound_message_max_bytes': 180000})
    raw, _, meta = invoke_batch(builder, prepared_request(value), SimpleNamespace())
    rows = json.loads(raw)['data']['result']['mappings']
    assert rows['NAME0']['source_attributes'] == agent.selected
    assert len(agent.calls) == 2
    assert agent.unadmitted not in refs(agent.calls[0][0])
    assert agent.unadmitted in refs(agent.calls[1][0])
    assert [item['target_attribute'] for item in unpack(agent.calls[1][0])['data']['attributes']] == ['NAME0']


def test_unknown_field_is_not_admitted_from_table_existence():
    answer = answer_for(['NAME0'], NAME0={'source_attributes': ['a.RECORDTYPEID']})
    builder, rows, meta = run(wide_value(), [answer] * 8)
    assert rows['NAME0']['source_attributes'] == []
    assert all('a."RECORDTYPEID"' not in refs(messages) for messages, _ in builder._agent.calls)
    assert 'does not exist' in rows['NAME0']['unmatched_reason']
    assert len(builder._agent.calls) == 2


def test_continuation_rotates_optional_evidence_above_old_80_percent_limit():
    value = wide_value()
    rng = random.Random(73)
    noise = ''.join(rng.choices(string.ascii_letters + string.digits, k=130000))
    value['context']['mapping_intent'] = {'business_goal': noise}
    class PagingAgent(FinalAgent):
        def run_detailed(self, messages, **kwargs):
            self.calls.append((deepcopy(messages), kwargs))
            if len(self.calls) == 1:
                self.first_refs = refs(messages)
                return answer_for(['NAME0'], NAME0={'source_attributes': [], 'confidence_score': 0,
                    'transformation_classification': 'unresolved', 'unmatched_reason': 'Additional source evidence is required'}), None, {}
            added = refs(messages) - self.first_refs
            assert added
            return answer_for(['NAME0'], NAME0={'source_attributes': [sorted(added)[0]]}), None, {}
    agent = PagingAgent()
    builder = service(agent)
    builder._settings = builder._settings.model_copy(update={
        'agent_outbound_message_max_chars': 180000, 'agent_outbound_message_max_bytes': 180000})
    raw, _, meta = invoke_batch(builder, prepared_request(value), SimpleNamespace())
    assert json.loads(raw)['data']['result']['mappings']['NAME0']['source_attributes']
    assert len(agent.calls) == 2
    assert all(144000 < len(wire_text(messages)) <= 180000 for messages, _ in agent.calls)
    assert refs(agent.calls[0][0]) - refs(agent.calls[1][0])  # Optional replacement, not append-only.


def test_selected_completion_does_not_grant_reevaluation_authority():
    client = proxy()
    req = authored(pending=2)
    pending = req.data.attributes[-1].target_attribute
    req.meta['auto_map_target_scope'] = [pending]
    frozen = client._freeze_resolution(req)
    plan = client._trusted_resolution_plan(frozen)
    assert [row['target_attribute'] for row in plan['targets'] if row['status'] == 'pending'] == [pending]
    assert not any(row['reevaluate'] for row in plan['targets'])


@pytest.mark.parametrize('scope', [[], ['FOREIGN'], ['COL_0', 'COL_0']])
def test_invalid_target_scope_is_rejected(scope):
    from fastapi import HTTPException
    req = authored(pending=1)
    req.meta['auto_map_target_scope'] = scope
    with pytest.raises(HTTPException): proxy()._freeze_resolution(req)


def test_uncertain_unresolved_keeps_verified_alternatives_and_existing_schema():
    value = fast_payload()
    answer = answer_for(['NAME0'], NAME0={'source_attributes': [],
        'candidate_source_attributes': ['a.X47'], 'confidence_score': .35,
        'confidence_reason': 'Plausible candidate, but the business rule is not established.',
        'transformation_classification': 'unresolved', 'unmatched_reason': 'Need an approved business rule'})
    builder, rows, _ = run(value, [answer] * 8)
    row = rows['NAME0']
    assert row['source_attributes'] == []
    assert row['candidate_source_attributes'] == ['a.X47']
    assert row['confidence_score'] == 0
    assert row['confidence_reason'] == 'Plausible candidate, but the business rule is not established.'
    assert row['transformation_classification'] == 'unresolved'
    assert len(builder._agent.calls) == 1


def test_low_confidence_grounded_proposal_is_not_discarded_or_given_inflated_confidence():
    value = fast_payload()
    answer = answer_for(['NAME0'], NAME0={'source_attributes': ['a.X47'],
        'candidate_source_attributes': ['a.X47'], 'confidence_score': .35,
        'confidence_reason': 'Semantics are suggestive; review this proposal.'})
    _, rows, _ = run(value, [answer])
    assert rows['NAME0']['source_attributes'] == ['a.X47']
    assert rows['NAME0']['candidate_source_attributes'] == ['a.X47']
    assert rows['NAME0']['confidence_score'] == .35
    assert rows['NAME0']['confidence_reason'] == 'Semantics are suggestive; review this proposal.'


def test_fabricated_unresolved_alternative_is_rejected_without_losing_valid_sibling():
    value = fast_payload(2)
    answer = answer_for(['NAME0', 'NAME1'], NAME1={'source_attributes': [],
        'candidate_source_attributes': ['a.RECORDTYPEID'], 'confidence_score': 0,
        'transformation_classification': 'unresolved', 'unmatched_reason': 'Uncertain'})
    _, rows, _ = run(value, [answer] * 8)
    assert rows['NAME0']['source_attributes'] == ['a.X47']
    assert rows['NAME1']['source_attributes'] == []
    assert rows['NAME1']['candidate_source_attributes'] == []
    assert rows['NAME1']['transformation_classification'] == 'unresolved'


def test_malformed_unresolved_alternative_expression_keeps_valid_sibling():
    value = fast_payload(2)
    answer = answer_for(['NAME0', 'NAME1'], NAME1={'source_attributes': [],
        'candidate_source_attributes': ['a.X47'], 'confidence_score': 0,
        'preprocessing_rule_type': 'Custom', 'preprocessing_rule': '(',
        'transformation_classification': 'unresolved', 'unmatched_reason': 'Uncertain'})
    _, rows, _ = run(value, [answer] * 8)
    assert rows['NAME0']['source_attributes'] == ['a.X47']
    assert rows['NAME1']['source_attributes'] == []
    assert rows['NAME1']['candidate_source_attributes'] == []
    assert rows['NAME1']['transformation_classification'] == 'unresolved'
