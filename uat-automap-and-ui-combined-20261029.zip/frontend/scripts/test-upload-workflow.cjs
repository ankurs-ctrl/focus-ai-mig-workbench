const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ts = require('typescript');
const Module = require('node:module');
function compile(filename, source, dependencies = {}) {
  const loaded = new Module(filename, module);
  loaded.require = name => dependencies[name] ?? (name.startsWith('@/')
    ? load(`../src/${name.slice(2)}.ts`)
    : name.startsWith('.') ? load(path.resolve(path.dirname(filename), `${name}.ts`)) : require(name));
  loaded._compile(ts.transpileModule(source, {compilerOptions: {
    module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020,
  }}).outputText, filename);
  return loaded.exports;
}
function load(relative) {
  const filename = path.resolve(__dirname, relative);
  return compile(filename, fs.readFileSync(filename, 'utf8'));
}
const {buildSqlUploadWorkspace} = load('../src/features/sttm/mapping/sql-upload-workspace.ts');
const {buildWorkbenchContextSnapshot} = load('../src/features/sttm/context/workbench-context.ts');
const {relationAliasFor, readablePreviewSql, rewriteLegacyAliasReference} = load('../src/features/sttm/mapping/relation-alias.ts');
const {hydrateDerivedColumns} = load('../src/features/sttm/shared/derived-source-columns.ts');
const rootScope = {scope_id:'outer',query_kind:'select',parent_scope_id:null,clauses:{},joins:[],relations:[
  {relation_instance_id:'outer:0',alias:'result',relation_name:'final',source_scope_id:'final-scope'},
]};
const ctes = [
  {name:'base',scope_id:'base-scope',sql_text:'SELECT ID FROM D.S.A',definition_sql:'SELECT ID FROM D.S.A',
    tables_referenced:['D.S.A'],output_columns:[{name:'ID',data_type:'NUMBER'}],
    scope_contract:{relations:[{relation_name:'D.S.A',relation_instance_id:'base:0'}]}},
  {name:'final',scope_id:'final-scope',sql_text:'WITH base AS (SELECT ID FROM D.S.A) SELECT ID FROM base',
    definition_sql:'SELECT ID FROM base',tables_referenced:[],output_columns:[{name:'ID',data_type:'NUMBER'}],
    scope_contract:{relations:[{relation_name:'base',source_scope_id:'base-scope',relation_instance_id:'final:0'}]}},
];
const upload = {asset_id:'fixture',parsed_summary:{source_tables:['D.S.A'],ctes,query_scopes:[rootScope],
  // No legacy outer alias field: canonical scope must suffice.
  column_mappings:[],driving_relation:'final'}};
// A generated envelope is reparsed by Selection's Validate & Run. Its
// alias must resolve back to the existing derived source, not become a new CTE.
const existingCte = { id: 'sql-cte:source-701:jimshh', sourceName: 'jimshh',
  sqlText: 'WITH jimshh AS (SELECT a.ID AS LegacyCRMID FROM D.S.A a) SELECT * FROM jimshh',
  isSelected: true };
const renderedAlias = relationAliasFor(existingCte.id, existingCte.sourceName);
const roundtripInput = {asset_id:'source-701', parsed_summary: {
  source_tables:['D.S.A'], driving_relation:renderedAlias, column_mappings:[],
  ctes:[{name:renderedAlias,scope_id:'wrapper',existing_relation_id:existingCte.id,definition_sql:existingCte.sqlText,
    sql_text:`WITH ${renderedAlias} AS (${existingCte.sqlText}) SELECT * FROM ${renderedAlias}`,
    output_columns:[{name:'LegacyCRMID'}],tables_referenced:['D.S.A']}],
  query_scopes:[{...rootScope,relations:[{relation_instance_id:'outer:0',alias:renderedAlias,
    relation_name:renderedAlias,source_scope_id:'wrapper'}]}],
}};
const changedEnvelope = JSON.parse(JSON.stringify(roundtripInput));
delete changedEnvelope.parsed_summary.ctes[0].existing_relation_id;
assert.throws(() => buildSqlUploadWorkspace(changedEnvelope,{existingDerivedSources:[existingCte]}), /definition changed/);
const roundtrip = buildSqlUploadWorkspace(roundtripInput, {existingDerivedSources:[existingCte]});
assert.equal(roundtrip.drivingTableId, existingCte.id);
assert.equal(roundtrip.derivedSources[0].name, existingCte.sourceName);
assert.equal(roundtrip.derivedSources[0].sqlText, existingCte.sqlText);
assert.equal(relationAliasFor(roundtrip.derivedSources[0].id, roundtrip.derivedSources[0].name), renderedAlias);
const {buildCteDraftSql, buildCteDraft, buildSourceColumnOptions, buildCompilerRelationGraph} = load('../src/features/sttm/mapping/mapping-utils.ts');
const mixedCaseSource = {id:'sql-cte:test:acceptance_source',sourceName:'acceptance_source',isSelected:true,
  sqlText:'SELECT ID AS LegacyCRMID, NAME AS "DisplayName" FROM D.S.A',
  outputColumns:[{name:'LegacyCRMID'},{name:'DisplayName'}],queryScope:{outputs:[
    {name:'LegacyCRMID',sql:'ID AS LegacyCRMID'}, {name:'DisplayName',sql:'NAME AS "DisplayName"'}]},joins:[],filters:[],columns:[]};
const mixedGraph = buildCompilerRelationGraph({sourceTables:[],derivedSources:[mixedCaseSource],relationships:[],mappings:[]});
const threeRows = ['LEGACY_ID__C','NAME','MAIL_MERGE_FIRST_AND_LAST__C'].map((targetColumn,index)=>({id:String(index),
  status:'MAPPED',rule:'Direct',targetColumn,sourceColumns:['cte_acceptance_source.LegacyCRMID']}));
const uncompiled = buildCteDraftSql({graph:mixedGraph,drivingId:mixedCaseSource.id,mappings:threeRows});
assert.match(uncompiled,/SELECT\n/);
assert.equal((uncompiled.match(/AS (LEGACY_ID__C|NAME|MAIL_MERGE_FIRST_AND_LAST__C)/g)||[]).length,3);
assert.ok(uncompiled.includes('cte_acceptance_source."LEGACYCRMID"'));
assert.match(buildCteDraftSql({graph:mixedGraph,drivingId:mixedCaseSource.id,mappings:[{...threeRows[0],sourceColumns:['cte_acceptance_source.DisplayName']}]}),/review/);
assert.ok(buildCteDraftSql({graph:mixedGraph,drivingId:mixedCaseSource.id,mappings:[{...threeRows[0],sourceColumns:['cte_acceptance_source."DisplayName"']}]}).includes('cte_acceptance_source."DisplayName"'));

const manualOptions = buildSourceColumnOptions([], [mixedCaseSource]);
assert.equal(manualOptions[0].value, 'cte_acceptance_source.LegacyCRMID');
assert.equal(manualOptions[1].value, 'cte_acceptance_source."DisplayName"');
const fiveRows = [...threeRows,
  {...threeRows[0],id:'manual',targetColumn:'PARENTID',sourceColumns:['acceptance_source.LegacyCRMID']},
  {...threeRows[0],id:'invalid',targetColumn:'TRANSACTION_FIRM__C',sourceColumns:['D.S.A.ACCOUNTNUMBER']}];
const beforeDraft = JSON.stringify(fiveRows);
const partial = buildCteDraft({graph:mixedGraph,drivingId:mixedCaseSource.id,mappings:fiveRows});
assert.equal(partial.status,'partial');
assert.equal(partial.shownCount,4);
assert.equal(partial.mappedCount,5);
assert.equal(partial.diagnostics[0].targetColumn,'TRANSACTION_FIRM__C');
assert.match(partial.sql,/AS PARENTID/);
assert.ok(!partial.sql.includes('AS TRANSACTION_FIRM__C'));
assert.equal(JSON.stringify(fiveRows),beforeDraft);
const {canonicalizeMappingBindings, canonicalizeCteReferences, manualSourceScopeWarning} = load('../src/features/sttm/mapping/mapping-utils.ts');
const fullRequest = fiveRows.map(row=>canonicalizeMappingBindings(row,mixedGraph));
assert.equal(fullRequest.length,5);
assert.deepEqual(fullRequest[4].sourceColumns,['D.S.A.ACCOUNTNUMBER']);
assert.deepEqual(fullRequest[3].sourceColumns,['cte_acceptance_source.LegacyCRMID']);
assert.equal(canonicalizeCteReferences("'acceptance_source.LegacyCRMID' || TRIM(acceptance_source.LegacyCRMID)",mixedGraph),
  "'acceptance_source.LegacyCRMID' || TRIM(cte_acceptance_source.LegacyCRMID)");
const ambiguousGraph={...mixedGraph,nodes:[...mixedGraph.nodes,{...mixedGraph.nodes[0],relation_id:'other',alias:'other_alias'}]};
assert.equal(canonicalizeCteReferences('acceptance_source.LegacyCRMID',ambiguousGraph),'acceptance_source.LegacyCRMID');
assert.equal(manualSourceScopeWarning('acceptance_source.LegacyCRMID',mixedCaseSource.id,[mixedCaseSource],[]),null);
assert.match(manualSourceScopeWarning('D.S.A.ACCOUNTNUMBER',mixedCaseSource.id,[mixedCaseSource],[]),/Outside/);
assert.equal(manualSourceScopeWarning('D.S.A.ACCOUNTNUMBER',mixedCaseSource.id,[mixedCaseSource],
  [{leftTableId:mixedCaseSource.id,rightTableId:'D.S.A'}]),null);
assert.equal(buildCteDraft({graph:mixedGraph,drivingId:mixedCaseSource.id,mappings:fiveRows.slice(0,4)}).status,'complete');
const allInvalid=buildCteDraft({graph:mixedGraph,drivingId:mixedCaseSource.id,mappings:[fiveRows[4]]});
assert.equal(allInvalid.status,'blocked');
assert.ok(!allInvalid.sql.includes('SELECT'));
assert.equal(buildCteDraft({graph:mixedGraph,drivingId:mixedCaseSource.id,mappings:[]}).shownCount,0);
const valueRows=[{...threeRows[0],mappingMode:'constant',constantValue:'firm',targetType:'TEXT'},
  {...threeRows[1],mappingMode:'attribute',constantValue:null,attributeName:'Firm'}];
assert.equal(buildCteDraft({graph:mixedGraph,drivingId:mixedCaseSource.id,mappings:valueRows}).shownCount,1);
const missingJoin={...mixedGraph,edges:[{left_relation_id:mixedCaseSource.id,right_relation_id:'missing'}]};
assert.equal(buildCteDraft({graph:missingJoin,drivingId:mixedCaseSource.id,mappings:threeRows}).status,'blocked');
const draftGraph = {nodes:[{relation_id:'driver',kind:'DERIVED_SOURCE',alias:'cte_source',
  sql_text:'SELECT ID FROM D.S.A WHERE ACTIVE = TRUE',output_columns:[{name:'ID'}]},
  {relation_id:'D.S.A',kind:'PHYSICAL_TABLE',alias:'accounts',table:{database:'D',schema:'S',table:'A'}}],edges:[]};
const draftRows = [{id:'one',status:'MAPPED',rule:'Direct',targetColumn:'TARGET_ID',sourceColumn:'cte_source.ID'}];
const cteDraft = buildCteDraftSql({graph:draftGraph,drivingId:'driver',mappings:draftRows});
assert.match(cteDraft,/FROM cte_source AS cte_source/);
assert.match(cteDraft,/WHERE ACTIVE = TRUE/);
assert.match(cteDraft,/cte_source\."ID"\s+AS TARGET_ID/);
assert.match(buildCteDraftSql({graph:draftGraph,drivingId:'driver',mappings:[{...draftRows[0],sourceColumn:'D.S.A.ID'}]}),/TARGET_ID: review/);
assert.ok(!buildCteDraftSql({graph:draftGraph,drivingId:'driver',mappings:[{...draftRows[0],sourceColumn:'D.S.A.ID'}]}).includes('FROM accounts'));
const expressionDraft = buildCteDraftSql({graph:draftGraph,drivingId:'driver',mappings:[{...draftRows[0],expression:"'accounts.ID' || TRIM(cte_source.ID)"}]});
assert.ok(expressionDraft.includes("'accounts.ID' || TRIM(cte_source.\"ID\")"));
assert.match(buildCteDraftSql({graph:draftGraph,drivingId:'driver',mappings:[{...draftRows[0],expression:'(SELECT ID FROM D.S.A)'}]}),/TARGET_ID: review/);
console.log('CTE drafts retain driver filters and flag unresolved parent references.');
const workspace = buildSqlUploadWorkspace(upload);
assert.equal(workspace.targetTableFqn,null);
assert.deepEqual(workspace.derivedSources.filter(cte=>cte.isSelected).map(cte=>cte.name),['final']);
assert.equal(workspace.derivedSources[1].parentDerivedSourceIds[0],workspace.derivedSources[0].id);
assert.equal(workspace.drivingTableId,workspace.derivedSources[1].id);
assert.throws(()=>buildSqlUploadWorkspace({...upload,parsed_summary:{...upload.parsed_summary,query_scopes:[]}}),/missing CTE query scopes/);

const slicePath = path.resolve(__dirname,'../src/features/sttm/store/sttm-builder-slice.ts');
const slice = ts.createSourceFile(slicePath,fs.readFileSync(slicePath,'utf8'),ts.ScriptTarget.Latest,true);
let applyReducer, qualifiedTableRef;
function visit(node) {
  if (ts.isFunctionDeclaration(node) && node.name?.text === 'qualifiedTableRefOrNull') qualifiedTableRef=node.getText(slice);
  if (ts.isPropertyAssignment(node) && node.name.getText(slice)==='applyParsedSqlWorkspace') applyReducer=node.initializer.getText(slice);
  ts.forEachChild(node,visit);
}
visit(slice);
assert.ok(applyReducer);
const {computeAuthoredSqlSemanticKey} = load('../src/features/sttm/mapping/authored-sql-key.ts');
assert.ok(qualifiedTableRef);
const qualifiedTableRefOrNull = compile(slicePath, `${qualifiedTableRef}\nmodule.exports = qualifiedTableRefOrNull;`);
const apply = compile(slicePath,`module.exports = (qualifiedTableRefOrNull,authoredSqlKeyFromState,hydrateDerivedColumns) => (${applyReducer});`)(
  qualifiedTableRefOrNull,
  computeAuthoredSqlSemanticKey,
  hydrateDerivedColumns,
);
function assertSnapshot(nextWorkspace) {
  const state = {sources:[],targets:[],sourceDatabases:[],targetDatabases:[],derivedSources:[]};
  apply(state,{payload:nextWorkspace});
  const snapshot = buildWorkbenchContextSnapshot({action:'import.completed',page:'builder',surface:'SOURCE_SELECTION',
    sourceTables:state.sources,derivedSources:state.derivedSources,drivingTableId:state.drivingTableId,
    mappings:state.mappings,relationships:state.relationships});
  assert.equal(snapshot.derived_sources.length,nextWorkspace.derivedSources.length);
  assert.deepEqual(snapshot.derived_sources.filter(cte=>cte.is_selected).map(cte=>cte.name).sort(),
    nextWorkspace.derivedSources.filter(cte=>cte.isSelected).map(cte=>cte.name).sort());
  assert.ok(snapshot.derived_sources.every(cte=>cte.sql_text));
  return snapshot;
}
assertSnapshot(workspace);
// Only complete uploaded SQL string tokens are decoded, exactly once. The
// general mapping formatter must still quote raw values that contain quotes.
const {buildMappingExpression: constantExpression} = load('../src/features/sttm/mapping/mapping-utils.ts');
for (const [token, value] of [
  ["'O''Brien'", "O'Brien"], ["'''Current Client'''", "'Current Client'"],
  ["'a''''b'", "a''b"], ["'a' || 'b'", "'a' || 'b'"],
  ["'unterminated", "'unterminated"], ['42', '42'], ['TRUE', 'TRUE'],
  ['NULL', 'NULL'], ['$MissingValue', '$MissingValue'],
]) {
  const imported = buildSqlUploadWorkspace({asset_id:'constant-token',parsed_summary:{column_mappings:[
    {target_alias:'VALUE',mapping_mode:'constant',constant_value:token},
  ]}});
  assert.equal(imported.mappings[0].constantValue,value);
}
assert.equal(constantExpression({mappingMode:'constant',constantValue:"'Current Client'",targetType:'TEXT'}),
  "'''Current Client'''");
// Byte-exact lexer checks complement the real-parser pipeline below: the parser
// normalizes SQL, so comments, dollar strings and spacing must also be tested here.
const lowerAlias = relationAliasFor('D.S.LOWER_SOURCE');
const upperAlias = relationAliasFor('D.S.UPPER_SOURCE');
const escapedAlias = relationAliasFor('D.S.ESCAPED_SOURCE');
const qualifierSql = String.raw`"a" /* keep A.ID */ . "ID" + A.ID + a.ID + "A".ID + "a""b".ID
  || '"a".ID A.ID' || 'it\'s A.ID' || $$ "a".ID A.ID $$
  -- "a".ID A.ID
  || "a" || "unknown".ID || D.S.A.ID || $A.ID || "a"."a"`;
const expectedQualifierSql = String.raw`${lowerAlias} /* keep A.ID */ . "ID" + ${upperAlias}.ID + ${upperAlias}.ID + ${upperAlias}.ID + ${escapedAlias}.ID
  || '"a".ID A.ID' || 'it\'s A.ID' || $$ "a".ID A.ID $$
  -- "a".ID A.ID
  || "a" || "unknown".ID || D.S.A.ID || $A.ID || ${lowerAlias}."a"`;
const aliasInput = {asset_id:'token-check',parsed_summary:{source_tables:['D.S.LOWER_SOURCE','D.S.UPPER_SOURCE','D.S.ESCAPED_SOURCE'],
  query_scopes:[{...rootScope,relations:[
    {relation_instance_id:'l',alias:'a',alias_sql:'"a"',alias_quoted:true,relation_name:'D.S.LOWER_SOURCE'},
    {relation_instance_id:'u',alias:'A',alias_sql:'A',alias_quoted:false,relation_name:'D.S.UPPER_SOURCE'},
    {relation_instance_id:'e',alias:'a"b',alias_sql:'"a""b"',alias_quoted:true,relation_name:'D.S.ESCAPED_SOURCE'},
  ]}],column_mappings:[{target_alias:'VALUE',transformation:qualifierSql,source_columns:['"a".ID','A.ID']} ]}};
assert.equal(buildSqlUploadWorkspace(aliasInput).mappings[0].expression,expectedQualifierSql);
for (const relation of aliasInput.parsed_summary.query_scopes[0].relations) delete relation.alias_sql;
assert.equal(buildSqlUploadWorkspace(aliasInput).mappings[0].expression,expectedQualifierSql);
console.log('Upload qualifier tokens preserve quoted case, literals, comments and explicit bindings.');
for (const identity of ['D.S.EXACT', '"Db"."Schema.With.Dot"."MixedCase"']) {
  const reference = {raw_identifier:identity,resolved_fqn:null,resolution_status:'lookup_failed',catalog_status:'lookup_failed',reference_role:'source'};
  const exactWorkspace = buildSqlUploadWorkspace({asset_id:'exact-unknown',parsed_summary:{source_tables:[identity],column_mappings:[]},
    import_preview:{table_references:[reference]}});
  assert.deepEqual(exactWorkspace.sourceTableFqns,[identity]);
  assert.deepEqual(exactWorkspace.unresolvedSourceTables,[identity]);
  assert.equal(exactWorkspace.drivingTableId,identity);
}
for (const identity of ['ACCOUNTS', 'S.ACCOUNTS', 'D.S.ACCOUNTS.EXTRA', 'D.S.T; DROP TABLE D.S.T']) {
  assert.throws(() => buildSqlUploadWorkspace({asset_id:'invalid-unknown',parsed_summary:{source_tables:[identity]},
    import_preview:{table_references:[]}}), /source identities/);
}

const preservedSource = {...existingCte, joins:[], filters:[], columns:[],
  queryScope:{scope_id:'original', name:'jimshh'}, parentDerivedSourceIds:[],
  columnSemantics:[{name:'LegacyCRMID',source_columns:['a.ID']}],
  generatedByRequestId:'evidence-701', outputColumns:[{name:'LegacyCRMID'}]};
const roundtripState = {sources:[],targets:[],sourceDatabases:[],targetDatabases:[],
  derivedSources:[preservedSource], mappings:[{id:'manual',expression:"'FPT_DYN_' || ACCOUNTS.ID",status:'MAPPED'}]};
const nestedInput = JSON.parse(JSON.stringify(roundtripInput));
nestedInput.parsed_summary.ctes[0].scope_contract = {parent_scope_id:'outer',relations:[{source_scope_id:'inner'}]};
nestedInput.parsed_summary.ctes.push({name:'jimshh',scope_id:'inner',
  scope_contract:{parent_scope_id:'wrapper'},sql_text:existingCte.sqlText});
for (let cycle = 0; cycle < 4; cycle++) {
  const restored = buildSqlUploadWorkspace(nestedInput,{existingDerivedSources:roundtripState.derivedSources});
  assert.equal(restored.derivedSources.length,1);
  assert.deepEqual(restored.derivedSources[0].parentDerivedSourceIds,[]);
  apply(roundtripState,{payload:{...restored,preserveMappingRows:true}});
  assert.equal(roundtripState.derivedSources.length,1);
  assert.equal(roundtripState.drivingTableId,preservedSource.id);
  assert.deepEqual(roundtripState.derivedSources[0].queryScope,preservedSource.queryScope);
  assert.equal(roundtripState.derivedSources[0].generatedByRequestId,'evidence-701');
  assert.equal(roundtripState.derivedSources[0].sqlText,existingCte.sqlText);
  assert.equal(roundtripState.mappings[0].expression,"'FPT_DYN_' || ACCOUNTS.ID");
}
console.log('Repeated CTE hydration preserves owned scope, provenance, mappings and tag count.');
if (process.argv.includes('--parser-roundtrip')) {
  const input = JSON.parse(fs.readFileSync(0, 'utf8'));
  const parsedWorkspace = buildSqlUploadWorkspace({asset_id:'source-701',parsed_summary:input.parsed},
    {existingDerivedSources:input.state.derivedSources});
  apply(input.state,{payload:{...parsedWorkspace,preserveMappingRows:true}});
  const selected = input.state.derivedSources.filter(source => source.isSelected);
  assert.equal(selected.length,1);
  const source = selected[0];
  const alias = relationAliasFor(source.id,source.sourceName);
  const rendered = `WITH ${alias} AS (${source.sqlText}) SELECT * FROM ${alias}`;
  console.log('ROUNDTRIP_RESULT:' + JSON.stringify({state:input.state,sql:rendered}));
}

console.log('CTE scope selection, dependency closure, Apply reducer and first snapshot pass without a target.');

const alias = relationAliasFor('D.S.CONTACTS');
const nodes = [{identity:'D.S.CONTACTS',alias}];
const sql = `SELECT ${alias}.ID, '${alias}.ID' AS NOTE FROM D.S.CONTACTS AS ${alias} WHERE ${alias}.ID > 0 -- ${alias}`;
const readable = readablePreviewSql(sql,nodes);
assert.match(readable,/SELECT contacts.ID/);
assert.match(readable,/FROM D.S.CONTACTS AS contacts WHERE contacts.ID/);
assert.ok(readable.includes(`'${alias}.ID'`));
assert.ok(readable.endsWith(`-- ${alias}`));
assert.equal(readablePreviewSql(`WITH contacts AS (SELECT 1) ${sql}`,nodes),`WITH contacts AS (SELECT 1) ${sql}`);
assert.equal(readablePreviewSql(`SELECT "${alias}".ID FROM D.S.CONTACTS ${alias}`,nodes),`SELECT "${alias}".ID FROM D.S.CONTACTS ${alias}`);
const collisionNodes = [...nodes,{identity:'D.OTHER.CONTACTS',alias:relationAliasFor('D.OTHER.CONTACTS')}];
const collisionReadable = readablePreviewSql(sql,collisionNodes);
assert.match(collisionReadable,/SELECT contacts_1.ID/);
assert.match(collisionReadable,/FROM D.S.CONTACTS AS contacts_1 WHERE contacts_1.ID/);
assert.ok(collisionReadable.includes(`'${alias}.ID'`));
assert.ok(collisionReadable.endsWith(`-- ${alias}`));
const legacySql = "accounts.ID = target.ID AND note = 'accounts.ID' -- accounts.ID\n/* accounts.ID */ SELECT \"accounts.ID\", $$accounts.ID$$, accounts.NAME";
const rewritten = rewriteLegacyAliasReference(legacySql,new Map([['ACCOUNTS','accounts_gophxe']]));
assert.equal(rewritten,"accounts_gophxe.ID = target.ID AND note = 'accounts.ID' -- accounts.ID\n/* accounts.ID */ SELECT \"accounts.ID\", $$accounts.ID$$, accounts_gophxe.NAME");
console.log('Readable preview aliases preserve literals, comments, physical identities and collisions.');

const providerPath = path.resolve(__dirname,'../src/features/sttm/context/sttm-builder-context.tsx');
const provider = ts.createSourceFile(providerPath,fs.readFileSync(providerPath,'utf8'),ts.ScriptTarget.Latest,true);
let effect, effectDeps;
function visitEffect(node) {
  if (ts.isCallExpression(node) && node.expression.getText(provider)==='useEffect'
    && node.arguments[0]?.getText(provider).includes('const missingSourceNames')) {
    effect=node.arguments[0].getText(provider); effectDeps=node.arguments[1].getText(provider);
  }
  ts.forEachChild(node,visitEffect);
}
visitEffect(provider);
assert.match(effectDeps,/state.sourceDatabases/);
const {resolveSelectedSourceTables,resolveSelectedTargetTable} = load('../src/features/sttm/shared/sttm-selection-utils.ts');
const runEffect = compile(providerPath,`module.exports = input => { const {
  sessionHydrated,isInSttmBuilder,state,dispatch,window,resolveSelectedSourceTables,resolveSelectedTargetTable,
  sourceAttributesInFlightRef,targetAttributesInFlightRef,relationshipHydrationSignatureRef,
  attributeHydrationSignatureRef,selectionMetadataTimerRef,fetchAttributes,fetchRelationships,SELECTION_METADATA_DEBOUNCE_MS
} = input; return (${effect})(); };`);
let scheduled;
const requests=[];
runEffect({sessionHydrated:true,isInSttmBuilder:true,state:{derivedSources:[],sources:[{tableId:'D.S.A',qualifiedName:'D.S.A',isSelected:true}],
  sourceDatabases:[],targets:[],targetDatabases:[],sourceAttributeGroups:[],targetAttributeGroup:null,openSttmStatus:'idle'},
  dispatch:action=>{requests.push(action);return Promise.resolve();},window:{setTimeout:callback=>{scheduled=callback;return 1;},clearTimeout:()=>{}},
  resolveSelectedSourceTables,resolveSelectedTargetTable,sourceAttributesInFlightRef:{current:new Set()},
  targetAttributesInFlightRef:{current:new Set()},relationshipHydrationSignatureRef:{current:null},
  attributeHydrationSignatureRef:{current:null},selectionMetadataTimerRef:{current:null},
  fetchAttributes:args=>args,fetchRelationships:()=>({relationships:true}),SELECTION_METADATA_DEBOUNCE_MS:0});
scheduled();
assert.deepEqual(requests,[{qualifiedNames:['D.S.A'],side:'source'}]);
console.log('Actual hydration effect requests source columns before any target is selected.');

const savedState = {activeSttmId:'701',openSttmStatus:'success',derivedSources:[],
  sources:['D.S.ACCOUNTS','D.S.SYSTEMUSERS'].map(qualifiedName=>({tableId:qualifiedName,qualifiedName,isSelected:true})),
  sourceDatabases:[],targets:[],targetDatabases:[],
  sourceAttributeGroups:['D.S.ACCOUNTS','D.S.SYSTEMUSERS'].map(qualifiedName=>({qualifiedName,columns:[{name:'OWNERID'}]})),
  targetAttributeGroup:null};
const relationshipSignatureRef = {current:null};
function runSavedEffect(state) {
  scheduled = null;
  runEffect({sessionHydrated:true,isInSttmBuilder:true,state,
    dispatch:action=>{requests.push(action);return Promise.resolve();},
    window:{setTimeout:callback=>{scheduled=callback;return 1;},clearTimeout:()=>{}},
    resolveSelectedSourceTables,resolveSelectedTargetTable,
    sourceAttributesInFlightRef:{current:new Set()},targetAttributesInFlightRef:{current:new Set()},
    relationshipHydrationSignatureRef:relationshipSignatureRef,
    attributeHydrationSignatureRef:{current:null},selectionMetadataTimerRef:{current:null},
    fetchAttributes:args=>args,fetchRelationships:()=>({relationships:true}),SELECTION_METADATA_DEBOUNCE_MS:0});
  if (scheduled) scheduled();
}
requests.length = 0;
runSavedEffect(savedState);
assert.deepEqual(requests,[{relationships:true}]);
runSavedEffect(savedState);
assert.equal(requests.length,1,'same selection must not refetch repeatedly');
runSavedEffect({...savedState,activeSttmId:'702'});
assert.equal(requests.length,2,'another saved mapping must load its candidates');
runSavedEffect({...savedState,sources:[...savedState.sources,{tableId:'D.S.CONTACTS',qualifiedName:'D.S.CONTACTS',isSelected:true}]});
assert.equal(requests.filter(action=>action.relationships).length,3,'adding a source must refresh candidates');

const derivedState = {...savedState,sources:[savedState.sources[1]],derivedSources:[{id:'d',isSelected:true,sqlText:'SELECT OWNERID FROM D.S.ACCOUNTS'}]};
runSavedEffect(derivedState);
assert.equal(requests.filter(action=>action.relationships).length,4,'one physical plus one derived source must discover joins');
runSavedEffect({...derivedState,derivedSources:[{...derivedState.derivedSources[0],sqlText:'SELECT OWNERID AS OWNER FROM D.S.ACCOUNTS'}]});
assert.equal(requests.filter(action=>action.relationships).length,5,'edited derived SQL must refresh recommendations');

let relationshipReducer;
function visitRelationshipReducer(node) {
  if (ts.isCallExpression(node) && node.arguments[0]?.getText(slice)==='fetchRelationships.fulfilled') {
    relationshipReducer=node.arguments[1].getText(slice);
  }
  ts.forEachChild(node,visitRelationshipReducer);
}
visitRelationshipReducer(slice);
assert.ok(relationshipReducer);
const signature = join=>JSON.stringify([join.leftTableId,join.rightTableId,join.conditions]);
const reduceRelationships = compile(slicePath,`module.exports = (resolveSelectedSourceTables,normalizedRelationshipSignature,deduplicateRelationships) => (${relationshipReducer});`)(
  resolveSelectedSourceTables,signature,items=>[...new Map(items.map(item=>[signature(item),item])).values()]);
const authored = {id:'authored',leftTableId:'derived',rightTableId:'D.S.ACCOUNTS',conditions:[{leftColumn:'ID',rightColumn:'ID'}]};
const candidate = {id:'semantic',leftTableId:'D.S.ACCOUNTS',rightTableId:'D.S.SYSTEMUSERS',source:'SEMANTIC_VIEW',
  confidence:0.6,reviewRequired:true,conditions:[{leftColumn:'OWNERID',rightColumn:'OWNERID'}]};
for (const confidence of [0.6,0.9]) {
  const state = {...savedState,derivedSources:[],relationships:[authored],relationshipCandidates:[],
    relationshipRequestId:'request',loadState:{},compiledSqlReady:true,mappings:[{manual:true}]};
  const originalGraph = state.relationships;
  reduceRelationships(state,{meta:{requestId:'request'},payload:[{...candidate,confidence}]});
  assert.equal(state.relationships,originalGraph,'discovery cannot mutate saved joins');
  assert.equal(state.relationshipCandidates.length,1);
  assert.equal(state.relationshipCandidates[0].locked,false);
  assert.equal(state.compiledSqlReady,true);
  assert.deepEqual(state.mappings,[{manual:true}]);
}
const alreadyAdded = {...savedState,derivedSources:[],relationships:[candidate],relationshipCandidates:[],
  relationshipRequestId:'request',loadState:{}};
reduceRelationships(alreadyAdded,{meta:{requestId:'request'},payload:[candidate]});
assert.equal(alreadyAdded.relationshipCandidates.length,0,'accepted joins must not be recommended again');
const staleState = {...savedState,activeSttmId:'702',derivedSources:[],relationships:[authored],relationshipCandidates:[],
  relationshipRequestId:'request',relationshipScopeKey:JSON.stringify(['701',['D.S.ACCOUNTS','D.S.SYSTEMUSERS']]),loadState:{}};
reduceRelationships(staleState,{meta:{requestId:'request'},payload:[candidate]});
assert.equal(staleState.relationshipCandidates.length,0,'late response from another mapping must be ignored');
assert.deepEqual(staleState.relationships,[authored]);
console.log('Saved mappings refresh recommendations without auto-applying joins or changing manual mappings.');

const wildcard = {id:'wildcard',sourceName:'AllRows',isSelected:true,columns:[],outputColumns:[],
  queryScope:{scope_id:'star',outputs:[{star:true,plain_star:true}],relations:[{relation_name:'D.S.A'}]}};
const dependent = {...wildcard,id:'dependent',sourceName:'Dependent',parentDerivedSourceIds:['wildcard'],
  queryScope:{scope_id:'next',outputs:[{star:true,plain_star:true}],relations:[{source_scope_id:'star'}]}};
const columnGroups = [{qualifiedName:'D.S.A',columns:[{name:'ID',type:'NUMBER'},{name:'NAME',type:'VARCHAR'}]}];
assert.equal(hydrateDerivedColumns([wildcard],[])[0],wildcard);
const expanded = hydrateDerivedColumns([dependent,wildcard],columnGroups);
assert.deepEqual(expanded[0].columns.map(column=>column.name),['ID','NAME']);
assert.equal(expanded[0].columns[0].tableId,'dependent');
assert.equal(hydrateDerivedColumns(expanded,columnGroups)[0],expanded[0]);
const sameScopeOtherUpload = {...wildcard,id:'other-upload',queryScope:{...wildcard.queryScope,relations:[{relation_name:'D.S.B'}]}};
assert.deepEqual(hydrateDerivedColumns([dependent,wildcard,sameScopeOtherUpload],columnGroups)[0].columns,expanded[0].columns);
assert.equal(hydrateDerivedColumns([{...wildcard,queryScope:{...wildcard.queryScope,outputs:[{star:true,plain_star:false}]}}],columnGroups)[0].columns.length,0);
console.log('CTE wildcard outputs load from physical metadata and scoped parents without target selection or SQL execution.');

const review = fs.readFileSync(path.resolve(__dirname,'../src/features/sttm/mapping/sql-bundle-review-panel.tsx'),'utf8');
assert.doesNotMatch(review,/sqlExplanations|explanationRetry/);
const launcher = fs.readFileSync(path.resolve(__dirname,'../../start-ai-workbench-dev.ps1'),'utf8');
assert.match(launcher,/\$BACKEND_PORT\s*=\s*"8000"/);
assert.match(launcher,/\$env:NEXT_PUBLIC_BACKEND_DEV_ORIGIN\s*=\s*\$backendOrigin/);
console.log('Upload no longer starts description calls; launcher pins browser and proxy to backend 8000.');

// Cross-runtime regressions supply the real backend parser result and typed
// qualification evidence; no parser or workspace behavior is mocked here.
if (process.argv.includes('--upload-json')) {
  const input = JSON.parse(fs.readFileSync(0, 'utf8'));
  const before = JSON.stringify(input.uploaded);
  try {
    const actual = buildSqlUploadWorkspace(input.uploaded);
    const state = {sources:[],targets:[],sourceDatabases:[],targetDatabases:[],derivedSources:[]};
    apply(state, {payload:actual});
    const {sqlIdentifierParts} = load('../src/features/sttm/shared/sql-identifiers.ts');
    const tables = resolveSelectedSourceTables(state).map(table => {
      const [database,schema,name] = sqlIdentifierParts(table.qualifiedName);
      return {database,schema,table:name};
    });
    const graph = buildCompilerRelationGraph({sourceTables:tables, queryModifiers:state.sourceQueryModifiers,
      derivedSources:state.derivedSources,relationships:state.relationships,mappings:state.mappings});
    assert.equal(JSON.stringify(input.uploaded), before, 'Apply must not mutate the upload');
    const {buildMappingExpression, buildMappingSelectSql} = load('../src/features/sttm/mapping/mapping-utils.ts');
    const expressions = Object.fromEntries(state.mappings.map(row => [row.targetColumn, buildMappingExpression(row)]));
    const regeneratedSql = buildMappingSelectSql({mappings:state.mappings,sourceQuerySql:actual.sql});
    if (process.argv.includes('--hydration-lifecycle')) {
      require('./test-workspace-persistence.cjs').runHydrationLifecycle(structuredClone(state))
        .then(result=>console.log('HYDRATION_RESULT:' + JSON.stringify(result)))
        .catch(error=>{console.error(error);process.exitCode=1;});
    }
    console.log('UPLOAD_RESULT:' + JSON.stringify({workspace:actual,state,graph,expressions,regeneratedSql}));
  } catch (error) {
    if (!input.expectedError) throw error;
    assert.match(error.message, new RegExp(input.expectedError));
    assert.equal(JSON.stringify(input.uploaded), before);
    console.log('UPLOAD_RESULT:' + JSON.stringify({error:error.message}));
  }
}

if (process.argv.includes('--stdin')) {
  const parsed = JSON.parse(fs.readFileSync(0,'utf8'));
  const actual = buildSqlUploadWorkspace({asset_id:'read-only-audit',parsed_summary:parsed});
  const snapshot = assertSnapshot(actual);
  console.log(JSON.stringify({ctes:snapshot.derived_sources.length,
    selected:snapshot.derived_sources.filter(cte=>cte.is_selected).map(cte=>cte.name),
    retainedDependencies:snapshot.derived_sources.filter(cte=>!cte.is_selected).map(cte=>cte.name),
    sources:actual.sourceTableFqns.length,joins:actual.relationships.length}));
}
