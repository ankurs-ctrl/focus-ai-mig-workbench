"""V9 independent-review regressions, real guarded runtime and resolution stages.

Model/HTTP/Snowflake boundaries are fake. No live client accuracy claim.
"""
import asyncio
from collections import Counter
from copy import deepcopy
import json
import pytest
from app.core.automap_evidence_blocks import EvidenceBlocks, EvidenceBlockError
from tests.unit.core.test_automap_client_v9 import normal_review
from tests.unit.core.test_automap_fast_context import fast_payload,unpack
from tests.unit.core.test_automap_fast_batch import prepared_request,answer_for
from tests.unit.core.test_automap_guarded_specialist import setup
from tests.test_automap_fast_transport import harness as transport_harness

ALIASES=['AGT_SOURCE_MAPPING','SOURCE_MAPPING_AGENT','source_mapping']


def registry():
    blocks=EvidenceBlocks('snapshot',120000,120000);blocks.enabled=True;blocks.begin()
    blocks.project('Exact source contract; preserve authored population. '*7000)
    identity=blocks.pending[0]
    return blocks,identity,normal_review(blocks.blocks[identity])


@pytest.mark.parametrize('root_agent',[None,*ALIASES],ids=['root-absent','root-canonical','root-enum','root-short'])
@pytest.mark.parametrize('nested_agent',[None,*ALIASES],ids=['data-absent','data-canonical','data-enum','data-short'])
def test_review_uses_shared_supported_alias_identity_at_every_location(root_agent,nested_agent):
    blocks,identity,body=registry()
    if root_agent is not None:body['agent']=root_agent
    if nested_agent is None:body['data'].pop('agent')
    else:body['data']['agent']=nested_agent
    if root_agent is None and nested_agent is None:
        with pytest.raises(EvidenceBlockError):blocks.accept(identity,json.dumps(body))
        assert not blocks.reviews
    else:
        blocks.accept(identity,json.dumps(body));assert identity in blocks.reviews


@pytest.mark.parametrize('bad',['AGT_TRANSFORMATION_RULE','TRANSFORMATION_AGENT','transformation_rules','unknown','SOURCE_MAPPING','',None,[],{}],
    ids=['transform-canonical','transform-enum','transform-short','unknown','unsupported-case','empty','null','list','object'])
def test_valid_root_cannot_hide_unknown_or_conflicting_nested_agent(bad):
    blocks,identity,body=registry();body['agent']='SOURCE_MAPPING_AGENT';body['data']['agent']=bad
    with pytest.raises(EvidenceBlockError):blocks.accept(identity,json.dumps(body))
    assert not blocks.reviews


@pytest.mark.parametrize('poison',['delegation','conflicting_result','failed','extra_fact','fabricated_quote'])
def test_alias_normalization_never_weakens_the_full_envelope_or_literal_evidence_checks(poison):
    blocks,identity,body=registry();body['agent']='SOURCE_MAPPING_AGENT';body['data']['agent']='source_mapping'
    if poison=='delegation':body['data']['meta']={'delegation':{'tool':'Analyst'}}
    elif poison=='conflicting_result':body['result']={'mappings':{'FOREIGN':{}}}
    elif poison=='failed':body['status']='failed'
    elif poison=='extra_fact':body['meta']['evidence_review']['facts'][0]['observation']='unverified'
    else:body['meta']['evidence_review']['facts'][0]['quote']='fabricated meaning'
    with pytest.raises(EvidenceBlockError):blocks.accept(identity,json.dumps(body))
    assert not blocks.reviews


def test_whitespace_handling_matches_existing_application_normalizer():
    blocks,identity,body=registry();body['agent']=' SOURCE_MAPPING_AGENT ';body['data']['agent']=' source_mapping '
    blocks.accept(identity,json.dumps(body));assert identity in blocks.reviews


@pytest.mark.parametrize('alias',ALIASES,ids=['canonical','enum','short'])
def test_actual_alias_reviews_reach_decision_on_owning_guarded_runtime_without_format_retries(transport_harness,alias):
    h=transport_harness;builder,models,_,_=setup(h,1)
    value=fast_payload();value['data']['message']='Mandatory synthetic population rule. '*10000
    reviews=[];decisions=[]
    def hook(outgoing):
        packet=unpack(json.loads(outgoing.content)['messages'])
        if packet.get('protocol')=='auto_map_exact_evidence_block_v1':
            block=packet['context']['evidence_block'];reviews.append(block['block_id'])
            body=normal_review(block);body['data']['agent']=alias
            h.state.answer=json.dumps(body)
        else:
            decisions.append(packet.get('protocol'))
            body=json.loads(answer_for(['NAME0']));body['agent']=alias
            h.state.answer=json.dumps(body)
    h.state.hook=hook
    final=asyncio.run(builder.invoke_auto_map_parallel(prepared_request(value)))
    assert reviews and all(count==1 for count in Counter(reviews).values())
    assert decisions==['auto_map_fast_path_v1']
    assert final.result.mappings['NAME0'].source_attributes==['a.X47']
    assert all(slot['STATE']=='FREE' for slot in h.database.slots)


def test_explicit_37_target_reevaluation_reaches_all_targets_and_separates_three_replacements():
    from tests.test_automap_fast_job import authored,proxy
    from tests.unit.core.test_auto_mapping_proxy import _response
    req=authored(pending=34,expressions=('src.COL_0',"''",'CURRENT_TIMESTAMP()'))
    before=req.model_dump(mode='json')
    req.meta.update(auto_map_resolution_mode='reeval_all',auto_map_target_scope=[a.target_attribute for a in req.data.attributes])
    client=proxy();frozen=client._freeze_resolution(req)
    plan=client._trusted_resolution_plan(frozen)
    assert len(plan['targets'])==37
    assert all(target['reevaluate'] and target['status']=='pending' for target in plan['targets'])
    assert sum(target['had_baseline'] for target in plan['targets'])==3
    pending=client._pending_resolution_request(frozen)
    assert len(pending.data.attributes)==37
    result=client._complete_resolution_response(frozen,_response(pending))
    review=result.meta['auto_mapping_review']
    assert review['newly_mapped_count']==34 and review['proposed_count']==37
    assert review['proposed_count']-review['newly_mapped_count']==3
    assert all(target['reevaluate'] for target in result.meta['automap_resolution']['targets'])
    assert req.context.workspace_context.model_dump(mode='json')==before['context']['workspace_context']
