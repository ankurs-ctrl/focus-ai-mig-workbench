import json
import pytest
from app.core.automap_input_budget import fit_optional_history, wire_text
from app.core.agent_payload_budget import AgentPayloadBudgetError


def render(packet):
    return [{'role':'user','content':[{'type':'text','text':json.dumps(packet,ensure_ascii=False)}]}]


def test_final_wire_budget_defers_optional_history_without_changing_sql_or_corrections():
    rule="CASE WHEN src.ID = 1 THEN 'é' ELSE '中' END"
    correction={'mandatory':True,'record_id':'correction','body':'Keep SQL NULL intentional'}
    packet={'context':{'rule':rule,'mapping_evidence':{'NAME':{'recipes':[
        correction, {'pattern_id':'near','tier':'T1','description':'x'*1500},
        {'pattern_id':'distant','tier':'T4','description':'中'*6000}]}}}}
    messages, coverage=fit_optional_history(packet,render,max_chars=6000,max_bytes=6000)
    text=wire_text(messages)
    assert len(text)<=6000 and len(text.encode('utf-8'))<=6000
    assert coverage['deferred_evidence_ids']==['distant']
    decoded=json.loads(messages[0]['content'][0]['text'])
    assert decoded['context']['rule']==rule
    assert decoded['context']['mapping_evidence']['NAME']['recipes'][0]==correction
    assert len(packet['context']['mapping_evidence']['NAME']['recipes'])==3


def test_essential_contract_is_never_truncated():
    packet={'context':{'cte_dependencies':{'sql_text':'x'*20000}}}
    with pytest.raises(AgentPayloadBudgetError):
        fit_optional_history(packet,render,max_chars=3000,max_bytes=3000)


def test_late_source_packing_preserves_required_and_requested_pins():
    from tests.unit.core.test_automap_fast_context import fast_payload, plan_for
    value=fast_payload();value['meta']['automap_generation_policy']='draft-v3'
    _,plan=plan_for(value)
    render_original=plan._render
    required=set(plan.required_pins)
    def expanded(results,**kwargs):
        messages=render_original(results,**kwargs)
        messages.append({'role':'user','content':[{'type':'text','text':'x'*(len(plan.binding_admissions())*4000)}]})
        return messages
    plan._render=expanded
    messages=plan.messages([])
    assert len(wire_text(messages))<=plan.max_chars
    assert len(wire_text(messages).encode('utf-8'))<=plan.max_bytes
    assert required <= plan.pinned


@pytest.mark.parametrize('size',[181157,181403,184395,188885])
def test_incident_size_optional_history_can_be_deferred(size):
    packet={'context':{'source_bindings':['accounts."ADDRESS1_LINE1"'],
        'mapping_evidence':{'BILLINGSTREET':{'recipes':[{'pattern_id':'optional','description':'x'*size}]}}}}
    messages,coverage=fit_optional_history(packet,render,max_chars=180000,max_bytes=180000)
    text=wire_text(messages)
    assert len(text)<=180000 and len(text.encode('utf-8'))<=180000
    assert coverage['deferred_evidence_ids']==['optional']
    assert json.loads(messages[0]['content'][0]['text'])['context']['source_bindings']==['accounts."ADDRESS1_LINE1"']


def test_current_target_requirements_remain_plain_and_target_scoped_after_factoring():
    from tests.unit.core.test_automap_fast_context import fast_payload, plan_for
    value=fast_payload()
    description='Use exactly a.X0 as a direct mapping. The target suffix is a label, not a source ordinal.'
    for item in value['data']['attributes']:item['target_description']=description
    _,plan=plan_for(value)
    target=next(iter(plan.store.targets))
    messages=plan.messages([],targets={target})
    packet=json.loads(messages[0]['content'][0]['text'])
    assert 'current_target_requirements' not in packet
    assert packet['data']['attributes'][0]['target_description']==description
    assert {item['target_attribute'] for item in packet['data']['attributes']}=={target}
    assert len(wire_text(messages))<=plan.max_chars
    assert len(wire_text(messages).encode())<=plan.max_bytes
