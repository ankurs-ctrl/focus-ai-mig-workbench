from app.core.sttm_builder import _extract_stream_text_delta


def test_extracts_cortex_agent_answer_token() -> None:
    assert (
        _extract_stream_text_delta(
            "response.text.delta",
            {"content_index": 0, "text": "Hello"},
        )
        == "Hello"
    )


def test_does_not_expose_cortex_agent_thinking_token() -> None:
    assert (
        _extract_stream_text_delta(
            "response.thinking.delta",
            {"content_index": 0, "text": "private reasoning"},
        )
        is None
    )
