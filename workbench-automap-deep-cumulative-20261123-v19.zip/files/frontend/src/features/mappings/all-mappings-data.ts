export type MappingListStatus = "Complete" | "Partial" | "Draft";

export type AllMappingListItem = {
  id: string;
  index: number;
  name: string;
  qualifiedName: string;
  status: MappingListStatus;
  projectId: string;
  projectName: string;
  aiSummary: string;
  createdBy: {
    initials: string;
    name: string;
  };
  createdAt: string;
  relativeTime: string;
  /** Epoch ms of the last update (or creation); drives "Latest first" ordering. */
  lastActivityAt: number;
  logicalTargetKey?: string;
  sourceSystemKey?: string;
};

export type MappingSortOption = "latest-first" | "name-asc" | "mapping-no";

export type MappingStatusFilter = "all" | "complete" | "in-progress" | "partial" | "draft";

export const MAPPING_STATUS_SUMMARY = {
  total: 0,
  complete: 0,
  partial: 0,
  draft: 0,
};

export const SORT_OPTIONS: { value: MappingSortOption; label: string }[] = [
  { value: "latest-first", label: "Sort: Latest first" },
  { value: "name-asc", label: "Sort: Name A-Z" },
  { value: "mapping-no", label: "Sort: Mapping No." },
];

export const STATUS_FILTERS: { value: MappingStatusFilter; label: string }[] = [
  { value: "all", label: "All" },
  { value: "complete", label: "Complete" },
  { value: "in-progress", label: "In Progress" },
  { value: "partial", label: "Partial" },
  { value: "draft", label: "Draft" },
];

export function resolveStatusFilterFromParam(statusParam: string | null): MappingStatusFilter {
  return STATUS_FILTERS.find((filter) => filter.value === statusParam)?.value ?? "all";
}

export function buildMappingStatusSummary(items: AllMappingListItem[]) {
  return {
    total: items.length,
    complete: items.filter((item) => item.status === "Complete").length,
    partial: items.filter((item) => item.status === "Partial").length,
    draft: items.filter((item) => item.status === "Draft").length,
  };
}

export function filterMappings(
  items: AllMappingListItem[],
  statusFilter: MappingStatusFilter,
  searchQuery: string,
  projectFilter = "all",
): AllMappingListItem[] {
  const normalizedQuery = searchQuery.trim().toLowerCase();

  return items.filter((item) => {
    const matchesProject =
      projectFilter === "all" || item.projectId === projectFilter;

    if (!matchesProject) {
      return false;
    }

    // "in-progress" covers everything not yet complete (partial + draft),
    // matching the dashboard's In-progress Mappings count.
    const matchesStatus =
      statusFilter === "all" ||
      (statusFilter === "in-progress"
        ? item.status !== "Complete"
        : item.status.toLowerCase() === statusFilter);

    if (!matchesStatus) {
      return false;
    }

    if (!normalizedQuery) {
      return true;
    }

    // Mapping No. search: "#42" matches only serial 42; a bare "42" also
    // matches serial 42 and still falls through to the text search below.
    const serialQuery = /^#?\s*(\d+)$/.exec(normalizedQuery);
    if (serialQuery) {
      if (item.index === Number(serialQuery[1])) {
        return true;
      }
      if (normalizedQuery.startsWith("#")) {
        return false;
      }
    }

    const haystack = [
      item.name,
      item.qualifiedName,
      item.projectName,
      item.aiSummary,
      item.createdBy.name,
    ]
      .join(" ")
      .toLowerCase();

    return haystack.includes(normalizedQuery);
  });
}

export function sortMappings(
  items: AllMappingListItem[],
  sortBy: MappingSortOption,
): AllMappingListItem[] {
  const sorted = [...items];

  if (sortBy === "name-asc") {
    return sorted.sort((a, b) => a.name.localeCompare(b.name));
  }

  if (sortBy === "mapping-no") {
    return sorted.sort((a, b) => a.index - b.index);
  }

  return sorted.sort(
    (a, b) => b.lastActivityAt - a.lastActivityAt || b.index - a.index,
  );
}

export function timestampOf(value?: string | null): number {
  const time = value ? new Date(value).getTime() : NaN;
  return Number.isNaN(time) ? 0 : time;
}

/**
 * Serial numbers follow creation order (oldest = 1) so they stay fixed when a
 * mapping is updated and moves to the top of the "Latest first" list.
 */
export function serialNumbersByCreation(
  records: { sttm_id: string; created_at?: string | null }[],
): Map<string, number> {
  const ordered = [...records].sort(
    (a, b) =>
      timestampOf(a.created_at) - timestampOf(b.created_at) ||
      a.sttm_id.localeCompare(b.sttm_id),
  );
  return new Map(ordered.map((record, position) => [record.sttm_id, position + 1]));
}
