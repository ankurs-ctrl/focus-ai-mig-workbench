# Auto-map delivery and SQL-upload correction package

Baseline: `sync/uat-frontend-native-integration` at `96a14c175a12fe73b041c682c0997a28e385f40b`.
This is a source delta for that integration baseline. It includes the frontend team's merged code in affected files; it is not a replacement for the rest of their branch.

## Corrections

| Area | Result |
| --- | --- |
| Native delivery | Reconcile per target. A cached 1/2 response cannot replace a valid 2/2 worker result. Require the same batch, frozen snapshot, input revision and target bindings. Conflicting target deliveries retain the accepted checkpoint, preserve compatible siblings, and emit a warning. |
| Parent cutoff | Keep checkpoints accepted before cutoff in terminal partial assembly. New results observed after cutoff cannot replace them. |
| Native completion | Classify remote completion before content validation. Malformed statusless/nonterminal/truncated outcomes retain uncertain-call protection; complete documented synchronous envelopes remain compatible. No automatic POST replay. |
| Analyst completion | Explicit nonterminal status retains its permit. Supported synchronous Analyst responses need no invented status field. Invalid SQL is rejected independently of permit release. |
| Repeated physical relations | Keep physical catalog identity separate from query-instance IDs. Preserve mail/other country and state aliases, quoted case, joins, predicates and CTE boundaries through Apply, snapshots, reopen, metadata refresh, preview compilation and native source inventory. Ambiguous physical-only references cannot select a self-join instance. |
| Verification | Persist proofs/attempts, prioritize unread references, and resume bounded pages without restarting the first six DESCRIBEs. Semantic availability remains separate from existence. Page exhaustion is unknown, never proof of missing data. More than 200 references can progress across pages. |
| Upload latency | New UI uploads durably accept before parsing, qualification and learning preparation. Preview persistence precedes optional enrichment. Batch up to 100 learning work items per MERGE, with deterministic work IDs. Short admission transactions serialize duplicate logical submissions. |
| Disconnect recovery | Persist a browser request handle before POST. Recover using authorized GETs, including after reload. Do not replay an uncertain POST. Bounded observation stops with a recoverable message; explicit missing/failed acceptance permits a manual retry. |
| Processing lifecycle | Deduplicate documents separately from processing runs. Include processor version, project, content and relevant options in reuse identity; scope lookups to caller/role. Server-generated processing IDs separate verification/learning contexts even if callers reuse a browser ID. Failed runs retain history; a new explicit upload gets a fresh learning generation. Publication is lease/generation fenced. |
| SQL Values | The synthetic fixture exposed a text empty-string/NULL mismatch. Text empty and whitespace constants now survive frontend/backend compilation; authored NULL string literals remain exact SQL expressions. Existing non-text blank-input handling and conservative authored-query certification are retained. |

Frontend edits are confined to upload recovery and relation-instance integration in selection, mapping, snapshots and SQL previews. Navigation, tours, authentication, Quiz and team styling are retained. Existing Auto-map scope, alternatives, revision fencing and replacement acceptance are retained.

## Synthetic Household regression

The original `docs/01-EverNest-HHs-reference.sql` is unchanged. Two new fixtures live in `services/sttm-builder/tests/fixtures/sql_upload/`:

- `evernest_household_relation_instances.sql`: eleven physical tables, two address populations, three CTEs, four outer LEFT joins, `ccMail` / quoted `"ccOther"`, `scMail` / `scOther`, complex OR predicates, QUALIFY, population filters, quoted output and an empty-string constant.
- `evernest_household_relation_instances_seed.sql`: optional session-temporary synthetic data for a dedicated scratch namespace. It is not executed by the application. Replace the scratch namespace in both files if running manually.

The executable offline regression dialect-translates a copy of the reference and regenerated queries into in-memory SQLite. Both must return exactly:

`1 | Pittsburgh | US | CA | PA | ON | Jane Stone | <empty string>`

This catches crossed lookup bindings, lost population filters and lost QUALIFY behavior. It does not establish Snowflake compilation or client data accuracy. The actual Contacts query and its `ccOther` business predicate were not changed.

## Installation order (separate from application source review)

1. Use the existing namespace substitution to apply `infra/snowflake/sql_upload_recovery_v1.sql` before deploying this application delta. The same table/control-row definition is included in `create-table-ddl.sql` for fresh installations. Missing schema is an explicit failure, not a silent return to the old upload path.
2. Apply the updated FIR grants using the existing service-owner substitution. Caller roles used by the app need SELECT/INSERT/UPDATE on `TBL_SQL_UPLOAD_REQUESTS` and the existing reference persistence privileges, including DELETE on `TBL_FIR_ASSET_TABLE_REFERENCES`.
3. Reinstall the changed FIR procedure sources with the existing bootstrap: `sp-fir-read-documents.sql`, `sp-fir-enrich-context.sql`, and `sp-fir-reconcile-recommendation-identities.sql`. They prevent historical request generations from being combined into one evidence set. No agent definition or environment value is changed by this package.
4. Deploy backend and frontend together. New UI uploads send `upload_request_id` and use `/v1/upload/sql/requests/{request_id}?project_id=...`. Legacy callers retain their synchronous response contract; they must adopt request identities to get disconnect recovery.
5. Keep both required native Markdown source assets from the package: `infra/snowflake/automap_native_v1/investigator.md` and `transformation.md`. They are explicitly included even though unchanged in this delta.

Queued work is durable. A status read schedules resumable work; an expired worker lease can be reclaimed after 20 minutes. Verification continuations retain the same processing/learning identity and stop with explicit incomplete status after bounded attempts. This is request-driven recovery, not a new unattended scheduler. Uncertain native model-call permits are not recycled by upload recovery.

## Validation and acceptance

The included tests cover older/newer checkpoint reconciliation and cutoff, native and Analyst permit states, repeated relation instances and quoted aliases, source inventory identity, oversized verification paging, a slow first source, reload/disconnect recovery, concurrent deduplication, caller/project/role isolation, background failure, stale worker rejection, processing generations and exact learning-job selection.

Final local suite results and file hashes are recorded in the package manifest. Tests use simulated provider/Snowflake boundaries and synthetic data. Live Snowflake compilation, native tool invocation, client Auto-map accuracy and UAT latency remain client acceptance checks. No deployment, commit or remote push is performed for this delta.

## Rollback

Roll back backend/frontend together to the baseline commit. Keep durable request, checkpoint and failure-history tables for investigation; do not delete active or quarantined call records. Restore the previous FIR procedure sources only as part of a coordinated application rollback. The additive upload table does not modify source or target business data.

Native completion classification also covers Snowflake's documented statusless synchronous envelope, while keeping strict tool pairing and final-answer checks. [Snowflake Agents Run API](https://docs.snowflake.com/en/user-guide/snowflake-cortex/cortex-agents-run)

Analyst synchronous-message validation was checked against the [official Analyst REST API](https://docs.snowflake.com/en/user-guide/snowflake-cortex/cortex-analyst/rest-api); generated SQL is still validated before any bounded read-only execution.

## Final local results

- Full backend: 4141 passed, 31 skipped.
- Frontend: 22 harnesses passed; TypeScript passed. The final preview-alias regression also passed.
- Final affected delivery/upload boundaries: 47 passed (overlapping coverage; do not add to the full-suite count).
- Synthetic reference and regenerated rows matched in the offline execution check.
- Changed FIR procedure Python bodies parsed successfully. Live Snowflake/UAT acceptance was not performed.
