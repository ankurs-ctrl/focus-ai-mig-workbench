# Frontend Test-Case Generation Handoff

## Purpose

Use the mapping's validated/current compiled SQL and semantic workspace to generate test cases with `AGT_DBT_TEST_GENERATION`. The Summary page already starts this request once when a usable payload becomes available and reuses the in-flight or completed result while the user changes tabs.

This is a generated artifact endpoint, not a static test-case catalogue. Mock rows must only be used when the application is explicitly running with the mock database flag.

## Primary endpoint

```http
POST /api/v1/workbench/test-cases
```

The frontend route constant is `/v1/workbench/test-cases`; the shared API client adds the `/api` proxy prefix.

Operation name:

```text
test_cases.generate
```

The frontend call is:

```ts
const result = await dbService.generateTestCases(payload);
```

The configured client timeout is seven minutes because this is an agent-backed generation request.

## Request envelope

```json
{
  "contract_version": "1.0",
  "request_id": "...",
  "operation": "test_cases.generate",
  "actor": null,
  "context": {
    "project_id": "903",
    "sttm_id": "1401",
    "target_table": {
      "database": "FFP_HDP_CRM_MIG_DB_DEV",
      "schema": "SCH_REDTAIL_EVERNEST_TARGET",
      "table": "EVERNEST_HH"
    },
    "source_tables": [],
    "relationships": []
  },
  "data": {
    "project_id": "903",
    "sttm_id": "1401",
    "project_name": "EverNest Mapping Intelligence V2 Acceptance",
    "domain_name": "CRM migration",
    "target_layer": "curated",
    "materialization": "incremental",
    "source_tables": [],
    "target_table": {
      "database": "FFP_HDP_CRM_MIG_DB_DEV",
      "schema": "SCH_REDTAIL_EVERNEST_TARGET",
      "table": "EVERNEST_HH"
    },
    "relationships": [],
    "validated_sql": "SELECT ...",
    "mappings": [],
    "semantic_context": [],
    "derived_sources": []
  },
  "warnings": [],
  "meta": {}
}
```

Required fields:

- `target_table`
- `validated_sql` (non-empty)

The frontend should also send all available `source_tables`, `relationships`, mapped rows, semantic context, and derived-source SQL/lineage. Omitting those fields reduces the quality and traceability of generated tests.

Each derived source has this shape:

```ts
type TestCaseDerivedSourceItem = {
  derived_source_name: string;
  sql_text?: string | null;
  semantic_view_name?: string | null;
  base_sources: Array<{
    table: TableRef;
    attribute_semantic_model: Array<Record<string, unknown>>;
  }>;
};
```

## Response data

The endpoint returns the standard response envelope. `data` contains:

```ts
type TestCaseGenerationResponse = {
  status: "completed" | "failed" | string;
  domain_name?: string | null;
  target_layer?: string | null;
  materialization?: string | null;
  target_model?: string | null;
  target_table?: string | null;
  test_groups: Array<{
    group: string;
    target_columns: string[];
  }>;
  seed_files: Array<{
    file_path: string;
    file_type: string;
    content: string;
  }>;
  test_case_document: Array<{
    test_case_id: string;
    group: string;
    target_attribute: string;
    source_columns: string;
    mapping_rule: string;
    test_case_description: string;
    test_type: string;
    sample_source_input: string;
    expected_target_value: string;
    confidence?: string | null;
  }>;
  agent_name: string;
  retrieved_inference_ids: string[];
  retrieved_recommendation_ids: string[];
  used_inference_ids: string[];
  used_recommendation_ids: string[];
};
```

`test_case_document` drives the Test Cases table. `seed_files` and `test_groups` are generated artifacts and grouping metadata; they must not be replaced with frontend mock constants.

## Required frontend lifecycle

1. Build the payload from the current Summary workspace after the current compiled SQL and target table are available.
2. Start generation on Summary-page entry. Do not wait for the user to click the Test Cases tab.
3. Compute a stable payload signature.
4. Reuse the same in-flight Promise for the same signature.
5. Cache the completed response for the same signature.
6. Switching Summary tabs must not cancel or restart generation.
7. A deliberate Regenerate action may bypass the completed cache, but must be visibly initiated by the user.
8. If the mapping, compiled SQL, target, semantics, relationships, or derived sources change, the payload signature must change and a new result may be generated.

The existing `TestCasesTab` module-level request and result caches implement the in-flight and completed-result behavior. Keep generation state outside tab visibility so unmount/remount does not lose progress.

## Loading, empty, and failure behavior

- While pending, show that the agent is generating tests and keep existing completed rows visible if a refresh was explicitly requested.
- A successful result with zero rows is a valid empty result; do not substitute mock test cases.
- If `data.status` is `failed`, show generation failure and a Retry action.
- `401`: session missing or expired; return to authentication.
- `403`: authenticated caller lacks access; show access denied and do not retry automatically.
- `422`: request contract is incomplete or invalid. Show the field-level validation details.
- `5xx` or timeout: show a recoverable failure with Retry. Do not create parallel retries for the same payload signature.

## Authentication and permissions

The endpoint resolves the authenticated principal when it creates the caller-scoped Snowflake service. The route does not currently declare a separate `require_persona(...)` or explicit `can_edit` check.

For current frontend behavior:

- Require an authenticated session.
- Treat test-case generation as a mapping-generation action and expose it only when `session.ui_permissions.can_edit` is true.
- A Viewer may see previously persisted/exported test-case results in a read-only screen, but should not trigger a new agent request from the UI.

This frontend rule does not replace backend authorization. The backend should add explicit permission enforcement if Viewer generation must be prohibited as a security requirement.

## Frontend acceptance checks

- Entering Summary starts exactly one request for a new payload.
- Opening Test Cases while generation is running shows the same request's progress.
- Switching away and back does not send another request.
- A completed response remains visible across Summary tab changes.
- Generated rows come from `data.test_case_document`, never `STATIC_TEST_CASES` outside explicit mock mode.
- Changing the compiled SQL or semantic workspace causes a new payload signature.
- Retry starts one new request only after a failed request.
- Viewer mode does not start generation or show Regenerate controls.
- Workbook export uses the same cached generated test cases shown in the UI.

## Source references

- Frontend route registry: `frontend/src/api/routes.ts`
- Frontend API client: `frontend/src/services/dbService.ts`
- Frontend Test Cases UI/cache: `frontend/src/features/sttm/summary/test-cases-tab.tsx`
- Summary-page orchestration: `frontend/src/features/sttm/summary/summary-workspace.tsx`
- Frontend contracts: `frontend/src/types/api-contract.ts`
- Backend endpoint: `services/sttm-builder/app/routers/test_case_generation.py`
- Backend request/response schema: `services/sttm-builder/app/schema/test_case_generation.py`
- Backend generation service: `services/sttm-builder/app/core/test_case_generation.py`
- Authentication/session handoff: `docs/FRONTEND_PERSONA_ACCESS_HANDOFF.md`
