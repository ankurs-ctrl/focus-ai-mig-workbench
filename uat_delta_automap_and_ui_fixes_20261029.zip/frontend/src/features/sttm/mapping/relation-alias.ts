/**
 * Relation alias generation - single source of truth.
 *
 * Aliases used to be POSITIONAL (`${name}_${index + 1}`, with derived sources
 * offset by `sourceTables.length`) and the generator was duplicated in three
 * places. Two consequences made mapping work unrecoverable:
 *
 *  1. Adding, removing or reordering any physical source renumbered every derived
 *     alias, so aliases already frozen into persisted `source_columns` stopped
 *     matching anything.
 *  2. The snapshot writer and the compiler payload builder each had their own copy
 *     of the generator, free to drift apart.
 *
 * The alias is now derived only from the relation's own stable identity, so it
 * does not depend on how many other relations exist or what order they are in.
 * A short hash keeps aliases unique when two schemas contain the same table name,
 * without reintroducing positional coupling.
 */

/** Lower-cased, SQL-safe form of the last dotted segment. */
function aliasStem(seed: string): string {
  const stem = seed
    .split(".")
    .pop()
    ?.replace(/[^A-Za-z0-9_]/g, "_")
    .replace(/^_+|_+$/g, "")
    .toLowerCase();
  return stem || "source";
}

/**
 * Short, stable, non-cryptographic digest of the full identity.
 * FNV-1a: deterministic across sessions and machines, which matters because the
 * alias it produces gets persisted.
 */
function identityDigest(identity: string): string {
  let hash = 0x811c9dc5;
  for (let index = 0; index < identity.length; index += 1) {
    hash ^= identity.charCodeAt(index);
    hash = Math.imul(hash, 0x01000193) >>> 0;
  }
  return hash.toString(36).padStart(6, "0").slice(-6);
}

/**
 * Alias for a relation, derived purely from its stable identity.
 *
 * `identity` must be the relation's durable key - a fully qualified table name for
 * physical tables, or the derived-source id for derived sources. Never pass an
 * array index or anything else that varies with unrelated workspace edits.
 */
export function relationAliasFor(identity: string, displaySeed?: string | null): string {
  const key = String(identity || "").trim();
  if (!key) return "source";
  // Imported SQL CTEs already have a query-scoped, meaningful identity. Keep
  // that name in generated SQL instead of appending an opaque numeric digest.
  // Ids are `sql-cte:<name>` or upload-scoped `sql-cte:<scope>:<name>`.
  if (key.startsWith("sql-cte:")) {
    return `cte_${aliasStem(displaySeed || key.slice(8).split(":").pop() || key.slice(8))}`;
  }
  return `${aliasStem(displaySeed || key)}_${identityDigest(key)}`;
}

/** Display-only names; persisted references and execution aliases stay unchanged. */
export function buildRelationDisplayAliases(
  nodes: Array<{ identity: string; alias: string; displaySeed?: string | null }>,
): Map<string, string> {
  const labels = nodes.map((node) => ({ node, label: aliasStem(node.displaySeed || node.identity) }));
  const counts = new Map<string, number>();
  for (const { label } of labels) counts.set(label, (counts.get(label) ?? 0) + 1);
  const ordinals = new Map<string, number>();
  const reserved = new Set(labels.map(({ label }) => label));
  const used = new Set<string>();
  const aliases = new Map<string, string>();
  for (const { node, label } of labels) {
    if (node.alias !== relationAliasFor(node.identity, node.displaySeed)) continue;
    let ordinal = (ordinals.get(label) ?? 0) + 1;
    while (counts.get(label) !== 1 && (reserved.has(`${label}_${ordinal}`) || used.has(`${label}_${ordinal}`))) ordinal += 1;
    ordinals.set(label, ordinal);
    // Display duplicate names with a small ordinal instead of the identity
    // hash. Runtime aliases stay stable and distinct in saved SQL.
    const visible = counts.get(label) === 1 ? label : `${label}_${ordinal}`;
    used.add(visible);
    aliases.set(node.alias.toUpperCase(), visible);
    aliases.set(node.identity.toUpperCase(), visible);
  }
  return aliases;
}

export function formatRelationDisplayText(text: string, aliases: Map<string, string>): string {
  // Skip literals and comments. This formats UI text only, never executable SQL.
  return text.replace(
    /'(?:''|[^'])*'|\$\$[\s\S]*?\$\$|--[^\r\n]*|\/\*[\s\S]*?\*\/|"(?:""|[^"])*"|\b[A-Za-z_][A-Za-z0-9_$]*(?:\.[A-Za-z_][A-Za-z0-9_$]*)*/g,
    (token) => {
      if (/^['"$]|^--|^\/\*/.test(token)) return token;
      const dot = token.lastIndexOf('.');
      if (dot < 0) return aliases.get(token.toUpperCase()) ?? token;
      const label = aliases.get(token.slice(0, dot).toUpperCase());
      return label ? `${label}${token.slice(dot)}` : token;
    },
  );
}

export function splitSourceDisplayLabel(reference: string): { column: string; relation: string } {
  const dot = reference.lastIndexOf('.');
  return dot < 0 ? { column: reference, relation: '' }
    : { column: reference.slice(dot + 1), relation: reference.slice(0, dot) };
}

/** Rename only known generated aliases, never physical FQNs, strings or comments. */
export function readablePreviewSql(sql: string, nodes: Array<{ identity: string; alias: string; displaySeed?: string | null }>): string {
  const candidates = buildRelationDisplayAliases(nodes);
  const tokens = /'(?:''|[^'])*'|\$\$[\s\S]*?\$\$|--[^\r\n]*|\/\*[\s\S]*?\*\/|"(?:""|[^"])*"|\b[A-Za-z_][A-Za-z0-9_$]*(?:\.[A-Za-z_][A-Za-z0-9_$]*)*/g;
  const sqlTokens = sql.match(tokens) ?? [];
  const quoted = new Set(sqlTokens.filter(token => token.startsWith('"'))
    .map(token => token.slice(1, -1).replaceAll('""', '"').toUpperCase()));
  const occupied = new Set(sqlTokens
    .filter(token => !/^['"$]|^--|^\/\*/.test(token))
    .map(token => token.split('.')[0].toUpperCase()));
  const renames = new Map(nodes.flatMap(node => {
    const label = candidates.get(node.alias.toUpperCase());
    return label && !occupied.has(label.toUpperCase()) && !quoted.has(label.toUpperCase())
      && !quoted.has(node.alias.toUpperCase())
      ? [[node.alias.toUpperCase(), label] as const] : [];
  }));
  return sql.replace(tokens, token => {
    if (/^['"$]|^--|^\/\*/.test(token)) return token;
    const [qualifier, ...parts] = token.split('.');
    if (parts.length > 1) return token;
    const alias = renames.get(qualifier.toUpperCase());
    return alias ? [alias, ...parts].join('.') : token;
  });
}

/**
 * Map superseded aliases onto the aliases the generator produces today.
 *
 * Mappings saved while aliases were positional persisted qualifiers such as
 * `servicing_advisors_15`. Physical-table aliases are regenerated from identity
 * on every load, so those stored qualifiers now resolve to nothing. Derived
 * sources restore their persisted alias verbatim and therefore never drift.
 *
 * The persisted relation graph is the authoritative record of which alias a
 * stored reference was written against, so pair each persisted node alias with
 * the alias its identity yields now. Entries are only emitted where the two
 * actually differ.
 */
export function buildLegacyAliasRewrites(
  nodes: Array<{ alias?: unknown; identity?: unknown; displaySeed?: unknown }>,
): Map<string, string> {
  const rewrites = new Map<string, string>();
  const ambiguous = new Set<string>();
  for (const node of nodes) {
    const storedAlias = String(node.alias ?? "").trim();
    const identity = String(node.identity ?? "").trim();
    if (!storedAlias || !identity) continue;
    const displaySeed = String(node.displaySeed ?? "").trim() || null;
    const currentAlias = relationAliasFor(identity, displaySeed);
    if (currentAlias === storedAlias) continue;
    const key = storedAlias.toUpperCase();
    const existing = rewrites.get(key);
    if (existing && existing !== currentAlias) {
      // One stored alias cannot stand for two relations. Guessing would
      // silently rewrite a reference onto the wrong table.
      ambiguous.add(key);
      continue;
    }
    rewrites.set(key, currentAlias);
  }
  for (const key of ambiguous) rewrites.delete(key);
  return rewrites;
}

/**
 * Rewrite `<legacyAlias>.COLUMN` qualifiers onto current aliases.
 *
 * Only a single-token qualifier is rewritten. A dotted reference is already a
 * fully qualified name, which the compiler resolves directly, so touching it
 * would risk corrupting a valid reference.
 */
export function rewriteLegacyAliasReference(
  value: string,
  rewrites: Map<string, string>,
): string {
  if (!rewrites.size) return value;
  const text = String(value ?? "");
  if (!text.trim()) return text;
  return text.replace(
    /(?<![A-Za-z0-9_$.])([A-Za-z_][A-Za-z0-9_$]*)(?=\s*\.\s*[A-Za-z_])/g,
    (match, qualifier: string) => rewrites.get(qualifier.toUpperCase()) ?? match,
  );
}
