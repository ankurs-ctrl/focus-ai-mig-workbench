from __future__ import annotations

from types import SimpleNamespace
import json

from app.agent_runtime.routing import ExecutionDecision, ExecutionLane, plan_review_advice, route_request
from app.agent_runs.models import AgentActor


class PlainJsonModel:
    def __init__(self, content: str):
        self.content = content
        self.messages = None

    def invoke(self, messages):
        self.messages = messages
        return SimpleNamespace(content=self.content)

    def with_structured_output(self, _schema):
        raise AssertionError("Cortex fast-path routing must not send a tool schema")


def test_complex_request_routes_to_durable_workflow_without_tool_schema():
    model = PlainJsonModel(
        '{"lane":"DEEP_WORKFLOW","reason":"Multi-step migration",'
        '"answer":null,"operation":"none","arguments":{}}'
    )
    decision = route_request(model, prompt="Create and validate a Household mapping", prepared_context={})
    assert decision.lane is ExecutionLane.DEEP_WORKFLOW
    assert model.messages[1]["content"]


def test_plain_json_router_accepts_fenced_response():
    model = PlainJsonModel(
        '```json\n{"lane":"DIRECT_ANSWER","reason":"General explanation",'
        '"answer":"A mapping links source and target columns.",'
        '"operation":"none","arguments":{}}\n```'
    )
    decision = route_request(model, prompt="What is a mapping?", prepared_context={})
    assert decision.answer == "A mapping links source and target columns."


def test_explicit_plan_skips_fast_model():
    model = PlainJsonModel("invalid")
    decision = route_request(model, prompt="Plan migration", prepared_context={}, plan_mode=True)
    assert decision.lane is ExecutionLane.DEEP_WORKFLOW
    assert model.messages is None


def test_broad_deep_work_gets_plan_offer_even_if_model_omits_recommendation():
    decision = ExecutionDecision(lane=ExecutionLane.DEEP_WORKFLOW, reason="Migration task")
    offered, reason = plan_review_advice(
        decision,
        "Create a project, map every column, generate SQL, validate it, and run a preview and tests.",
        min_workstreams=3,
    )
    assert offered
    assert "column mapping" in reason
    assert not plan_review_advice(decision, "Map one column", min_workstreams=3)[0]


def test_attachment_question_uses_one_scoped_read_and_one_model_call(monkeypatch):
    from app.agent_runs.document_qa import answer_uploaded_document
    calls = {"sql": 0, "model": 0}
    class Session:
        def sql(self, query, params):
            calls["sql"] += 1
            assert "OWNER_USER_ID = ?" in query
            assert params == ["att_1", "user", "tenant"]
            return self
        def collect(self):
            return [{"ATTACHMENT_ID": "att_1", "ATTACHMENT_PAYLOAD": json.dumps({
                "attachment_id": "att_1", "filename": "call.vtt",
                "parsed_manifest": {"atomized": {"document_text": "00:00:20 Client: Use the primary address."}},
            })}]
    class Model:
        def invoke(self, messages):
            calls["model"] += 1
            assert "00:00:20" in messages[1]["content"]
            return SimpleNamespace(content=json.dumps({
                "answer": "Use the primary address (call.vtt, 00:00:20).",
                "question": {"prompt": "Which address if primary is missing?", "options": [
                    {"label": "Latest current", "description": "Most recently updated"},
                    {"label": "Leave blank", "description": "Needs review"},
                ]},
            }))
    monkeypatch.setattr("app.agent_runs.document_qa.build_snowflake_cortex_model", lambda **_kwargs: Model())
    client = SimpleNamespace(session=Session(), get_rest_session_context=lambda: SimpleNamespace(host="host", token="token"))
    settings = SimpleNamespace(migration_agent_model_light="model", migration_agent_model_timeout_seconds=120)
    actor = AgentActor(app_user_id="user", tenant_id="tenant", effective_role="ROLE")
    answer, question = answer_uploaded_document("Summarize address rules", ["att_1"], client, settings, actor)
    assert "primary address" in answer
    assert question["options"][0]["label"] == "Latest current"
    assert calls == {"sql": 1, "model": 1}
