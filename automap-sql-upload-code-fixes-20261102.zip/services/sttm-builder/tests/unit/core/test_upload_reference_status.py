from types import SimpleNamespace

import pytest

from app.core.upload_reference_status import (
    UploadLookupContext, classify_reference, identifier_parts,
    inspect_upload_references, qualified_identifier,
)


@pytest.mark.parametrize("status,expected", [
    ("pending", "semantic_checking"), ("lookup_failed", "semantic_lookup_failed"),
    ("active", "semantic_available"), ("missing", "semantic_missing"), ("stale", "semantic_stale"),
])
def test_pending_and_failed_checks_are_not_missing(status, expected):
    assert classify_reference({"resolution_status": "resolved", "semantic_status": status}) == expected


@pytest.mark.parametrize("identifier,parts", [
    ("db.sch.tab", ("DB", "SCH", "TAB")),
    ('"Db.Name"."Mixed"."a.b"', ("Db.Name", "Mixed", "a.b")),
    ('DB.S."quote""name"', ("DB", "S", 'quote"name')),
])
def test_identifier_roundtrip(identifier, parts):
    assert identifier_parts(identifier) == parts
    assert identifier_parts(qualified_identifier(parts)) == parts


SETTINGS = SimpleNamespace(
    resolved_semantic_views_table="DB.M.TABLE_REGISTRY",
    resolved_semantic_native_views_table="DB.M.NATIVE_REGISTRY",
)


def references(*names):
    return [{"raw_identifier": name, "resolved_fqn": name, "resolution_status": "resolved",
             "reference_role": "source"} for name in names]


class ClockSession:
    def __init__(self, monkeypatch, handler):
        import app.core.upload_reference_status as status
        self.now = 0.0
        self.calls = []
        self.handler = handler
        monkeypatch.setattr(status.time, "monotonic", lambda: self.now)

    def sql(self, query, params):
        def collect(*, statement_params):
            timeout = statement_params["STATEMENT_TIMEOUT_IN_SECONDS"]
            assert 1 <= timeout <= 5
            self.calls.append((query, params, timeout, self.now))
            return self.handler(self, query, params, timeout)
        return SimpleNamespace(collect=collect)


def accessible(session, query, params, timeout):
    if query == "DESCRIBE TABLE IDENTIFIER(?)":
        return [{"name": "ID", "type": "NUMBER"}]
    assert "WITH requested" in query, "FQNs must never use broad catalog discovery"
    return []


def test_exact_checks_deduplicate_roles_and_preserve_quoted_case(monkeypatch):
    session = ClockSession(monkeypatch, accessible)
    inputs = references('"Db.Name"."Mixed"."a.b"', '"Db.Name"."Other"."quote\'name"')
    inputs.append({**inputs[0], "reference_role": "target"})
    result = inspect_upload_references(session, SETTINGS, inputs)
    assert len(session.calls) == 4
    assert [call[1] for call in session.calls[:2]] == [
        ['"Db.Name"."Mixed"."a.b"'], ['"Db.Name"."Other"."quote\'name"'],
    ]
    from sqlglot import parse_one
    for query, *_ in session.calls:
        assert parse_one(query, read="snowflake") is not None
    assert [item["catalog_status"] for item in result] == ["available"] * 3
    assert all(item["semantic_status"] == "missing" for item in result)
    assert "catalog_status" not in inputs[0]


@pytest.mark.parametrize("count", [3, 5, 8, 9, 300])
def test_exact_checks_take_priority_over_semantics_with_fixed_call_limit(monkeypatch, count):
    session = ClockSession(monkeypatch, accessible)
    result = inspect_upload_references(session, SETTINGS, references(*(f"DB.S.T{i:04}" for i in range(count))))
    assert len(session.calls) <= 8
    verified = min(count, 6)
    assert all(item["catalog_status"] == "available" for item in result[:verified])
    assert all(item["catalog_status"] == "lookup_failed" for item in result[verified:])
    assert all(call[0] == "DESCRIBE TABLE IDENTIFIER(?)" for call in session.calls[:verified])
    if count > 8:
        assert result[8]["metadata_warnings"][0]["reason"] == "call_limit"
    if count > 200:
        assert result[200]["metadata_warnings"][0]["reason"] == "reference_limit"
    if count <= 100:
        assert all(item["semantic_status"] == "missing" for item in result)
    else:
        assert all(item['semantic_status'] != 'missing' for item in result)


@pytest.mark.parametrize("failure", ["statement timed out", "metadata unavailable", "access denied"])
def test_one_local_failure_does_not_stop_other_exact_checks(monkeypatch, failure):
    def handler(session, query, params, timeout):
        if query.startswith("DESCRIBE") and params == ["DB.S.A"]:
            raise RuntimeError(failure)
        return accessible(session, query, params, timeout)
    session = ClockSession(monkeypatch, handler)
    result = inspect_upload_references(session, SETTINGS, references("DB.S.A", "DB.S.B", "DB.S.C"))
    assert len(session.calls) == 5
    assert result[0]["catalog_status"] == "lookup_failed"
    assert result[0]["resolved_fqn"] == "DB.S.A"
    assert [item["catalog_status"] for item in result[1:]] == ["available", "available"]
    assert all(item["semantic_status"] == "missing" for item in result)


def test_actual_deadline_stops_sql_and_never_claims_missing(monkeypatch):
    from snowflake.snowpark.exceptions import SnowparkSQLException
    def handler(session, query, params, timeout):
        session.now = 5.1
        raise SnowparkSQLException("SQL execution canceled: statement timeout", sql_error_code=630)
    session = ClockSession(monkeypatch, handler)
    inputs = references(*(f"DB.S.T{i:04}" for i in range(300)))
    result = inspect_upload_references(session, SETTINGS, inputs)
    assert len(session.calls) == 1
    assert session.calls[0][2] == 1
    assert all(item["catalog_status"] == "lookup_failed" for item in result)
    assert all(item["semantic_status"] == "lookup_failed" for item in result)
    assert all(item["resolved_fqn"] == original["resolved_fqn"] for item, original in zip(result, inputs))
    assert all(item["semantic_table_view_id"] is None for item in result)


def test_time_is_shared_across_exact_checks_not_reset_per_object(monkeypatch):
    def handler(session, query, params, timeout):
        session.now += timeout
        raise RuntimeError("statement timed out")
    session = ClockSession(monkeypatch, handler)
    result = inspect_upload_references(session, SETTINGS, references(*(f"DB.S.T{i}" for i in range(9))))
    assert len(session.calls) == 5
    assert [call[2] for call in session.calls] == [1] * 5
    assert session.now == 5
    assert all(item["catalog_status"] == "lookup_failed" for item in result)
    assert result[5]["metadata_warnings"][0]["reason"] == "deadline_exhausted"


def test_registry_failure_does_not_downgrade_exact_catalog_success(monkeypatch):
    def handler(session, query, params, timeout):
        if "WITH requested" in query:
            raise RuntimeError("access denied")
        return accessible(session, query, params, timeout)
    session = ClockSession(monkeypatch, handler)
    result = inspect_upload_references(session, SETTINGS, references("DB.S.T"))[0]
    assert result["resolution_status"] == "resolved"
    assert result["catalog_status"] == "available"
    assert result["semantic_status"] == "lookup_failed"


@pytest.mark.parametrize("status", ["ACTIVE", "STALE"])
@pytest.mark.parametrize("failed_registry", ["TABLE_REGISTRY", "NATIVE_REGISTRY"])
def test_confirmed_active_semantics_survive_other_registry_failure(monkeypatch, status, failed_registry):
    def handler(session, query, params, timeout):
        if failed_registry in query:
            raise RuntimeError("registry unavailable")
        if "WITH requested" in query:
            return [{"DATABASE_NAME": "DB", "SCHEMA_NAME": "S", "TABLE_NAME": "T",
                     "ASSET_ID": "verified", "STATUS": status, "ASSET_VERSION": "v1"}]
        return accessible(session, query, params, timeout)
    session = ClockSession(monkeypatch, handler)
    result = inspect_upload_references(session, SETTINGS, references("DB.S.T"))[0]
    assert result["catalog_status"] == "available"
    if status == "ACTIVE":
        assert result["semantic_status"] == "active"
        assert result["semantic_table_view_id"] == "verified"
        assert result["classification"] == "semantic_available"
    else:
        assert result["semantic_status"] == "lookup_failed"
        assert result["semantic_table_view_id"] is None
        assert result["semantic_version"] is None
        assert result["semantic_registry"] is None
        assert result["classification"] == "semantic_lookup_failed"
        assert result["metadata_warnings"][0]["status"] == "unknown"


def test_partial_registry_chunk_failure_does_not_claim_missing_for_unchecked_refs(monkeypatch):
    def handler(session, query, params, timeout):
        if "NATIVE_REGISTRY" in query and params[2] == "T0100":
            raise RuntimeError("registry response unavailable")
        return []
    session = ClockSession(monkeypatch, handler)
    context = UploadLookupContext(session)
    inputs = references(*(f"DB.S.T{i:04}" for i in range(101)))
    # Previously observed caller catalog evidence in this same request.
    context.catalog.update({identifier_parts(item["resolved_fqn"]): None for item in inputs})
    result = inspect_upload_references(session, SETTINGS, inputs, lookup_context=context)
    assert len(session.calls) == 4
    assert all(item["catalog_status"] == "available" for item in result)
    assert all(item["semantic_status"] == "missing" for item in result[:100])
    assert result[-1]["semantic_status"] == "lookup_failed"


def test_empty_describe_is_unknown_not_proof_of_absence(monkeypatch):
    session = ClockSession(monkeypatch, lambda *_: [])
    result = inspect_upload_references(session, SETTINGS, references("DB.WRONG.T"))[0]
    assert result["resolved_fqn"] == "DB.WRONG.T"
    assert result["catalog_status"] == "lookup_failed"
    assert result["resolution_status"] == "lookup_failed"
    assert result["semantic_status"] == "missing"


def test_request_cache_cannot_be_reused_by_another_caller(monkeypatch):
    session = ClockSession(monkeypatch, accessible)
    context = UploadLookupContext(session)
    context.describe(("DB", "S", "T"))
    other = ClockSession(monkeypatch, lambda *_: pytest.fail("Wrong caller must not query"))
    with pytest.raises(ValueError, match="different caller"):
        inspect_upload_references(other, SETTINGS, references("DB.S.T"), lookup_context=context)
    assert not other.calls


def test_expired_budget_and_no_references_make_no_sql_calls(monkeypatch):
    import app.core.upload_reference_status as status
    session = ClockSession(monkeypatch, lambda *_: pytest.fail("No SQL allowed"))
    assert inspect_upload_references(session, SimpleNamespace(), []) == []
    monkeypatch.setattr(status, "_LOOKUP_BUDGET_SECONDS", 0.5)
    result = inspect_upload_references(session, SETTINGS, references("DB.S.T"))
    assert not session.calls
    assert result[0]["metadata_warnings"][0]["reason"] == "deadline_exhausted"


def test_multiple_passes_keep_verified_sources_and_reach_all_eleven(monkeypatch):
    session=ClockSession(monkeypatch,accessible);context=UploadLookupContext(session)
    refs=references(*(f'DB.S.T{i:02}'for i in range(11)))
    first=inspect_upload_references(session,SETTINGS,refs,lookup_context=context)
    assert sum(item['catalog_status']=='available'for item in first)==6
    context.next_pass()
    final=inspect_upload_references(session,SETTINGS,first,lookup_context=context)
    assert all(item['catalog_status']=='available'for item in final)
    describes=[params[0]for sql,params,*_ in session.calls if sql.startswith('DESCRIBE')]
    assert len(describes)==11 and len(set(describes))==11


def test_restart_retains_proofs_and_prioritizes_unread_after_slow_source(monkeypatch):
    def slow_first(session,query,params,timeout):
        if query=='DESCRIBE TABLE IDENTIFIER(?)' and params[0]=='DB.S.T00':
            session.now+=timeout
            raise TimeoutError('slow source')
        return accessible(session,query,params,timeout)
    session=ClockSession(monkeypatch,slow_first)
    result=inspect_upload_references(session,SETTINGS,references(*(f'DB.S.T{i:02}' for i in range(11))))
    for _ in range(5):
        # New context simulates process restart; only persisted reference data survives.
        session.now+=1
        result=inspect_upload_references(session,SETTINGS,result)
    assert all(item['catalog_status']=='available' for item in result[1:])
    assert result[0]['catalog_status']=='lookup_failed'
    assert result[0]['resolution_status']!='missing'
    names=[params[0] for query,params,*_ in session.calls if query=='DESCRIBE TABLE IDENTIFIER(?)']
    assert all(names.count(f'DB.S.T{i:02}')==1 for i in range(1,11))


def test_more_than_page_limit_eventually_verifies_without_downgrading_proofs(monkeypatch):
    session=ClockSession(monkeypatch,accessible)
    result=references(*(f'DB.S.T{i:03}' for i in range(210)))
    for _ in range(40):
        result=inspect_upload_references(session,SETTINGS,result)
    assert all(item['catalog_status']=='available' for item in result)
    assert all(item['semantic_status']=='missing' for item in result)
    described=[params[0] for query,params,*_ in session.calls if query=='DESCRIBE TABLE IDENTIFIER(?)']
    assert len(described)==len(set(described))==210
