import type { MappingState } from '@/features/sttm/types/sttm.types';

export type ConfidenceGroupId = 'high' | 'medium' | 'low' | 'unmapped';

export type ConfidenceGroupConfig = {
  id: ConfidenceGroupId;
  title: string;
  rangeLabel: string;
  backgroundColor: string;
  dotColor: string;
  titleColor: string;
  badgeBackground: string;
  badgeColor: string;
};

export const CONFIDENCE_GROUP_ORDER: ConfidenceGroupId[] = ['high', 'medium', 'low', 'unmapped'];

export const CONFIDENCE_GROUP_CONFIG: Record<ConfidenceGroupId, ConfidenceGroupConfig> = {
  high: {
    id: 'high',
    title: 'HIGH CONFIDENCE',
    rangeLabel: 'Confidence: 80-100% · Manual',
    backgroundColor: '#ecfdf5',
    dotColor: '#16a34a',
    titleColor: '#15803d',
    badgeBackground: '#f1f5f9',
    badgeColor: '#64748b',
  },
  medium: {
    id: 'medium',
    title: 'MEDIUM CONFIDENCE',
    rangeLabel: 'Confidence: 60-80%',
    backgroundColor: '#fefce8',
    dotColor: '#d97706',
    titleColor: '#b45309',
    badgeBackground: '#f1f5f9',
    badgeColor: '#64748b',
  },
  low: {
    id: 'low',
    title: 'LOW CONFIDENCE',
    rangeLabel: 'Confidence: 0-60%',
    backgroundColor: '#fef2f2',
    dotColor: '#dc2626',
    titleColor: '#b91c1c',
    badgeBackground: '#f1f5f9',
    badgeColor: '#64748b',
  },
  unmapped: {
    id: 'unmapped',
    title: 'UNMAPPED',
    rangeLabel: 'No mapping yet',
    backgroundColor: '#f8fafc',
    dotColor: '#94a3b8',
    titleColor: '#475569',
    badgeBackground: '#f1f5f9',
    badgeColor: '#64748b',
  },
};

/** Normalize API scores that may arrive as 0-1 fractions or 0-100 percentages. */
export function normalizeConfidencePercent(
  confidenceScore: number | null | undefined,
): number | null {
  if (confidenceScore == null || Number.isNaN(Number(confidenceScore))) {
    return null;
  }
  const raw = Number(confidenceScore);
  const percent = raw <= 1 ? raw * 100 : raw;
  return Math.max(0, Math.min(100, percent));
}

export function hasConfidenceScore(
  confidenceScore: number | null | undefined,
): boolean {
  return normalizeConfidencePercent(confidenceScore) != null;
}

type ConfidenceGroupInput = {
  confidenceScore?: number | null;
  status?: MappingState['status'] | null;
  manuallySaved?: boolean;
};

/** Confidence shown for every manual mapping: the user mapped it, so they are fully confident. */
export const MANUAL_CONFIDENCE_PERCENT = 100;

/** A mapping the user saved by hand (cleared rows stay unmapped). */
export function isSavedManualMapping(
  mapping: Pick<ConfidenceGroupInput, 'manuallySaved' | 'status'>,
): boolean {
  return Boolean(mapping.manuallySaved) && mapping.status != null && mapping.status !== 'UNMAPPED';
}

/**
 * Resolve confidence band for sorting/grouping.
 * Saved manual mappings are always High; others follow their confidence score.
 */
export function getConfidenceGroup(
  mappingOrScore:
    | ConfidenceGroupInput
    | number
    | null
    | undefined,
  status?: MappingState['status'],
): ConfidenceGroupId {
  if (
    mappingOrScore != null
    && typeof mappingOrScore === 'object'
  ) {
    if (isSavedManualMapping(mappingOrScore)) {
      return 'high';
    }
    if (mappingOrScore.status === 'UNMAPPED') {
      return 'unmapped';
    }
    const percent = normalizeConfidencePercent(mappingOrScore.confidenceScore);
    if (percent == null) {
      // Rows waiting on Auto-map have no result yet.
      return mappingOrScore.status === 'PROCESSING' ? 'unmapped' : 'low';
    }
    if (percent >= 80) return 'high';
    if (percent >= 60) return 'medium';
    return 'low';
  }

  void status;
  const percent = normalizeConfidencePercent(mappingOrScore);
  if (percent == null) {
    return 'low';
  }
  if (percent >= 80) return 'high';
  if (percent >= 60) return 'medium';
  return 'low';
}

function mappingSortScore(mapping: MappingState): number {
  if (isSavedManualMapping(mapping)) {
    return MANUAL_CONFIDENCE_PERCENT;
  }
  return normalizeConfidencePercent(mapping.confidenceScore) ?? -1;
}

/**
 * The version of a row that decides its group and position. Rows with unsaved
 * edits pass their pre-edit snapshot, so they stay where they were until Save.
 */
export type ConfidenceRankSource = (mapping: MappingState) => MappingState;

const rankAsIs: ConfidenceRankSource = (mapping) => mapping;

export function sortMappingsByConfidenceGroups(
  mappings: MappingState[],
  rankSource: ConfidenceRankSource = rankAsIs,
): MappingState[] {
  return [...mappings].sort((leftRow, rightRow) => {
    const left = rankSource(leftRow);
    const right = rankSource(rightRow);
    const leftGroup = getConfidenceGroup(left);
    const rightGroup = getConfidenceGroup(right);
    const groupOrder =
      CONFIDENCE_GROUP_ORDER.indexOf(leftGroup) - CONFIDENCE_GROUP_ORDER.indexOf(rightGroup);
    if (groupOrder !== 0) return groupOrder;

    const leftScore = mappingSortScore(left);
    const rightScore = mappingSortScore(right);
    if (leftScore !== rightScore) return rightScore - leftScore;

    const ordinalDifference = (left.targetOrdinal ?? Number.MAX_SAFE_INTEGER)
      - (right.targetOrdinal ?? Number.MAX_SAFE_INTEGER);
    if (ordinalDifference !== 0) return ordinalDifference;

    return left.targetColumn.localeCompare(right.targetColumn);
  });
}

export function countMappingsByConfidenceGroup(
  mappings: MappingState[],
  rankSource: ConfidenceRankSource = rankAsIs,
): Record<ConfidenceGroupId, number> {
  return mappings.reduce(
    (counts, mapping) => {
      const group = getConfidenceGroup(rankSource(mapping));
      counts[group] += 1;
      return counts;
    },
    { high: 0, medium: 0, low: 0, unmapped: 0 } satisfies Record<ConfidenceGroupId, number>,
  );
}

/**
 * When the user edits an auto-mapped row, keep its confidence score (and sort
 * position) and mark it as manually edited after auto-map.
 * Score is only replaced when an explicit confidenceScore update is provided
 * (auto-map / FIR / recommendation), or when the mapping is fully cleared.
 */
export function withPreservedAutoMapConfidence(
  row: Pick<
    MappingState,
    | 'confidenceScore'
    | 'confidenceReason'
    | 'manuallyEditedAfterAutoMap'
    | 'manuallySaved'
    | 'mappingMode'
    | 'expression'
  >,
  updates: Partial<MappingState>,
): Partial<MappingState> {
  // Explicit confidence updates (auto-map / FIR / recommendation) replace prior score.
  if (Object.prototype.hasOwnProperty.call(updates, 'confidenceScore')) {
    return {
      ...updates,
      manuallyEditedAfterAutoMap: false,
      manuallySaved: false,
    };
  }

  if (!hasConfidenceScore(row.confidenceScore) && !row.manuallySaved) {
    return {
      ...updates,
      manuallyEditedAfterAutoMap: false,
    };
  }

  const priorMode = row.mappingMode ?? 'source';
  const nextMode = updates.mappingMode ?? priorMode;
  // Keep score/group while dirty — even if sources were cleared — until Save.
  // Mode switches (e.g. Direct → Attribute) also keep the auto-map score.
  void priorMode;
  void nextMode;

  return {
    ...updates,
    confidenceScore: row.confidenceScore ?? null,
    confidenceReason: row.confidenceReason ?? updates.confidenceReason ?? null,
    manuallyEditedAfterAutoMap: true,
    // Keep prior manuallySaved until explicit Save commit replaces it.
    manuallySaved: row.manuallySaved ?? false,
  };
}
