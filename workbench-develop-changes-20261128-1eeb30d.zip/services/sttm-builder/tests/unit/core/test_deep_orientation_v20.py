from types import SimpleNamespace
from threading import RLock, Event, Thread
from unittest.mock import Mock
import time
import pytest
from app.agent_runs.models import ToolResult
from app.agent_runtime.execution import ExecutionBudget
from app.agent_runtime.run_knowledge import RunKnowledge
from app.agent_tools.catalog_discovery import discover
from app.agent_tools.capability_registry import CapabilityRegistry
from app.agent_tools.source_orientation import resolve, mapping_graph


def bench(rows=()):
    session=SimpleNamespace(sql=Mock())
    session.sql.return_value.collect.return_value=list(rows)
    return SimpleNamespace(_session=session,_domain_lock=RLock(),_settings=SimpleNamespace(snowflake_database='META',resolved_metadata_database='META',snowflake_schema='CONTROL'))


def registry(w, context, knowledge=None):
    r=CapabilityRegistry(context_provider=lambda:context,workflow_executor=lambda *a:None,workbench=w,budget=ExecutionBudget(model_limit=20,tool_limit=50),knowledge=knowledge)
    r.begin_run(context)
    return r


def test_unknown_source_scope_never_defaults_to_workbench_database():
    w=bench()
    result=discover(w,['household'],8)
    assert result.error_code=='catalog_scope_required'
    w._session.sql.assert_not_called()


def test_compatible_terms_are_one_sql_with_per_term_limits():
    w=bench([{'SEARCH_TERM':'accounts','TABLE_CATALOG':'CRM','TABLE_SCHEMA':'FIRM_A','TABLE_NAME':'ACCOUNT'}])
    result=discover(w,['accounts','contacts'],8,database='CRM',schema='FIRM_A')
    assert result.data['matches']['accounts']==['"CRM"."FIRM_A"."ACCOUNT"']
    assert w._session.sql.call_count==1
    call=w._session.sql.call_args
    assert 'UNION ALL' in call.args[0] and call.args[0].count('LIMIT ?')==2
    assert call.kwargs['params'].count(8)==2


def test_catalog_cache_includes_limit_and_authority():
    w=bench();discover(w,['accounts'],2,database='CRM',schema='S',context={'app_user_id':'a'})
    discover(w,['accounts'],8,database='CRM',schema='S',context={'app_user_id':'a'})
    discover(w,['accounts'],8,database='CRM',schema='S',context={'app_user_id':'b'})
    assert w._session.sql.call_count==3


def test_source_resolution_returns_real_ambiguous_estates_without_table_scan():
    w=bench([{'database_name':'CRM','name':'SCH_FIRM_A_RAW'},{'database_name':'CRM','name':'SCH_FIRM_A_CURATED'},{'database_name':'META','name':'CONTROL'}])
    result=resolve(w,{},hint='firm a')
    assert result.data['resolution']=='ambiguous'
    assert len(result.data['candidates'])==2
    assert all('TABLES IN ACCOUNT' not in call.args[0] for call in w._session.sql.call_args_list)
    assert result.data['recommended_scope'] is None


def test_exact_selected_source_estate_needs_no_inventory():
    w=bench();result=resolve(w,{'authorized_source_scope':['CRM.FIRM_A.ACCOUNT']})
    assert result.data['resolution']=='resolved'
    assert result.data['recommended_scope']['database']=='CRM'
    w._session.sql.assert_not_called()


def test_target_does_not_select_source_estate():
    w=bench();result=resolve(w,{'authorized_target_scope':['META.TARGETS.HOUSEHOLD']},hint='firm a')
    assert result.data['resolution']=='unresolved'
    assert result.data['candidates']==[]


def test_precedent_defaults_ignore_catalog_bag_and_preserve_explicit_empty():
    w=bench();context={'run_id':'r','authorized_source_scope':['CRM.S.ACCOUNT'],'authorized_target_scope':['DW.T.HOUSEHOLD']}
    r=registry(w,context);r._catalog_candidates.update(['META.CONTROL.TBL_JOBS','DW.T.HOUSEHOLD'])
    assert r._precedent_search_defaults('',None,None)[1:]==(['CRM.S.ACCOUNT'],['DW.T.HOUSEHOLD'])
    assert r._precedent_search_defaults('',[],[])[1:]==([],[])


def test_scope_denial_precedes_single_contract_read():
    w=bench();w.inspect_table_contract=Mock()
    r=registry(w,{'run_id':'r','authorized_schemas':['CRM.S']})
    result={t.name:t for t in r.tools()}['inspect_table_contract'].invoke({'table_fqn':'OTHER.S.ACCOUNT'})
    assert result['status']=='denied';w.inspect_table_contract.assert_not_called()


def test_timeout_and_broad_budget_survive_runtime_reconstruction():
    ctx={'run_id':'r','app_user_id':'u','effective_role':'ROLE','authorized_schemas':['CRM.S']}
    knowledge=RunKnowledge(scope='run:r',access_scope='u:ROLE',run_id='r',ttl_seconds=600)
    w=bench();error=RuntimeError('secret SQL');error.sql_error_code=630
    w._session.sql.return_value.collect.side_effect=error
    first=registry(w,ctx,knowledge)
    discover(w,['account'],8,database='CRM',schema='S',context=ctx)
    first._broad_batches=2;first._recovery_state={'nudges':1,'stalled_turns':2};first._save_discovery_state()
    restored=registry(bench(),ctx,knowledge)
    result=discover(restored._workbench,['contact'],8,database='CRM',schema='S',context=ctx)
    assert result.error_code=='catalog_timeout'
    restored._workbench._session.sql.assert_not_called()
    assert restored._broad_batches==2 and restored._recovery_state['nudges']==1


def test_durable_discovery_is_not_reused_for_changed_role():
    knowledge=RunKnowledge(scope='run:r',access_scope='u:ROLE',run_id='r',ttl_seconds=600)
    first=registry(bench(),{'run_id':'r','effective_role':'ROLE'},knowledge)
    first._broad_batches=2;first._save_discovery_state()
    second=registry(bench(),{'run_id':'r','effective_role':'OTHER'},knowledge)
    assert second._broad_batches==0


def test_empty_repeated_and_cached_activity_is_not_budget_progress():
    r=registry(bench(),{'run_id':'r'})
    empty=ToolResult(status='succeeded',summary='empty',data={'candidates':[]})
    assert not r._meaningful_progress('search_catalog',empty,{})
    found=ToolResult(status='succeeded',summary='found',data={'candidates':['CRM.S.ACCOUNT']})
    assert r._meaningful_progress('search_catalog',found,{})
    assert not r._meaningful_progress('search_catalog',found,{})
    assert r._budget.structured_snapshot()['category_meaningful_progress']==1


def test_alternating_plan_errors_share_one_repair_allowance():
    r=registry(bench(),{'run_id':'r'})
    result={'status':'needs_input','error_code':'one'}
    def validate_migration_plan():return result
    call=r._trace_early_refusals(validate_migration_plan)
    call();result['error_code']='two';call();result['error_code']='three';call()
    assert r.plan_validation_failure['attempts']==3


def test_saved_graph_available_before_preparation_with_complete_cte_and_filters():
    w=bench();w.get_project_context=Mock(return_value=ToolResult(status='succeeded',summary='project',data={'mappings':[{'sttm_id':'m'}]}))
    sql='WITH X AS (SELECT ID FROM CRM.S.ACCOUNT WHERE ID IS NOT NULL) SELECT ID FROM X'
    w._precedent_detail=Mock(return_value=SimpleNamespace(latest_snapshot={'mapping_sql':sql,'source_tables':['CRM.S.ACCOUNT']},sources=[],mapping_rows=[],sttm=SimpleNamespace(status='PUBLISHED',target_table='DW.T.HOUSEHOLD')))
    summary=mapping_graph(w,'p','m');assert summary.data['sources']==['CRM.S.ACCOUNT']
    assert summary.data['mapping_sql']==sql
    assert summary.data['ctes'] and summary.data['filters']
    assert {'sources','joins','ctes','filters','sql','rows'}<=set(summary.data['complete_sections'])
    ctes=mapping_graph(w,'p','m','ctes');assert 'SELECT' in ctes.data['records'][0]['sql_text']
    assert mapping_graph(w,'p','m','filters').data['records'][0]['kind']=='Where'
    assert mapping_graph(w,'p','wrong').status=='denied'
    w._session.sql.assert_not_called()


def test_saved_graph_keeps_authored_structure_when_the_draft_has_no_sql():
    workbench = bench()
    workbench.get_project_context = Mock(return_value=ToolResult(
        status="succeeded", summary="Project", data={"mappings": [{"sttm_id": "m"}]},
    ))
    join = {"left_table": "CRM.S.ACCOUNT", "right_table": "CRM.S.CONTACT", "join_type": "LEFT"}
    cte = {"name": "contact_summary", "sql_text": "SELECT ID FROM CRM.S.CONTACT"}
    filters = {"filter_sql": "ACCOUNT.ID IS NOT NULL"}
    workbench._precedent_detail = Mock(return_value=SimpleNamespace(
        latest_snapshot={"relationships": [join], "derived_sources": [cte], "filters": filters},
        sources=[], mapping_rows=[], sttm=SimpleNamespace(status="DRAFT", target_table="DW.T.HOUSEHOLD"),
    ))

    graph = mapping_graph(workbench, "p", "m").data

    assert graph["joins"] == [join]
    assert graph["ctes"] == [cte]
    assert graph["filters"] == [filters]


def test_oversized_saved_sql_is_deferred_not_cut():
    w=bench();w.get_project_context=Mock(return_value=ToolResult(status='succeeded',summary='p',data={'mappings':[{'sttm_id':'m'}]}))
    sql="SELECT '"+'界'*20000+"' FROM CRM.S.A"
    w._precedent_detail=Mock(return_value=SimpleNamespace(latest_snapshot={'mapping_sql':sql},sources=[],mapping_rows=[],sttm=SimpleNamespace(status='PUBLISHED',target_table='DW.T.T')))
    result=mapping_graph(w,'p','m','sql')
    assert result.data['records']==[] and result.data['deferred']['index']==0


def test_trace_barrier_checks_failure_after_final_queue_drain():
    from app.agent_runs.trace_writer import DurableTraceWriter
    writer=object.__new__(DurableTraceWriter);writer._failure=None
    class Queue:
        @property
        def unfinished_tasks(self):
            writer._failure=RuntimeError('failed final commit')
            return 0
    writer._queue=Queue()
    with pytest.raises(RuntimeError,match='trace writer failed'):writer.flush()


def test_control_connection_cleanup_is_bounded_and_never_closes_active_io():
    from app.agent_runs.service_connections import ServiceConnection
    entered=Event();release=Event();closed=Event()
    client=SimpleNamespace(session=SimpleNamespace(),close=lambda:closed.set())
    connection=ServiceConnection(lambda:client,'test',timeout_seconds=1)
    thread=Thread(target=lambda:connection.execute(lambda _: (entered.set(),release.wait(2)),operation='read',read_only=True))
    thread.start();assert entered.wait(1)
    started=time.monotonic();assert not connection.close(timeout=.01)
    assert time.monotonic()-started<.2 and not closed.is_set()
    release.set();thread.join(1);assert connection.close(timeout=1) and closed.is_set()


def test_multischema_current_selection_is_one_estate_not_a_false_ambiguity():
    w=bench();result=resolve(w,{'authorized_source_scope':['CRM.RAW.ACCOUNT','CRM.REF.USER']})
    assert result.data['resolution']=='resolved'
    assert len(result.data['recommended_scopes'])==2
    w._session.sql.assert_not_called()


def test_saved_reference_resolution_preserves_case_and_component_dots():
    from app.agent_tools.source_readiness import resolve_visible_references
    sources=['"Db"."Mixed.Schema"."Account"','"Db"."Mixed.Schema"."ACCOUNT"']
    found,missing=resolve_visible_references(['"Mixed.Schema"."Account"'],sources)
    assert found==[sources[0]] and missing==[]


def test_actual_runtime_returns_evidence_backed_scope_question_without_plan_validation():
    from langchain_core.language_models.fake_chat_models import FakeMessagesListChatModel
    from langchain_core.messages import AIMessage
    from app.agent_runtime.deepagents_runtime import DeepAgentsRuntime
    from app.agent_runtime.interface import RuntimeInvocation
    from app.agent_runs.models import EffortLevel
    from app.migration_workflow.graph import build_migration_graph
    class Model(FakeMessagesListChatModel):
        def bind_tools(self,tools,**kwargs):return self
    model=Model(responses=[AIMessage(content='',tool_calls=[{'id':'estate','name':'resolve_source_scope','args':{'hint':'firm a'}}]),AIMessage(content='[FINAL] Two estates match the request.')])
    w=bench()
    runtime=DeepAgentsRuntime(model=model,migration_graph=build_migration_graph(),workbench=w,budget=ExecutionBudget(model_limit=8,tool_limit=20))
    result=runtime.invoke(RuntimeInvocation(run_id='scope-question',thread_id='scope-question',prompt='Plan a household mapping using firm a sources.',effort=EffortLevel.MEDIUM,
        workflow_input={'run_mode':'plan','intent':'NEW_MIGRATION_TASK','authorized_schemas':['CRM.FIRM_A_RAW','CRM.FIRM_A_CURATED']}))
    assert result.status=='AWAITING_INPUT'
    choices=result.workflow_state['__interrupt__'][0]['choices']
    assert len(choices)==2 and all('FIRM_A_' in option['label'] for option in choices)
    assert runtime._registry.plan_validation_failure is None
    w._session.sql.assert_not_called()


def test_saved_graph_summary_carries_complete_sql_and_reuses_immutable_research():
    w=bench();calls=[]
    w.get_project_context=lambda _: ToolResult(status='succeeded',summary='project',data={'mappings':[{'sttm_id':'1'}]})
    sql='WITH C AS (SELECT ID FROM CRM.S.T) SELECT ID FROM C'
    def detail(*args):
        calls.append(args)
        return SimpleNamespace(latest_snapshot={'mapping_sql':sql},sources=[],mapping_rows=[],sttm=SimpleNamespace(status='PUBLISHED',target_table='DW.S.T'))
    w._precedent_detail=detail
    assert mapping_graph(w,'p','1').data['mapping_sql']==sql
    mapping_graph(w,'p','1',section='ctes')
    assert len(calls)==1


def test_read_only_profile_excludes_migration_schemas_and_keeps_authorized_reads(monkeypatch):
    import app.agent_runtime.deepagents_runtime as module
    captured={}
    monkeypatch.setattr(module,'create_deep_agent',lambda **kwargs:captured.update(kwargs) or SimpleNamespace())
    module.DeepAgentsRuntime(model=SimpleNamespace(),migration_graph=SimpleNamespace(),budget=ExecutionBudget(model_limit=4,tool_limit=10),tool_profile='read_only_qa')
    names={tool.name for tool in captured['tools']}
    assert {'read_mapping_definition','read_stored_semantic_context','resolve_source_scope'}<=names
    assert 'validate_migration_plan' not in names and not captured['subagents']
    assert len(captured['system_prompt'])<15000


def test_technical_runtime_failure_is_not_converted_into_review_success():
    from app.agent_runs.models import AgentActor, RunCreateRequest, RunStatus
    from app.agent_runs.repository import InMemoryAgentRunRepository
    from app.agent_runs.service import AgentRunService
    from app.agent_runs.worker import AgentWorker
    from app.agent_runtime.interface import RuntimeResult
    repo=InMemoryAgentRunRepository();service=AgentRunService(repo)
    run=service.create_run(RunCreateRequest(prompt='Plan a mapping'),AgentActor(app_user_id='u',effective_role='R'))
    runtime=SimpleNamespace(invoke=lambda invocation:RuntimeResult(status='FAILED',safe_summary='Verified findings retained.',workflow_state={'status':'FAILED','error_code':'DEEP_PLAN_STALLED','assistant_message':'Verified findings retained.'},model_calls_used=2,tool_calls_used=3,budget_usage={}))
    assert AgentWorker(repo,None,worker_id='test',runtime_factory=lambda current:(runtime,lambda:None)).run_once()
    saved=repo.get_run(run.run_id)
    assert saved.status is RunStatus.FAILED and saved.error_code=='DEEP_PLAN_STALLED'


def test_historical_source_roles_require_all_current_contracts_before_preparation():
    w=bench();calls=[]
    w.inspect_table_contract=lambda table:ToolResult(status='succeeded',summary='contract',data={'table':table,'columns':['ID']})
    w.prepare_migration_evidence=lambda context,**kwargs:calls.append(kwargs) or ToolResult(status='succeeded',summary='prepared')
    ctx={'run_id':'r','intent':'NEW_MIGRATION_TASK','authorized_schemas':['CRM.S','DW.S'],'authorized_target_scope':['DW.S.T']}
    reg=registry(w,ctx)
    graph=ToolResult(status='succeeded',summary='graph',data={'target_table':'DW.S.T','sources':['CRM.S.A','CRM.S.B'],'sttm_id':'1'})
    reg._meaningful_progress('read_mapping_graph',graph,{})
    tools={t.name:t for t in reg.tools()}
    tools['inspect_table_contract'].invoke({'table_fqn':'DW.S.T'})
    tools['inspect_table_contract'].invoke({'table_fqn':'CRM.S.A'})
    assert not calls
    tools['inspect_table_contract'].invoke({'table_fqn':'CRM.S.B'})
    assert calls[0]['source_tables']==['CRM.S.A','CRM.S.B']
    assert not ctx.get('authorized_source_scope')  # proposal never becomes a selection


def test_batch_contract_timeout_retains_native_diagnostics_and_auth_is_not_swallowed():
    from app.core.exceptions import DelegatedCredentialsRotated
    w=bench();error=RuntimeError('private query');error.sql_error_code=630;error.sfqid='query-1'
    w.inspect_table_contract=Mock(side_effect=error)
    reg=registry(w,{'run_id':'r','authorized_schemas':['CRM.S']})
    tool=next(t for t in reg.tools() if t.name=='inspect_table_contracts_batch')
    result=tool.invoke({'table_fqns':['CRM.S.A']})
    failed=result['data']['failures'][0]
    assert failed['category']=='timeout' and failed['diagnostics']['query_id']=='query-1'
    w.inspect_table_contract.side_effect=DelegatedCredentialsRotated('Same identity rotated')
    with pytest.raises(DelegatedCredentialsRotated):tool.invoke({'table_fqns':['CRM.S.B']})


def test_schema_inventory_uses_the_shared_two_broad_batch_allowance():
    from app.agent_tools.catalog_discovery import _caller_schema_scopes
    w=bench();reg=registry(w,{'run_id':'r'})
    reg._broad_batches=2
    assert _caller_schema_scopes(w,{},set())==([],True)
    w._session.sql.assert_not_called()


def test_source_scope_business_hint_ignores_generic_source_words():
    w=bench([{'database_name':'CRM','name':'SCH_NORTH_RAW'},{'database_name':'CRM','name':'SCH_OTHER_RAW'}])
    result=resolve(w,{},hint='sources for north firm')
    assert result.data['resolution']=='resolved'
    assert result.data['recommended_scope']['schema']=='SCH_NORTH_RAW'


def test_answering_estate_choice_does_not_resume_a_nonexistent_migration_checkpoint():
    from app.agent_runtime.deepagents_runtime import DeepAgentsRuntime
    from app.agent_runtime.interface import RuntimeInvocation
    from app.agent_runs.models import EffortLevel
    reg=registry(bench(),{'run_id':'r','authorized_schemas':['CRM.RAW','CRM.CURATED']})
    reg._source_resolution={'resolution':'ambiguous','candidates':[{'database':'CRM','schema':'RAW'},{'database':'CRM','schema':'CURATED'}]}
    runtime=SimpleNamespace(_registry=reg,_workflow_checkpoint_started=lambda invocation:False,
        _trusted_context=lambda:{'authorized_schemas':['CRM.RAW','CRM.CURATED']})
    invocation=RuntimeInvocation(run_id='r',thread_id='r',prompt='Plan it',effort=EffortLevel.LIGHT,
        resume_value={'source_scope':{'database':'CRM','schema':'RAW'}},workflow_input={})
    assert DeepAgentsRuntime._resume_source_scope(runtime,invocation)
    assert reg._source_resolution['recommended_scope']['schema']=='RAW'
    assert invocation.workflow_input['source_estate_answered']
    reg._source_resolution={'resolution':'ambiguous','candidates':[{'database':'CRM','schema':'RAW'}]}
    invocation.resume_value={'source_scope':{'database':'OTHER','schema':'RAW'}}
    with pytest.raises(ValueError):DeepAgentsRuntime._resume_source_scope(runtime,invocation)


def test_no_progress_is_counted_per_model_decision_after_tool_receipts():
    from langchain_core.messages import AIMessage, ToolMessage
    from app.agent_runtime.deepagents_runtime import DeepAgentsRuntime
    reg=registry(bench(),{'run_id':'r'});runtime=SimpleNamespace(_registry=reg,_budget=reg._budget)
    for index in range(2):
        decision=AIMessage(id=str(index),content='',tool_calls=[{'id':str(index),'name':'inspect_workbench_context','args':{}}])
        assert not DeepAgentsRuntime._model_decision_stalled(runtime,[decision])  # still pending
        assert DeepAgentsRuntime._model_decision_stalled(runtime,[decision,ToolMessage(content='unchanged',tool_call_id=str(index))]) is (index==1)
    reg._budget.record_progress()
    assert not DeepAgentsRuntime._model_decision_stalled(runtime,[AIMessage(id='new',content='New evidence')])
    assert reg._recovery_state['model_stalls']==0


def test_reused_handler_does_not_carry_saved_graphs_into_a_different_authority():
    w=bench();registry(w,{'run_id':'r','effective_role':'R1'})
    w._orientation_graph_reads={('project','p'):'old'}
    w._catalog_discovery_queries=24
    registry(w,{'run_id':'r','effective_role':'R2'})
    assert not getattr(w,'_orientation_graph_reads',{})
    assert getattr(w,'_catalog_discovery_queries',0)==0


def test_large_saved_graph_summary_defers_whole_sources_and_cannot_select_partial_graph():
    w=bench();w.get_project_context=lambda _:ToolResult(status='succeeded',summary='p',data={'mappings':[{'sttm_id':'m'}]})
    sources=['CRM.S.T_'+str(index)+'_'+'x'*200 for index in range(200)]
    w._precedent_detail=lambda *args:SimpleNamespace(latest_snapshot={},sources=sources,mapping_rows=[],sttm=SimpleNamespace(status='PUBLISHED',target_table='DW.S.T'))
    result=mapping_graph(w,'p','m')
    assert not result.data['sources_complete'] and result.data['source_count']==200
    assert result.data['sources']==sources[:result.data['deferred_sources_offset']]
    reg=registry(w,{'run_id':'r'})
    reg._meaningful_progress('read_mapping_graph',result,{})
    assert not getattr(reg,'_proposed_graphs',{})


def test_estate_answer_restores_stored_options_even_when_optional_knowledge_is_unavailable():
    from app.agent_runtime.deepagents_runtime import DeepAgentsRuntime
    from app.agent_runtime.interface import RuntimeInvocation
    from app.agent_runs.models import EffortLevel
    reg=registry(bench(),{'run_id':'r','authorized_schemas':['CRM.RAW','CRM.CURATED']})
    runtime=SimpleNamespace(_registry=reg,_workflow_checkpoint_started=lambda _:False,
        _trusted_context=lambda:{'authorized_schemas':['CRM.RAW','CRM.CURATED']})
    question={'category':'confidence_gate','subject_keys':['source_estate'],'choices':[
        {'selection_payload':{'source_scope':{'database':'CRM','schema':'RAW'}}},
        {'selection_payload':{'source_scope':{'database':'CRM','schema':'CURATED'}}}]}
    invocation=RuntimeInvocation(run_id='r',thread_id='r',prompt='Plan it',effort=EffortLevel.LIGHT,
        resume_value={'source_scope':{'database':'CRM','schema':'RAW'}},workflow_input={'answered_question':question})
    assert DeepAgentsRuntime._resume_source_scope(runtime,invocation)
    assert reg._source_resolution['resolution']=='resolved'
    reg._source_resolution=None;invocation.resume_value={'decision':'other','feedback':'Use another current source design'}
    assert DeepAgentsRuntime._resume_source_scope(runtime,invocation)
    assert reg._source_resolution['resolution']=='researching_alternative'


def test_saved_driver_evidence_preserves_cte_role_without_inventing_a_join():
    from app.agent_tools.source_orientation import preserve_saved_driver
    cte={'id':'cte1','name':'PARSED_AMOUNT','sql':'SELECT ID, TRY_TO_NUMBER(CENTS) AS N FROM CRM.S.A'}
    result=preserve_saved_driver([dict(cte)],saved_driver='cte1',parsed_driver='PARSED_AMOUNT',physical_driver_matches=True)
    assert result[0]['is_driving_source'] and result[0]['sql']==cte['sql']
    untouched=preserve_saved_driver([dict(cte)],saved_driver='cte1',parsed_driver='PARSED_AMOUNT',physical_driver_matches=False)
    assert 'is_driving_source' not in untouched[0]
    existing=preserve_saved_driver([dict(cte),{'id':'other','name':'OTHER','is_driving_source':True}],
        saved_driver='cte1',parsed_driver='PARSED_AMOUNT',physical_driver_matches=True)
    assert 'is_driving_source' not in existing[0]  # explicit current choice wins


def test_model_timing_separates_mandatory_receipt_from_provider_call(monkeypatch):
    from app.agent_runtime.execution import SharedBudgetMiddleware
    import app.agent_runtime.execution as module
    times=iter([1.0,1.03,1.04]);monkeypatch.setattr(module.time,'perf_counter',lambda:next(times))
    events=[];middleware=SharedBudgetMiddleware(ExecutionBudget(model_limit=4,tool_limit=10),trace=lambda *args:events.append(args))
    middleware._focus_requested_submission=lambda request:request
    middleware._usage=lambda *args:{}
    middleware._check_complete_output=lambda *args:None
    middleware.wrap_model_call(SimpleNamespace(),lambda request:SimpleNamespace())
    metrics=next(event[3]['metrics'] for event in events if event[0]=='model.completed')
    assert metrics['pre_dispatch_persistence_ms']==30 and metrics['duration_ms']==10


def test_failed_mandatory_model_receipt_blocks_provider_even_without_usage_callback():
    from app.agent_runs.trace_writer import DurableTraceWriter
    from app.agent_runs.models import AgentRunEvent
    from app.agent_runtime.execution import SharedBudgetMiddleware
    provider=Mock()
    service=SimpleNamespace(build_event=lambda run,event,*args,**kw:AgentRunEvent(event_id='e',run_id='r',sequence=1,event_type=event,status='running',safe_summary='Starting',data=kw.get('data') or {}),
        repository=SimpleNamespace(append_events=Mock(side_effect=RuntimeError('commit failed'))))
    writer=DurableTraceWriter(service,SimpleNamespace(run_id='r'),flush_interval_seconds=.01)
    middleware=SharedBudgetMiddleware(ExecutionBudget(model_limit=3,tool_limit=3),trace=writer)
    middleware._focus_requested_submission=lambda request:request
    try:
        with pytest.raises(RuntimeError,match='trace writer failed'):
            middleware.wrap_model_call(SimpleNamespace(),provider)
        provider.assert_not_called()
    finally:
        with pytest.raises(RuntimeError):writer.close(timeout=.2)


def test_plan_failures_do_not_leak_into_a_different_run():
    r=registry(bench(),{'run_id':'old'})
    r._plan_validation_failure={'attempts':3,'error_code':'old'}
    r.begin_run({'run_id':'new'})
    assert r.plan_validation_failure is None


def test_unpublished_agent_working_copy_is_not_accepted_precedent():
    from app.agent_tools.source_orientation import unpublished_agent_draft
    generated={'status':'IN_PROGRESS','metadata':{'draft_only':True,'migration_run_id':'old-run'}}
    assert unpublished_agent_draft(generated)
    assert not unpublished_agent_draft({**generated,'status':'COMPLETE'})
    assert not unpublished_agent_draft({'status':'IN_PROGRESS','metadata':{}})


def test_project_orientation_keeps_working_copies_visible_after_accepted_designs():
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    w=bench();w._tool=lambda *_:None
    def record(**data):return SimpleNamespace(model_dump=lambda **_:data)
    w._projects=SimpleNamespace(get_project=lambda _:record(project_id='p'),
        list_sttms=lambda _:[record(sttm_id='generated',status='DRAFT',metadata={'draft_only':True,'migration_run_id':'r'}),
                            record(sttm_id='manual',status='DRAFT',metadata={}),
                            record(sttm_id='published',status='COMPLETE',metadata={})],list_project_links=lambda _:[])
    result=WorkbenchWorkflowHandlers.get_project_context(w,'p')
    assert [value['sttm_id'] for value in result.data['mappings']]==['published','manual','generated']


def test_source_estate_uses_only_active_published_semantic_registry_rows():
    w=bench([{'DATABASE_NAME':'CRM','SCHEMA_NAME':'FIRM_A_RAW'}]);w._tool=lambda *_:None
    w._settings.resolved_semantic_native_views_table='META.CONTROL.SEM_NATIVE_VIEWS'
    result=resolve(w,{},hint='firm')
    assert result.data['resolution']=='resolved'
    assert "UPPER(STATUS) = 'ACTIVE'" in w._session.sql.call_args.args[0]


def test_unresolved_business_scope_is_a_resumable_question_without_fabricated_choices():
    from langchain_core.language_models.fake_chat_models import FakeMessagesListChatModel
    from langchain_core.messages import AIMessage
    from app.agent_runtime.deepagents_runtime import DeepAgentsRuntime
    from app.agent_runtime.interface import RuntimeInvocation
    from app.agent_runs.models import EffortLevel
    from app.migration_workflow.graph import build_migration_graph
    class Model(FakeMessagesListChatModel):
        def bind_tools(self,*args,**kwargs):return self
    model=Model(responses=[AIMessage(content='',tool_calls=[{'id':'estate','name':'resolve_source_scope','args':{'hint':'loan income'}}])])
    runtime=DeepAgentsRuntime(model=model,migration_graph=build_migration_graph(),workbench=bench(),budget=ExecutionBudget(model_limit=8,tool_limit=20))
    result=runtime.invoke(RuntimeInvocation(run_id='missing-estate',thread_id='missing-estate',prompt='Plan loan income mapping',effort=EffortLevel.MEDIUM,
        workflow_input={'run_mode':'plan','intent':'NEW_MIGRATION_TASK'}))
    assert result.status=='AWAITING_INPUT'
    assert not result.workflow_state.get('error_code')
    payload=result.workflow_state['__interrupt__'][0]
    assert payload['allow_free_text'] and payload['choices']==[]
    assert payload['subject_keys']==['source_estate']
    assert 'Which project or source database/schema' in payload['question']
    assert 'tables are absent' not in result.assistant_message
    assert runtime._registry.plan_validation_failure is None


def test_unresolved_estate_question_resumes_other_answer_without_workflow_checkpoint():
    from app.agent_runtime.deepagents_runtime import DeepAgentsRuntime
    from app.agent_runtime.interface import RuntimeInvocation
    from app.agent_runs.models import EffortLevel
    reg=registry(bench(),{'run_id':'r'})
    runtime=SimpleNamespace(_registry=reg,_workflow_checkpoint_started=lambda _:False)
    question={'category':'confidence_gate','subject_keys':['source_estate'],'choices':[]}
    invocation=RuntimeInvocation(run_id='r',thread_id='r',prompt='Plan it',effort=EffortLevel.LIGHT,
        resume_value={'decision':'other','feedback':'Use our Loan Income project'},workflow_input={'answered_question':question})
    assert DeepAgentsRuntime._resume_source_scope(runtime,invocation)
    assert invocation.workflow_input['source_estate_answered']
    assert reg._source_resolution['resolution']=='researching_alternative'


def test_scope_summary_only_claims_verified_contracts_and_retains_lookup_gaps():
    from app.agent_runtime.deepagents_runtime import DeepAgentsRuntime
    runtime=SimpleNamespace(_registry=SimpleNamespace(_inspected_contracts={'DB.DW.TARGET'}))
    resolution={'resolution':'unresolved','checked_scopes':[{'database':'DB','schema':'RAW'}],
                'coverage_gaps':[{'operation':'schema_inventory','diagnostics':{'native_code':'630'}}]}
    result=DeepAgentsRuntime._source_scope_question(runtime,{},resolution)
    assert result['status']=='AWAITING_INPUT'
    assert 'DB.DW.TARGET' in result['assistant_message']
    assert '"DB"."RAW"' in result['assistant_message']
    assert result['source_resolution']==resolution
    assert 'does not mean the tables are absent' in result['assistant_message']


def test_source_history_recovery_preserves_prerequisites_and_is_durably_bounded():
    from app.agent_runtime.deepagents_runtime import DeepAgentsRuntime
    reg=registry(bench(),{'run_id':'r'})
    runtime=SimpleNamespace(_registry=reg)
    reg._source_resolution={'resolution':'unresolved','candidates':[]}
    reg._inspected_contracts={'DB.DW.TARGET'}
    message=DeepAgentsRuntime._begin_source_history_recovery(runtime)
    assert 'search_precedents' in message and 'DB.DW.TARGET' in message
    assert reg._recovery_state['source_history_attempted']
    assert reg._source_resolution['resolution']=='researching_history'
    assert DeepAgentsRuntime._begin_source_history_recovery(runtime) is None


def test_new_history_projects_count_as_progress_but_reordering_and_duplicates_do_not():
    reg=registry(bench(),{'run_id':'r'})
    result=ToolResult(status='succeeded',summary='Projects',data={'projects':[{'project_id':'1'},{'project_id':'2'}]})
    assert reg._meaningful_progress('search_precedents',result,{})
    assert not reg._meaningful_progress('search_precedents',result.model_copy(update={'data':{'projects':[{'project_id':'2'},{'project_id':'1'},{'project_id':'1'}]}}),{})
    assert reg._meaningful_progress('search_precedents',result.model_copy(update={'data':{'projects':[{'project_id':'3'}]}}),{})


def test_saved_definition_reuses_compiled_sql_without_substituting_preview():
    from app.agent_tools.source_orientation import saved_definition_sql
    assert saved_definition_sql({'mapping_sql':'','compiled_mapping_sql':'WITH C AS (SELECT ID FROM DB.S.T) SELECT ID FROM C','mapping_preview_sql':'SELECT 1 LIMIT 3'})==('WITH C AS (SELECT ID FROM DB.S.T) SELECT ID FROM C','compiled_mapping_sql')
    assert saved_definition_sql({'mapping_sql':'SELECT ID FROM DB.S.T','compiled_mapping_sql':'SELECT OLD FROM DB.S.T'})==('SELECT ID FROM DB.S.T','mapping_sql')
    assert saved_definition_sql({'mapping_preview_sql':'SELECT 1'})==('',None)
    w=bench();w.get_project_context=lambda _:ToolResult(status='succeeded',summary='p',data={'mappings':[{'sttm_id':'1'}]})
    w._precedent_detail=lambda *args:SimpleNamespace(latest_snapshot={'mapping_sql':'','compiled_mapping_sql':'SELECT ID FROM CRM.S.T'},sources=['CRM.S.T'],mapping_rows=[],sttm=SimpleNamespace(status='DRAFT',target_table='DW.S.T'))
    data=mapping_graph(w,'p','1').data
    assert data['mapping_sql']=='SELECT ID FROM CRM.S.T'
    assert data['sql_source']=='compiled_mapping_sql' and data['historical']


def test_resolved_scope_preparation_has_own_bounded_prerequisite_receipts():
    from app.agent_runtime.deepagents_runtime import DeepAgentsRuntime
    reg=registry(bench(),{'run_id':'r'})
    reg._source_resolution={'resolution':'resolved','recommended_scopes':[{'database':'DB','schema':'RAW'}]}
    reg._recovery_state={'source_history_attempted':True,'nudges':1}
    runtime=SimpleNamespace(_registry=reg)
    for i in range(3):
        reg._inspected_contracts={f'DB.RAW.T{n}' for n in range(i)}
        message=DeepAgentsRuntime._begin_resolved_scope_preparation(runtime)
        assert 'prepare_migration_evidence' in message
        assert DeepAgentsRuntime._begin_resolved_scope_preparation(runtime) is None
    reg._inspected_contracts={'DB.RAW.NEW'}
    assert DeepAgentsRuntime._begin_resolved_scope_preparation(runtime) is None
    assert reg._recovery_state['source_history_attempted']


def test_natural_language_plan_request_honors_plan_mode_when_ui_is_auto():
    from app.agent_runtime.deepagents_runtime import _effective_run_mode
    from app.agent_runtime.interface import RuntimeInvocation
    from app.agent_runs.models import EffortLevel
    invocation=RuntimeInvocation(run_id='r',thread_id='r',prompt='Create relationships and give me the plan to generate this query',effort=EffortLevel.LIGHT,workflow_input={'run_mode':'auto'})
    assert _effective_run_mode(invocation)=='plan'
    invocation.prompt='Create the mappings and implement the plan now'
    assert _effective_run_mode(invocation)=='auto'


def test_saved_definition_tool_returns_complete_compiled_sql_with_provenance_and_owner_check():
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    w=SimpleNamespace(_tool=lambda name:None,_domain_lock=RLock())
    snapshot={'mapping_sql':'','compiled_mapping_sql':'SELECT ID FROM DB.S.T'}
    w._projects=SimpleNamespace(get_project=lambda *a,**k:object(),
        get_sttm_record=lambda *a,**k:SimpleNamespace(project_id='p',last_snapshot_id='snapshot',status='DRAFT',target_table='DB.DW.T'),
        _latest_snapshot=lambda *a,**k:snapshot)
    result=WorkbenchWorkflowHandlers.read_mapping_definition(w,'p','m')
    assert result.status=='succeeded'
    assert result.data['mapping_sql']==snapshot['compiled_mapping_sql']
    assert result.data['sql_source']=='compiled_mapping_sql'
    assert WorkbenchWorkflowHandlers.read_mapping_definition(w,'foreign','m').status=='denied'
    snapshot['compiled_mapping_sql']='SELECT '+"'"+'a'*49000+"'"
    result=WorkbenchWorkflowHandlers.read_mapping_definition(w,'p','m')
    assert result.data['mapping_sql'] is None and result.data['sql_deferred']


def test_zero_source_evidence_does_not_suppress_resolved_scope_preparation():
    from app.agent_runtime.deepagents_runtime import DeepAgentsRuntime
    reg=registry(bench(),{'run_id':'r'})
    reg._prepared_plan_candidate={'source_preparation':{'target_table':'DB.DW.TARGET','driving_source':None},'auto_map':{'target_columns':['ID']}}
    reg._source_resolution={'resolution':'resolved','recommended_scopes':[{'database':'DB','schema':'RAW'}]}
    runtime=SimpleNamespace(_registry=reg)
    assert 'prepare_migration_evidence' in DeepAgentsRuntime._begin_resolved_scope_preparation(runtime)
    assert 'Source scope is resolved' in reg.prerequisite_recovery()
    assert reg._prepared_plan_candidate['auto_map']['target_columns']==['ID']
    reg._prepared_plan_candidate['source_preparation']['driving_source']='DB.RAW.SOURCE'
    assert DeepAgentsRuntime._begin_resolved_scope_preparation(runtime) is None


@pytest.mark.parametrize('target,expected',[
    ('"DB"."DW"."TARGET"','DB.DW.TARGET'),
    ('"Db"."Mixed.Schema"."Target"','"Db"."Mixed.Schema"."Target"'),
])
def test_evidence_preparation_resolves_quoted_target_before_precedent_lookup(target,expected):
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    class StopAfterLookup(Exception):pass
    seen=[]
    def lookup(value,**kwargs):
        seen.append(value)
        raise StopAfterLookup()
    w=SimpleNamespace(_describe_tables=lambda values:None,
        _describe_table=lambda value:{'columns':['ID'],'column_contracts':[]},
        _related_saved_plans=lambda state, value: [],
        _tool=lambda *args:None,_settings=SimpleNamespace(migration_agent_precedent_project_limit=5),
        _domain_lock=RLock(),_projects=SimpleNamespace(find_target_precedent_projects=lookup))
    with pytest.raises(StopAfterLookup):
        WorkbenchWorkflowHandlers.prepare_migration_evidence(w,{},source_tables=[],target_table=target)
    assert seen==[expected]


def test_fir_lookup_uses_the_same_exact_identity_as_catalog_and_preparation():
    from app.agent_tools.workbench import WorkbenchWorkflowHandlers
    calls=[]
    def cards(**kwargs):calls.append(kwargs);return [],[]
    w=SimpleNamespace(_learning_cards=cards)
    result=WorkbenchWorkflowHandlers.retrieve_fir_evidence(w,{},'"DB"."DW"."TARGET"',['ID'])
    assert result.status=='succeeded'
    assert calls[0]['target_table']=='DB.DW.TARGET'


def test_target_only_evidence_points_to_source_inspection_instead_of_plan_validation():
    w=bench()
    w.prepare_migration_evidence=lambda *a,**k:ToolResult(status='succeeded',summary='Target research',data={
        'plan_candidate':{'source_preparation':{'target_table':'DB.DW.TARGET','driving_source':None},'auto_map':{'target_columns':['ID']}},
        'historical_source_candidates':['DB.RAW.SOURCE']})
    reg=registry(w,{'run_id':'r','authorized_schemas':['DB.DW','DB.RAW'],'authorized_target_scope':['DB.DW.TARGET']})
    tool=next(tool for tool in reg.tools() if tool.name=='prepare_migration_evidence')
    result=tool.invoke({'source_tables':[],'target_table':'"DB"."DW"."TARGET"'})
    assert result['data']['source_preparation_status']=='sources_not_selected'
    assert result['data']['next_action']=='inspect_current_sources_before_plan_submission'
    assert result['data']['next_tool']['arguments']['table_fqns']==['DB.RAW.SOURCE']
    assert 'before submitting a plan' in result['data']['plan_submission_hint']
    assert not reg.validated_supervisor_plan


def test_same_join_from_history_and_current_verification_is_one_contract_with_both_receipts():
    join={'left_table':{'database':'DB','schema':'RAW','table':'LOAN'},'right_table':'DB.DW.USER',
          'join_type':'LEFT JOIN','conditions':[{'left_column':'ADMIN_ID','right_column':'ID','operator':'='}],
          'source':'PRECEDENT_SQL','evidence_refs':['saved:1']}
    current={**join,'left_table':'"DB"."RAW"."LOAN"','join_type':'LEFT','source':'RELATIONSHIP_GRAPH','evidence_refs':['query:2']}
    merged=CapabilityRegistry._merge_join_evidence([join],[current])
    assert len(merged)==1
    assert merged[0]['evidence_refs']==['saved:1','query:2']
    assert merged[0]['evidence_sources']==['PRECEDENT_SQL','RELATIONSHIP_GRAPH']
    for changed in [{**current,'join_type':'INNER'},{**current,'conditions':[{'left_column':'OTHER_ID','right_column':'ID'}]},
                    {**current,'literal_filters':[{'side':'right','column':'ACTIVE','value':True}]}]:
        assert len(CapabilityRegistry._merge_join_evidence([join,changed]))==2


def test_target_only_research_verifies_saved_draft_sources_before_asking():
    workbench = bench()
    workbench.inspect_table_contract = Mock(side_effect=lambda table: ToolResult(
        status='succeeded', summary='contract', data={'table': table, 'columns': ['ID']}
    ))
    reg = registry(workbench, {'run_id': 'r', 'authorized_schemas': ['CRM.S', 'DW.S']})
    design = {
        'project_id': 'earlier', 'sttm_id': 'saved-draft', 'driver': 'CRM.S.CURRENT',
        'source_tables': ['CRM.S.CURRENT', 'CRM.S."Lookup.V1"'],
        'working_copy': True, 'has_mapping_sql': True, 'relationship_count': 1,
        'column_lineage': {'ID': ['CRM.S.CURRENT.ID', 'CRM.S."Lookup.V1".ID']},
    }
    reviewed = {'precedents': [
        {**design, 'sttm_id': 'inaccessible', 'driver': 'OTHER.S.PRIVATE'},
        {**design, 'sttm_id': 'obsolete', 'driver': 'CRM.S.OLD',
         'source_tables': ['CRM.S.OLD'], 'column_lineage': {'ID': ['CRM.S.OLD.REMOVED']}},
        design,
    ]}
    verified = reg.verify_retained_source_designs('DW.S.TARGET', reviewed)
    assert [item['sttm_id'] for item in verified] == ['saved-draft']
    assert verified[0]['working_copy'] and not verified[0]['published']
    assert verified[0]['tables'] == ['CRM.S.CURRENT', 'CRM.S."Lookup.V1"']
    assert 'OTHER.S.PRIVATE' not in [call.args[0] for call in workbench.inspect_table_contract.call_args_list]
    workbench.inspect_table_contract.reset_mock()
    assert reg.verify_retained_source_designs('DW.S.TARGET', reviewed) == verified
    workbench.inspect_table_contract.assert_not_called()


def test_steering_waits_until_every_parallel_tool_receipt_is_present():
    from langchain_core.messages import AIMessage, ToolMessage
    from app.agent_runtime.deepagents_runtime import DeepAgentsRuntime

    request = AIMessage(content='', tool_calls=[
        {'id': 'first', 'name': 'inspect_table_contract', 'args': {}},
        {'id': 'second', 'name': 'inspect_table_contract', 'args': {}},
    ])
    first = ToolMessage(content='verified', tool_call_id='first')
    second = ToolMessage(content='verified', tool_call_id='second')
    assert not DeepAgentsRuntime._steering_boundary([request])
    assert not DeepAgentsRuntime._steering_boundary([request, first])
    assert DeepAgentsRuntime._steering_boundary([request, first, second])


def test_host_researches_verified_target_before_asking_about_an_ambiguous_estate():
    from app.agent_runtime.deepagents_runtime import DeepAgentsRuntime

    runtime = object.__new__(DeepAgentsRuntime)
    runtime._trusted_context = lambda: {'authorized_target_scope': ['"DW"."OPS"."LOAN"']}
    reg = SimpleNamespace(
        _precedent_targets={'DW.OPS.LOAN'}, _inspected_contracts={'DW.OPS.LOAN'},
        _multi_target_active=False, _recovery_state={},
        prepared_plan_candidate=None, prepared_plan_review=None,
        _save_discovery_state=Mock(),
    )
    runtime._registry = reg

    def prepare(*, source_tables, target_table):
        assert not source_tables and target_table == 'DW.OPS.LOAN'
        reg.prepared_plan_review = {'target_table': target_table, 'precedents': [{'sttm_id': 'old-draft'}]}

    reg._prepare_evidence = Mock(side_effect=prepare)
    design = {'sttm_id': 'old-draft', 'project_id': 'project', 'tables': ['DATA.RAW.LOAN'], 'strength': (1,)}
    reg.verify_retained_source_designs = Mock(return_value=[design])
    reg.prepare_verified_source_design = Mock(return_value={'status': 'succeeded'})

    assert runtime._check_retained_source_design({}) == (None, True)
    reg._prepare_evidence.assert_called_once()
    reg.prepare_verified_source_design.assert_called_once_with('DW.OPS.LOAN', design)
    assert runtime._check_retained_source_design({}) == (None, False)


def test_steering_reconciles_a_lost_receipt_without_appending_the_guidance_twice():
    from app.agent_runtime.deepagents_runtime import DeepAgentsRuntime

    runtime = object.__new__(DeepAgentsRuntime)
    saved = []
    runtime._agent = SimpleNamespace(
        get_state=lambda _: SimpleNamespace(values={'messages': saved}),
        update_state=Mock(side_effect=lambda _, update: saved.extend(update['messages'])),
    )
    runtime._registry = SimpleNamespace(
        _validated_supervisor_plan={'old': True}, _pending_supervisor_plan=None, _persist_plan_state=Mock(),
    )
    runtime._trace = Mock()
    runtime._acknowledge_steering = Mock(side_effect=[TimeoutError(), None])
    queued = SimpleNamespace(turn_id='inbox_1', message='Keep the current source and explain the join.')
    with pytest.raises(TimeoutError):
        runtime._checkpoint_steer({}, queued)
    assert runtime._registry._validated_supervisor_plan is None
    runtime._checkpoint_steer({}, queued)
    assert [message.id for message in saved] == ['inbox_1']
    runtime._agent.update_state.assert_called_once()
    runtime._trace.assert_called_once()


def test_unowned_project_pauses_before_plan_approval_or_draft_writes():
    from app.agent_runtime.deepagents_runtime import DeepAgentsRuntime
    from app.agent_runtime.interface import RuntimeInvocation

    runtime = object.__new__(DeepAgentsRuntime)
    runtime._active_invocation = RuntimeInvocation(
        run_id='r', thread_id='r', prompt='Plan a mapping in Test Map', effort='medium',
        workflow_input={'project_id': 'shared-project', 'run_mode': 'plan'},
    )
    runtime._workflow_result = None
    runtime._workbench = SimpleNamespace(
        require_draft_project_owner=Mock(side_effect=PermissionError('not owned')),
    )
    runtime._migration_graph = Mock()
    result = runtime._execute_workflow_with_scope(
        ['DW.OPS.TARGET'], [], {'_deep_supervisor_validated': True, 'source_preparation': {
            'driving_source': 'DATA.RAW.SOURCE', 'target_table': 'DW.OPS.TARGET',
        }},
    )
    assert result['status'] == 'AWAITING_INPUT'
    question = result['__interrupt__'][0]
    assert question['subject_keys'] == ['destination_project']
    assert question['choices'][0]['selection_payload'] == {'destination_project': 'create'}
    runtime._migration_graph.invoke.assert_not_called()
