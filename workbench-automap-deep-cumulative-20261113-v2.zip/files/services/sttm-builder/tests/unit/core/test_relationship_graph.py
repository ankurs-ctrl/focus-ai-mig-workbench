"""Phase 2: relationship candidates come from contracts and are decided by data."""
from __future__ import annotations

from typing import Any

import pytest

from app.agent_tools import relationship_graph as graph
from app.agent_tools.workbench import WorkbenchWorkflowHandlers

_FAMILY = WorkbenchWorkflowHandlers._type_family


def _contract(*columns: str, key: str | None = "ID", types: dict[str, str] | None = None) -> dict[str, Any]:
    types = types or {}
    return {
        "columns": list(columns),
        "key_columns": [key] if key else [],
        "column_contracts": [{"name": name, "type": types.get(name, "NUMBER(38,0)" if name.endswith("ID") else "VARCHAR(255)")}
                             for name in columns],
    }


_TMD = {
    "DB.SRC.CONTACTS": _contract("ID", "CATEGORY_ID", "FIRST_NAME"),
    "DB.SRC.CONTACT_FAMILIES": _contract("ID", "NAME"),
    "DB.SRC.CONTACT_FAMILY_MEMBERS": _contract("ID", "FAMILY_ID", "CONTACT_ID", "HOH"),
    "DB.SRC.CATEGORIES": _contract("ID", "NAME"),
    "DB.SRC.CONTACT_CATEGORIES": _contract("ID", "NAME"),
    "DB.SRC.ACTIVITIES": _contract("ID", "CATEGORY_ID", "SUBJECT"),
    "DB.SRC.ACTIVITIES_CONTACTS": _contract("ID", "ACTIVITY_ID", "CONTACT_ID"),
    "DB.SRC.NOTES": _contract("ID", "BODY"),
    "DB.SRC.NOTE_ASSOCIATIONS": _contract("ID", "NOTE_ID", "NOTEABLE_ID", "NOTEABLE_TYPE"),
    "DB.SRC.ADDRESSES": _contract("ID", "ADDRESSABLE_ID", "ADDRESSABLE_TYPE", "CITY"),
}


def _edges() -> list[graph.RelationshipEdge]:
    return graph.fk_name_candidates(_TMD, _FAMILY)


def _pairs(edges) -> set[tuple[str, str, str]]:
    return {(graph._leaf(e.child_table), e.child_column, graph._leaf(e.parent_table)) for e in edges}


def test_singular_handles_common_table_plurals() -> None:
    assert graph.singular("CATEGORIES") == "CATEGORY"
    assert graph.singular("ACTIVITIES") == "ACTIVITY"
    assert graph.singular("ADDRESSES") == "ADDRESS"
    assert graph.singular("STATUSES") == "STATUS"
    assert graph.singular("CONTACTS") == "CONTACT"
    assert graph.singular("STATUS") == "STATUS"


def test_fk_name_rule_finds_stem_and_qualified_parents_without_any_table_names() -> None:
    pairs = _pairs(_edges())
    assert ("CONTACT_FAMILY_MEMBERS", "FAMILY_ID", "CONTACT_FAMILIES") in pairs
    assert ("CONTACT_FAMILY_MEMBERS", "CONTACT_ID", "CONTACTS") in pairs
    assert ("ACTIVITIES_CONTACTS", "ACTIVITY_ID", "ACTIVITIES") in pairs
    assert ("NOTE_ASSOCIATIONS", "NOTE_ID", "NOTES") in pairs
    # Both category tables compete for each CATEGORY_ID column.
    assert {("CONTACTS", "CATEGORY_ID", "CATEGORIES"), ("CONTACTS", "CATEGORY_ID", "CONTACT_CATEGORIES")} <= pairs
    # No ID = ID noise and no self references.
    assert not any(column == "ID" for _, column, _ in pairs)
    rules = {(graph._leaf(e.child_table), graph._leaf(e.parent_table)): e.name_rule for e in _edges()}
    assert rules[("CONTACTS", "CONTACT_CATEGORIES")] == "qualified_shared"
    assert rules[("ACTIVITIES", "CONTACT_CATEGORIES")] == "qualified_foreign"
    assert rules[("ACTIVITIES", "CATEGORIES")] == "exact_stem"


def test_incompatible_key_types_are_not_candidates() -> None:
    contracts = {
        "DB.SRC.ORDERS": _contract("ID", "CUSTOMER_ID", types={"CUSTOMER_ID": "VARCHAR(18)"}),
        "DB.SRC.CUSTOMERS": _contract("ID"),
    }
    assert graph.fk_name_candidates(contracts, _FAMILY) == []


def test_junction_tables_are_recognized_and_never_compete_as_qualified_parents() -> None:
    junctions = graph.junction_tables(_edges())
    assert set(junctions["DB.SRC.ACTIVITIES_CONTACTS"]) == {"DB.SRC.ACTIVITIES", "DB.SRC.CONTACTS"}
    assert "DB.SRC.CONTACT_FAMILY_MEMBERS" in junctions
    assert not any(graph._leaf(edge.parent_table) == "ACTIVITIES_CONTACTS" for edge in _edges())


def test_polymorphic_type_values_become_literal_filtered_edges() -> None:
    slots = graph.polymorphic_slots(_TMD)
    assert ("DB.SRC.NOTE_ASSOCIATIONS", "NOTEABLE_ID", "NOTEABLE_TYPE") in slots
    assert ("DB.SRC.ADDRESSES", "ADDRESSABLE_ID", "ADDRESSABLE_TYPE") in slots
    values = {("DB.SRC.NOTE_ASSOCIATIONS", "NOTEABLE_TYPE"): ["Crm::Contact", "Crm::Activity", "Crm::Unknown"],
              ("DB.SRC.ADDRESSES", "ADDRESSABLE_TYPE"): ["Crm::Contact"]}
    edges = graph.polymorphic_candidates(slots, values, _TMD)
    found = {(graph._leaf(e.child_table), e.child_column, graph._leaf(e.parent_table), e.literal_filters[0].value)
             for e in edges}
    assert found == {
        ("NOTE_ASSOCIATIONS", "NOTEABLE_ID", "CONTACTS", "Crm::Contact"),
        ("NOTE_ASSOCIATIONS", "NOTEABLE_ID", "ACTIVITIES", "Crm::Activity"),
        ("ADDRESSES", "ADDRESSABLE_ID", "CONTACTS", "Crm::Contact"),
    }
    relationship = next(e for e in edges if e.literal_filters[0].value == "Crm::Contact"
                        and e.child_column == "NOTEABLE_ID").to_relationship()
    assert relationship["literal_filters"] == [{"side": "left", "column": "NOTEABLE_TYPE", "operator": "=",
                                                "value": "Crm::Contact"}]


def _verify(edge: graph.RelationshipEdge, coverage: float, *, unique: bool = True, values: int = 1000,
            dense_parent: bool = False) -> None:
    row = {"CHILD_VALUES": values, "MATCHED_VALUES": round(values * coverage),
           "PARENT_VALUES": values, "MAX_PARENT_ROWS": 1 if unique else 3}
    if dense_parent:  # parent keys fill the child's whole value span
        row.update({"CHILD_MIN": 1, "CHILD_MAX": values, "PARENT_IN_CHILD_SPAN": values})
    graph.apply_verification(edge, row, min_child_values=1)


def test_data_decides_between_competing_parents_and_reports_confidence() -> None:
    edges = [e for e in _edges() if e.child_column == "CATEGORY_ID"]
    coverage = {("CONTACTS", "CATEGORIES"): 0.923, ("CONTACTS", "CONTACT_CATEGORIES"): 0.988,
                ("ACTIVITIES", "CATEGORIES"): 1.0, ("ACTIVITIES", "CONTACT_CATEGORIES"): 0.969}
    for edge in edges:
        _verify(edge, coverage[(graph._leaf(edge.child_table), graph._leaf(edge.parent_table))])
    graph.score_edges(edges)
    best = {graph._leaf(e.child_table): max((x for x in edges if x.child_table == e.child_table),
                                            key=lambda x: x.confidence) for e in edges}
    assert graph._leaf(best["CONTACTS"].parent_table) == "CONTACT_CATEGORIES"
    assert graph._leaf(best["ACTIVITIES"].parent_table) == "CATEGORIES"
    for edge in best.values():
        assert graph.auto_resolvable(edge, confidence=0.75, margin=0.15)


def test_a_lone_unverified_or_orphaned_candidate_is_never_auto_resolved() -> None:
    lone = graph.RelationshipEdge("DB.SRC.A", "B_ID", "DB.SRC.B", "ID", name_rule="exact_stem")
    graph.score_edges([lone])
    assert lone.confidence < 1.0
    assert not graph.auto_resolvable(lone, confidence=0.75, margin=0.15)  # not verified

    orphaned = graph.RelationshipEdge("DB.SRC.A", "B_ID", "DB.SRC.B", "ID", name_rule="exact_stem")
    _verify(orphaned, 0.6)
    graph.score_edges([orphaned])
    assert not graph.auto_resolvable(orphaned, confidence=0.75, margin=0.15)

    duplicated = graph.RelationshipEdge("DB.SRC.A", "B_ID", "DB.SRC.B", "ID", name_rule="exact_stem")
    _verify(duplicated, 1.0, unique=False)
    graph.score_edges([duplicated], duplicate_parent_penalty=0.05)
    assert not graph.auto_resolvable(duplicated, confidence=0.75, margin=0.15)


def test_external_evidence_strengthens_matching_edges_and_id_equals_id_stays_weak() -> None:
    edges = _edges()
    graph.merge_external(edges, [
        ("registry_inferred", {"left_table": "DB.SRC.CONTACTS", "right_table": "DB.SRC.CATEGORIES",
                               "conditions": [{"left_column": "ID", "right_column": "ID"}], "confidence": 0.6}),
        ("learning", {"left_table": "DB.SRC.CONTACT_FAMILIES", "right_table": "DB.SRC.CONTACT_FAMILY_MEMBERS",
                      "conditions": [{"left_column": "ID", "right_column": "FAMILY_ID"}], "confidence": 1.0,
                      "evidence_ids": ["learning:42"]}),
    ], _TMD)
    shared = next(e for e in edges if e.child_column == "ID")
    assert shared.name_rule == "shared_primary_key"
    family = next(e for e in edges if e.child_column == "FAMILY_ID")
    assert family.child_table == "DB.SRC.CONTACT_FAMILY_MEMBERS"  # orientation normalized to child -> key
    assert family.evidence[0].kind == "learning" and family.evidence[0].evidence_ids == ["learning:42"]
    _verify(shared, 1.0, dense_parent=True)
    _verify(family, 1.0)
    graph.score_edges([shared, family])
    assert family.confidence > 0.9
    assert graph.auto_resolvable(family, confidence=0.75, margin=0.15)
    # Dense surrogate keys overlap by chance: full coverage adds no confidence.
    assert shared.verification["chance_coverage"] == 1.0
    assert shared.confidence < 0.3
    assert not graph.auto_resolvable(shared, confidence=0.75, margin=0.15)


def test_best_paths_prefer_confident_bridges_between_driver_and_target() -> None:
    edges = [e for e in _edges() if graph._leaf(e.child_table) in {"ACTIVITIES_CONTACTS", "CONTACT_FAMILY_MEMBERS"}]
    for edge in edges:
        _verify(edge, 1.0)
    graph.score_edges(edges)
    paths = graph.best_paths(edges, "DB.SRC.CONTACTS", "DB.SRC.ACTIVITIES")
    confidence, path = paths[0]
    assert [graph._leaf(e.child_table) for e in path] == ["ACTIVITIES_CONTACTS", "ACTIVITIES_CONTACTS"]
    assert 0 < confidence <= 1


def test_verification_sql_binds_filters_samples_deterministically_and_rejects_unsafe_names() -> None:
    edge = graph.RelationshipEdge("DB.SRC.NOTE_ASSOCIATIONS", "NOTEABLE_ID", "DB.SRC.CONTACTS", "ID",
                                  literal_filters=(graph.LiteralFilter("left", "NOTEABLE_TYPE", "Crm::Contact"),))
    sql, params = graph.verification_sql(edge, 5000)
    assert "ORDER BY HASH(K) LIMIT 5000" in sql
    assert '"NOTEABLE_TYPE" = ?' in sql and "Crm::Contact" not in sql
    assert params == ["Crm::Contact", edge.key]
    with pytest.raises(ValueError):
        graph.verification_sql(graph.RelationshipEdge("DB.SRC.A", "X; DROP", "DB.SRC.B", "ID"), 10)


def test_batched_verification_issues_one_query_per_batch() -> None:
    edges = [e for e in _edges() if e.child_column == "CATEGORY_ID"]
    calls: list[tuple[str, list]] = []

    class _Rows:
        def __init__(self, rows): self._rows = rows
        def collect(self): return self._rows

    def sql(query, params=None):
        calls.append((query, params))
        keys = [value for value in params if isinstance(value, str) and len(value) == 20]
        return _Rows([{"EDGE_KEY": key, "CHILD_VALUES": 10, "MATCHED_VALUES": 10, "PARENT_VALUES": 10,
                       "MAX_PARENT_ROWS": 1} for key in keys])

    queries = graph.verify_edges(sql, edges, sample_limit=100, min_child_values=1, batch_size=3)
    assert queries == 2 and len(calls) == 2
    assert all(edge.verified and edge.verification["coverage"] == 1.0 for edge in edges)


# ---- join research integration ---------------------------------------------------

_SELECTED = ["DB.SRC.CONTACTS", "DB.SRC.NOTES", "DB.SRC.NOTE_ASSOCIATIONS"]


def test_reviewed_rule_attaches_a_literal_filter_to_the_join_sharing_its_stem() -> None:
    from app.agent_tools.join_research import parse_join_rules

    joins = parse_join_rules(
        "NOTES.ID = NOTE_ASSOCIATIONS.NOTE_ID; NOTE_ASSOCIATIONS.NOTEABLE_ID = CONTACTS.ID; "
        "NOTE_ASSOCIATIONS.NOTEABLE_TYPE = 'Crm::Contact'", _SELECTED)
    assert "literal_filters" not in joins[0]
    assert joins[1]["literal_filters"] == [{"side": "left", "column": "NOTEABLE_TYPE", "operator": "=",
                                            "value": "Crm::Contact"}]
    quoted = parse_join_rules("NOTE_ASSOCIATIONS.NOTEABLE_ID = CONTACTS.ID; NOTE_ASSOCIATIONS.NOTEABLE_TYPE = 'A;''B'",
                              _SELECTED)
    assert quoted[0]["literal_filters"][0]["value"] == "A;'B"


def test_reviewed_filter_without_a_join_on_its_table_is_rejected() -> None:
    from app.agent_tools.join_research import parse_join_rules

    with pytest.raises(ValueError, match="needs a join"):
        parse_join_rules("NOTES.ID = CONTACTS.ID; NOTE_ASSOCIATIONS.NOTEABLE_TYPE = 'Crm::Contact'", _SELECTED)
    with pytest.raises(ValueError):
        parse_join_rules("NOTE_ASSOCIATIONS.NOTEABLE_ID = CONTACTS.ID; NOTE_ASSOCIATIONS.NOTEABLE_TYPE = 'x' OR 1=1",
                         _SELECTED)


def test_normalized_candidate_keeps_valid_filters_and_rejects_unsafe_ones() -> None:
    from app.agent_tools.join_research import normalized_candidate

    base = {"left_table": "DB.SRC.NOTE_ASSOCIATIONS", "right_table": "DB.SRC.CONTACTS",
            "conditions": [{"left_column": "NOTEABLE_ID", "right_column": "ID"}], "confidence": 0.97}
    kept = normalized_candidate({**base, "literal_filters": [{"side": "left", "column": "noteable_type",
                                                              "value": "Crm::Contact"}]})
    assert kept["literal_filters"][0]["column"] == "NOTEABLE_TYPE" and kept["confidence"] == 0.97
    assert normalized_candidate({**base, "literal_filters": [{"side": "left", "column": "X; DROP", "value": "a"}]}) is None
    assert normalized_candidate({**base, "literal_filters": [{"side": "middle", "column": "T", "value": "a"}]}) is None


def _graph_evidence() -> dict[str, Any]:
    edges = [e for e in _edges() if graph._leaf(e.child_table) in {"ACTIVITIES_CONTACTS", "CONTACT_FAMILY_MEMBERS"}
             or e.child_column == "CATEGORY_ID"]
    coverage = {("CONTACTS", "CATEGORIES"): 0.9, ("CONTACTS", "CONTACT_CATEGORIES"): 0.99}
    for edge in edges:
        _verify(edge, coverage.get((graph._leaf(edge.child_table), graph._leaf(edge.parent_table)), 1.0))
    graph.score_edges(edges)
    serialized = []
    for edge in edges:
        relationship = edge.to_relationship()
        relationship["auto_resolvable"] = graph.auto_resolvable(edge, confidence=0.75, margin=0.15)
        serialized.append(relationship)
    return {"data": {
        "plan_candidate": {"source_preparation": {
            "driving_source": "DB.SRC.CONTACTS",
            "supporting_sources": ["DB.SRC.ACTIVITIES", "DB.SRC.CONTACT_CATEGORIES", "DB.SRC.CONTACT_FAMILIES"],
            "relationships": [],
        }},
        "relationship_graph": {"edges": serialized, "tables": sorted(_TMD)},
    }}


def test_join_questions_from_the_graph_recommend_verified_paths_with_confidence() -> None:
    from app.agent_tools.join_research import research_questions

    questions = {graph._leaf(item["target"]): item for item in research_questions(_graph_evidence(), _TMD)}
    activities = questions["ACTIVITIES"]
    best = activities["options"][0]
    assert activities["recommended_option_id"] == best["id"] and best["recommended"]
    assert [graph._leaf(join["left_table"]) for join in best["joins"]] == ["ACTIVITIES_CONTACTS", "ACTIVITIES_CONTACTS"]
    assert 0.5 < best["confidence"] <= 1 and "% confidence" in best["label"]
    category = questions["CONTACT_CATEGORIES"]["options"][0]
    assert graph._leaf(category["joins"][0]["right_table"]) == "CONTACT_CATEGORIES"
    assert category["recommended"]
    # No ID = ID noise is offered anywhere.
    assert not any(join["conditions"][0]["left_column"] == "ID" and join["conditions"][0]["right_column"] == "ID"
                   for question in questions.values() for option in question["options"] for join in option["joins"])


def test_a_weak_registry_claim_does_not_block_a_name_rule_join_when_data_cannot_separate_them() -> None:
    # Live case: ACTIVITIES.ACTIVITY_CODE_ID holds small codes that also exist
    # as CONTACTS.ID values; the registry proposed CONTACTS twice at LOW.
    contracts = {
        "DB.SRC.ACTIVITIES": _contract("ID", "ACTIVITY_CODE_ID"),
        "DB.SRC.ACTIVITY_CODES": _contract("ID", "NAME"),
        "DB.SRC.CONTACTS": _contract("ID", "NAME"),
    }
    edges = graph.fk_name_candidates(contracts, _FAMILY)
    claim = {"left_table": {"database": "DB", "schema": "SRC", "table": "ACTIVITIES"},
             "right_table": {"database": "DB", "schema": "SRC", "table": "CONTACTS"},
             "column_mappings": [{"fk_column": "ACTIVITY_CODE_ID", "pk_column": "ID"}], "confidence": "LOW"}
    graph.merge_external(edges, [("registry_inferred", claim), ("registry_inferred", claim)], contracts)
    for edge in edges:
        _verify(edge, 1.0, dense_parent=True)
    graph.score_edges(edges)
    codes = next(edge for edge in edges if graph._leaf(edge.parent_table) == "ACTIVITY_CODES")
    contacts = next(edge for edge in edges if graph._leaf(edge.parent_table) == "CONTACTS")
    assert len(contacts.evidence) == 2  # both claims kept for provenance
    assert graph.auto_resolvable(codes, confidence=0.75, margin=0.15)
    assert contacts.confidence < 0.2


def test_an_id_equals_id_pair_over_a_dense_key_span_carries_no_confidence() -> None:
    contracts = {"DB.SRC.ACTIVITY_CODES": _contract("ID", "NAME"), "DB.SRC.ACTIVITIES": _contract("ID", "NAME")}
    edges = graph.merge_external([], [("registry_inferred", {
        "left_table": "DB.SRC.ACTIVITY_CODES", "right_table": "DB.SRC.ACTIVITIES",
        "conditions": [{"left_column": "ID", "right_column": "ID"}], "confidence": 0.6})], contracts)
    _verify(edges[0], 1.0, dense_parent=True)
    graph.score_edges(edges)
    assert edges[0].name_rule == "shared_primary_key"
    assert edges[0].confidence < 0.2


def _live_activities_graph(*, drop_bridge: bool = False) -> dict[str, Any]:
    """Phase 2B live case: CONTACTS -> ACTIVITIES has a junction route, a
    polymorphic same-column route and a shared-category route, all verified."""
    slots = graph.polymorphic_slots(_TMD)
    values = {("DB.SRC.NOTE_ASSOCIATIONS", "NOTEABLE_TYPE"): ["Crm::Contact", "Crm::Activity"],
              ("DB.SRC.ADDRESSES", "ADDRESSABLE_TYPE"): ["Crm::Contact"]}
    edges = [e for e in [*_edges(), *graph.polymorphic_candidates(slots, values, _TMD)]
             if not (drop_bridge and graph._leaf(e.child_table) == "ACTIVITIES_CONTACTS")]
    for edge in edges:
        _verify(edge, 1.0)
    graph.score_edges(edges)
    serialized = []
    for edge in edges:
        relationship = edge.to_relationship()
        relationship["auto_resolvable"] = graph.auto_resolvable(edge, confidence=0.75, margin=0.15)
        serialized.append(relationship)
    return {"data": {
        "plan_candidate": {"source_preparation": {
            "driving_source": "DB.SRC.CONTACTS", "supporting_sources": ["DB.SRC.ACTIVITIES"], "relationships": [],
        }},
        "relationship_graph": {"edges": serialized, "tables": sorted(_TMD),
                               "thresholds": {"confidence": 0.75, "margin": 0.15, "min_coverage": 0.9}},
    }}


def test_path_shape_rejects_one_column_referencing_two_parents_and_counts_shared_parent_peaks() -> None:
    contacts, activities = "DB.SRC.CONTACTS", "DB.SRC.ACTIVITIES"
    polymorphic = [("DB.SRC.NOTE_ASSOCIATIONS", "NOTEABLE_ID", contacts),
                   ("DB.SRC.NOTE_ASSOCIATIONS", "NOTEABLE_ID", activities)]
    assert graph.path_shape(contacts, polymorphic) == (False, 0)
    junction = [("DB.SRC.ACTIVITIES_CONTACTS", "CONTACT_ID", contacts),
                ("DB.SRC.ACTIVITIES_CONTACTS", "ACTIVITY_ID", activities)]
    assert graph.path_shape(contacts, junction) == (True, 0)
    shared_category = [("DB.SRC.NOTE_ASSOCIATIONS", "NOTEABLE_ID", contacts),
                       ("DB.SRC.NOTE_ASSOCIATIONS", "NOTE_ID", "DB.SRC.NOTES"),
                       ("DB.SRC.NOTES", "CATEGORY_ID", "DB.SRC.CATEGORIES"),
                       ("DB.SRC.ACTIVITIES", "CATEGORY_ID", "DB.SRC.CATEGORIES")]
    assert graph.path_shape(contacts, shared_category) == (True, 1)
    chain = [("DB.SRC.CONTACTS", "CATEGORY_ID", "DB.SRC.CONTACT_CATEGORIES")]
    assert graph.path_shape(contacts, chain) == (True, 0)


def test_live_activities_question_recommends_the_junction_and_never_the_polymorphic_route() -> None:
    from app.agent_tools.join_research import research_questions

    question = research_questions(_live_activities_graph(), _TMD)[0]
    labels = [option["label"] for option in question["options"]]
    best = question["options"][0]
    assert [graph._leaf(join["left_table"]) for join in best["joins"]] == ["ACTIVITIES_CONTACTS", "ACTIVITIES_CONTACTS"]
    assert best["recommended"] and question["recommended_option_id"] == best["id"]
    # NOTEABLE_ID read as both Crm::Contact and Crm::Activity is never offered.
    assert not any("Crm::Contact" in label and "Crm::Activity" in label for label in labels)
    # A route that only shares a category ranks far below and is never recommended.
    assert all(not option["recommended"] for option in question["options"][1:])
    assert all(option["confidence"] < 0.5 for option in question["options"][1:])


def test_two_equally_strong_coherent_routes_are_a_question_not_a_recommendation() -> None:
    from app.agent_tools.join_research import research_questions

    evidence = _live_activities_graph()
    # A second, direct and equally verified route to ACTIVITIES.
    edges = evidence["data"]["relationship_graph"]["edges"]
    direct = dict(next(item for item in edges if graph._leaf(item["left_table"]) == "ACTIVITIES_CONTACTS"
                       and item["conditions"][0]["left_column"] == "ACTIVITY_ID"))
    edges.append({**direct, "left_table": "DB.SRC.CONTACTS", "right_table": "DB.SRC.ACTIVITIES",
                  "conditions": [{"left_column": "CATEGORY_ID", "right_column": "ID", "operator": "="}]})
    question = research_questions(evidence, {**_TMD, "DB.SRC.CONTACTS": _contract("ID", "CATEGORY_ID", "FIRST_NAME")})[0]
    assert question["options"][0]["confidence"] - question["options"][1]["confidence"] < 0.15
    assert question["recommended_option_id"] is None


def test_a_source_without_any_verified_path_explains_why() -> None:
    from app.agent_tools.join_research import research_questions

    evidence = _live_activities_graph(drop_bridge=True)
    evidence["data"]["relationship_graph"]["edges"] = [
        item for item in evidence["data"]["relationship_graph"]["edges"]
        if "DB.SRC.ACTIVITIES" not in {item["left_table"], item["right_table"]}]
    question = research_questions(evidence, _TMD)[0]
    assert question["options"] == []
    assert "compatible type" in question["no_path_reason"]


def test_unfiltered_polymorphic_join_is_dropped_when_its_type_filtered_version_is_verified() -> None:
    # Phase 2C live case: ADDRESSES.ADDRESSABLE_ID = CONTACTS.ID with and without
    # ADDRESSABLE_TYPE = 'Crm::Contact' scored 100% vs 99%, blocking a recommendation.
    filtered = graph.RelationshipEdge("DB.SRC.ADDRESSES", "ADDRESSABLE_ID", "DB.SRC.CONTACTS", "ID",
                                      literal_filters=(graph.LiteralFilter("left", "ADDRESSABLE_TYPE", "Crm::Contact"),),
                                      name_rule="polymorphic")
    plain = graph.RelationshipEdge("DB.SRC.ADDRESSES", "ADDRESSABLE_ID", "DB.SRC.CONTACTS", "ID")
    other = graph.RelationshipEdge("DB.SRC.ADDRESSES", "COUNTRY_ID", "DB.SRC.COUNTRIES", "ID")
    for edge in (filtered, plain, other):
        _verify(edge, 1.0)
    assert graph.without_subsumed_unfiltered([filtered, plain, other]) == [filtered, other]
    # An unverified filtered candidate does not hide the plain join.
    unverified = graph.RelationshipEdge("DB.SRC.ADDRESSES", "ADDRESSABLE_ID", "DB.SRC.CONTACTS", "ID",
                                        literal_filters=(graph.LiteralFilter("left", "ADDRESSABLE_TYPE", "X"),))
    assert plain in graph.without_subsumed_unfiltered([unverified, plain])


def test_bare_table_names_in_a_rule_resolve_to_the_question_schema_when_a_precedent_schema_has_the_same_table() -> None:
    from app.agent_tools.join_research import parse_join_rules

    selected = ["DB.SCH_TMD_SOURCE.CONTACTS", "DB.SCH_TMD_SOURCE.MAPPER_USER", "DB.SCH_EVERNEST_HH_SOURCE.MAPPER_USER"]
    with pytest.raises(ValueError, match="unambiguous"):
        parse_join_rules("CONTACTS.WRITING_ADVISOR_ID = MAPPER_USER.WRITING_ADVISOR_ID", selected)
    joins = parse_join_rules("CONTACTS.WRITING_ADVISOR_ID = MAPPER_USER.WRITING_ADVISOR_ID", selected,
                             preferred_schemas=["DB.SCH_TMD_SOURCE"])
    assert joins[0]["right_table"] == "DB.SCH_TMD_SOURCE.MAPPER_USER"


def test_optional_joins_are_oriented_away_from_the_driver_so_the_driver_grain_is_kept() -> None:
    # Demo 3 live case: child -> parent evidence compiled into RIGHT JOINs from CONTACTS.
    from app.schema.sttm_builder import RelationEdge, RelationshipConditionItem, RelationshipLiteralFilter

    def edge(edge_id, left, right, left_column, right_column, **extra):
        return RelationEdge(edge_id=edge_id, left_relation_id=left, right_relation_id=right, join_type="LEFT",
                            conditions=[RelationshipConditionItem(left_column=left_column, right_column=right_column,
                                                                  operator="=")], **extra)

    members = edge("m", "members", "contacts", "CONTACT_ID", "ID")
    families = edge("f", "members", "families", "FAMILY_ID", "ID")
    addresses = edge("a", "addresses", "contacts", "ADDRESSABLE_ID", "ID", literal_filters=[
        RelationshipLiteralFilter(side="left", column="ADDRESSABLE_TYPE", value="Crm::Contact")])
    status = edge("s", "contacts", "statuses", "STATUS_ID", "ID")
    oriented = {item.edge_id: item for item in WorkbenchWorkflowHandlers._edges_oriented_from(
        "contacts", [members, families, addresses, status])}
    assert (oriented["m"].left_relation_id, oriented["m"].conditions[0].left_column) == ("contacts", "ID")
    assert oriented["m"].conditions[0].right_column == "CONTACT_ID"
    assert oriented["f"].left_relation_id == "members"  # already points away from the driver
    assert oriented["s"].left_relation_id == "contacts"
    assert oriented["a"].left_relation_id == "contacts" and oriented["a"].literal_filters[0].side == "right"


def test_precedent_edges_take_the_contract_spelling_and_unknown_columns_are_dropped() -> None:
    contracts = {"DB.SRC.NOTE_ASSOCIATIONS": _contract("ID", "NOTEABLE_ID", "NOTEABLE_TYPE"),
                 "DB.SRC.CONTACTS": _contract("ID", "NAME")}
    edges = graph.merge_external([], [
        ("precedent_sql", {"left_table": "DB.SRC.NOTE_ASSOCIATIONS", "right_table": "DB.SRC.CONTACTS",
                           "conditions": [{"left_column": "noteable_id", "right_column": "id"}],
                           "literal_filters": [{"side": "left", "column": "noteable_type", "value": "Crm::Contact"}]}),
        ("precedent_sql", {"left_table": "DB.SRC.NOTE_ASSOCIATIONS", "right_table": "DB.SRC.CONTACTS",
                           "conditions": [{"left_column": "legacy_ref", "right_column": "id"}]}),
    ], contracts)
    assert len(edges) == 1
    assert (edges[0].child_column, edges[0].parent_column) == ("NOTEABLE_ID", "ID")
    assert edges[0].literal_filters[0].column == "NOTEABLE_TYPE"


def test_connected_requested_sources_do_not_research_unrelated_schema_tables(monkeypatch):
    import threading
    from types import SimpleNamespace
    handler = object.__new__(WorkbenchWorkflowHandlers)
    handler._knowledge = None
    handler._setting = lambda name, default=None: default
    handler._domain_lock = threading.RLock()
    handler._session = SimpleNamespace(sql=lambda *_args, **_kwargs: None)
    handler._tool = lambda *_args: None
    handler._emit = lambda *_args, **_kwargs: None
    handler._relationship_learning_claims = lambda _: []
    handler.decision_thresholds = lambda: (0.75, 0.15)
    reads = []
    contracts = {'DB.S.CUSTOMERS': _contract('ID', 'STATUS_ID'), 'DB.S.STATUSES': _contract('ID', 'LABEL')}
    def describe(tables):
        reads.append(list(tables))
        assert set(tables) <= set(contracts), 'Unrelated tables must not be read for an already connected graph'
        return {table: contracts[table] for table in tables}
    handler._describe_tables = describe
    monkeypatch.setattr(graph, 'verify_edges', lambda *_args, **_kwargs: 0)
    result = handler.discover_relationship_graph(list(contracts), [*contracts, 'DB.S.UNRELATED'], [])
    assert reads == [list(contracts)]
    assert result['tables'] == sorted(contracts)
    assert len(result['edges']) == 1
