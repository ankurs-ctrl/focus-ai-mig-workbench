# Auto-map packet and regeneration follow-up — v9

## Changes

New fast generations use one server-owned packet policy through parent planning, durable worker hydration and model dispatch. The parent sizes each complete normalized message once, freezes its evidence admission state and verifies its digest. Workers load the acknowledged, caller/role-scoped receipt from the existing job table instead of rebuilding the packet or sending a multi-megabyte worker envelope. The model receives ordinary complete JSON messages, never compressed storage data. Both character and UTF-8 byte ceilings remain 180,000.

Prepared workspace version 2 stores a normalized catalog, deduplicated retained records and target-to-evidence references. Source groups start at eight targets. Unexamined full-schema inventory indexes are deferred before rendering; admitted bindings and complete relevant semantics remain supplied. Sizing uses at most four full renders per unchanged group and subdivides only undispatched oversized contracts. Target descriptions remain readable. Transformation packets retain selected bindings, relevant evidence and dependency contracts without copying the entire workspace or the generated candidate roster.

Fresh regeneration captures old definitions for Undo without compiling definitions that are being replaced. Checked requests regenerate exactly their target scope; no checked rows regenerates all targets. Older preservation/recovery policies retain their existing operation identities. A retry never authorizes replay of an uncertain model submission.

The frontend applies supported current-generation drafts to requested saved/manual/confirmed rows. In-flight edits hold the affected proposal. Duplicate or late empty receipts retain successful results and the original Undo baseline. Persisted generation provenance supports requested, processed, supported, newly applied, replaced, unchanged, held and unfinished counts. An identical definition is an unchanged reevaluation, not a missing proposal. Uploaded query population is retained separately from blank row definitions. Business Suggestions remain model-authored.

The native investigation also found Snowflake compilation delays of 55–77 seconds in job-state MERGE statements containing repeated large JSON trees. New generations store large context sections and exact receipts losslessly compressed within the existing VARIANT column, with bounded decompression and integrity/projection checks. Project/mapping identities, operational state and result mappings remain SQL-readable. Storage decoding has a 16 MB output ceiling and 64 MB decoder-memory ceiling, checks exact length/end-of-stream/digest, and retains the earlier zlib decoder for compatibility. Job writes and packet reads suppress Snowpark AST emission so bound evidence is not sent again as query metadata; an execution error never triggers a replay. Application readers expand the artifact before validating requests. Read-only inspection scripts understand the encoding. Existing unencoded and v1 exact JSON jobs remain readable. Private handoff and packet bodies are excluded from response metadata so each partial result does not echo the full input receipt. Both source and transformation packets identify exact allowed evidence IDs per target; labels and source-agent names are not citations, and invalid attribution receives a specific focused repair diagnostic.

Terminal result persistence now uses the same lock order as the other lifecycle mutations: fenced operation row, then standard audit/archive tables. The result and terminal state still commit atomically, and no in-memory success is recorded before commit acknowledgement. A failed or uncertain commit retains its native allowlisted SQL code/query ID and outcome for reconciliation; it never authorizes a model replay. The isolated incident that motivated this check returned error 630 at COMMIT after 7.4 seconds blocked. This observation alone does not identify every historical client lock holder. Snowflake documents lock behavior and explicit-transaction deadlocks at https://docs.snowflake.com/en/sql-reference/transactions.

## Installation

1. Apply the cumulative files/ overlay at the repository root. Preserve all environment files and credentials.
2. Rebuild and deploy matching frontend, API, Auto-map workers and Deep Agent worker versions together on every replica. Do not mix old readers with new v9 encoded job records. The rollout must allow active old jobs to finish or recover using their original protocol; do not reset operational tables or replay uncertain calls.
3. V9 adds no table, migration, environment variable, grant, agent tool, context increase or capacity change. Existing v8 bootstrap/ownership-table and agent instructions still apply if not previously installed. Keep AUTOMAP_SHARED_CAPACITY_LIMIT=false for fresh ownership-only generations and preserve existing limits.
4. Prepared Auto-map artifacts are versioned. Incompatible old prepared evidence is rebuilt through the existing prepared-workspace path; no semantic generation or pipeline trigger is introduced.
5. Start a fresh isolated run. Verify packet_version, packet_digest and message_digest, actual source/specialist POST counts, positive estimated confidence, SQL outputs and frontend completion counts. An unchanged result should say reevaluated and unchanged.

The cumulative delivery retains Deep Agent, PR #63, SQL-upload validation/preview/publication, administration and the earlier OAuth/routing/UI fixes. No client mapping or failed client job is modified by the acceptance scripts.

## Verification status

See PACKET-REGENERATION-V9-RESULTS.json for the final measured acceptance and regression results. Native tests use the actual prepare -> durable job -> private worker endpoints, real Snowflake native agents and the frontend result reducer, starting without execution context. Synthetic fixtures contain 37 targets, six sources, an additional CTE node, 600 real source columns and persisted FIR, with existing, blank uploaded-SQL and mixed definitions.

The local acceptance harness keeps one private-worker ASGI lifespan open across concurrent batches, rather than starting/stopping the same recovery loop for each batch. It provisions the artifact stage from the production bootstrap. A truncated post-completion verification SELECT can retry on a fresh same-caller connection; no model submission is replayed. The native incident fixture uses the physical source as its driver; CTE-driven coverage remains in the existing Loan Income acceptance and regression suite. Local native runs are not an isolated five-replica SPCS benchmark. Report first/all POST latency and full result latency separately; do not add overlapping batch durations. A completed job alone does not pass the 200-second performance gate. Provider failures, missing business inputs and deployment-specific caller grants remain separate outcomes.

## Reviewing the native results locally

From the repository root, run `python3 -m http.server 8020 --bind localhost --directory docs/combined-release-20261113`, then open http://localhost:8020/PACKET-REGENERATION-V9-REVIEW.html. This is a read-only report of real agent results and frontend reducer verification, not the production application. Select each scenario to inspect confidence, custom expressions, counts and executed output values.

## Measured final acceptance

| Scenario | Click to durable result | First source POST | Source / specialist POSTs | Applied / unchanged |
|---|---:|---:|---:|---:|
| existing | 158.61s | 51.84s | 5 / 2 | 0 / 37 |
| blank_with_uploaded_sql | 172.27s | 53.38s | 5 / 2 | 37 / 0 |
| mixed | 191.36s | 53.08s | 7 / 2 | 35 / 2 |

All three runs returned 37 supported proposals with positive estimated confidence, cited FIR for the historical custom rule, two completed custom expressions, and three expected Snowflake output rows. Five model operations overlapped in each run. No model request exceeded the 180,000 character/byte limit. Warm preparation measured 8.7–9.2 seconds; packet sizing rendered each initial group once and totaled 0.27–0.28 seconds across five groups. The mixed run recovered malformed/incomplete model output with two additional bounded source submissions. It did not replay an uncertain transport operation.

The three warm 200-second result gates passed. The first-source-POST 20-second gate did not pass: operational persistence, worker hydration and thread handoff still contribute to the approximately 52–53 second startup. Cold/coalesced page preparation took 30.99 seconds before click. Five-replica SPCS timing remains unverified. These limitations are recorded rather than hidden by the successful result totals.

Verification: 5,813 backend tests passed (32 skipped), 525 frontend tests passed, TypeScript passed, agent manifest verified, and six targeted single-attempt HTTP pointer checks passed. The final native tests used local API/private-worker endpoints with real Snowflake agents, not mocked model responses or a seeded execution context.
