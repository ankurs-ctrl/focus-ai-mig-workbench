#!/usr/bin/env python3
"""Render the native Auto-map deployment package; never connect or deploy.

Portable Python 3.11+ (Windows AVD/Linux/macOS). Does not read client.env or build
Docker. Every generated runtime import is content addressed and ZIP paths use /.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import zipfile
from uuid import UUID, uuid4

ROOT = Path(__file__).resolve().parents[1]
TEMPLATE = ROOT / "infra/snowflake/automap_native_v1"


def identifier(value, parts=1):
    if not re.fullmatch(
        r"[A-Za-z_][A-Za-z0-9_$]*(?:\.[A-Za-z_][A-Za-z0-9_$]*){" + str(parts - 1) + "}",
        value,
    ):
        raise ValueError("Expected explicit unquoted Snowflake identifier")
    return value.upper()


def json_text(value):
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    )


def literal(value):
    return "'" + str(value).replace("\\", "\\\\").replace("'", "''") + "'"


def fingerprint(value):
    return hashlib.sha256(json_text(value).encode()).hexdigest()


def render(
    metadata,
    warehouse,
    role,
    stage,
    output,
    *,
    source_model=None,
    rule_model=None,
    account_namespace=None,
    pool_capacity=8,
):
    metadata = identifier(metadata, 2)
    warehouse = identifier(warehouse)
    role = identifier(role)
    stage = identifier(stage, 3)
    out = Path(output)
    out.mkdir(parents=True, exist_ok=True)
    if type(pool_capacity) is not int or not 1 <= pool_capacity <= 32:
        raise ValueError("Native pool capacity must be 1..32")
    if account_namespace:
        account_namespace = identifier(account_namespace, 2)
    old = (
        json.loads((out / "runtime-manifest.json").read_text())
        if (out / "runtime-manifest.json").exists()
        else {}
    )
    epoch = old.get("pool_epoch") or str(uuid4())
    if str(UUID(epoch)) != epoch:
        raise ValueError("Invalid persisted native pool epoch")
    template = json.loads((TEMPLATE / "agent-template.json").read_text())
    runtime = out / "automap_native_runtime.zip"
    app = ROOT / "services/sttm-builder/app"
    with zipfile.ZipFile(
        runtime, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
    ) as archive:
        for file in sorted(app.rglob("*.py")):
            if file.is_symlink() or "__pycache__" in file.parts:
                continue
            info = zipfile.ZipInfo(
                file.relative_to(app.parent).as_posix(), (2026, 1, 1, 0, 0, 0)
            )
            info.create_system = 0
            info.external_attr = 0x20
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, file.read_bytes())
    runtime_hash = hashlib.sha256(runtime.read_bytes()).hexdigest()
    stage_file = "@" + stage + "/" + runtime_hash + "/" + runtime.name
    sql = [
        f'-- First installation only. No OR REPLACE, resetting permits, or shared agent edits.\nUSE DATABASE {metadata.split(".")[0]};\nUSE SCHEMA {metadata.split(".")[1]};',
        f"""CREATE TABLE {metadata}.TBL_AUTOMAP_NATIVE_CONTROL (CONTROL_KEY VARCHAR, VERSION NUMBER);
INSERT INTO {metadata}.TBL_AUTOMAP_NATIVE_CONTROL VALUES ('registry',0);
CREATE TABLE {metadata}.TBL_AUTOMAP_NATIVE_JOBS (
 HANDLE VARCHAR, OWNER_ID VARCHAR, ROLE_NAME VARCHAR, SNAPSHOT_HASH VARCHAR, BATCH_IDENTITY VARCHAR,
 SNAPSHOT VARIANT, CONFIG VARIANT, STATE VARIANT, DEADLINE_AT TIMESTAMP_LTZ, CREATED_AT TIMESTAMP_LTZ,
 LEASE_TOKEN VARCHAR, LEASE_UNTIL TIMESTAMP_LTZ);
CREATE ROW ACCESS POLICY {metadata}.RAP_AUTOMAP_NATIVE_CALLER AS (OWNER_ID VARCHAR, ROLE_NAME VARCHAR)
 RETURNS BOOLEAN -> OWNER_ID=CURRENT_USER() AND ROLE_NAME=CURRENT_ROLE();
ALTER TABLE {metadata}.TBL_AUTOMAP_NATIVE_JOBS ADD ROW ACCESS POLICY {metadata}.RAP_AUTOMAP_NATIVE_CALLER ON (OWNER_ID,ROLE_NAME);
CREATE TABLE {metadata}.TBL_AUTOMAP_NATIVE_ANALYST_SLOTS (
 SLOT_ID NUMBER, FENCE NUMBER, STATE VARCHAR, OWNER_TOKEN VARCHAR, OWNER_ID VARCHAR, ROLE_NAME VARCHAR);
INSERT INTO {metadata}.TBL_AUTOMAP_NATIVE_ANALYST_SLOTS
 SELECT SEQ4(),0,'FREE',NULL,NULL,NULL FROM TABLE(GENERATOR(ROWCOUNT=>4));
CREATE TABLE {metadata}.TBL_AUTOMAP_NATIVE_SOURCE_DOCUMENTS (
 HANDLE VARCHAR, OWNER_ID VARCHAR, PROJECT_ID VARCHAR, SNAPSHOT_HASH VARCHAR,
 BINDING_ID VARCHAR, DOCUMENT VARCHAR, CREATED_AT TIMESTAMP_LTZ) CHANGE_TRACKING=TRUE;
CREATE CORTEX SEARCH SERVICE {metadata}.CSS_AUTOMAP_SOURCE_COLUMNS_V2
 ON DOCUMENT ATTRIBUTES PROJECT_ID,SNAPSHOT_HASH,OWNER_ID
 WAREHOUSE={warehouse} TARGET_LAG='1 minute'
 AS SELECT HANDLE,OWNER_ID,PROJECT_ID,SNAPSHOT_HASH,BINDING_ID,DOCUMENT FROM {metadata}.TBL_AUTOMAP_NATIVE_SOURCE_DOCUMENTS;""",
    ]
    sql.append(
        f"""CREATE TABLE {metadata}.TBL_AUTOMAP_NATIVE_MODEL_SLOTS_V1 (
 ACCOUNT_NAMESPACE VARCHAR(256),POOL_EPOCH VARCHAR(36),SLOT_ID NUMBER,STATE VARCHAR(16),
 OWNER_TOKEN VARCHAR(32),FENCE NUMBER,JOB_ID VARCHAR(256),CALLER_ID VARCHAR(256),
 GENERATION VARCHAR(256),SHARD_ID VARCHAR(256),LEASE_EXPIRES_AT TIMESTAMP_LTZ,
 UPDATED_AT TIMESTAMP_LTZ,COMPLETION VARCHAR(32),RECONCILIATION_REF VARCHAR(256)) AS
 SELECT CURRENT_ORGANIZATION_NAME()||'.'||CURRENT_ACCOUNT_NAME(),{literal(epoch)},ROW_NUMBER() OVER(ORDER BY SEQ4()),
 'FREE',NULL,0,NULL,NULL,NULL,NULL,NULL,CURRENT_TIMESTAMP(),NULL,NULL
 FROM TABLE(GENERATOR(ROWCOUNT=>{pool_capacity}));
CREATE TABLE {metadata}.TBL_AUTOMAP_NATIVE_MODEL_ARCHIVE_V1 (
 OWNER_ID VARCHAR,ACCESS_SCOPE VARCHAR,SNAPSHOT_ID VARCHAR,CONTENT_HASH VARCHAR,
 BODY VARCHAR(16777216),CREATED_AT TIMESTAMP_LTZ);
CREATE ROW ACCESS POLICY {metadata}.RAP_AUTOMAP_NATIVE_ARCHIVE AS (OWNER_ID VARCHAR)
 RETURNS BOOLEAN -> OWNER_ID=CURRENT_USER();
ALTER TABLE {metadata}.TBL_AUTOMAP_NATIVE_MODEL_ARCHIVE_V1 ADD ROW ACCESS POLICY {metadata}.RAP_AUTOMAP_NATIVE_ARCHIVE ON (OWNER_ID);
GRANT SELECT,UPDATE ON TABLE {metadata}.TBL_AUTOMAP_NATIVE_MODEL_SLOTS_V1 TO ROLE {role};
GRANT SELECT,INSERT ON TABLE {metadata}.TBL_AUTOMAP_NATIVE_MODEL_ARCHIVE_V1 TO ROLE {role};"""
    )
    procedures = {
        item["procedure"]: (name, "source") for name, item in template["tools"].items()
    }
    procedures.update(
        {
            "VALIDATE_RULE": ("ValidateProposal", "rule"),
            "SUBMIT_RULE": ("SubmitProposals", "rule"),
        }
    )
    for suffix, (tool, phase) in procedures.items():
        sql.append(
            f"""CREATE PROCEDURE {metadata}.SP_AUTOMAP_{suffix}(REQUEST_JSON VARCHAR)
RETURNS VARCHAR LANGUAGE PYTHON RUNTIME_VERSION='3.11'
ARTIFACT_REPOSITORY=snowflake.snowpark.pypi_shared_repository
PACKAGES=('snowflake-snowpark-python','pydantic>=2.12,<3','sqlglot==30.12.0','pyyaml>=6,<7')
IMPORTS=({literal(stage_file)}) HANDLER='run' EXECUTE AS CALLER
AS $$
from app.core.automap_native_tools import dispatch
import json
def run(session, request_json):
    try:
        if request_json == '{{"protocol_probe":"automap_native_v1"}}':
            from app.core.automap_native_contract import VERSION
            return json.dumps({{"protocol":VERSION,"tool":{tool!r},"phase":{phase!r},"metadata":{metadata!r}}})
        return dispatch(session,{tool!r},request_json,phase={phase!r},metadata={metadata!r})
    except Exception:
        return json.dumps({{"status":"unavailable","code":"native_tool_configuration_or_input_failure","new_information":False}})
$$;"""
        )
    specs = {}
    for kind in ("source", "rule"):
        row = template[kind]
        names = (
            list(template["tools"])
            if kind == "source"
            else [
                "ReadEvidence",
                "InspectRelationships",
                "ValidateProposal",
                "SubmitProposals",
            ]
        )
        instructions = (TEMPLATE / row["instructions"]).read_text()
        if kind == "rule":
            instructions += (
                "\nShared tool contracts (source investigation instructions are not permission to use unregistered tools):\n"
                + (TEMPLATE / "investigator.md")
                .read_text()
                .split("Every tool has ONE string parameter")[1]
                .split("A cached/repeated request")[0]
            )
        spec = {
            "models": {
                "orchestration": (source_model if kind == "source" else rule_model)
                or row["model"]
            },
            "orchestration": {
                "tool_not_accessible": "reject",
                "budget": {"seconds": row["seconds"], "tokens": row["tokens"]},
            },
            "instructions": {
                "orchestration": instructions,
                "response": "Return only the completed checkpoint summary JSON specified in orchestration instructions.",
            },
            "tools": [],
            "tool_resources": {},
        }
        for name in names:
            item = template["tools"][name]
            suffix = item["procedure"]
            if kind == "rule" and name in {"ValidateProposal", "SubmitProposals"}:
                suffix = (
                    "VALIDATE_RULE" if name == "ValidateProposal" else "SUBMIT_RULE"
                )
            spec["tools"].append(
                {
                    "tool_spec": {
                        "type": "generic",
                        "name": name,
                        "description": item["description"]
                        + " Required request_json structure: "
                        + json_text(item["request_example"])
                        + ". Keep operation fields inside params and always include target_ids.",
                        "input_schema": {
                            "type": "object",
                            "properties": {
                                "request_json": {
                                    "type": "string",
                                    "description": "Encode this exact object structure as a JSON string: "
                                    + json_text(item["request_example"])
                                    + ". All operation-specific arguments belong inside params. target_ids is mandatory. At most 32768 UTF-8 bytes.",
                                }
                            },
                            "required": ["request_json"],
                        },
                    }
                }
            )
            spec["tool_resources"][name] = {
                "type": "procedure",
                "identifier": metadata + ".SP_AUTOMAP_" + suffix,
                "execution_environment": {
                    "type": "warehouse",
                    "warehouse": warehouse,
                    "query_timeout": 60,
                },
            }
        specs[kind] = spec
        (out / ("agent-" + kind + ".json")).write_text(
            json.dumps(spec, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
        )
        # Single-quoted SQL literal is escaped; do not interpolate a model or SQL
        # string into a shell invocation. The SQL itself is reviewable output.
        sql.append(
            f'CREATE AGENT {metadata}.{row["name"]} FROM SPECIFICATION {literal(json_text(spec))};'
        )
    sql.extend(
        [
            f'GRANT USAGE ON DATABASE {metadata.split(".")[0]} TO ROLE {role};',
            f"GRANT USAGE ON SCHEMA {metadata} TO ROLE {role};",
            f"GRANT USAGE ON WAREHOUSE {warehouse} TO ROLE {role};",
            f"GRANT SELECT,INSERT,UPDATE ON TABLE {metadata}.TBL_AUTOMAP_NATIVE_JOBS TO ROLE {role};",
            f"GRANT SELECT,UPDATE ON TABLE {metadata}.TBL_AUTOMAP_NATIVE_CONTROL TO ROLE {role};",
            f"GRANT SELECT,UPDATE ON TABLE {metadata}.TBL_AUTOMAP_NATIVE_ANALYST_SLOTS TO ROLE {role};",
            f"GRANT INSERT ON TABLE {metadata}.TBL_AUTOMAP_NATIVE_SOURCE_DOCUMENTS TO ROLE {role};",
            f"GRANT USAGE ON CORTEX SEARCH SERVICE {metadata}.CSS_AUTOMAP_SOURCE_COLUMNS_V2 TO ROLE {role};",
            f"GRANT CREATE VIEW ON SCHEMA {metadata} TO ROLE {role};",
        ]
    )
    for suffix in procedures:
        sql.append(
            f"GRANT USAGE ON PROCEDURE {metadata}.SP_AUTOMAP_{suffix}(VARCHAR) TO ROLE {role};"
        )
    for kind in specs:
        sql.append(
            f'GRANT USAGE ON AGENT {metadata}.{template[kind]["name"]} TO ROLE {role};'
        )
    sql.append(
        "-- Existing canonical FIR/Search/source SELECT and Cortex database roles remain required; no ownership or target DML is granted here."
    )
    (out / "install.sql").write_text("\n\n".join(sql) + "\n", encoding="utf-8")
    (out / "upload.txt").write_text(
        "Upload the runtime ZIP BEFORE install.sql. Content address: "
        + stage_file
        + "\n"
        + "Use the existing Snow CLI stage-copy command; overwrite must be disabled. Verify SHA256 "
        + runtime_hash
        + " before upload.\n",
        encoding="utf-8",
    )
    config = {
        "AUTOMAP_NATIVE_PERMIT_TABLE_FQN": metadata
        + ".TBL_AUTOMAP_NATIVE_MODEL_SLOTS_V1",
        "AUTOMAP_NATIVE_ARCHIVE_TABLE_FQN": metadata
        + ".TBL_AUTOMAP_NATIVE_MODEL_ARCHIVE_V1",
        "AUTOMAP_NATIVE_ACCOUNT_NAMESPACE": account_namespace
        or "<SET_CANONICAL_ORG.ACCOUNT>",
        "AUTOMAP_NATIVE_POOL_EPOCH": epoch,
        "AUTOMAP_NATIVE_POOL_CAPACITY": pool_capacity,
        "AUTOMAP_NATIVE_TOOLS_V1": False,
        "AUTOMAP_NATIVE_PROJECT_IDS": "501",
        "AUTOMAP_NATIVE_SOURCE_SPEC_SHA256": fingerprint(specs["source"]),
        "AUTOMAP_NATIVE_RULE_SPEC_SHA256": fingerprint(specs["rule"]),
        "AUTOMAP_NATIVE_BATCH_COUNT": 4,
        "AUTOMAP_NATIVE_MAX_TOOL_CALLS": 64,
        "AUTOMAP_NATIVE_WINDOW_TOOL_CALLS": 32,
        "AUTOMAP_NATIVE_MAX_WINDOWS": 2,
    }
    (out / "configuration.json").write_text(json.dumps(config, indent=2) + "\n")
    (out / "runtime-manifest.json").write_text(
        json.dumps(
            {
                "protocol": template["protocol"],
                "runtime_sha256": runtime_hash,
                "stage_import": stage_file,
                "pool_epoch": epoch,
                "pool_capacity": pool_capacity,
                "spec_sha256": {
                    kind: fingerprint(spec) for kind, spec in specs.items()
                },
                "note": "Compare GET agent_spec with these generated specs before pinning. Provider normalization may require pinning the verified GET representation.",
            },
            indent=2,
        )
        + "\n"
    )
    return {
        "output": str(out),
        "runtime_sha256": runtime_hash,
        "agent_spec_hashes": {kind: fingerprint(spec) for kind, spec in specs.items()},
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for field in ("metadata", "warehouse", "role", "stage", "output"):
        parser.add_argument("--" + field, required=True)
    parser.add_argument("--source-model")
    parser.add_argument("--rule-model")
    parser.add_argument("--account-namespace")
    parser.add_argument("--pool-capacity", type=int, default=8)
    args = parser.parse_args()
    print(json.dumps(render(**vars(args)), indent=2))


if __name__ == "__main__":
    main()
